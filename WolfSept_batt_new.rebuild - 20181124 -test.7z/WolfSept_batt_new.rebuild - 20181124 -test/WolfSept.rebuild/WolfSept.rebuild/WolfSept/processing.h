#ifndef PROCESSING_H
#define PROCESSING_H

#ifdef __cplusplus
extern "C" {
#endif

#include "databank.h"
#include "binarize.h"
#include "scanner.h"
#include "rigidmodel.h"
#include "decoder.h"


void FuncMemoryAlloc(void);

void FuncDataInit(void);

void FuncMemoryDestroy(void);

bool FuncProcessing(void);

void FuncInfoOutput(bool bIsSuccess);

#ifdef __cplusplus
}
#endif

#endif // PROCESSING_H
