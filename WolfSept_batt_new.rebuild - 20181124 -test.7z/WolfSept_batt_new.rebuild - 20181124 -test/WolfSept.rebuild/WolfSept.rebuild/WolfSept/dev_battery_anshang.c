﻿/********************************************************************************
* Copyright (C) 2025, JD.COM, Inc.
* All rights reserved.
* FileName    : dev_battery_anshang.c
* Author      : yyf   Version: V1.0   Data:2018-11-21
* Description : dev_battery_anshang.c
********************************************************************************/
#include "can.h"
#include "device.h"
#include "global_var.h"
#include "dev_battery_anshang.h"



#define ANSHANG_BMS_LOW_SINGLEVOL       3450

//#define DUMP_BATT_INFO_CYCLES	5		// 单位：秒

static uint32_t g_uReqCommand = 0;
static uint32_t g_uAckCommand = 0;
static bool s_bBatteryFull = FALSE;
extern int g_iNotReport3019;


/*******************************************************************************
* Function Name      : write_batt_summary_info
* Description	     : write battery summary info to battery.monitor.log.
* Input 		     : pBatCanData is the obtained data.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
static int write_batt_summary_info(batt_info_t *pBattInfo)
{
	float fVoltage = 0.0;
	float fCurrent = 0.0;

	fVoltage = ((float)pBattInfo->uVoltage) / 10.0;
	fCurrent = ((float)pBattInfo->uCurrent) / 10.0;
	LOG_BATTERY("battery temperature:[%dC],voltage:[%.2fV],current[%.2fA],battery:[act:%d%, mod:%d%],state:[%s]\n",
		pBattInfo->uTemp - TEMPER_BASE, fVoltage, fCurrent, g_stAgvAttr.iOriginalSocVal, pBattInfo->uSoc,
		((pBattInfo->uState == 1) ? "charging" : "not charging"));

	return 0;
}

/*******************************************************************************
*Function Name    :anshang_recv_bms_info
*Description      :CAN1记录电池BMS信息帧到队列中
*Input       	  :struct can_frame * pBatCanData
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int anshang_recv_bms_info(struct can_frame * pCanFrame)
{
	int iRet = 0;
	
	g_uAckCommand = g_uReqCommand;
	
	if (pCanFrame == NULL)
		return -1;
	
	iRet = linkqueue_append(g_stAgvParm.pBmsCanFrameQueue, pCanFrame, sizeof(struct can_frame));
	if (iRet < 0)
	{
		LOG_WRN("append can frame[0x%x] to pBmsCanFrameQueue failed\n", pCanFrame->can_id);
	}
	
	return 0;
}

/*******************************************************************************
*Function Name    :call_can1
*Description      :CAN1发送安尚电池概要信息查询帧
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int call_can1(struct can_frame *pBatCanReq,struct can_frame *pBatCanAck)
{
	int iCount = -1;
	int iRet = -1;
	int iTryCount = TRY_COUNT_LIMIT;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery error info can frame\n");
	print_can_frame(pBatCanReq);
#endif

	g_uReqCommand = BATT_REQ_CANID + g_stAgvAttr.bms.uInquiryCount;
	
	iCount = send_can(BATT_CAN_DEV, pBatCanReq);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}

	// 接收CAN查询应答
	while (iTryCount--)
	{
		iRet = linkqueue_retrieve(g_stAgvParm.pBmsCanFrameQueue, pBatCanAck);;
		if (iRet < 0)
		{
			usleep(500);
			continue;
		}
		if ( g_uReqCommand == g_uAckCommand)
		{
			iRet = 0;
			break;
		}
	}

	if (iTryCount <= 0)
	{
		return -2;
	}

#if(DEBUG_AGV == 333)
	LOG_INF("recv battery ack can frame\n");
	print_can_frame(pBatCanAck);
#endif

	return 0;
}

/*******************************************************************************
*Function Name    :inquiry_bms_summary_info
*Description      :CAN1发送安尚电池概要信息查询帧
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int inquiry_bms_summary_info(batt_info_t *pBattInfo)
{
	int iRet = 0;
	struct can_frame stBatCanReq = { 0 };
	struct can_frame stBatCanAck = { 0 };

	if (pBattInfo == NULL)
		return -1;

	// 发送CAN查询请求
	// DATA[8]= 16 BB XX XX XX XX XX 7E
	stBatCanReq.can_id = BATT_REQ_CANID;
	stBatCanReq.can_dlc = 8;
	stBatCanReq.data[0] = 0x16;
	stBatCanReq.data[1] = 0xBB;
	stBatCanReq.data[7] = 0x7E;

	iRet = call_can1(&stBatCanReq, &stBatCanAck);
	if(iRet < 0)
	{
		return -2;
	}

	// 解析CAN查询应答
	pBattInfo->uVoltage = htons(*(int16_t *)(&stBatCanAck.data[0]));		// 字节0,1
	pBattInfo->uCurrent = htons(*(int16_t *)(&stBatCanAck.data[2]));		// 字节2,3
	pBattInfo->uSocOrg = stBatCanAck.data[4];					// 字节4
	pBattInfo->uSocModified = stBatCanAck.data[4];					// 字节4
	pBattInfo->uTemp = stBatCanAck.data[5];					// 字节5
	pBattInfo->uState = stBatCanAck.data[6];				// 字节6
	pBattInfo->uCellNum = stBatCanAck.data[7];				// 字节7

	return 0;
}

/*******************************************************************************
*Function Name    :inquiry_bms_cell_info
*Description      :CAN1发送安尚电池单体信息查询帧
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int inquiry_bms_cell_info(batt_info_t *pBattInfo)
{
	int iTryCount = TRY_COUNT_LIMIT;
	int iRet = 0;
	int iCellGrpIdx = 0;
	uint8_t uData = 0;
	struct can_frame stBatCanReq = { 0 };
	struct can_frame stBatCanAck = { 0 };
	int iCount = -1;

	if (pBattInfo == NULL)
		return -1;

	// 发送CAN查询请求
	// DATA[8]= 16 C1 XX XX XX XX XX 7E---Cell[01-04]
	// DATA[8]= 16 C2 XX XX XX XX XX 7E---Cell[05-08]
	// DATA[8]= 16 C3 XX XX XX XX XX 7E---Cell[09-12]
	// DATA[8]= 16 C4 XX XX XX XX XX 7E---Cell[13-16]
	// DATA[8]= 16 C5 XX XX XX XX XX 7E---Cell[17-20]
	// DATA[8]= 16 C6 XX XX XX XX XX 7E---Cell[21-24]
	// DATA[8]= 16 C7 XX XX XX XX XX 7E---Cell[25-28]
	// DATA[8]= 16 C8 XX XX XX XX XX 7E---Cell[29-32]

	for (iCellGrpIdx = 0; iCellGrpIdx < BATT_CELL_NUM / 4; iCellGrpIdx++)
	{
		uData = 0xC1 + iCellGrpIdx;

		stBatCanReq.can_id = BATT_REQ_CANID;
		stBatCanReq.can_dlc = 8;
		stBatCanReq.data[0] = 0x16;
		stBatCanReq.data[1] = uData;
		stBatCanReq.data[7] = 0x7E;

		iRet = call_can1(&stBatCanReq, &stBatCanAck);
		if(iRet < 0)
		{
			return -2;
		}

		// 解析CAN查询应答
		pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 0] = htons(*(int16_t *)(&stBatCanAck.data[0]));		// 字节0,1
		pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 1] = htons(*(int16_t *)(&stBatCanAck.data[2]));		// 字节2,3
		pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 2] = htons(*(int16_t *)(&stBatCanAck.data[4]));		// 字节4,5
		pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 3] = htons(*(int16_t *)(&stBatCanAck.data[6]));	// 字节6,7

		if ((pBattInfo->uInquiryCount % DUMP_BATT_INFO_CYCLES) == 0)
		{
			LOG_BATTERY("battery cell group[%d]'voltage:%4d, %4d, %4d, %4d mV\n",
				iCellGrpIdx,
				pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 0],
				pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 1],
				pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 2],
				pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 3]);
		}
	}

	if (pBattInfo->iBattVersion == 0)
	{
		if ((pBattInfo->iBattCellVolt[0] == 0) && (pBattInfo->iBattCellVolt[1] == 0) && (pBattInfo->iBattCellVolt[2] == 0) && (pBattInfo->iBattCellVolt[3] != 0))
		{
			pBattInfo->iBattVersion = ANSHANG_BMS_TYPE_GREEN;
		}
		else if (pBattInfo->iBattCellVolt[0] && pBattInfo->iBattCellVolt[1] && pBattInfo->iBattCellVolt[2] && pBattInfo->iBattCellVolt[3])
		{
			pBattInfo->iBattVersion = ANSHANG_BMS_TYPE_BLUE;
		}
		else
		{
			LOG_WRN("Init the anshang bms type failed\n");
			return -3;
		}
	}

	return 0;
}

/*******************************************************************************
*Function Name    :inquiry_bms_fault_info
*Description      :CAN1发送安尚电池故障信息查询帧
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int inquiry_bms_fault_info(batt_info_t *pBattInfo)
{	
	int iRet = 0;
	struct can_frame stBatCanReq = { 0 };
	struct can_frame stBatCanAck = { 0 };

	if (pBattInfo == NULL)
		return -1;

	// 发送CAN查询请求
	// DATA[8]= 16 BE XX XX XX XX XX 7E
	stBatCanReq.can_id = BATT_REQ_CANID;
	stBatCanReq.can_dlc = 8;
	stBatCanReq.data[0] = 0x16;
	stBatCanReq.data[1] = 0xBE;
	stBatCanReq.data[7] = 0x7E;

	iRet = call_can1(&stBatCanReq, &stBatCanAck);
	if(iRet < 0)
	{
		return -2;
	}

	int16_t iVState = htons((int16_t)stBatCanAck.data[0]);	// 字节0,1
	int16_t iCState = htons((int16_t)stBatCanAck.data[2]);	// 字节2,3
	int16_t iTState = htons((int16_t)stBatCanAck.data[4]);	// 字节4,5
	int8_t iFETState = stBatCanAck.data[6];					// 字节6
	int8_t iAlarm = stBatCanAck.data[7];					// 字节7

	if ((pBattInfo->uInquiryCount % DUMP_BATT_INFO_CYCLES) == 0)
	{
		LOG_BATTERY("battery fault:iVState=0x%04x, iCState=0x%04x, iTState=0x%04x, iFETState=0x%02x, iAlarm=0x%02x\n",
			iVState, iCState, iTState, iFETState, iAlarm);
	}

	if ((pBattInfo->iVState == iVState) && (pBattInfo->iCState == iCState)
		&& (pBattInfo->iTState == iTState) && (pBattInfo->iFETState == iFETState)
		&& (pBattInfo->iAlarm == iAlarm) && (pBattInfo->iPreVoltDiffProtectUser == pBattInfo->iVoltDiffProtectUser))
	{
		return -1;
	}

	LOG_WRN("battery fault info:iVState.............[0x%04x-->0x%04x]\n", pBattInfo->iVState, iVState);
	LOG_WRN("battery fault info:iCState.............[0x%04x-->0x%04x]\n", pBattInfo->iCState, iCState);
	LOG_WRN("battery fault info:iTState.............[0x%04x-->0x%04x]\n", pBattInfo->iTState, iTState);
	LOG_WRN("battery fault info:iFETState...........[0x%04x-->0x%04x]\n", pBattInfo->iFETState, iFETState);
	LOG_WRN("battery fault info:iAlarm..............[0x%04x-->0x%04x]\n", pBattInfo->iAlarm, iAlarm);
	LOG_WRN("battery fault info:VoltDiffProtectUser.[0x%04x-->0x%04x]\n", pBattInfo->iPreVoltDiffProtectUser, pBattInfo->iVoltDiffProtectUser);

	pBattInfo->iVState = iVState;
	pBattInfo->iCState = iCState;
	pBattInfo->iTState = iTState;
	pBattInfo->iFETState = iFETState;
	pBattInfo->iAlarm = iAlarm;

	if (pBattInfo->iBattVersion == ANSHANG_BMS_TYPE_GREEN)
	{
		// iVState
		pBattInfo->iBattCellOverVolt = iVState & 0x0001;
		pBattInfo->iBattCellUnderVolt = iVState & 0x0002;
		pBattInfo->iBattGroupOverVolt = iVState & 0x0004;
		pBattInfo->iBattGroupUnderVolt = iVState & 0x0008;
		pBattInfo->iBattCellOverVoltWarn = iVState & 0x0010;
		pBattInfo->iBattCellUnderVoltWarn = iVState & 0x0020;
		pBattInfo->iBattGroupOverVoltWarn = iVState & 0x0040;
		pBattInfo->iBattGroupUnderVoltWarn = iVState & 0x0080;
		pBattInfo->iVoltDiffProtectSys = iVState & 0x0100;
		pBattInfo->iCommBreak = iVState & 0x0200;
		pBattInfo->iLowVoltProhibitCharge = iVState & 0x0400;
		// iCState
		pBattInfo->iChargeStateFault = iCState & 0x0001;
		pBattInfo->iDischargeStateFault = iCState & 0x0002;
		pBattInfo->iChargeOverCurrProtection = iCState & 0x0004;
		pBattInfo->iShortCircuitProtection = iCState & 0x0008;
		pBattInfo->iDischargeOverCurrL1 = iCState & 0x0010;
		pBattInfo->iDischargeOverCurrL2 = iCState & 0x0020;
		pBattInfo->iChargeOverCurrWarn = iCState & 0x0040;
		pBattInfo->iDischargeOverCurrWarn = iCState & 0x0080;
		// iTState
		pBattInfo->iChargeOverTempProtection = iTState & 0x0001;
		pBattInfo->iChargeUnderTempProtection = iTState & 0x0002;
		pBattInfo->iDischargeOverTempProtection = iTState & 0x0004;
		pBattInfo->iDischargeUnderTempProtection = iTState & 0x0008;
		pBattInfo->iEnvOverTempProtection = iTState & 0x0010;
		pBattInfo->iEnvUnderTempProtection = iTState & 0x0020;
		pBattInfo->iPowerOverTempProtection = iTState & 0x0040;
		pBattInfo->iPowerUnderTempProtection = iTState & 0x0080;
		pBattInfo->iBattCellOverTempWarn = iTState & 0x0100;
		pBattInfo->iBattCellUnderTempWarn = iTState & 0x0200;
		pBattInfo->iEnvOverTempWarn = iTState & 0x0400;
		pBattInfo->iEnvUnderTempWarn = iTState & 0x0800;
		pBattInfo->iPowerOverTempWarn = iTState & 0x1000;
		pBattInfo->iPowerUnderTempWarn = iTState & 0x2000;
	}
	else if (pBattInfo->iBattVersion == ANSHANG_BMS_TYPE_BLUE)
	{
		pBattInfo->iHighVolProtect = stBatCanAck.data[0] & 0x0001;
		pBattInfo->iLowVolProtect = stBatCanAck.data[1] & 0x0001;
		pBattInfo->iOffLineProtect = stBatCanAck.data[2] & 0x0001;
		pBattInfo->iChargeOverCurrent = stBatCanAck.data[3] & 0x0001;
		pBattInfo->iDischargeOverCurrent = stBatCanAck.data[4] & 0x0001;
		pBattInfo->iShortCircuitPortect = stBatCanAck.data[5] & 0x0001;
		pBattInfo->iHighTemPortect = stBatCanAck.data[6] & 0x0001;
		pBattInfo->iLowTemPortect = stBatCanAck.data[7] & 0x0001;
	}
	else
	{
		return -1;
	}

	return 1;
}

/*******************************************************************************
*Function Name    :anshang_inquiry_bms_info
*Description      :查询安尚电池信息
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int anshang_inquiry_bms_info(batt_info_t *pBattInfo)
{
	int iRet = 0;
	
	if(pBattInfo == NULL)
	{
		return -1;
	}
	
	iRet = inquiry_bms_summary_info(pBattInfo);
	if(iRet < 0)
	{
		return iRet;
	}
	
	iRet = inquiry_bms_cell_info(pBattInfo);
	if(iRet < 0)
	{
		return iRet;
	}
	
	iRet = inquiry_bms_fault_info(pBattInfo);
	if(iRet < 0)
	{
		return iRet;
	}
	
	return 0;
}

static int calc_cell_max_and_min_voltage(batt_info_t *pBattInfo)
{
	int i = 0;
	int16_t iBattCellVolt = 0;
	int16_t iTmpVoltMax	= 0;	// 单体电压的最大值
	int16_t iTmpVoltMin = 0;	// 单体电压的最小值
	int16_t iVoltDiff = 0;
	int16_t	*pBattCellVoltArray = NULL;

	if (pBattInfo == NULL)
	{
		return -1;
	}

	pBattCellVoltArray = pBattInfo->iBattCellVolt;
	
	// 避免绿版电池前面为0,无法判断单体电压最小值
	iTmpVoltMax = pBattCellVoltArray[8];
	iTmpVoltMin = pBattCellVoltArray[8];

	for (i = 1; i < BATT_CELL_NUM; i++)
	{
		iBattCellVolt = pBattCellVoltArray[i];

		if (iBattCellVolt == 0)
			continue;

		if (iBattCellVolt > iTmpVoltMax)
		{
			iTmpVoltMax = iBattCellVolt;
		}
		else if (iBattCellVolt < iTmpVoltMin)
		{
			iTmpVoltMin = iBattCellVolt;
		}
	}

	pBattInfo->iBattCellVoltMax = iTmpVoltMax;
	pBattInfo->iBattCellVoltMin = iTmpVoltMin;
	pBattInfo->iBattCellVoltDelt = iTmpVoltMax - iTmpVoltMin;
	
	return 0;
}

/*******************************************************************************
*Function Name    anshang_update_bms_info
*Description      :监测/校准安尚电池电量,主要用于上报控制台
*Input       	  :bat_info_t * pBattInfo
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int anshang_update_bms_info(batt_info_t *pBattInfo)
{
	int iRet = 0;
	
	if (pBattInfo == NULL)
	{
		return -1;
	}

	iRet = calc_cell_max_and_min_voltage(pBattInfo);
	
	//1.单体电压值超出正常范围
	if ((pBattInfo->iBattCellVoltMin <= ANSHANG_BMS_MIN_SINGLEVOL ) || (pBattInfo->iBattCellVoltMax >= ANSHANG_BMS_MAX_SINGLEVOL))
	{
		LOG_WRN("The single vol is invalid-iTmpVoltMin[%d] iTmpVoltMax[%d]\n", pBattInfo->iBattCellVoltMin, pBattInfo->iBattCellVoltMax);
		pBattInfo->iVoltDiffProtectUser = 0;
		pBattInfo->iPreVoltDiffProtectUser = 0;
		return -2;
	}

	//2.单体电压的（最大值 - 最小值）超过300mv，则需进行压差保护异常上报
	if (pBattInfo->iBattCellVoltDelt >= MAX_VOLT_DIFF)
	{
		LOG_INF("battery cell voltage : max[%d]mv, min[%d]mv, diff[%d]mv > %dmv, set iVoltDiffProtect == TRUE\n",
			pBattInfo->iBattCellVoltMax, pBattInfo->iBattCellVoltMin, pBattInfo->iBattCellVoltDelt, MAX_VOLT_DIFF);
		pBattInfo->iPreVoltDiffProtectUser = pBattInfo->iVoltDiffProtectUser;
		pBattInfo->iVoltDiffProtectUser = 0x0100;
	}
	else
	{
		pBattInfo->iPreVoltDiffProtectUser = pBattInfo->iVoltDiffProtectUser;
		pBattInfo->iVoltDiffProtectUser = 0;
	}

	// 3. 单体电压最小于ANSHANG_BMS_LOW_SINGLEVOL（3450mv）电量置成29%，由控制台调度充电
	if (pBattInfo->iBattCellVoltMin < ANSHANG_BMS_LOW_SINGLEVOL)
	{
		if (pBattInfo->iMoidfySocFlag == FALSE)
		{
			LOG_INF("the min voltage[%d]mv of all battery cell < [%d]mv, then correct soc to %d\n",
				pBattInfo->iBattCellVoltMin, ANSHANG_BMS_LOW_SINGLEVOL, ANSHANG_BMS_LOW_SOC_29);
		}

		pBattInfo->iMoidfySocFlag = TRUE;
		pBattInfo->uSocModified = ANSHANG_BMS_LOW_SOC_29;	
	}
	else
	{
		pBattInfo->iMoidfySocFlag = FALSE;
	}

	//4.电池充电完成后，判断电量是否小于60%
	if ((true == s_bBatteryFull) &&(g_stAgvAttr.iMoveStatus == agv_charge)&& (BATT_STATE_CHARGING != pBattInfo->uState))
	{
		if (pBattInfo->uSocOrg >= BATTERY_CHARGE_SOC_60) //电池充电保护状态，电量校准到100%，以便控制台调度小车离开
		{
			LOG_INF("during charging, correct battery'soc:[%d->%d] when soc is incorrect\n", pBattInfo->uSocOrg, BATTERY_CHARGE_SOC_100);
			g_stAgvAttr.iOriginalSocVal = pBattInfo->uSocOrg;
			pBattInfo->uSocOrg = BATTERY_CHARGE_SOC_100;
		}
	}

	return 0;
}

/*******************************************************************************
*Function Name    :calibrate_battery
*Description      : by tiger.89
*Input       	  :bat_info_t * pBattery
*Output 		  :
*Return           :int:1:calibrate finish
0:on calibrating,
-1: need not calibrate,
-2:calibrate timeout
*******************************************************************************/
static int calibrate_battery(batt_info_t *pBattery, int iCalibrationPeriod)
{
	if (NULL == pBattery || iCalibrationPeriod <= 0)
	{
		return NEED_NOT_CALIBRATION;
	}

	int iCalibrationTime = (pBattery->uCalibrateTime)*iCalibrationPeriod;

	if (pBattery->uVoltage < CALIBRATE_VOLTAGE_V)
	{
		LOG_INF("need not wait calibrate battery,for battery voltage = %dV \n", pBattery->uVoltage / 10);
		pBattery->uCalibrateTime = 0;
		return NEED_NOT_CALIBRATION;
	}

	if (pBattery->uSoc >= CALIBRATION_FINISH_SOC)
	{
		LOG_INF("calibrate battery finish,for battery voltage = %dV Soc = %d ,calibation_time = %d\n",
			pBattery->uVoltage / 10, pBattery->uSoc, iCalibrationTime);
		pBattery->uCalibrateTime = 0;
		return CALIBRATION_FINISHED;
	}

	if (++pBattery->uCalibrateTime > CALIBRATION_SECONDS / iCalibrationPeriod)
	{
		LOG_INF("calibrate battery timeout,for %ds\n", iCalibrationTime);
		pBattery->uCalibrateTime = 0;
		return CALIBRATION_TIMEOUT;
	}

	LOG_INF("calibrating battery ,for %ds\n", iCalibrationTime);
	return CALIBRATING;

}

/*******************************************************************************
*Function Name    :query_charge_status
*Description      : query charge status 2 times
*Input       	  :bat_info_t * pBattery
*Output 		  :
*Return           :int:1:calibrate finish
0:on calibrating,
-1: need not calibrate,
-2:calibrate timeout
*******************************************************************************/
static int query_charge_status(struct bat_info *pBattInfo)
{
	static int iLowChargeCurCount = 0;
	static int iRetryChargeCount = 0;
	int iRet = -1;

	iLowChargeCurCount++;

	if (iLowChargeCurCount >= LOW_CHARGE_CUR_COUNT)
	{
		LOG_WRN("battery charging failure, stop charging, trytime=%d\n", iLowChargeCurCount);
		write_batt_summary_info(pBattInfo);
		iLowChargeCurCount = 0;

		iRet = stop_charge();
		if (iRet < 0)
		{
			return iRet;
		}
		if (g_stAgvAttr.iStopChargeConflict == TRUE)
		{
			g_stAgvAttr.iStopChargeConflict = FALSE;
			LOG_WRN("Filter the EVENT_ERR_CHARGECURSAMLL and stop to retry when the stop charge conflict\n");
			return iRet;
		}

		if (iRetryChargeCount < RETRY_CHARGE_TIMES )
		{
			LOG_INF("detect 3010-EVENT_ERR_CHARGECURSAMLL,start change again\n");
			iRet = start_charge();
			if (iRet != OK)
			{
				if (BERROR == iRet)
				{
					send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_PARKPRECISION);
				}
				return iRet;
			}
			iRetryChargeCount++;
			LOG_INF("%dth start change by MM2.0 success\n",iRetryChargeCount);					
		}
		else
		{
			iRetryChargeCount = 0;
			iRet = 0;

		}			
	}
	return iRet;
}

/*******************************************************************************
* Function Name      : anshang_check_charge_status_every_five_minutes
* Description	     : anshang check charge status every five minutes.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int check_charge_status_period(batt_info_t *pBattInfo, int iPeriod)
{
	static int iParseChargeInfoCount = 0;
	static int iPreFiveMinuteSoc = 0;
	static float fPreFiveMinuteVol = 0;
	static float fPreFiveMinuteCur = 0;

	int iRet = 0;
	float fVoltage = 0.0f;
	float fCurrent = 0.0f;

	if (NULL == pBattInfo)
	{
		return -1;
	}

	if ((pBattInfo->uState == BATT_STATE_CHARGING) && (agv_charge == g_stAgvAttr.iMoveStatus))
	{
		iParseChargeInfoCount++;
		if (iParseChargeInfoCount == 1)
		{
			iPreFiveMinuteSoc = pBattInfo->uSoc;
			fPreFiveMinuteVol = (float)pBattInfo->uVoltage / 10.0;
			fPreFiveMinuteCur = (float)pBattInfo->uCurrent / 10.0;
		}

		if (0 == (iParseChargeInfoCount % iPeriod))
		{
			iParseChargeInfoCount = 0;
			fVoltage = (float)pBattInfo->uVoltage / 10;
			fCurrent = (float)pBattInfo->uCurrent / 10;

			if (((pBattInfo->uSoc - iPreFiveMinuteSoc) < 1) && ((fVoltage - fPreFiveMinuteVol) < 0.1f) && (fCurrent < 0.2f))
			{
				LOG_WRN("EVENT_ERR_CHARGECURSAMLL[3010]-SOC:[%d-->%d], Volt:[%.2f-->%.2f]V, Current:[%.2f-->%.2f]A\n",
					iPreFiveMinuteSoc, pBattInfo->uSoc, fPreFiveMinuteVol, fVoltage, fPreFiveMinuteCur, fCurrent);
				return -3010;
			}
		}
	}
	else
	{
		iParseChargeInfoCount = 0;
		iPreFiveMinuteSoc = 0;
		fPreFiveMinuteVol = 0.0;
		fPreFiveMinuteCur = 0.0;
	}

	return iRet;
}

/*******************************************************************************
*Function Name    :anshang_batt_exception_handle
*Description      :电池信息异常处理
*Input       	  :bat_info_t * pBattInfo
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int anshang_bms_info_exception_handle(batt_info_t *pBattInfo)
{
	int iRet = -1;
	float fVoltage = 0.0f;
	static bool s_bCurSmallErr = FALSE;
	static time_t s_iStartCalTime = 0;
	time_t iCurCalTime = 0;

	if (g_stAgvAttr.iMoveStatus == agv_charge) //控制台为充电任务状态
	{
		if (pBattInfo->uState != BATT_STATE_CHARGING)  //电池处于非充电状态
		{
			g_stAgvAttr.iStopChargeFromMM = TRUE; //控制台为充电状态

			//1.充电时尝试充电2次
			if ((BATTERY_CHARGE_SOC_100 != pBattInfo->uSocOrg))
			{
				LOG_INF("query_charge_status\n");
				iRet = query_charge_status(pBattInfo);
				if (0 == iRet)
				{
					s_bCurSmallErr = true;
					LOG_INF("s_bCurSmallErr = true\n");
				}
			}
		}
		else   //电池处于充电状态
		{
			//2. 安尚电池，充电状态下，每五分钟检查一次充电状态
			iRet = check_charge_status_period(pBattInfo,300);
			if(-3010 == iRet)
			{
				send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CHARGECURSAMLL);    //上报3010错误				
			}
		}
	}
	else
	{
		//3.控制台不在充电状态，标志为置为false
		s_bBatteryFull = false;

		//4.电池充电完成后，判断电量是否小于60%
		if ((true == s_bBatteryFull) && (BATT_STATE_CHARGING != pBattInfo->uState))
		{
			if (pBattInfo->uVoltage > CALIBRATE_VOLTAGE_V && pBattInfo->uSoc < BATTERY_CHARGE_SOC_60)
			{
				fVoltage = (float)pBattInfo->uVoltage / 10.0;
				LOG_WRN("3010-EVENT_ERR_BMS_SOC_DISTORTION: fVoltage[act:%.2fV, exp:%.2fV, Soc[act:%3d%, exp:%3d%\n",
					fVoltage, CALIBRATE_VOLTAGE_V / 10.0f, pBattInfo->uSoc, BATTERY_CHARGE_SOC_60);
				send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CHARGECURSAMLL);   //上报3010错误
			}
		}
	}

	//5. 停止充电校准
	if (true == s_bCurSmallErr)
	{
		iRet = calibrate_battery(pBattInfo, 1);
		if (iRet == CALIBRATION_FINISHED)
		{
			s_bCurSmallErr = false;
		}
		else if (iRet == CALIBRATION_TIMEOUT)
		{
			s_bCurSmallErr = false;
			s_bBatteryFull = true;
		}
		else if (iRet == NEED_NOT_CALIBRATION)
		{
			s_bCurSmallErr = false;
			LOG_WRN("battery charging failure, send error msg[%d-%s] to console\n",
				EVENT_ERR_CHARGECURSAMLL, get_err_str(EVENT_ERR_CHARGECURSAMLL));
			send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CHARGECURSAMLL);
		}
		else
		{
			LOG_INF("keep on  calibratint battery\n");
		}
	}
		
	// start add by tiger.102
	// 在(TRUE == g_stAgvInfo.stBatInfo.uNeedCheckSoc)成立的情况下
	// 权衡策略一:在上次充电1.5小时电量仍未到80%时, 多次重启都会上报3057(当前使用的策略)，除非手电充电到80%以上
	// 权衡策略二:在上次充电1.5小时电量仍未到80%时, 有且只有在第一次重启时会上报3057
	if (TRUE == pBattInfo->uNeedCheckSoc)
	{
		// g_stAgvInfo.stBatInfo.uNeedCheckSoc只可能在重启后,通过配置文件加载更新
		pBattInfo->uNeedCheckSoc = FALSE;
		if (pBattInfo->uSoc < CHARGE_HOURS_1_5_SOC)
		{
			LOG_ERR("batt'soc[%d] < expect[%d] when charge time > 1.5h at reboot\n",
				pBattInfo->uSoc, CHARGE_HOURS_1_5_SOC);
			anshang_dump_bms_info(pBattInfo);//dump bat info
			send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_NEED_OFFLINE);
		}
		else
		{
			set_check_soc_flag("0");
		}
	}

	if ((agv_charge == g_stAgvAttr.iMoveStatus) &&
		(BATT_STATE_CHARGING == pBattInfo->uState)
		&& (pBattInfo->uSoc < CHARGE_HOURS_1_5_SOC))
	{
		time(&iCurCalTime);
		// 记录开始充电时间，以便判断充电时间是否超过预设值（默认：1.5小时）
		// 如果(0 == s_iStartCalTime) : 表示未记录过开始充电时间
		// 如果(0 != s_iStartCalTime) : 保持不变即可
		(0 == s_iStartCalTime) ? (s_iStartCalTime = iCurCalTime) : (s_iStartCalTime = s_iStartCalTime);//save charge start time
		if (iCurCalTime - s_iStartCalTime >= HOURS_1_5)
		{
			set_check_soc_flag("1");
			g_iNotReport3019 = TRUE;
			iRet = stop_charge();
			if (iRet < 0)
			{
				g_iNotReport3019 = FALSE;
				return iRet;
			}
			g_iNotReport3019 = FALSE;

			LOG_ERR("batt'soc[%d] < expect[%d] when charge time > 1.5h, then send error msg\n",
				pBattInfo->uSoc, CHARGE_HOURS_1_5_SOC);
			anshang_dump_bms_info(pBattInfo);//dump bat info
			send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHECK_FAILED);
		}
	}
	else
		s_iStartCalTime = 0;
		
	return 0;
}

/*******************************************************************************
*Function Name    anshang_commit_bms_info
*Description      :电池信息异常处理
*Input       	  :bat_info_t * pBattInfo
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int anshang_commit_bms_info(batt_info_t *pBattInfo)
{
	if (pBattInfo == NULL)
	{
		return -1;
	}

	// 检查是否存在电池上报故障, 如果有则上报控制台以及记录日志
	if (pBattInfo->iBattVersion == ANSHANG_BMS_TYPE_GREEN)
	{
		// 电池故障:压差保护/电压不平衡
		if (pBattInfo->iVoltDiffProtectSys != 0)
		{
			LOG_ERR("Green BMS Exception Anshang:voltage diff protect in system\n");
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_VOLDISBALANCE);//by tiger.102
		}

		// 电池故障:压差保护/电压不平衡
		if ((pBattInfo->iVoltDiffProtectUser != 0) && (pBattInfo->iPreVoltDiffProtectUser != pBattInfo->iVoltDiffProtectUser))
		{
			LOG_ERR("Green BMS Exception Anshang:voltage diff protect in user mode\n");
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_VOLDISBALANCE);//by tiger.102
		}
		// 电池故障:放电过温告警及过温保护
		if ((pBattInfo->iDischargeOverTempProtection != 0) ||
			(pBattInfo->iDischargeOverTempWarn != 0))
		{
			LOG_ERR("Green BMS Exception Anshang:over temperture warn/protect\n");
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERTEMP);//by tiger.102
		}
		// 电池故障:充电欠温告警及欠温保护
		if ((pBattInfo->iChargeOverTempProtection != 0) ||
			(pBattInfo->iChargeOverTempWarn != 0))
		{
			LOG_ERR("Green BMS Exception Anshang:over temperture protect\n");
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEOVERTEMP);//by tiger.102
		}
		// 电池故障:充电过压告警及过压保护
		if ((pBattInfo->iBattCellOverVolt != 0) ||
			(pBattInfo->iBattGroupOverVolt != 0) ||
			(pBattInfo->iBattCellOverVoltWarn != 0) ||
			(pBattInfo->iBattGroupOverVoltWarn != 0))
		{
			LOG_ERR("Green BMS Exception Anshang:over voltage warn/protect\n");
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERVOL);//by tiger.102
		}
		// 电池故障:放电过压告警及过压保护
		if ((pBattInfo->iDischargeOverVoltProtection != 0) ||
			(pBattInfo->iBattCellOverVolt != 0) ||
			(pBattInfo->iBattGroupOverVolt != 0) ||
			(pBattInfo->iBattCellOverVoltWarn != 0) ||
			(pBattInfo->iBattGroupOverVoltWarn != 0))
		{
			LOG_ERR("Green BMS Exception Anshang:over voltage warn/protect\n");
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEOVERVOL);//by tiger.102
		}

		// 电池故障:放电过流告警及过流保护
		if ((pBattInfo->iDischargeOverCurrFlag != 0) ||
			(pBattInfo->iDischargeOverCurrProtection != 0) ||
			(pBattInfo->iDischargeOverCurrL1 != 0) ||
			(pBattInfo->iDischargeOverCurrL2 != 0))
		{
			LOG_ERR("Green BMS Exception Anshang:discharge over current warn/protect\n");
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERCUR);//by tiger.102
		}
		// 电池故障:放电过流告警及过流保护
		if ((pBattInfo->iDischargeOverCurrFlag != 0) ||
			(pBattInfo->iDischargeOverCurrProtection != 0) ||
			(pBattInfo->iDischargeOverCurrL1 != 0) ||
			(pBattInfo->iDischargeOverCurrL2 != 0))
		{
			LOG_ERR("Green BMS Exception Anshang:discharge over current warn/protect\n");
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERCUR);//by tiger.102
		}
		// 电池故障:充电异常
		if (pBattInfo->iChargeStateFault != 0)
		{
			LOG_ERR("Green BMS Exception Anshang:charge error\n");
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEERR);//by tiger.102
		}
	}
	else
	{
		if (pBattInfo->iHighVolProtect != 0)
		{
			LOG_ERR("Blue BMS Exception Anshang:high voltage protect\n");
		}

		if (pBattInfo->iLowVolProtect != 0)
		{
			LOG_ERR("Blue BMS Exception Anshang:low voltage protect\n");
		}

		if (pBattInfo->iOffLineProtect != 0)
		{
			LOG_ERR("Blue BMS Exception Anshang:offline protect\n");
		}

		if (pBattInfo->iChargeOverCurrent != 0)
		{
			LOG_ERR("Blue BMS Exception Anshang:charge over-current\n");
		}

		if (pBattInfo->iDischargeOverCurrent != 0)
		{
			LOG_ERR("Blue BMS Exception Anshang:discharge over-current\n");
		}

		if (pBattInfo->iShortCircuitPortect != 0)
		{
			LOG_ERR("Green BMS Exception Anshang:short circuit protect\n");
		}

		if (pBattInfo->iHighTemPortect != 0)
		{
			LOG_ERR("Blue BMS Exception Anshang:high temperature protect\n");
		}

		if (pBattInfo->iLowTemPortect != 0)
		{
			LOG_ERR("Blue BMS Exception Anshang:low temperature protect\n");
		}

		if (pBattInfo->iVoltDiffProtectUser != 0)
		{
			LOG_ERR("Blue BMS Exception Anshang:voltage diff protect in user mode\n");
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_VOLDISBALANCE);
		}
	}

	return 0;
}

/*******************************************************************************
* Function Name      : anshang_dump_bms_info
* Description	     : print all information from battery bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int anshang_dump_bms_info(batt_info_t *pBattInfo)
{
	int i = 0;
	
	if (pBattInfo == NULL)
	{
		return -1;
	}
	
	LOG_INF("battery base information\n");
	LOG_INF("iBattManufactor               : %s\n", get_manufactor_desc(pBattInfo->iBattManufactor));//add by jxu 20181017
	LOG_INF("iBattVersion                  : %d\n", pBattInfo->iBattVersion);//add by jxu 20181017
	LOG_INF("uVoltage                      : %.2f V\n", (float)pBattInfo->uVoltage / 10.0);
	LOG_INF("uCurrent                      : %.2f A\n", (float)pBattInfo->uCurrent / 10.0);
	LOG_INF("uSoc                          : %d\n", pBattInfo->uSoc);
	LOG_INF("uTemperature                  : %d\n", pBattInfo->uTemp - TEMPER_BASE);
	LOG_INF("uState                        : %d\n", pBattInfo->uState);
	LOG_INF("uCellNum                      : %d\n", pBattInfo->uCellNum);

	LOG_INF("battery cell information\n");
	for (i = 0; i < BATT_CELL_NUM; i++)
	{
		LOG_INF("iBattCellVolt[%02d]             : %5d mv\n", i, pBattInfo->iBattCellVolt[i]);
	}
	LOG_INF("iBattCellVoltMax              : %5d mv\n", pBattInfo->iBattCellVoltMax);
	LOG_INF("iBattCellVoltMin              : %5d mv\n", pBattInfo->iBattCellVoltMin);
	LOG_INF("iBattCellVoltDelta            : %5d mv\n", pBattInfo->iBattCellVoltMax - pBattInfo->iBattCellVoltMin);


	if (pBattInfo->iBattVersion == ANSHANG_BMS_TYPE_GREEN)
	{
		LOG_INF("green BMS:battery fault information\n");

		LOG_INF("iVoltDiffProtectSys           : 0x%04x\n", pBattInfo->iVoltDiffProtectSys);
		LOG_INF("iVoltDiffProtectUser          : 0x%04x\n", pBattInfo->iVoltDiffProtectUser);
		LOG_INF("iDischargeUnderVolt           : 0x%04x\n", pBattInfo->iDischargeUnderVolt);
		LOG_INF("iChargeUnderVolt              : 0x%04x\n", pBattInfo->iChargeUnderVolt);
		LOG_INF("iBatteryFullFlag              : 0x%04x\n", pBattInfo->iBatteryFullFlag);
		LOG_INF("iBatteryCapacityLowFlag       : 0x%04x\n", pBattInfo->iBatteryCapacityLowFlag);

		LOG_INF("iDischargeOverCurrFlag        : 0x%04x\n", pBattInfo->iDischargeOverCurrFlag);
		LOG_INF("iChargeFaultFlag              : 0x%04x\n", pBattInfo->iChargeFaultFlag);
		LOG_INF("iDischargeOverVoltProtection  : 0x%04x\n", pBattInfo->iDischargeOverVoltProtection);
		LOG_INF("iDischargeUnderVoltProtection : 0x%04x\n", pBattInfo->iDischargeUnderVoltProtection);
		LOG_INF("iDischargeOverTemProtection   : 0x%04x\n", pBattInfo->iDischargeOverTemProtection);
		LOG_INF("iTempSensorFault              : 0x%04x\n", pBattInfo->iTempSensorFault);
		LOG_INF("iDischargeOverCurrProtection  : 0x%04x\n", pBattInfo->iDischargeOverCurrProtection);

		LOG_INF("iSwitchAction                 : 0x%04x\n", pBattInfo->iSwitchAction);
		LOG_INF("iBattCellOverVolt             : 0x%04x\n", pBattInfo->iBattCellOverVolt);
		LOG_INF("iBattCellUnderVolt            : 0x%04x\n", pBattInfo->iBattCellUnderVolt);
		LOG_INF("iBattGroupOverVolt            : 0x%04x\n", pBattInfo->iBattGroupOverVolt);
		LOG_INF("iBattGroupUnderVolt           : 0x%04x\n", pBattInfo->iBattGroupUnderVolt);
		LOG_INF("iBattCellOverVoltWarn         : 0x%04x\n", pBattInfo->iBattCellOverVoltWarn);
		LOG_INF("iBattCellUnderVoltWarn        : 0x%04x\n", pBattInfo->iBattCellUnderVoltWarn);
		LOG_INF("iBattGroupOverVoltWarn        : 0x%04x\n", pBattInfo->iBattGroupOverVoltWarn);
		LOG_INF("iBattGroupUnderVoltWarn       : 0x%04x\n", pBattInfo->iBattGroupUnderVoltWarn);

		LOG_INF("iCommBreak                    : 0x%04x\n", pBattInfo->iCommBreak);
		LOG_INF("iLowVoltProhibitCharge        : 0x%04x\n", pBattInfo->iLowVoltProhibitCharge);

		LOG_INF("iChargeStateFault             : 0x%04x\n", pBattInfo->iChargeStateFault);
		LOG_INF("iDischargeStateFault          : 0x%04x\n", pBattInfo->iDischargeStateFault);
		LOG_INF("iChargeOverCurrProtection     : 0x%04x\n", pBattInfo->iChargeOverCurrProtection);
		LOG_INF("iShortCircuitProtection       : 0x%04x\n", pBattInfo->iShortCircuitProtection);
		LOG_INF("iDischargeOverCurrL1          : 0x%04x\n", pBattInfo->iDischargeOverCurrL1);
		LOG_INF("iDischargeOverCurrL2          : 0x%04x\n", pBattInfo->iDischargeOverCurrL2);
		LOG_INF("iChargeOverCurrWarn           : 0x%04x\n", pBattInfo->iChargeOverCurrWarn);
		LOG_INF("iDischargeOverCurrWarn        : 0x%04x\n", pBattInfo->iDischargeOverCurrWarn);

		LOG_INF("iDischargeSwitchState         : 0x%04x\n", pBattInfo->iDischargeSwitchState);
		LOG_INF("iChargeSwitchState            : 0x%04x\n", pBattInfo->iChargeSwitchState);
		LOG_INF("iDischargeSwitch              : 0x%04x\n", pBattInfo->iDischargeSwitch);
		LOG_INF("iChargeSwitch                 : 0x%04x\n", pBattInfo->iChargeSwitch);
		LOG_INF("iDischargeMOSFlag             : 0x%04x\n", pBattInfo->iDischargeMOSFlag);
		LOG_INF("iChargeMOSFlag                : 0x%04x\n", pBattInfo->iChargeMOSFlag);

		LOG_INF("iChargeOverTempProtection     : 0x%04x\n", pBattInfo->iChargeOverTempProtection);
		LOG_INF("iChargeUnderTempProtection    : 0x%04x\n", pBattInfo->iChargeUnderTempProtection);
		LOG_INF("iDischargeOverTempProtection  : 0x%04x\n", pBattInfo->iDischargeOverTempProtection);
		LOG_INF("iDischargeUnderTempProtection : 0x%04x\n", pBattInfo->iDischargeUnderTempProtection);
		LOG_INF("iEnvOverTempProtection        : 0x%04x\n", pBattInfo->iEnvOverTempProtection);
		LOG_INF("iEnvUnderTempProtection       : 0x%04x\n", pBattInfo->iEnvUnderTempProtection);
		LOG_INF("iPowerOverTempProtection      : 0x%04x\n", pBattInfo->iPowerOverTempProtection);
		LOG_INF("iPowerUnderTempProtection     : 0x%04x\n", pBattInfo->iPowerUnderTempProtection);
		LOG_INF("iDischargeOverTempWarn        : 0x%04x\n", pBattInfo->iDischargeOverTempWarn);
		LOG_INF("iChargeOverTempWarn           : 0x%04x\n", pBattInfo->iChargeOverTempWarn);
		LOG_INF("iBattCellOverTempWarn         : 0x%04x\n", pBattInfo->iBattCellOverTempWarn);
		LOG_INF("iBattCellUnderTempWarn        : 0x%04x\n", pBattInfo->iBattCellUnderTempWarn);
		LOG_INF("iEnvOverTempWarn              : 0x%04x\n", pBattInfo->iEnvOverTempWarn);
		LOG_INF("iEnvUnderTempWarn             : 0x%04x\n", pBattInfo->iEnvUnderTempWarn);
		LOG_INF("iPowerOverTempWarn            : 0x%04x\n", pBattInfo->iPowerOverTempWarn);
		LOG_INF("iPowerUnderTempWarn           : 0x%04x\n", pBattInfo->iPowerUnderTempWarn);
	}
	else
	{
		LOG_INF("blue BMS:battery fault information\n");

		LOG_INF("iHighVolProtect               : 0x%04x\n", pBattInfo->iHighVolProtect);
		LOG_INF("iLowVolProtect                : 0x%04x\n", pBattInfo->iLowVolProtect);
		LOG_INF("iOffLineProtect               : 0x%04x\n", pBattInfo->iOffLineProtect);
		LOG_INF("iChargeOverCurrent            : 0x%04x\n", pBattInfo->iChargeOverCurrent);
		LOG_INF("iDischargeOverCurrent         : 0x%04x\n", pBattInfo->iDischargeOverCurrent);
		LOG_INF("iShortCircuitPortect          : 0x%04x\n", pBattInfo->iShortCircuitPortect);
		LOG_INF("iHighTemPortect               : 0x%04x\n", pBattInfo->iHighTemPortect);
		LOG_INF("iLowTemPortect                : 0x%04x\n", pBattInfo->iLowTemPortect);
	}
	
	return 0;
}

/*******************************************************************************
*Function Name    :anshang_start_charge
*Description      :CAN1发送安尚电池充电指令
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int anshang_start_charge()
{
	return 0;
}

/*******************************************************************************
*Function Name    :anshang_stop_charge
*Description      :CAN1发送安尚电池停止充电指令
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int anshang_stop_charge()
{
	return 0;
}

/*******************************************************************************
*Function Name    :anshang_get_lasterfive_poweroff
*Description      :查询安尚电池前五次断电信息
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int anshang_get_lasterfive_poweroff()
{
	return 0;
}

/*******************************************************************************
*Function Name    :anshang_get_pack_type
*Description      :查询安尚电池PACK类型
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int anshang_get_pack_type()
{
	return 0;
}

/*******************************************************************************
*Function Name    :anshang_get_vid_pid
*Description      :查询安尚电池PID信息
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int anshang_get_vid_pid()
{
	return 0;
}
