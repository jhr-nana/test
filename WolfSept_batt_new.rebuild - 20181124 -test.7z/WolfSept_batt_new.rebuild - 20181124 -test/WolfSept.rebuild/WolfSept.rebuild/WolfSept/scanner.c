#include "scanner.h"
#include "multipatternfinder.h"

/* 根据特征圆按照检测线数目和检测线的单位宽度所占的像素数目比较大小 */
static bool FuncDetectRingCompare(snake_detectedRing *r1, snake_detectedRing *r2, float estimatedMouleSize);

/* 计算特征圆的圆心 */
static inline void FuncCalculateRingCenter(snake_detectedRing *ring);

/* 选择最好的3个特征圆 */
static bool FuncSelectBestRings();

/********************************************
函数功能: 根据特征圆按照检测线数目和检测线的单位宽度所占的像素数目比较大小
函数输入: 两个特征圆的指针，检测线单位宽度的像素数目estimatedMouleSize
函数输出: 当r1检测线数目大于r2，返回true；当两者数目相同，r1的检测线单位宽度像素数目接近estimatedMouleSize时，返回true;
*********************************************/
static bool FuncDetectRingCompare(snake_detectedRing *r1, snake_detectedRing *r2, float estimatedMouleSize)
{
    if (r1->DetectCount > r2->DetectCount)
        return true;

    if (fabs(r1->estimatedModuleSize - estimatedMouleSize)<fabs(r2->estimatedModuleSize - estimatedMouleSize))
        return true;
    return false;
}

/********************************************
函数功能: 计算特征圆的圆心
函数输入: 特征圆的指针
函数输出: 特征圆圆心
*********************************************/
static inline void FuncCalculateRingCenter(snake_detectedRing *ring)
{
    int i = 0;
    int sumLenCenter=0;
    int sumPixCenter=0;

    for(i=0; i<ring->DetectCount;i++)
    {
        snake_detectedLine detectedLine= ring->detectedLine[i];
        sumPixCenter=sumPixCenter+detectedLine.pos.Pix+0.5*(detectedLine.Len+0.5);
        sumLenCenter= sumLenCenter+detectedLine.pos.Lin;
    }

    ring->pos.Pix =(sumPixCenter+0.5)/ring->DetectCount;
    ring->pos.Lin =(sumLenCenter+0.5)/ring->DetectCount;
}

// 计算校正特征模式的坐标
static bool FuncCalcuRevisePattern(snake_detectedRing *patternA,
                                           snake_detectedRing *patternB,
                                           snake_detectedRing *patternC, snake_pointf *ret)
{
    snake_pointf Center;
    if (NULL==patternA || NULL==patternB || NULL==patternC)
        return false;

    // 计算线段AC的中点 Center

    Center.Pix = (patternA->pos.Pix + patternC->pos.Pix)/2.0;
    Center.Lin = (patternA->pos.Lin + patternC->pos.Lin)/2.0;

    // 计算校正特征模式的中心：Center + (Center - B)
    ret->Pix = 2.0*Center.Pix - patternB->pos.Pix;
    ret->Lin = 2.0*Center.Lin - patternB->pos.Lin;

    return true;
}  

/********************************************
函数功能: 选择最好的3个特征圆
函数输入: 特征圆数组的首指针及数组大小
函数输出: 当最终剩余的特征圆数目等于3时，返回true，否则返回false
*********************************************/
static bool FuncSelectBestRings()
{
    int i = 0;
    int j = 0;
    int k = 0;
    float fBAlen = 0.0f;  // Length of BA
    float fBClen = 0.0f;  // Length of BC
    float fAClen = 0.0f;  // Length of AC
    float estimatedModuleSize = 0.0f;   // 检测线单位宽度的像素数目
    float totalModuleSize = 0.0f;
    float average = 0.0f;
    float stdDev = 0.0f;
    float square = 0.0f;
    float limit = 0.0f;
    float line12 = 0.0f;
    float line13 = 0.0f;
    float line23 = 0.0f;
    float vABBC = 0.0f;
    float dCpy = 0.0f;
    float vPyC = 0.0f;
    int nRingIdxArray = 0;
    snake_detectedRing tmp;
    snake_point r1, r2, r3;
    snake_pointf revisePoint = {0.0f, 0.0f};
    float fLenPix = 0.0f;
    float fLenLin = 0.0f;
    float avgLegEdgeLength = 0.0f; // 计算所有直角边的均值
    float len = 0.0f;
	bool isExist = false;

    // (1) 根据每个特征圆检测线的单位宽度所占的像素数目的统计特性删除假圆
    int lineIdx = 0, ringIdx = 0;

    for (ringIdx = 0; ringIdx<detectedRingsNum; ringIdx++)
    {
        // 如果特征圆的检测线数目少于3条，则删除该特征圆
        while (detectedRings[ringIdx].DetectCount<=2 && ringIdx!=detectedRingsNum-1)
        {
            memcpy(&detectedRings[ringIdx],&detectedRings[--detectedRingsNum],sizeof(detectedRings[ringIdx]));
        }

        if (detectedRings[ringIdx].DetectCount<=2 && ringIdx==detectedRingsNum-1)
            detectedRingsNum--;

        // 如果特征圆数目少于3，则返回错误，即没有找到特征圆
        if (detectedRingsNum<STANDARD_RING_NUM)
            return false;

        // 计算每个特征圆的检测线的单位宽度所占的像素数目
        estimatedModuleSize = 0.0f;
        for (lineIdx = 0; lineIdx < detectedRings[ringIdx].DetectCount; lineIdx++)
        {
            estimatedModuleSize += detectedRings[ringIdx].detectedLine[lineIdx].Len;
        }
        estimatedModuleSize /= detectedRings[ringIdx].DetectCount*8.0;
        detectedRings[ringIdx].estimatedModuleSize = estimatedModuleSize;
    }

    totalModuleSize = 0.0f;
    square = 0.0f;
    for (i = 0; i < detectedRingsNum; i++) {
        estimatedModuleSize = detectedRings[i].estimatedModuleSize;
        totalModuleSize += estimatedModuleSize;
        square += estimatedModuleSize * estimatedModuleSize;
    }
    // 计算所有特征圆的检测线单位宽度的像素的均值和标准差
    average = totalModuleSize / (float) detectedRingsNum;
    stdDev = (float)sqrtf(square / detectedRingsNum - average * average);

    // 对特征圆按照检测线数目和检测线的单位宽度所占的像素数目两个因素进行降序排列
    for (i = 0; i<detectedRingsNum-1; i++)
    {
        for (j = 0; j<detectedRingsNum; j++)
        {
            if(FuncDetectRingCompare(&detectedRings[i], &detectedRings[j], average))
                continue;
            memcpy(&tmp, &detectedRings[i], sizeof(tmp));
            memcpy(&detectedRings[i], &detectedRings[j], sizeof(tmp));
            memcpy(&detectedRings[j], &tmp, sizeof(tmp));
        }
    }

    // 删除单位宽度的像素数超出标准差的圆环
    limit = MAX(0.2f * average, stdDev);
    for (i = detectedRingsNum-1; i >= 0 && detectedRingsNum > STANDARD_RING_NUM; i--)
    {
        if (fabs(detectedRings[i].estimatedModuleSize - average) > limit)
        {
            memcpy(&detectedRings[i],&detectedRings[detectedRingsNum-1],sizeof(detectedRings[0]));
            detectedRingsNum--;
        }
    }

    if (detectedRingsNum<STANDARD_RING_NUM)
        return false;

    // 计算特征圆的圆心
    for (i=0; i<detectedRingsNum; i++)
    {
        FuncCalculateRingCenter(&detectedRings[i]);
    }

    // (2) 根据特征圆圆心之间距离的几何关系删除假圆
    for (i=0; i<detectedRingsNum-2; i++)
    {
        r1.Pix = detectedRings[i].pos.Pix;
        r1.Lin = detectedRings[i].pos.Lin;
        for (j=i+1; j<detectedRingsNum-1; j++)
        {
            r2.Pix = detectedRings[j].pos.Pix;
            r2.Lin = detectedRings[j].pos.Lin;
            for (k=j+1; k<detectedRingsNum; k++)
            {
                r3.Pix = detectedRings[k].pos.Pix;
                r3.Lin = detectedRings[k].pos.Lin;

                line12 = sqrtf((r1.Pix - r2.Pix)*(r1.Pix - r2.Pix)
                         + (r1.Lin - r2.Lin)*(r1.Lin - r2.Lin));

                line13 = sqrtf((r1.Pix - r3.Pix)*(r1.Pix - r3.Pix)
                           + (r1.Lin - r3.Lin)*(r1.Lin - r3.Lin));

                line23 = sqrtf((r2.Pix - r3.Pix)*(r2.Pix - r3.Pix)
                          + (r2.Lin - r3.Lin)*(r2.Lin - r3.Lin));

                // BA 和 BC 这里姑且随意指定
                if (line12<line23 && line13<line23)
                {
                    fAClen = line23;
                    fBAlen = line12;
                    fBClen = line13;
                }
                else if (line12<line13 && line23<line13)
                {
                    fAClen = line13;
                    fBAlen = line12;
                    fBClen = line23;
                }
                else
                {
                    fAClen = line12;
                    fBAlen = line23;
                    fBClen = line13;
                }

                /* 这里仍需确定BA或BC占用单位宽度的区间，即宽度的上下界"MAX_MODULE_COUNT"和"MIN_MODULE_COUNT"
                // 计算BA和BC平均长度是多少个单位宽度
                float estimatedModuleCount = (fBAlen + fBClen) / (detectedRings[i].estimatedModuleSize * 2.0f);
                if (estimatedModuleCount > MAX_MODULE_COUNT
                        || estimatedModuleCount < MIN_MODULE_COUNT)
                {
                    continue;
                }
                */

                // 判断两条直角边长度是否相等
                vABBC = fabs((fBAlen - fBClen) / MIN(fBAlen, fBClen));
                if (vABBC >= 0.1f)
                    continue;

                // 判断三条边是否满足勾股定理
                dCpy = (float) sqrtf(fBAlen * fBAlen + fBClen * fBClen);
                // Compare to the real distance in %
                vPyC = fabs((fAClen - dCpy) / MAX(fAClen, dCpy));
                if (vPyC >= 0.1f)
                    continue;

                // 将符合条件的三个圆心对应的索引保存到数组中
                g_iPatternIdxArray[nRingIdxArray++] = i;
                g_iPatternIdxArray[nRingIdxArray++] = j;
                g_iPatternIdxArray[nRingIdxArray++] = k;
            }
        }
    }


    /******************下面删除错误的A/B/C三元组**********************/

    // 满足等腰直角三角形条件的三个圆环依次为A/B/C，计算圆环D的圆心
    // 若得到的圆心正好是黑白同心圆环，则A/B/C圆环组成的三元组删除
    for (i=0; i<nRingIdxArray; i+=3)
    {
        // D的圆心坐标
        isExist = FuncCalcuRevisePattern(&detectedRings[g_iPatternIdxArray[i]],
                               &detectedRings[g_iPatternIdxArray[i+1]],
                               &detectedRings[g_iPatternIdxArray[i+2]],
                               &revisePoint);
		if (isExist)
		{
			// 遍历其余特征圆，比较特征圆圆心之间的距离
	        for (j=0; j<nRingIdxArray; j++)
	        {
	            if (j>=i && j<i+3)
	                continue;

	            // 计算圆心 Pix 和 Lin 方向的距离
	            fLenPix = fabs(detectedRings[g_iPatternIdxArray[j]].pos.Pix - revisePoint.Pix);
	            fLenLin = fabs(detectedRings[g_iPatternIdxArray[j]].pos.Lin - revisePoint.Lin);

	            // 当圆心距离很接近时，则删除三元组
	            if ( fLenPix < 4*detectedRings[g_iPatternIdxArray[j]].estimatedModuleSize
	                 && fLenLin < 4*detectedRings[g_iPatternIdxArray[j]].estimatedModuleSize )
	            {
	                g_iPatternIdxArray[i] = g_iPatternIdxArray[nRingIdxArray-3];
	                g_iPatternIdxArray[i+1] = g_iPatternIdxArray[nRingIdxArray-2];
	                g_iPatternIdxArray[i+2] = g_iPatternIdxArray[nRingIdxArray-1];
	                g_iPatternIdxArray[nRingIdxArray-3] = -1;
	                g_iPatternIdxArray[nRingIdxArray-2] = -1;
	                g_iPatternIdxArray[nRingIdxArray-1] = -1;
	                nRingIdxArray -= 3;
	                i -= 3;
	                break;
	            }
	        }
		}
        else
		{
			g_iPatternIdxArray[i] = g_iPatternIdxArray[nRingIdxArray-3];
			g_iPatternIdxArray[i+1] = g_iPatternIdxArray[nRingIdxArray-2];
			g_iPatternIdxArray[i+2] = g_iPatternIdxArray[nRingIdxArray-1];
			g_iPatternIdxArray[nRingIdxArray-3] = -1;
			g_iPatternIdxArray[nRingIdxArray-2] = -1;
			g_iPatternIdxArray[nRingIdxArray-1] = -1;
			nRingIdxArray -= 3;
			i -= 3;
		}
    }

    // 根据直角边边长的均值与方差删除假的A/B/C三元组
    avgLegEdgeLength = 0.0f;
    square = 0.0f;
    for (i=0; i<nRingIdxArray-2; i+=3)
    {
        r1.Pix = detectedRings[g_iPatternIdxArray[i]].pos.Pix;
        r1.Lin = detectedRings[g_iPatternIdxArray[i]].pos.Lin;
        r2.Pix = detectedRings[g_iPatternIdxArray[i+1]].pos.Pix;
        r2.Lin = detectedRings[g_iPatternIdxArray[i+1]].pos.Lin;
        len = sqrtf((r1.Pix - r2.Pix)*(r1.Pix - r2.Pix)
                            + (r1.Lin - r2.Lin)*(r1.Lin - r2.Lin));
        avgLegEdgeLength += len;
        square += len*len;
    }

    // 直角边的均值
    avgLegEdgeLength /= nRingIdxArray/3;

    // 直角边的标准差
    stdDev = (float)sqrtf(square / (nRingIdxArray/3) - avgLegEdgeLength * avgLegEdgeLength);

    // 阈值
    limit = MAX(0.2f * avgLegEdgeLength, stdDev);

    for (i=0; i<nRingIdxArray-2; i+=3)
    {
        r1.Pix = detectedRings[g_iPatternIdxArray[i]].pos.Pix;
        r1.Lin = detectedRings[g_iPatternIdxArray[i]].pos.Lin;
        r2.Pix = detectedRings[g_iPatternIdxArray[i+1]].pos.Pix;
        r2.Lin = detectedRings[g_iPatternIdxArray[i+1]].pos.Lin;
        len = sqrtf((r1.Pix - r2.Pix)*(r1.Pix - r2.Pix)
                    + (r1.Lin - r2.Lin)*(r1.Lin - r2.Lin));

        // 当标准差大于一定值时，说明存在较大的等腰直角三角形
        // 因为A/B/C组成的直角边边长最小，所以这里只用判断大于均值的直角边
        if (len-avgLegEdgeLength>limit)
        {
            g_iPatternIdxArray[i] = g_iPatternIdxArray[nRingIdxArray-3];
            g_iPatternIdxArray[i+1] = g_iPatternIdxArray[nRingIdxArray-2];
            g_iPatternIdxArray[i+2] = g_iPatternIdxArray[nRingIdxArray-1];
            g_iPatternIdxArray[nRingIdxArray-3] = -1;
            g_iPatternIdxArray[nRingIdxArray-2] = -1;
            g_iPatternIdxArray[nRingIdxArray-1] = -1;
            nRingIdxArray -= 3;
            i -= 3;
        }
    }

    detectedRingsNum = nRingIdxArray;

    if (detectedRingsNum < STANDARD_RING_NUM)
        return false;
    else
        return true;
}

/********************************************
函数功能:FuncRingDet函数实现,图像轮廓检测
函数输入:
函数输出:
*********************************************/
bool FuncRingsDetect(uint8_t * imageDataHeader,int pixStart,int pixEnd,int linStart,int linEnd)
{
#if 1
    if (NULL == imageDataHeader)
    {
        // printf("The image pointer of function %s is null\n",__func__);
        return false;
    }

    if (FuncFindPatternCenters(imageDataHeader))
    {
        return true;
    }
    return false;
#else
    int	 usPix,usLin;

    uint8_t	 uacData[6];
    int	 usDataSumTmp0;
    int	 usDataSumTmp1;
    int	 uasPi[4];
    uint8_t	 n;
    uint8_t	 ucDistNum=0;
    int	 usDistPix;
    int	 usDistLin;
    int	 ucDetFlg = 0;
    bool ucRingFlg = false; // 是否检测到新圆环标记符
    int	 usLen[5] = {0,0,0,0,0};



    int maxCount=0;

    // 初始化特征数据
    detectedRingsNum=0;
    memset(detectedRings, 0x00, sizeof(detectedRings));


    usPix = pixStart;
    for (usLin = linStart; usLin < linEnd; ) // 行
    {
        if (usPix > (pixEnd - 2))  // 本行搜索完成，进入下一行
        {
            usPix = pixStart;
            usLin++;
            ucDetFlg = 0; // 重置搜索标识符
            memset(usLen, 0x00, sizeof(usLen));
        }


        // 获得数据矩阵当前列头地址
        uint8_t * rowHeader= (uint8_t *)(imageDataHeader + usLin*IMG_WIDTH);


        switch (ucDetFlg)
        {
        case 0 :
        {
            memset(usLen, 0x00, sizeof(usLen));
            for (; usPix < pixEnd - 1; usPix++)
            {
                // 此处效率不高，可以改进，这个运算imageDataHeader + usLin*pixEnd可以合并
                uacData[0] = (*(uint8_t *)(rowHeader+ usPix - 3));
                uacData[1] = (*(uint8_t *)(rowHeader + usPix - 2));
                uacData[2] = (*(uint8_t *)(rowHeader + usPix - 1));
                uacData[3] = (*(uint8_t *)(rowHeader + usPix));
                uacData[4] = (*(uint8_t *)(rowHeader + usPix + 1));
                uacData[5] = (*(uint8_t *)(rowHeader + usPix + 2));

                usDataSumTmp0 = uacData[0] + uacData[1] + uacData[2];
                usDataSumTmp1 = uacData[3] + uacData[4] + uacData[5];

                if (((WHITE*3) == usDataSumTmp0)&&(BLACK == usDataSumTmp1))
                    //&&(usPix < pixEnd - MIN_LEN_RING_DET))
                {
                    // 如果遇到3块白+3块黑的

                    ucDetFlg = 1;
                    break;
                }
            }
        }
            break;
        case 1 : // BLACK 0
        {
            // 继续往后搜索，步长为2
            for (; usPix < pixEnd - 1; usPix += 2)
            {
                uacData[0] = (*(uint8_t *)(rowHeader + usPix));
                uacData[1] = (*(uint8_t *)(rowHeader + usPix + 1));

                usDataSumTmp0 = uacData[0] + uacData[1];
                if (usDataSumTmp0 < (WHITE + 1)) // 如果小于256，可能是黑白相间，但肯定不是全白
                {
                    usLen[0] += 2;  // 黑块长度增加2
                }

                if ((WHITE<<1) == usDataSumTmp0)
                {
                    ucDetFlg = 2; // 检测到白块部分，进入下一个判别环节
                    //usPix--;
                    if ((usLen[0] > DELTA_LEN_MAX)  //如果累积的黑块长度大于25或小于7，则认为不是圆形标记符
                            ||(usLen[0] < DELTA_LEN_MIN))
                    {
                        ucDetFlg = 0;
                    }
                    break;
                }

                if (usLen[0] > DELTA_LEN_MAX) // 如果黑块长度已经大于25
                {
                    ucDetFlg = 0;  // 圆形标识符检测失败
                    break;
                }

            }
        }
            break;
        case 2 :  // WHITE 1
        {

            for (; usPix < pixEnd - 1; usPix += 2) // 继续往后搜索，步进为2
            {
                // imageDataHeader + usLin*pixEnd 可以化简

                uacData[0] = (*(uint8_t *)(rowHeader + usPix));
                uacData[1] = (*(uint8_t *)(rowHeader + usPix + 1));

                usDataSumTmp0 = uacData[0] + uacData[1];
                if (usDataSumTmp0 > (WHITE - 1)) // 如果大于254，可能是黑白相间，但肯定不是全黑
                {
                    usLen[1] += 2; // 白块长度增加2
                }

                if (BLACK == usDataSumTmp0)
                {
                    uasPi[0] = (usLen[1]*100)/usLen[0]; // white1与black0长度做比值*100

                    if ((uasPi[0] > THRE_LOW1_RING_DET)  // 如果比值大于67且小于145
                            &&(uasPi[0] < THRE_HIGH1_RING_DET))
                    {
                        ucDetFlg = 3; // 白块辨别成功，进入下一步
                        //usPix--;
                        if ((usLen[1] > DELTA_LEN_MAX) //如果白块宽度大于25或者小于7，则识别失败
                                ||(usLen[1] < DELTA_LEN_MIN))
                        {
                            ucDetFlg = 0;  //  继续从case0开始搜索
                        }
                        break;
                    }
                    else
                    {
                        ucDetFlg = 0;     // 圆形标识符检测失败
                        break;
                    }
                }

                if (usLen[1] > DELTA_LEN_MAX) // 如果白块的长度也已经大于25了
                {
                    ucDetFlg = 0;        // 圆形标识符检测失败
                    break;
                }
            }
        }
            break;
        case 3 :  // BLACK 2
        {
            for (; usPix < pixEnd - 1; usPix += 2)  //步进2
            {
                uacData[0] = (*(uint8_t *)(rowHeader + usPix));
                uacData[1] = (*(uint8_t *)(rowHeader + usPix + 1));

                usDataSumTmp0 = uacData[0] + uacData[1];
                if (usDataSumTmp0 < (WHITE + 1)) // 如果不是全白
                {
                    usLen[2] += 2; // 黑块长度增2
                }

                if ((WHITE<<1) == usDataSumTmp0)  // 如果是白的
                {
                    uasPi[1] = (usLen[2]*10)/usLen[0]; // black2与black0长度做比值*10

                    if ((uasPi[1] > THRE_LOW4_RING_DET) // 如果比值大于34且小于45
                            &&(uasPi[1] < THRE_HIGH4_RING_DET))
                    {
                        ucDetFlg = 4; // 黑块识别成功，进入下一个环节
                        //usPix--;
                        if ((usLen[2] > (DELTA_LEN_MAX<<2)) // 如果黑块的长度大于
                                ||(usLen[2] < (DELTA_LEN_MIN<<2))) // 或者小于
                        {
                            ucDetFlg = 0; // 检测失败，仍然维持在本行，继续从case0开始搜索
                        }
                        break;
                    }
                    else
                    {
                        ucDetFlg = 0;
                        break;
                    }
                }

                if (usLen[2] > DELTA_LEN_MAX<<2) //如果黑块长度大于100
                {
                    ucDetFlg = 0;
                    break;
                }
            }
        }
            break;
        case 4 :  // WHITE 3
        {
            for (; usPix < pixEnd - 1; usPix += 2) // 步进2
            {
                uacData[0] = (*(uint8_t *)(rowHeader + usPix));
                uacData[1] = (*(uint8_t *)(rowHeader + usPix + 1));

                usDataSumTmp0 = uacData[0] + uacData[1];
                if (usDataSumTmp0 > (WHITE - 1)) // 如果不是全黑
                {
                    usLen[3] += 2; //白块长度加2
                }

                if (BLACK == usDataSumTmp0)  // 如果检测到全黑
                {
                    uasPi[2] = (usLen[3]*100)/usLen[0];  // white3与black0长度做比值*100

                    if ((uasPi[2] > THRE_LOW1_RING_DET) // 如果比值在范围内
                            &&(uasPi[2] < THRE_HIGH1_RING_DET))
                    {
                        ucDetFlg = 5; // 检测成功，进入下一步
                        //usPix--;
                        if ((usLen[3] > DELTA_LEN_MAX) // 如果白块长度过长或过短，则检测失败
                                ||(usLen[3] < DELTA_LEN_MIN))
                        {
                            ucDetFlg = 0;
                        }
                        break;
                    }
                    else
                    {
                        ucDetFlg = 0;  // 如果比值不在范围内，则判断检测失败
                        break;
                    }
                }

                if (usLen[3] > DELTA_LEN_MAX) // 如果白块长度过长，则检测失败
                {
                    ucDetFlg = 0;
                    break;
                }
            }
        }
            break;
        case 5 :  // BLACK 4
        {
            for (; usPix < pixEnd - 1; usPix += 2)  // 步进2
            {
                uacData[0] = (*(uint8_t *)(rowHeader + usPix));
                uacData[1] = (*(uint8_t *)(rowHeader + usPix + 1));

                usDataSumTmp0 = uacData[0] + uacData[1];
                if (usDataSumTmp0 < (WHITE + 1)) // 如果非全白
                {
                    usLen[4] += 2;  // 黑块长度增2
                }

                if ((WHITE<<1) == usDataSumTmp0) // 如果检测到全白
                {
                    uasPi[3] = (usLen[4]*100)/usLen[0];  // black4与black0长度做比值*100

                    if ((uasPi[3] > THRE_LOW1_RING_DET)
                            &&(uasPi[3] < THRE_HIGH1_RING_DET)) // 如果比值在范围内
                    {
                        ucDetFlg = 6; // 辨识成功，进入下一步
                        //usPix--;
                        if ((usLen[4] > DELTA_LEN_MAX)
                                ||(usLen[4] < DELTA_LEN_MIN)) // 如果黑块过短或过长，则检测失败
                        {
                            ucDetFlg = 0;
                        }
                        break;
                    }
                    else
                    {
                        ucDetFlg = 0;
                        break;
                    }
                }

                if (usLen[4] > DELTA_LEN_MAX)  // 如果黑块过长，则检测失败
                {
                    ucDetFlg = 0;
                    break;
                }
            }
        }
            break;
        case 6 :  // Detected ring，经过以上检测步骤，成功检测出圆环
        {

            // 检测到满足条件的特征line
            snake_detectedLine detectedLine;

            // 特征线截面的总长度
            detectedLine.Len= usLen[4] + usLen[3]  \
                    + usLen[2] + usLen[1]  \
                    + usLen[0];

            // 特征线起始点坐标
            detectedLine.pos.Pix=usPix - 1 - detectedLine.Len;
            detectedLine.pos.Lin=usLin;

            //消除域内重复，
            // orgDetectedRingsNum为检测到的总圆环的数目, orgDetectedRings存储所有已经检测到的圆环
            for (n= 0; n < detectedRingsNum; n++)
            {
                // 当前圆环距所有已知圆环的水平像素距离
                usDistPix = abs(detectedLine.pos.Pix - detectedRings[n].pos.Pix);
                // 当前圆环距所有已知圆环的垂直像素距离
                usDistLin = abs(detectedLine.pos.Lin - detectedRings[n].pos.Lin);

                if ((usDistPix + usDistLin) > MIN_LEN_RING_DET) // 如果像素距离和大于80
                {
                    ucDistNum += 1;  // 问题，ucDistNum没有赋初值，是不是有问题??
                }
                else
                {
                    int count=detectedRings[n].DetectCount;

                    detectedRings[n].detectedLine[count]=detectedLine;
                    detectedRings[n].DetectCount += 1; // 当前圆环与第n个圆环为同一圆环，被检测到的次数加1

                    detectedRings[n].pos=detectedLine.pos;
                    detectedRings[n].Len=detectedLine.Len;

                    // 通过统计检测次数，可以估计圆环的高度
                }
            }
            // 对于以上循环的分析，如果当前orgDetectedRingsNum=0；则以上操作只会将usRingDetCnt的计数加一
            // 如果orgDetectedRingsNum=2，则当前圆环会与Num=1,Num=0的圆环做比较，每次比较成功ucDistNum += 1
            // 因此，最终ucDistNum=2.



            if (ucDistNum == detectedRingsNum) // 如果当前圆环与所有已知圆环均可有效区分
            {
                ucRingFlg = true;
            }else{

                ucRingFlg = false;
            }


            ucDistNum = 0; // 重置计数器

            if ((detectedRings[detectedRingsNum].Len < (IMG_WIDTH>>2)) // 如果当前圆环的长度小于1/4总长度
                    &&(true == ucRingFlg)) // 且能与其他圆环有效区分,则表示检测到新圆环
            {
                ucRingFlg = false; // 重置圆环判别标记位

                // 记录当前圆环的行列像素坐标
                detectedRings[detectedRingsNum].detectedLine[0]=detectedLine;
                detectedRings[detectedRingsNum].DetectCount += 1; // 当前圆环与第n个圆环为同一圆环，被检测到的次数加1

                detectedRings[detectedRingsNum].pos=detectedLine.pos;
                detectedRings[detectedRingsNum].Len=detectedLine.Len;

                detectedRingsNum++; // 圆环数目加1

                ucDetFlg = 0; // 重置特征判别标记位

                if (detectedRingsNum>=MAX_RING_NUM){

                    printf("ERR: detected too more rings\n");
                    return false;
                }

            }
            else
            {
                ucDetFlg = 0;
                break;
            }
        }
            break;
        default :
        {
            //error;
            ucDetFlg = 0;
        }
        }
    }


    if (!FuncSelectBestRings())
        return false;

    // 将检测到的圆环坐标换算至圆心位置，换算采用加和平均的方式
    return true;
#endif
}



//********************************************
//函数功:FuncCodeMapPoseCalculate函数实现,获取图像位姿数据
//函数输入:
//函数输出:
//*********************************************/
bool FuncCodeMapPoseEstimate(int i, int j, int k){

    snake_detectedRing *pRing0 = NULL, *pRing1 = NULL, *pRing2 = NULL;
    snake_vector vector01, vector12, vector20;
    snake_vector standardSlope = {-1,1};
    snake_vector testSlope;
    snake_point imgCenter;
    snake_point pointA, pointB, pointC;		//ABC按顺时针排序，B为直角点

    int rotationDirection;
    float cosTheta, rotationTheta;
    int dist_1, dist_2, dist_3;		//三条边长度

    pRing0 = &detectedRings[g_iPatternIdxArray[i]];
    pRing1 = &detectedRings[g_iPatternIdxArray[j]];
    pRing2 = &detectedRings[g_iPatternIdxArray[k]];

    vector01.Pix = pRing1->pos.Pix - pRing0->pos.Pix;
    vector01.Lin = pRing1->pos.Lin - pRing0->pos.Lin;

    vector12.Pix = pRing2->pos.Pix - pRing1->pos.Pix;
    vector12.Lin = pRing2->pos.Lin - pRing1->pos.Lin;

    vector20.Pix = pRing0->pos.Pix - pRing2->pos.Pix;
    vector20.Lin = pRing0->pos.Lin - pRing2->pos.Lin;

    rotationDirection = -1;		//-1代表逆时针，1代表顺时针

    //满足条件说明，时针顺序与标准相同，后续只需判断直角点，即可确定三个点顺序
    if (vector01.Pix * vector12.Lin - vector01.Lin * vector12.Pix > 0)
    {
        rotationDirection = 1;
    }


    dist_1 = vector01.Pix * vector01.Pix + vector01.Lin * vector01.Lin;
    dist_2 = vector12.Pix * vector12.Pix + vector12.Lin * vector12.Lin;
    dist_3 = vector20.Pix * vector20.Pix + vector20.Lin * vector20.Lin;


    if ((dist_3 > dist_2) && (dist_3 > dist_1))		//找出两条直角边
    {

        if (rotationDirection == 1)
        {
            testSlope = vector20;

            pointA = pRing0->pos;
            pointB = pRing1->pos;
            pointC = pRing2->pos;

            mapPose.pixPerGrid=sqrtf(dist_2)/MAP_WIDTH;
            mapPose.linPerGrid=sqrtf(dist_1)/MAP_HEIGHT;
        }
        else
        {
            testSlope.Pix = -1 * vector20.Pix;
            testSlope.Lin = -1 * vector20.Lin;

            pointA = pRing2->pos;
            pointB = pRing1->pos;
            pointC = pRing0->pos;

            mapPose.pixPerGrid=sqrtf(dist_1)/MAP_WIDTH;
            mapPose.linPerGrid=sqrtf(dist_2)/MAP_HEIGHT;

        }
    }
    else if ((dist_1 > dist_2) && (dist_1 > dist_3))
    {

        if (rotationDirection == 1)
        {
            testSlope = vector01;

            pointA = pRing1->pos;
            pointB = pRing2->pos;
            pointC = pRing0->pos;

            mapPose.pixPerGrid=sqrtf(dist_3)/MAP_WIDTH;
            mapPose.linPerGrid=sqrtf(dist_2)/MAP_HEIGHT;

        }
        else
        {
            testSlope.Pix = -1 * vector01.Pix;
            testSlope.Lin = -1 * vector01.Lin;

            pointA = pRing0->pos;
            pointB = pRing2->pos;
            pointC = pRing1->pos;

            mapPose.pixPerGrid=sqrtf(dist_2)/MAP_WIDTH;
            mapPose.linPerGrid=sqrtf(dist_3)/MAP_HEIGHT;

        }
    }
    else if ((dist_2 > dist_1) && (dist_2 > dist_3))
    {

        if (rotationDirection == 1)
        {
            testSlope = vector12;

            pointA = pRing2->pos;
            pointB = pRing0->pos;
            pointC = pRing1->pos;

            mapPose.pixPerGrid=sqrtf(dist_1)/MAP_WIDTH;
            mapPose.linPerGrid=sqrtf(dist_3)/MAP_HEIGHT;

        }
        else
        {
            testSlope.Pix = -1 * vector12.Pix;
            testSlope.Lin = -1 * vector12.Lin;

            pointA = pRing1->pos;
            pointB = pRing0->pos;
            pointC = pRing2->pos;

            mapPose.pixPerGrid=sqrtf(dist_3)/MAP_WIDTH;
            mapPose.linPerGrid=sqrtf(dist_1)/MAP_HEIGHT;

        }
    }


    mapPose.PointA=pointA;
    mapPose.PointB=pointB;
    mapPose.PointC=pointC;


    // check 获得的ABC点是否满足刚体变换关系
    mapPose.transType = isRigidTransform(&mapPose);


    if(mapPose.transType==TRANS_ERROR){

        return false;

    }else{

        cosTheta = (-1 * testSlope.Pix + testSlope.Lin) / sqrtf(2 * (testSlope.Pix * testSlope.Pix + testSlope.Lin * testSlope.Lin));
        rotationTheta = acos(cosTheta);		//图像旋转角度，输出为弧度，返回0-pi

        //设定：图像顺时针旋转为正，逆时针旋转为负，弧度范围[-pi, pi]
        if (standardSlope.Pix * testSlope.Lin - standardSlope.Lin * testSlope.Pix < 0)
        {
            rotationTheta = -1 * rotationTheta;
        }

//        // 单码图的中心
//        imgCenter.Pix = (pointA.Pix + pointC.Pix) / 2;		//图像中心点坐标
//        imgCenter.Lin = (pointA.Lin + pointC.Lin) / 2;

        // 多码图的中心
        imgCenter.Pix = pointA.Pix + pointC.Pix - pointB.Pix;		//图像中心点坐标
        imgCenter.Lin = pointA.Lin + pointC.Lin - pointB.Lin;

        // 进一步改进：
        // 1. 当前仅利用了AC点确定方向，其他候选方向还有BC，AB。采用取中值的方式进一步优化方向角求解精度

        mapPose.mapCenter=imgCenter;
        mapPose.theta=rotationTheta;


        return true;
    }
}



/* 检查当前是否满足刚体变换 */
snake_transType isRigidTransform(snake_mapPose *mapPose){


    snake_vector vectorBA, vectorBC;

    float normVectorBA, normVectorBC;

    float dotProduct;		//两条直角边点乘积

    snake_transType transType; // 变换类型

    vectorBA.Pix= mapPose->PointA.Pix - mapPose->PointB.Pix;
    vectorBA.Lin= mapPose->PointA.Lin - mapPose->PointB.Lin;

    vectorBC.Pix= mapPose->PointC.Pix - mapPose->PointB.Pix;
    vectorBC.Lin= mapPose->PointC.Lin - mapPose->PointB.Lin;

    normVectorBA= sqrtf(vectorBA.Pix*vectorBA.Pix+vectorBA.Lin*vectorBA.Lin);
    normVectorBC= sqrtf(vectorBC.Pix*vectorBC.Pix+vectorBC.Lin*vectorBC.Lin);

    mapPose->ePix.Pix = vectorBC.Pix/normVectorBC;
    mapPose->ePix.Lin = vectorBC.Lin/normVectorBC;
    mapPose->eLin.Pix = vectorBA.Pix/normVectorBA;
    mapPose->eLin.Lin = vectorBA.Lin/normVectorBA;
//    mapPose->ePix={vectorBC.Pix/normVectorBC, vectorBC.Lin/normVectorBC};
//    mapPose->eLin={vectorBA.Pix/normVectorBA, vectorBA.Lin/normVectorBA};

    dotProduct = (vectorBA.Pix * vectorBC.Pix + vectorBA.Lin * vectorBC.Lin)/(normVectorBA*normVectorBC);

    // 如果BA，BC两直线的角度偏差小于1度（dotProduct<0.0175），则继续运算。否则，考虑进行仿射变换，甚至透射变换
    if(fabs(dotProduct) > 0.1/* || fabs(normVectorBA-normVectorBC)> 4*mapPose->pixPerGrid*/){

        transType= TRANS_ERROR;

    }else{

        // 更新像素的物理尺寸
        mapPose->widthPerPix=REAL_MAP_WIDTH/normVectorBC;
        mapPose->heightPerLin=REAL_MAP_HEIGTH/normVectorBA;

        transType=RIGID;

    }

    return transType;

}




/////////////////////// end //////////////////////////
