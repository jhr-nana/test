/********************************************************************************
* Copyright (c) 2018, JD.COM, Inc .
* All rights reserved.
* FileName: bms_update.c
* Author: Xu Jing   Version: V1.0   Data:2018-07-27
* Description:
* support the bms upgrade to the Pansonic
********************************************************************************/
#include "bms_update.h"
#include "wget_update.h" 
static const unsigned short crc16tab[256] = {
	0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
	0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef,
	0x1231, 0x0210, 0x3273, 0x2252, 0x52b5, 0x4294, 0x72f7, 0x62d6,
	0x9339, 0x8318, 0xb37b, 0xa35a, 0xd3bd, 0xc39c, 0xf3ff, 0xe3de,
	0x2462, 0x3443, 0x0420, 0x1401, 0x64e6, 0x74c7, 0x44a4, 0x5485,
	0xa56a, 0xb54b, 0x8528, 0x9509, 0xe5ee, 0xf5cf, 0xc5ac, 0xd58d,
	0x3653, 0x2672, 0x1611, 0x0630, 0x76d7, 0x66f6, 0x5695, 0x46b4,
	0xb75b, 0xa77a, 0x9719, 0x8738, 0xf7df, 0xe7fe, 0xd79d, 0xc7bc,
	0x48c4, 0x58e5, 0x6886, 0x78a7, 0x0840, 0x1861, 0x2802, 0x3823,
	0xc9cc, 0xd9ed, 0xe98e, 0xf9af, 0x8948, 0x9969, 0xa90a, 0xb92b,
	0x5af5, 0x4ad4, 0x7ab7, 0x6a96, 0x1a71, 0x0a50, 0x3a33, 0x2a12,
	0xdbfd, 0xcbdc, 0xfbbf, 0xeb9e, 0x9b79, 0x8b58, 0xbb3b, 0xab1a,
	0x6ca6, 0x7c87, 0x4ce4, 0x5cc5, 0x2c22, 0x3c03, 0x0c60, 0x1c41,
	0xedae, 0xfd8f, 0xcdec, 0xddcd, 0xad2a, 0xbd0b, 0x8d68, 0x9d49,
	0x7e97, 0x6eb6, 0x5ed5, 0x4ef4, 0x3e13, 0x2e32, 0x1e51, 0x0e70,
	0xff9f, 0xefbe, 0xdfdd, 0xcffc, 0xbf1b, 0xaf3a, 0x9f59, 0x8f78,
	0x9188, 0x81a9, 0xb1ca, 0xa1eb, 0xd10c, 0xc12d, 0xf14e, 0xe16f,
	0x1080, 0x00a1, 0x30c2, 0x20e3, 0x5004, 0x4025, 0x7046, 0x6067,
	0x83b9, 0x9398, 0xa3fb, 0xb3da, 0xc33d, 0xd31c, 0xe37f, 0xf35e,
	0x02b1, 0x1290, 0x22f3, 0x32d2, 0x4235, 0x5214, 0x6277, 0x7256,
	0xb5ea, 0xa5cb, 0x95a8, 0x8589, 0xf56e, 0xe54f, 0xd52c, 0xc50d,
	0x34e2, 0x24c3, 0x14a0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
	0xa7db, 0xb7fa, 0x8799, 0x97b8, 0xe75f, 0xf77e, 0xc71d, 0xd73c,
	0x26d3, 0x36f2, 0x0691, 0x16b0, 0x6657, 0x7676, 0x4615, 0x5634,
	0xd94c, 0xc96d, 0xf90e, 0xe92f, 0x99c8, 0x89e9, 0xb98a, 0xa9ab,
	0x5844, 0x4865, 0x7806, 0x6827, 0x18c0, 0x08e1, 0x3882, 0x28a3,
	0xcb7d, 0xdb5c, 0xeb3f, 0xfb1e, 0x8bf9, 0x9bd8, 0xabbb, 0xbb9a,
	0x4a75, 0x5a54, 0x6a37, 0x7a16, 0x0af1, 0x1ad0, 0x2ab3, 0x3a92,
	0xfd2e, 0xed0f, 0xdd6c, 0xcd4d, 0xbdaa, 0xad8b, 0x9de8, 0x8dc9,
	0x7c26, 0x6c07, 0x5c64, 0x4c45, 0x3ca2, 0x2c83, 0x1ce0, 0x0cc1,
	0xef1f, 0xff3e, 0xcf5d, 0xdf7c, 0xaf9b, 0xbfba, 0x8fd9, 0x9ff8,
	0x6e17, 0x7e36, 0x4e55, 0x5e74, 0x2e93, 0x3eb2, 0x0ed1, 0x1ef0
};

/*******************************************************************************
*Function Name    :recv_updatebms_info
*Description      :deal mc update cmd ACK of bms update
*Input       	  :int iCanID��the can id need to receive
*Input       	  :int iTimeOut:wait time ;unit:S
*Output 		  :NONE
*Return           :int:0 if OK ,-1 on error
*******************************************************************************/
int recv_updatebms_info(int iCanID, int iTimeOut)
{
	fd_set stReadFds;
	bool bTimeOut = false;
	int iCmd = 0, iRet = 0;
	unsigned int uiSize = 0;
	struct timeval stTimePre = { 0 };
	struct timeval stTimeNow = { 0 };
	struct timeval stTimeout = { 0 };
	struct can_frame stData;

	bzero(&stTimePre, sizeof(struct timeval));
	bzero(&stTimeNow, sizeof(struct timeval));
	bzero(&stData, sizeof(struct can_frame));

	stTimeout.tv_sec = iTimeOut;
	while (false == bTimeOut)
	{
		gettimeofday(&stTimePre, NULL);
		FD_ZERO(&stReadFds);
		FD_SET(g_stAgvParm.iCanSocketFd1, &stReadFds);
		if (stTimeout.tv_sec <= 0)
		{
			LOG_ERR("the stTimeout.tv_sec =%d,iTimeout = %d\n", stTimeout.tv_sec, iTimeOut);
			FD_CLR(g_stAgvParm.iCanSocketFd1, &stReadFds);
			return -1;
		}
		if ((iRet = select(g_stAgvParm.iCanSocketFd1 + 1, &stReadFds, NULL, NULL, &stTimeout)) > 0)
		{
			bzero(&stData, sizeof(stData));
			uiSize = read(g_stAgvParm.iCanSocketFd1, &stData, sizeof(struct can_frame));
			if (uiSize == sizeof(struct can_frame))
			{
				if (iCanID == stData.can_id)
				{
					switch (stData.can_id)
					{
					case (CAN_EFF_FLAG | BMS_INQUIRY_CANID):
						LOG_INF("[BMS ACK]:success receive BMS_INQUIRY_CANID ACK\n");
						print_can_frame(&stData);
						bTimeOut = true;
						break;
					case (CAN_EFF_FLAG | BMS_FLASH_ERASE_CANID):
						LOG_INF("[BMS ACK]:success receive BMS_FLASH_ERASE_CANID ACK\n");
						print_can_frame(&stData);
						bTimeOut = true;
						break;
					case (CAN_EFF_FLAG | BMS_PACKAGE_LEN_CANID):
						//LOG_INF("[BMS ACK]:success receive BMS_PACKAGE_LEN_CANID ACK\n");
						//print_can_frame(&stData);
						bTimeOut = true;
						break;
					case (CAN_EFF_FLAG | BMS_BINFILE_TRAS_CANID):
						g_stAgvAttr.iCrcCheckRet = 0;
						//LOG_INF("[BMS ACK]:success receive BMS_BINFILE_TRAS_CANID ACK\n");
						//print_can_frame(&stData);
						bTimeOut = true;
						break;
					default:
						LOG_INF("filter the can id %d\n", stData.can_id);
						gettimeofday(&stTimeNow, NULL);
						stTimeout.tv_sec = stTimeout.tv_sec - (stTimeNow.tv_sec - stTimePre.tv_sec);
						break;
					}
				}
				else
				{
					if (stData.can_id == (CAN_EFF_FLAG | BMS_BINFILE_TRAS_ERR_CANID))
					{
						g_stAgvAttr.iCrcCheckRet = -1;
						LOG_ERR("[BMS ACK]:failed receive BMS_BINFILE_TRAS_ERR_CANID ACK\n");
						print_can_frame(&stData);
						FD_CLR(g_stAgvParm.iCanSocketFd1, &stReadFds);
						return -1;
					}
					else
					{
						LOG_INF("the received BMS CAN id 0x%x is not wanted and drop out\n", stData.can_id);
						gettimeofday(&stTimeNow, NULL);
						stTimeout.tv_sec = stTimeout.tv_sec - (stTimeNow.tv_sec - stTimePre.tv_sec);
					}

				}

			}
			else
			{
				LOG_INF("wrong:bms reply %d data ", uiSize);
				gettimeofday(&stTimeNow, NULL);
				stTimeout.tv_sec = stTimeout.tv_sec - (stTimeNow.tv_sec - stTimePre.tv_sec);
			}
		}
		else
		{
			LOG_ERR("bms can recv failure:[%d-%s]\n", errno, strerror(errno));
			FD_CLR(g_stAgvParm.iCanSocketFd1, &stReadFds);
			return -1;
		}
	}
	FD_CLR(g_stAgvParm.iCanSocketFd1, &stReadFds);
	return 0;
}
/*******************************************************************************
* Function Name      : inquiry_nodeid_info
* Description	     : send inquiry information cmd to bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int inquiry_nodeid_info()
{
	int iRet = 0;
	struct can_frame stInquiryNodeIdData = { 0 };
	int iCount = -1;

	stInquiryNodeIdData.can_id = CAN_EFF_FLAG | BMS_INQUIRY_CANID;
	stInquiryNodeIdData.can_dlc = 0;
	//stInquiryNodeIdData.data[8] = 0;

#if(DEBUG_AGV == 333)
	LOG_INF("send query node id info can frame\n");
	print_can_frame(&stInquiryNodeIdData);
#endif
	iCount = send_can(BATT_CAN_DEV, &stInquiryNodeIdData);
	if (iCount != sizeof(struct can_frame))
	{
		LOG_WRN("send inquiry node id cmd failed\n");
	}
	else
	{
		LOG_INF("send inquiry node id cmd success\n");
	}
	iRet = recv_updatebms_info(stInquiryNodeIdData.can_id, TIME_OUT_8S / 1000);
	if (iRet < 0)
	{
		LOG_INF("Do not get the BMS_INQUIRY_CANID frame\n");
		return -1;
	}
	else
	{
		LOG_INF("get the BMS_INQUIRY_CANID is success\n");
	}
	return 0;
}

/*******************************************************************************
* Function Name      : erase_bms_flash
* Description	     : send the info to erase the bms flash.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int erase_bms_flash()
{
	int iRet = 0;
	struct can_frame stEraseBmsFlashData = { 0 };
	int iCount = -1;
	u32 u32FailCount = 0;

	//stEraseBmsFlashData.can_id = (BMS_FLASH_ERASE_CANID & CAN_EFF_MASK) | CAN_EFF_FLAG;
	stEraseBmsFlashData.can_id = CAN_EFF_FLAG | BMS_FLASH_ERASE_CANID;
	stEraseBmsFlashData.can_dlc = 0;

#if(DEBUG_AGV == 333)
	LOG_INF("send erase bms flash info can frame\n");
	print_can_frame(&stInquiryNodeIdData);
#endif
	iCount = send_can(BATT_CAN_DEV, &stEraseBmsFlashData);
	if (iCount != sizeof(struct can_frame))
	{
		LOG_WRN("send erase bms flash cmd failed\n");
	}
	else
	{
		LOG_INF("send erase bms flash cmd success\n");
	}
	iRet = recv_updatebms_info(stEraseBmsFlashData.can_id, TIME_OUT_8S / 1000);
	if (iRet < 0)
	{
		u32FailCount++;
		LOG_INF("Do not get the BMS_FLASH_ERASE_CANID frame u32FailCount=%d\n", u32FailCount);
		return -1;
	}
	else
	{
		LOG_INF("get the BMS_FLASH_ERASE_CANID is success\n");
	}

	return 0;
}

/*******************************************************************************
* Function Name      : send_package_len_info
* Description	     : send the info to erase the bms flash.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int send_package_len_info(int iLen)
{
	int iRet = 0;
	struct can_frame stPackageLenData = { 0 };
	int iCount = -1;
	stPackageLenData.can_id = CAN_EFF_FLAG | BMS_PACKAGE_LEN_CANID;
	stPackageLenData.can_dlc = 8;
	if ((iLen > PACKAGE_DATA_LENGTH) || (iLen < 0))
	{
		LOG_WRN("the package data length is invalid\n");
		return -1;
	}
	else if (iLen == PACKAGE_DATA_LENGTH)
	{	
		stPackageLenData.data[4] = 0x00;
		stPackageLenData.data[5] = 0x00;
		stPackageLenData.data[6] = 0x04;
		stPackageLenData.data[7] = 0x02;

	}
	else
	{
		stPackageLenData.data[4] = iLen >> 24;
		stPackageLenData.data[5] = iLen >> 16;
		stPackageLenData.data[6] = iLen >> 8;
		stPackageLenData.data[7] = iLen;
	}
#if(DEBUG_AGV == 333)
	LOG_INF("send erase bms flash info can frame\n");
	print_can_frame(&stInquiryNodeIdData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stPackageLenData);
	if (iCount != sizeof(struct can_frame))
	{
		LOG_WRN("send bms package length failed\n");
		return -1;
	}
	iRet = recv_updatebms_info(stPackageLenData.can_id, TIME_OUT_8S / 1000);
	if (iRet < 0)
	{
		LOG_WRN("get bms package length ACK time out\n");
		return -1;
	}
	return 0;
}
/*******************************************************************************
* Function Name      : jump_boot
* Description	     : send the info to jump to the boot.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int jump_boot()
{
	struct can_frame stJumpBootData = { 0 };
	int iCount = -1;

	stJumpBootData.can_id = CAN_EFF_FLAG | BMS_JUMP_BOOT_CANID;
	stJumpBootData.can_dlc = 0;

#if(DEBUG_AGV == 333)
	LOG_INF("send erase bms flash info can frame\n");
	print_can_frame(&stJumpBootData);
#endif
	system("sync");
	sleep(1);
	iCount = send_can(BATT_CAN_DEV, &stJumpBootData);
	if (iCount != sizeof(struct can_frame))
	{
		LOG_WRN("send bms jump_boot failed\n");
		return -1;
	}
	else
	{
		LOG_WRN("send bms jump_boot success\n");
		print_can_frame(&stJumpBootData);
	}
	system("sync");
	sleep(20);
	//search the softeware the version
	int iSongxia = songxia_battery_init_check();
	if (iSongxia < 0)
	{
		LOG_INF("Update flow end:get the bmsversion failed\n");
	}
	else
	{
		LOG_INF("Update flow end:get the bmsversion success-g_stAgvAttr.iBmsVersion[%d]\n", g_stAgvAttr.iBmsVersion);
	}
	return 0;
}
/*******************************************************************************
*Function Name    :bms_get_current_version
*Description      :get mc current version
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error
*******************************************************************************/
int bms_get_current_version()
{
	int iRet = 0;
	iRet = sprintf(stOtaMc.stUpdateMethod.pCurVersion, "%d", g_stAgvAttr.iBmsVersion);
	if (iRet < 0)
	{
		LOG_ERR("get bms current version failed:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	return 0;
}
/*******************************************************************************
*Function Name    :crc16_ccitt
*Description      :get the 16 crc of the buf
*input 			  :char *buf-the data buf
*input 			  :unsigned int len-the  len of data buf
*Output 		  :crc16
*Return           :int:0 if OK,-1 on error
*******************************************************************************/
unsigned short crc16_ccitt(const unsigned char *buf, unsigned int len)
{
	unsigned int counter;
	unsigned short crc = 0;
	for (counter = 0; counter < len; counter++)
		crc = (crc << 8) ^ crc16tab[((crc >> 8) ^ *(unsigned char *)buf++) & 0x00FF];
	return crc;
}
/*******************************************************************************
*Function Name    :ota_bms_tx_app
*Description      :send app to bms
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error
*******************************************************************************/
int bms_tx_app()
{
	char pAppPath[100] = { 0 };
	int iFd = 0, iRet = 0, i = 0, iCount = 0;
	char pSrcData[BMS_DATA_SECTOR] = { 0 };
	ssize_t iSize = 0, iSizePadding = 0;
	struct can_frame stCanFrame = {
		.can_id = (CAN_EFF_FLAG | BMS_BINFILE_TRAS_CANID),
		.can_dlc = MC_DATA_DLC,
	};
	iRet = sprintf(pAppPath, "%s/%s", stOtaMc.stUpdateMethod.pDownloadDir, stOtaMc.stUpdateMethod.pMasterAppName);
	if (iRet < 0)
		return -1;

	iFd = open(pAppPath, O_RDONLY);
	if (iFd < 0)
	{
		LOG_INF("open file error:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}

	iRet = lseek(iFd, 0, SEEK_SET);
	if (iRet < 0)
	{
		LOG_ERR("SEEK_SET the file faild:%d-%s", errno, strerror(errno));
		return -1;
	}
	int iPackageNum = 0;
	int iLastPackage = FALSE;
	int iLastFrameLen = 0;
	LOG_INF("begin to send %s to bms\n", stOtaMc.stUpdateMethod.pMasterAppName);
	do
	{
		bzero(pSrcData, BMS_DATA_SECTOR);
		iSize = read(iFd, pSrcData, BMS_DATA_SECTOR);
		if (iSize < BMS_DATA_SECTOR)
		{
			iPackageNum = iPackageNum + 1;
			iLastPackage = TRUE;
			iLastFrameLen = iSize % 8;
			LOG_INF("Will handle the last package iPackageNum=%d iSize=%d iLastFrameLen=%d\n", iPackageNum, iSize, iLastFrameLen);

		}
		else
		{
			iPackageNum = iPackageNum + 1;
		}
		iSizePadding = (iSize + MC_DATA_DLC - 1) &  ~(MC_DATA_DLC - 1);//padding MC_DATA_DLC*n bytes
		stCanFrame.can_dlc = MC_DATA_DLC;
		iRet = send_package_len_info(iSize+2);//need to confirm
		if (iRet < 0)
		{
			LOG_ERR("send_package_len_info:%d-%s", errno, strerror(errno));
			return -1;
		}
		int iNumPackge = iSizePadding / MC_DATA_DLC;
		for (i = 0; i < iNumPackge; i++)
		{
			if ((iLastPackage == TRUE) && (i == (iNumPackge - 1)) && (iLastFrameLen < MC_DATA_DLC) && (iLastFrameLen!=0))
			{
				usleep(1000);//sleep for 1ms
				memcpy(stCanFrame.data, pSrcData + i*MC_DATA_DLC, iLastFrameLen);
				stCanFrame.can_dlc = iLastFrameLen;
				iCount = send_can(BATT_CAN_DEV, &stCanFrame);
				//LOG_INF("BMS Send:data[3-0] = 0x%02x %02x %02x %02x\n",
				//	stCanFrame.data[3], stCanFrame.data[2], stCanFrame.data[1], stCanFrame.data[0]);
				if (iCount != sizeof(struct can_frame))
				{
					LOG_ERR("send app data can frame failed\n");
					return -1;
				}
			
			}
			else
			{
				usleep(1000);//sleep for 1ms
				memcpy(stCanFrame.data, pSrcData + i*MC_DATA_DLC, MC_DATA_DLC);
				iCount = send_can(BATT_CAN_DEV, &stCanFrame);
				//LOG_INF("BMS Send:data[7-0] = 0x%02x %02x %02x %02x %02x %02x %02x %02x\n",
				//	stCanFrame.data[7], stCanFrame.data[6], stCanFrame.data[5], stCanFrame.data[4],
				//	stCanFrame.data[3], stCanFrame.data[2], stCanFrame.data[1], stCanFrame.data[0]);
				if (iCount != sizeof(struct can_frame))
				{
					LOG_ERR("send app data can frame failed\n");
					return -1;
				}
			}


		}

		//send the 2byte crc and then recv the ack
		usleep(1000);
		u16 iCrc16 = crc16_ccitt(pSrcData, iSize);
		stCanFrame.can_dlc = 2;
		stCanFrame.data[0] = iCrc16 >> 8;
		stCanFrame.data[1] = iCrc16 & 0x00ff;
		iCount = send_can(BATT_CAN_DEV, &stCanFrame);
		//LOG_INF("BMS Send:iCrc16=%x stCanFrame.data[0]=%02x stCanFrame.data[1]=%02x\n",
		//	iCrc16, stCanFrame.data[0], stCanFrame.data[1]);
		if (iCount <= 0 )
		{
			LOG_ERR("send app data crc can frame failed\n");
			return -1;
		}
		iRet = recv_updatebms_info(stCanFrame.can_id, TIME_OUT_8S / 1000);
		if (iRet < 0)
		{
			LOG_ERR("get update data ACK time out\n");
			return -1;
		}

	} while (BMS_DATA_SECTOR == iSize);

	LOG_INF("send %s to bms success\n", stOtaMc.stUpdateMethod.pMasterAppName);
	return 0;
}

/*******************************************************************************
*Function Name    :bms_update_init
*Description      :init D500_20  mc update var����stOtaMc
*Input       	  :char * pConfFilePath
*Input       	  :iBatType
*Output 		  :NONE
*Return           :int:0 if OK ,-1 on error
*******************************************************************************/
int bms_update_init(char *pConfFilePath, int iBatType)
{
	int iRet = 0;
	char pVersionFilePath[100] = { 0 };
	update_method stUpdateMethod = { 0 };
	if (NULL == pConfFilePath)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}

	bzero(&stOtaMc, sizeof(ota_mc));
	stOtaMc.get_current_version = bms_get_current_version;
	stOtaMc.get_new_version = ota_mc_get_new_version;
	stOtaMc.end_update = erase_bms_flash;
	stOtaMc.get_app = ota_mc_get_app;
	stOtaMc.tx_app = bms_tx_app;
	stOtaMc.excute_app = jump_boot;

	iRet = ini_read(pConfFilePath, "autoflow_conf", "update_method", stUpdateMethod.pUpdateMethod, sizeof(stUpdateMethod.pUpdateMethod));
	if (iRet < 0)
	{
		strcpy(stUpdateMethod.pUpdateMethod, "ftp");
	}

	if (strcasecmp(stUpdateMethod.pUpdateMethod, "ftp") == 0)
	{
		iRet = _ftp_mc_init(pConfFilePath, &stUpdateMethod);
		if (iRet < 0)
		{
			LOG_ERR("init ftp configure failure\n");
			return iRet;
		}
	}
	sprintf(stUpdateMethod.pDownloadDir, "%s", UPDATE_BMS_DIR);
	if (iBatType == BAT_TYPE_SONGXIA)
	{
		sprintf(stUpdateMethod.pMasterAppName, "%s", PANSONIC_APP_NAME);
	}
	sprintf(stUpdateMethod.pVersionFileName, "%s", BMS_VERSION_FILE_NAME);
	stOtaMc.stUpdateMethod = stUpdateMethod;
	return 0;
}
/*******************************************************************************
*Function Name    :update_agv_bms
*Description      :update update_agv_bms
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error
*******************************************************************************/
int update_agv_bms(int iBatType)
{
	int iRet = 0, iTryTime = 0;
	char pPWD[200] = { 0 };
	char pStr[200] = { 0 };
	char *Pointer = NULL;
	int iResult = 0;
	int iNeedSleep = TRUE;
	LOG_INF("Begin to update the agv_bms\n");
	Pointer = getcwd(pPWD, sizeof(pPWD));
	if (NULL == Pointer)
	{
		LOG_WRN("get current worker path failed,use default /\n");
		strcpy(pPWD, "/");
	}
	///add wget update,start by tiger.101 
	g_bBmsAppWgetOK = false;
	iRet = wget_download_file(BMS_APP_URL, BMS_TGZ, TRY_5_TIMES);
	LOG_INF("wget %s %s\n", BMS_TGZ, (0 == iRet) ? "Success" : "Failed");
	if (0 == iRet)
	{
		iRet = wget_untar_file(BMS_TGZ, UPDATE_BMS_DIR);
		if (iRet < 0)
		{
			g_bBmsAppWgetOK = false;
		}
		LOG_INF("untar %s %s\n", BMS_TGZ, (g_bBmsAppWgetOK == true) ? ("Success") : ("Failed"));
	}
	/////add wget update,end by tiger.101 

	iRet = bms_update_init(CONFIGURE_FILE_PATH, iBatType);
	if (iRet < 0)
	{
		LOG_ERR("ota mc init failed\n");
		return -1;
	}
	iRet = stOtaMc.get_current_version();
	if (iRet < 0)
	{
		LOG_ERR("ota mc get current version failed\n");
		iResult = -1;
		iNeedSleep = FALSE;
		goto out;
	}
	iRet = stOtaMc.get_new_version(g_bBmsAppWgetOK);//by tiger.101
	if (iRet < 0)
	{
		LOG_ERR("ota mc get new version failed\n");
		iResult = -1;
		iNeedSleep = FALSE;
		goto out;
	}
	iRet = strcasecmp(stOtaMc.stUpdateMethod.pNewVersion, stOtaMc.stUpdateMethod.pCurVersion);
	if (iRet <= 0)
	{
		LOG_INF("BMS need no update ,the new version(%s) = the cur version(%s)\n", stOtaMc.stUpdateMethod.pNewVersion, stOtaMc.stUpdateMethod.pCurVersion);
		iResult = 0;
		iNeedSleep = FALSE;
		goto out;
	}
	else
	{
		LOG_INF("BMS need to update ,the new version(%s), the cur version(%s)\n", stOtaMc.stUpdateMethod.pNewVersion, stOtaMc.stUpdateMethod.pCurVersion);
	}

	iRet = stOtaMc.get_app(g_bBmsAppWgetOK);//by tiger.101
	if (iRet < 0)
	{
		LOG_ERR("get mc app[%s] failed\n", stOtaMc.stUpdateMethod.pMasterAppName);
		iResult = -1;
		iNeedSleep = FALSE;
		goto out;
	}
	iRet = inquiry_nodeid_info();
	if (iRet < 0)
	{
		iResult = iRet;
		goto out;
	}
	iRet = stOtaMc.end_update();
	if (iRet < 0)
	{
		iResult = iRet;
		goto out;
	}
	iTryTime = 0;
	while ((iTryTime++ < BMS_TX_APP_COUNT) && (iRet = stOtaMc.tx_app()) < 0) //send app one
	{
		LOG_WRN("%dth send %s to mc failed\n", iTryTime, stOtaMc.stUpdateMethod.pMasterAppName);
		if (BMS_TX_APP_COUNT == iTryTime)
		{
			iResult = iRet;
			goto out;
		}
	}

	iRet = stOtaMc.excute_app();
	if (iRet < 0)
	{
		LOG_ERR("excute mc app failed\n");
		iResult = -1;
		goto out;
	}
	else
	{
		iNeedSleep = FALSE;
		LOG_INF("excute mc app success\n");
	}
out:
	//unlink tmp file and dir
	iRet = sprintf(pStr, "%s/%s", UPDATE_BMS_DIR, BMS_VERSION_FILE_NAME);
	if (iRet > 0)
		unlink(pStr);
	iRet = sprintf(pStr, "%s/%s", UPDATE_BMS_DIR, PANSONIC_APP_NAME);
	if (iRet > 0)
		unlink(pStr);
	chdir(pPWD);
	iRet = rmdir(UPDATE_BMS_DIR);
	if (iRet < 0)
	{
		LOG_WRN("remove dir %s failed:[%d-%s]\n", UPDATE_BMS_DIR, errno, strerror(errno));
	}
	if (iNeedSleep)
	{
		LOG_INF("Prepare to sleep 30s when exit the bms update\n");
		sleep(30);
	}
	return iResult;
}