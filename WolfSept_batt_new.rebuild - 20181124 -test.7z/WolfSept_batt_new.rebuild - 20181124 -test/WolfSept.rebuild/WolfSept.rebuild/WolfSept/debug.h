#ifndef _DEBUG_H__
#define _DEBUG_H__

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <pthread.h>

#define MAX_LOG_FILE_NAME_SIZE 40
#define MAX_LOG_FILE_SIZE      64  // MB

#define PRINT_LEVEL_INF			(0)
#define PRINT_LEVEL_MCU			(1)
#define PRINT_LEVEL_CMD			(2)	
#define LRFINISH_LEVEL_MSG		(3)
#define MCHEARTBEAT_LEVEL_MSG	(4)
#define PGV_HEARTBEAT_MSG		(5)
#define PRINT_LEVEL_EVENT		(6)
#define PRINT_LEVEL_ACTION		(7)
#define SHELF_DIFF_MSG			(8)//add by jxu 20180222
#define PGV_JITTER_MSG			(9)//add by jxu 20180313
#define PRINT_LEVEL_NET			(10)
#define PRINT_LEVEL_BATTERY			(11) //add by tiger.86

enum
{
	INF = 0,
	DBG = 1,
	WRN = 2,
	ERR = 3
};

extern int __my_printf(int level, char *file, int line, char *func, char *format, ...);
extern int __basic_log(int type, int level, char *file, int line, char *func, char *format, ...);
extern int __basic_0_log(int type, char *format, ...);
extern int __basic_1_log(int type, char *format, ...);

#define FILE_NAME   (strrchr(__FILE__,'/')==NULL) ? __FILE__ : (strrchr(__FILE__,'/')+1)

#define LOG_INF(...)  __basic_log(PRINT_LEVEL_INF, INF, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define LOG_DBG(...)  __basic_log(PRINT_LEVEL_INF, DBG, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define LOG_WRN(...)  __basic_log(PRINT_LEVEL_INF, WRN, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define LOG_ERR(...)  __basic_log(PRINT_LEVEL_INF, ERR, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define LOG_BATTERY(...)  __basic_log(PRINT_LEVEL_BATTERY, INF, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)//by tiger.86

#define MC_LOG_INF(...)  __basic_log(MCHEARTBEAT_LEVEL_MSG, INF, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define MCU_LOG(...) __basic_1_log(PRINT_LEVEL_MCU, ##__VA_ARGS__)
#define NET_LOG(...) __basic_1_log(PRINT_LEVEL_NET, ##__VA_ARGS__)
#define EVENT_LOG(...) __basic_1_log(PRINT_LEVEL_EVENT, ##__VA_ARGS__)
#define ACTION_LOG(...) __basic_0_log(PRINT_LEVEL_ACTION, ##__VA_ARGS__)

#define my_printf(...)  __my_printf(PRINT_LEVEL_INF, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define msg_printf(...) __my_printf(PRINT_LEVEL_INF, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define mcu_printf(...) __my_printf(PRINT_LEVEL_MCU, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define cmd_printf(...) __my_printf(PRINT_LEVEL_CMD, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define lrfinish_printf(...) __my_printf(LRFINISH_LEVEL_MSG, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define mcheartbeat_printf(...) __my_printf(MCHEARTBEAT_LEVEL_MSG, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define pgv_printf(...) __my_printf(PGV_HEARTBEAT_MSG, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)
#define shelfdiff_printf(...) __my_printf(SHELF_DIFF_MSG, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__)//add by jxu 20180222
#define pgvjitter_printf(...) __basic_log(PGV_JITTER_MSG, INF, FILE_NAME, __LINE__, (char*)__FUNCTION__, ##__VA_ARGS__);//add by jxu 20180313

#endif/*_DEBUG_H__*/
