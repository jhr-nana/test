/********************************************************************************
* Copyright (c) 2017, JD.COM, Inc .
* All rights reserved.
* FileName: tc_v1.c
* Author: tongkedong   Version: V1.0   Data:2017-12-18
* Description:
* top control low-level support api code
********************************************************************************/
#ifndef _TC_V1_H_
#define _TC_V1_H_
#include "global_var.h"
#include "device.h"
#include "debug.h"


typedef struct tc_can_cmd_req {
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned char  ireserve[5];			//Byte[0-4]
	unsigned char  iCmd;				//Byte[5]
	unsigned char  iStyle;				//Byte[6]
	unsigned char  iSeq;				//Byte[7]
} tc_can_cmd_req_t;

typedef struct tc_can_cmd_ack{
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned short iData1;				//Byte[0-1]
	unsigned short iData2;				//Byte[2-3]
	unsigned char  iReserve;			//Byte[4]
	unsigned char  iCmd;				//Byte[5]
	unsigned char  iStyle;				//Byte[6]
	unsigned char  iSeq;				//Byte[7]
} tc_can_cmd_ack_t;

typedef struct tc_can_cmd_fin
{
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned short iData1;				//Byte[0-1]
	unsigned short iData2;				//Byte[2-3]
	unsigned char  iReserve;			//Byte[4]
	unsigned char  iCmd;				//Byte[5]
	unsigned char  iStyle;				//Byte[6]
	unsigned char  iSeq;				//Byte[7]
} tc_can_cmd_fin_t;

typedef struct tc_can_notify
{
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned short iData1;				//Byte[0-1]
	unsigned short iData2;				//Byte[2-3]
	unsigned short iReserve;			//Byte[4-5]
	unsigned char  iStyle;				//Byte[6]
	unsigned char  iSeq;				//Byte[7]
} tc_can_notify_t;

extern int tc_v1_check_version();
extern int tc_v1_get_flag(u8 u8FlagVar);
extern int tc_v1_set_flag(u8 u8FlagVar, u32 u32Value);
extern int tc_v1_get_param(u8 u8ParamVar);
extern int tc_v1_set_param(u8 u8ParamVar, float fValue);
extern int tc_v1_enable_wdg();
extern int tc_v1_start();
extern int tc_v1_reset();
extern int tc_v1_stop();
extern void tc_v1_deal_ack(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
extern void tc_v1_deal_angle_ack(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
extern void tc_v1_deal_fin(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
extern int tc_v1_deal_heartbeat(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
extern int tc_v1_deal_exception(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);

extern int tc_v1_send_angle_offset(u16 u16Angle);
extern int tc_v1_cntl_lift_motor(u8 u8Operate, u8 u8Weight);
extern int tc_v1_cntl_cycle_motor(u8 u8Operate, u8 u8Weight, u16 u16Angle, u16 u16Speed);

#endif //_MC_V1_H_
