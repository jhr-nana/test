/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* All rights reserved.
* FileName: udp.c
* Author: Zhiyong Xu   Version: V1.0   Data:2017-06-23
* Description:
********************************************************************************/
#include "global_var.h"
#include "udp.h"
#include "statistical_info.h" 
#include "debug.h"

/*******************************************************************************
* Function Name      : init_udp
* Description	     : Initialize the udp socket.
* Input 		     : uiPort: recieve port/send port.
* Output		     : NONE
* Return		     : fd if OK, -1 on error
*******************************************************************************/
int init_udp(uint16_t uiPort)
{
	//struct ifreq if_net = { 0 };
	struct sockaddr_in stServer = { 0 };
	int iSockfd = 0;
	int iOptval = 1;

	if ((iSockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
	{
		LOG_ERR("udp socket error: [%s]\n", strerror(errno));
		return -1;
	}

	if (setsockopt(iSockfd, SOL_SOCKET, SO_REUSEADDR, (const void*)&iOptval, sizeof(int)) < 0)
	{
		LOG_ERR("udp socket set SO_REUSEADDR error: [%s]\n", strerror(errno));
		return -1;
	}

	//strncpy(if_net.ifr_name, UDP_DEV, IFNAMSIZ); // set name of if as "wlan0"
	//if (setsockopt(iSockfd, SOL_SOCKET, SO_BINDTODEVICE, (char *)&if_net, sizeof(if_net)))
	//{
	//	LOG_INF("bind wlan0 error :%s \n", strerror(errno));
	//	return -1;
	//}
	//else
	//{
	//	if (!(ioctl(iSockfd, SIOCGIFADDR, (char *)&if_net)))
	//	{
	//		LOG_INF("my host ip :%s \n", inet_ntoa(((struct sockaddr_in*)(&if_net.ifr_addr))->sin_addr));
	//	}
	//	else
	//	{
	//		LOG_INF("get host ip error\n");
	//	}
	//}
	bzero(&stServer, sizeof(stServer));
	stServer.sin_family = AF_INET;
	stServer.sin_addr.s_addr = htonl(INADDR_ANY);
	stServer.sin_port = htons(uiPort);
	if (bind(iSockfd, (struct sockaddr *)&stServer, sizeof(stServer)) < 0)
	{
		LOG_INF("bind error: %s!\n", strerror(errno));
		close(iSockfd);
		return -1;
	}

	return iSockfd;
}

/*******************************************************************************
* Function Name      : send_udp
* Description	     : send data by udp.
* Input 		     : iSockfd: the udp socket,
* Input 		     : pBuf: data buffer pointer
* Input 		     : iLen: data length
* Input 		     : uiSendPort: send port
* Input 		     : cSendIP : ip to be sended.
* Output		     : NONE
* Return		     : return the send data number,-1 on error.
*******************************************************************************/
int send_udp(int iSockfd, const void* pBuf, int iLen, uint16_t uiSendPort, char *cSendIP)
{
	int iNum = 0;
	struct sockaddr_in stAddr; // send socket addr

	if (pBuf == NULL)
	{
		LOG_ERR("udp send buffer is NULL\n");
		return -1;
	}

	if (cSendIP == NULL)
	{
		LOG_ERR("udp send server ip is NULL\n");
		return -1;
	}

	stAddr.sin_family = AF_INET;
	stAddr.sin_port = htons(uiSendPort);
	stAddr.sin_addr.s_addr = inet_addr(cSendIP);
	if (stAddr.sin_addr.s_addr == INADDR_NONE)
	{
		LOG_ERR("incorrect ip address!\n");
		return -1;
	}

	iNum = sendto(iSockfd, pBuf, iLen, 0, (struct sockaddr *)&stAddr, sizeof(stAddr));
	if (iNum < 0)
	{
		LOG_ERR("udp send error:%s\n", strerror(errno));
		return -1;
	}

	return iNum;
}

/*******************************************************************************
* Function Name      : send_udp
* Description	     : send data by udp.
* Input 		     : iSockfd: the udp socket,
* Input 		     : pBuf: data buffer pointer
* Input 		     : iLen: data length
* Input 		     : uiSendPort: send port
* Input 		     : cSendIP : ip to be sended.
* Output		     : NONE
* Return		     : return the send data number,-1 on error.
*******************************************************************************/
int send_msg2console(const void* pBuf, int iLen)
{
	int iNum = 0;
	int iSockfd = g_stAgvParm.iMsgSocketFd;
	uint16_t uiSendPort = g_stAgvParm.iMsgSendServerPort;
	char *cSendIP = g_stAgvParm.cServerIp;

	iNum = send_udp(iSockfd, pBuf, iLen, uiSendPort, cSendIP);

	return iNum;
}

/*******************************************************************************
* Function Name      : send_inf2collector
* Description	     : send data by udp.
* Input 		     : iSockfd: the udp socket,
* Input 		     : pBuf: data buffer pointer
* Input 		     : iLen: data length
* Input 		     : uiSendPort: send port
* Input 		     : cSendIP : ip to be sended.
* Output		     : NONE
* Return		     : return the send data number,-1 on error.
*******************************************************************************/
int send_inf2collector(const void* pBuf, int iLen)
{
	int iNum = 0;
	int iSockfd = g_stAgvParm.iInfSocketFd;
	uint16_t uiSendPort = g_stAgvParm.iInfSendServerPort;
	//char *cSendIP = g_stAgvParm.cServerIp; //configure the ip
	//iNum = send_udp(iSockfd, pBuf, iLen, uiSendPort, cSendIP);

	iNum = send_udp(iSockfd, pBuf, iLen, uiSendPort, g_stAgvAttr.pWarehouseBrainIp);

	return iNum;
}

/*******************************************************************************
* Function Name      : recv_udp
* Description	     : receive data by udp.
* Input 		     : iSockfd: udp socket
* Input 		     : pBuf: receive data buffer
* Input 		     : iMaxSize: the max size of recv buffer.
* Output		     : NONE
* Return		     : return the receive data number,-1 on error.
*******************************************************************************/
int recv_udp(int iSockfd, void *pBuf, int iMaxSize, bool bBlock)
{
	int iNum = 0;
	//int flags = MSG_DONTWAIT;	// or flags = 0
	int flags = 0;	// WAIT if no udp message received
	struct sockaddr_in stClientAddr;
	socklen_t iLen = sizeof(stClientAddr);

	if (pBuf == NULL)
	{
		LOG_ERR("udp recv buff is NULL\n");
		return -1;
	}

	if (bBlock == TRUE)
		flags = 0;
	else
		flags = MSG_DONTWAIT;

	iNum = recvfrom(iSockfd, (void *)pBuf, iMaxSize, flags, (struct sockaddr *)&stClientAddr, &iLen);
	
	return iNum;
}

/*******************************************************************************
* Function Name      : close_udp
* Description	     : close udp.
* Input 		     : iSockfd: udp socket
* Output		     : NONE
* Return		     : -1 on error, 0 on success.
*******************************************************************************/
int close_udp(int iSockfd)
{
	int iRet = 0;

	if (iSockfd > 0) {
		iRet = close(iSockfd);
		if (iRet < 0)
		{
			LOG_WRN("udp recv error:%s\n", strerror(errno));
		}
	}

	return iRet;
}