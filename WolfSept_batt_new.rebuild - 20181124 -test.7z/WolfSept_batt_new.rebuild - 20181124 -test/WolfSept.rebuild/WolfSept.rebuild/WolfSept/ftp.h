/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* All rights reserved.
* FileName:FTP.H
* Author: Menghu Wang   Version: V1.0   Data:2017-05-13
* Description:THE INTERFACE OF FTP FUNCTION LIB
*others: null
*History:
	1. Date:
	    Author:
	    Modification:
	    VERSION:
********************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __FTP_H_
	#define __FTP_H_
/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#include <termios.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <regex.h>
#include <stdbool.h>
#include <linux/can.h>
#include <sys/select.h>
#include <signal.h>
#include <sys/time.h>
#include "ini_rw.h"
#include "global_var.h"
#include "debug.h"
#include "ota_mc.h"
//#include "device.h"
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
extern bool g_bRecvThreadOk;

/* Exported macro ------------------------------------------------------------*/
///by tiger.07 start
#define SIG_SEG_ERROR     777
#define SIG_STOP_ERROR    888
#define SIG_PIPE_ERROR    666
#define UPLOAD_OVER_TIME  5 //unit: seconds
#define WRIET_OVER_TIME   2 //unit:seconds
///end ,by tiger.07

#define MM_TGZ  "/root/jdagvclientserver/jdagvserver/mm.tgz"
#define MC_TGZ  "/root/jdagvclientserver/jdagvserver/mc.tgz"
#define TC_TGZ  "/root/jdagvclientserver/jdagvserver/tc.tgz"
#define BMS_TGZ  "/root/jdagvclientserver/jdagvserver/tc.tgz"

extern bool g_bMmAppWgetOK ;
extern bool g_bMcAppWgetOK ;
extern bool g_bTcAppWgetOK;
extern bool g_bBmsAppWgetOK;
#define MAXLINE 100
#define INITIAL_VERSION "0.0.0.0"
#define UPDATA_CONF "/root/jdagvclientserver/jdagvserver/flow.conf"
#define UPDATA_MASTER_DIR "/root/jdagvclientserver/jdagvserver/dcu_update"//by tiger.45
#define UPDATA_DSP_STM_DIR "/root/jdagvclientserver/jdagvserver/dsp_update"//by tiger.45


#define DOWNLOAD_MAX_COUNT 5 /*the max download app count,when failed*/
#define DEFAULT_FTP_PORT 21  //the ftp default control port
#define POLY 0xEDB88320L		//the crc32 is the same with WINRAR
#define KB 1024
#define FTP_SECTION "ftp_conf"//modified by tiger.06

///start by tiger.12



#define TC_LOG_PATH "/var/log/TcRam.log"
#define MC_LOG_PATH "/var/log/McRam.log"

#define MC_UPLOAD_LOG_OK (0x5a)
#define TC_UPLOAD_LOG_OK (0x5a)
#define MC_UPLOAD_LOG_FLAG (8)
#define TC_UPLOAD_LOG_FLAG (8)
#define GET_MC_LOG_DATA (13)
#define GET_TC_LOG_DATA (9)
///end,by tiger.12
///start by tiger.37
#define MC_LOG_TOTAL_TYPE	3
#define TC_LOG_TOTAL_TYPE	1
#define UPLOAD_OK_DATA_5    1
extern enMcLogType eMcLogType;
extern enTcLogType eTcLogType;

extern int s_iDspType[2];//g_iDspType[0]:TC ;g_iDspType[1]:MC, add by tiger.36

///end by tiger.37
/* Exported functions ------------------------------------------------------- */
extern int update_app(void);
extern int save_log_arm(int exception);
extern int save_log_dsp(int exception);
extern int upload_log(void);
extern int read_conf(const char *pFilename, const char *pName, char *pDes);
extern int update_d500_10_15(void);
int parse_hex_line(char *pStr, unsigned char *pOut);
int judge_car_num(int iNum, char *pCars);
extern void ftp_init(void);
extern int _ftp_mc_init(const char *pConfFilePath, update_method *pUpdateMaster);
extern  unsigned int get_crc(const char *pFilename);
//extern int ftp_get_dsp_log(bool bIsMC);
extern int save_log_img(int exception);//add by jxu 20180222
extern int save_log_coredump();
extern int ftp_recv_can_v2(int iCanID, int iTimeOut);//add by tiger.43
#endif /* __FTP_H_ */
