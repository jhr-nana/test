#include <pthread.h>
#include "linkqueue.h"
#include "debug.h"

/*******************************************************************************
* Function Name		 : get_queueitem_size
* Description	     : get queueitem size.
* Input 		     : pQueue: linkQueue pointer
* Output		     : NONE
* Return		     : -1 on error, return byte size of item on success
*******************************************************************************/
int get_queueitem_size(linkQueue * pQueue)
{
	int iRet = -1;

	pthread_mutex_lock(&pQueue->queueMutex);
	if ((pQueue != NULL) && (pQueue->iLength > 0))
	{
		iRet = pQueue->pHead->iSize;
	}
	pthread_mutex_unlock(&pQueue->queueMutex);

	return iRet;
}

/*******************************************************************************
* Function Name		 : linkqueue_create
* Description	     : create linkqueue.
* Input 		     : pQueue: linkQueue pointer
* Output		     : NONE
* Return		     : NULL on error, linkequeue pointer on success.
*******************************************************************************/
linkQueue * linkqueue_create()  
{
	linkQueue * pRet = (linkQueue *)malloc(sizeof(linkQueue));

	if (pRet != NULL)
	{
		pRet->pHead = NULL;
		pRet->pTail = NULL;
		pRet->iLength = 0;
		pthread_mutex_init(&pRet->queueMutex, NULL);
	}

	return pRet;
}

/*******************************************************************************
* Function Name		 : linkqueue_destroy
* Description	     : destroy linkqueue.
* Input 		     : pQueue: linkQueue pointer
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void linkqueue_destroy(linkQueue* pQueue) 
{
	if (pQueue != NULL)
	{
		linkqueue_clear(pQueue);
		free(pQueue);
		pQueue = NULL;
	}
}

/*******************************************************************************
* Function Name		 : linkqueue_clear
* Description	     : clear linkqueue.
* Input 		     : pQueue: linkQueue pointer
* Output		     : NONE
* Return		     : -1 on error, 0 on success.
*******************************************************************************/
void linkqueue_clear(linkQueue* pQueue)
{
	void *pItem = NULL;
	int iSize = 0;

	while (linkqueue_length(pQueue) > 0)
	{
		iSize = get_queueitem_size(pQueue);
		pItem = malloc(iSize);		
		if (pItem != NULL)
		{
			linkqueue_retrieve(pQueue, pItem);
			free(pItem);
		}
	}
}

/*******************************************************************************
* Function Name		 : linkqueue_append
* Description	     : append a node to linkqueue tail.
* Input 		     : pQueue: linkQueue pointer
* Input 		     : pItem: item buffer
* Input 		     : iSize: byte size of item
* Output		     : NONE
* Return		     : -1 on error, 0 on success.
*******************************************************************************/
int linkqueue_append(linkQueue* pQueue, const void *pItem, const int iSize)  
{	
	linkQueueNode* pNode = NULL;
	void *pNodeItem = NULL;

	if ((pQueue == NULL) || (pItem == NULL) || (iSize <= 0)) {
		return -1;
	}

	pNode = (linkQueueNode *)malloc(sizeof(linkQueueNode));
	if (pNode == NULL) {
		LOG_ERR("malloc memory for linkQueueNode\n");
		return -1;
	}
	pNode->iSize = 0;
	pNode->pItem = NULL;
	pNode->pNext = NULL;

	pNodeItem = malloc(iSize);	
	if (pNodeItem == NULL) {
		LOG_ERR("malloc memory for item data\n");
		goto error_0;
	}

	// nothing error, lock pQueue->queueMutex for multi-thread model
	pthread_mutex_lock(&pQueue->queueMutex);

	memcpy(pNodeItem, pItem, iSize);
	pNode->pItem = pNodeItem;
	pNode->iSize = iSize;
	if (pQueue->iLength > 0)
	{
		pQueue->pTail->pNext = pNode;
		pQueue->pTail = pNode;
		pNode->pNext = NULL;
	}
	else
	{
		pQueue->pHead = pNode;
		pQueue->pTail = pNode;
		pNode->pNext = NULL;
	}

	pQueue->iLength++;
	pthread_mutex_unlock(&pQueue->queueMutex);

	return 0;
	
error_0:
	if (pNode) {
		free(pNode);
		pNode = NULL;
	}

	return -1;
}

/*******************************************************************************
* Function Name		 : linkqueue_retrieve
* Description	     : retrieve linkqueue.
* Input 		     : pQueue: linkQueue pointer
* Input 		     : pItem: item buffer
* Output		     : NONE
* Return		     : -1 on error, return byte size on success.
*******************************************************************************/
int linkqueue_retrieve(linkQueue* pQueue, void * pItem)  
{
 
	linkQueueNode* pNode = NULL;
	int iRet = -1;

	pthread_mutex_lock(&pQueue->queueMutex);
	if ((pQueue != NULL) && (pQueue->iLength > 0))
	{
		pNode = pQueue->pHead;
		pQueue->pHead = pNode->pNext;

		if (pNode->pItem != NULL)
		{
			memcpy(pItem, pNode->pItem, pNode->iSize);
			free(pNode->pItem);
			pNode->pItem = NULL;
		}

		iRet = pNode->iSize;

		free(pNode);
		pNode = NULL;

		pQueue->iLength--;
		if (pQueue->iLength == 0)
		{
			pQueue->pHead = NULL;
			pQueue->pTail = NULL;
		}
	}
	pthread_mutex_unlock(&pQueue->queueMutex);

	return iRet;
}

/*******************************************************************************
* Function Name		 : linkqueue_peek
* Description	     : peek linkqueue.
* Input 		     : pQueue: linkQueue pointer
* Input 		     : pItem: item buffer
* Output		     : NONE
* Return		     : -1 on error, return byte size of item on success
*******************************************************************************/
int linkqueue_peek(linkQueue* pQueue, void *pItem)
{
	int iRet = -1;

	pthread_mutex_lock(&pQueue->queueMutex);
	if ((pQueue != NULL) && (pQueue->iLength > 0))
	{
		memcpy(pItem, pQueue->pHead->pItem, pQueue->pHead->iSize);
		iRet = pQueue->pHead->iSize;
	}
	pthread_mutex_unlock(&pQueue->queueMutex);

	return iRet;
}

/*******************************************************************************
* Function Name		 : linkqueue_length
* Description	     : get  linkqueue length.
* Input 		     : pQueue: linkQueue pointer
* Input 		     : pItem: item buffer
* Output		     : NONE
* Return		     : -1 on error, return inkqueue length on success
*******************************************************************************/
int linkqueue_length(linkQueue* pQueue) // O(1)
{
	int iRet = -1;

	pthread_mutex_lock(&pQueue->queueMutex);
	if (pQueue != NULL)
	{
		iRet = pQueue->iLength;
	}
	pthread_mutex_unlock(&pQueue->queueMutex);

	return iRet;
}

/*******************************************************************************
* Function Name		 : linkqueue_test
* Description	     : test linkqueue.
* Input 		     : NONE
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void linkqueue_test()
{
	int a = 5;
	int b = 0;
	int ret = 0;

	struct node
	{
		int a;
		int b;
		int c;

	} n1;
	n1.a = 10;
 

	linkQueue *pLinkQueue = linkqueue_create();
	if (pLinkQueue != NULL)
	{
		printf("create link queue success\n");
	}
	linkqueue_append(pLinkQueue, &a, sizeof(a));
	a = 6;
	linkqueue_append(pLinkQueue, &a, sizeof(a));
	linkqueue_append(pLinkQueue, &n1, sizeof(n1));
	ret = linkqueue_retrieve(pLinkQueue, &b);
	printf("data:%d -ret:%d\n", a, ret);
	ret = linkqueue_retrieve(pLinkQueue, &b);
	printf("data:%d -ret:%d\n", a, ret);
	
	ret = linkqueue_retrieve(pLinkQueue, &n1);
	printf("data:%d -ret:%d\n", n1.a, ret);
	linkqueue_destroy(pLinkQueue);
}