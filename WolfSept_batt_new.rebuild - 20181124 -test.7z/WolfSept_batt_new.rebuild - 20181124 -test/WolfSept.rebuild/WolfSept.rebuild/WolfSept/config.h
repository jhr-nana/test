#ifndef _CONFIG_H__
#define _CONFIG_H__

#define CONSOLE_SERVER_SECTION "upserverip_conf" //by tiger.15
#define FTP_SERVER_SECTION "ftp_conf" //by tiger.15

extern int get_value(char *pKey, char *pValue, const char *pFile);
extern int set_value(char *pKey, char *pValue, const char *pFile);
extern int get_agv_name(int * pAgvName);
extern int get_charge_type(char * pChargeType);
extern int check_ip(const char * ip);
extern int get_server_ip(char * pServerIp);
extern int get_big_ver_date(int * pBigVer, int * pBigVerDate);
extern int get_check_point(char * pCheckPoint);
extern int get_point_report(char * pPointReport);
extern int get_enable_test(char * pEnableTest);
extern int get_enable_debug(char * pEnableDebug);
extern int get_enable_send_statistical(char * pEnableStatistical);
extern int get_enable_pgv_period(char * pEnablePgvPeriod);//add by jxu 20180709
extern int set_check_soc_flag(const char * pSoc);//by tiger.102
extern int get_check_soc_flag(char * pSoc);//by tiger.102

extern int set_console_server_ip(char * pServerIp);
extern int set_ftp_server_ip(char * pServerIp);

#endif/*_CONFIG_H__*/