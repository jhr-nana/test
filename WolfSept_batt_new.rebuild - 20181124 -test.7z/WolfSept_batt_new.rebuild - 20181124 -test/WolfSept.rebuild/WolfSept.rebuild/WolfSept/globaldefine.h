#ifndef GLOBALDEFINE_H
#define GLOBALDEFINE_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>

#ifndef NULL
#define NULL ((void *)0)
#endif

#define  EPSILON (1e-6)

// 如果算法使用在下方摄像头时，必须注释掉此宏定义
#define CAMERA_UP           (1)

#define CONSERVATIVE_DECODE  (1)

// for display on PC
// #define DISPLAY             (1)

/// the maximum and minimum 2d code index
#define MIN_CODE_INDEX  (0)
#define MAX_CODE_INDEX  (19991999)

#define  WHITE              (0xFF)
#define  BLACK              (0x00)


#define  DELTA_LEN_MAX      (25)
#define  DELTA_LEN_MIN      (3)

#define  STANDARD_RING_NUM  (3)
#define  STANDARD_RING_MAX_NUM  (12)

// 定义码图中色块网格的尺寸比例
#define RING_R1             (2)
#define RING_R2             (1)
#define RING_R3             (1)
#define LINE_WIDTH          (3)
#define LINE_LENGTH         (16)
#define BAND_PIX            (5)
#define BAND_LINE           (5)

#define CODE_BLOCK          (4)
#define INFO_MATRIX_WIDTH   (5*CODE_BLOCK)
#define INFO_MATRIX_HEIGHT  (5*CODE_BLOCK)

#define MAP_WIDTH           (30)
#define MAP_HEIGHT          (30)

// 码图中信息矩阵的尺寸
#define INFO_MATRIX_ROW     (INFO_MATRIX_HEIGHT/CODE_BLOCK)       // INFO_MATRIX_WIDTH/CODE_BLOCK
#define INFO_MATRIX_COLUMN  (INFO_MATRIX_WIDTH/CODE_BLOCK)      // INFO_MATRXI_HEIGHT/CODE_BLOCK


// 用二维码生成工具生成的二维码中左右箭头末端的实际物理宽度(=上下箭头末端的实际物理高度)
#ifdef CAMERA_UP
#   define REAL_MAP_PIC_WIDTH  (640.0/9.0)     /// 71.111111mm
#   define REAL_MAP_PIC_HEIGTH (640.0/9.0)     /// 71.111111mm
#else
#   define REAL_MAP_PIC_WIDTH  (60.0)     /// 60mm
#   define REAL_MAP_PIC_HEIGTH (60.0)     /// 60mm
#endif

#define MAP_CONTOUR         (80)        // 多码码图左右箭头末端的逻辑宽度(=上下箭头末端的逻辑高度)
#define REAL_MAP_WIDTH      (REAL_MAP_PIC_WIDTH*MAP_WIDTH/MAP_CONTOUR)     // 单位mm
#define REAL_MAP_HEIGTH     (REAL_MAP_PIC_HEIGTH*MAP_HEIGHT/MAP_CONTOUR)


#define MAX(x,y) ((x)>(y)?(x):(y))
#define MIN(x,y) ((x)<(y)?(x):(y))
#define ROUND(x) ((x)>0?(int)((x)+0.5):(int)((x)-0.5))  // 四舍五入取整

#define MAX_COUNT (100) // 圆环被检测到的最多次数
#define MAX_RING_NUM (80) // 检测到的圆环的最大数目


// 解码相关
#define CODE_BITS (7)
#define INFO_BITS (4)
#define NUM_OF_DATAWORDS (8)

#define BITWIDTH (32)



// 通用
/* This enum describes the various decoder errors which may occur. */
// 解码后返回的状态信息
//typedef enum {
//    NO_DECODE_ERROR,
//    DECODE_ERR_CORRECTED,  //
//    DECODE_ERR_UNRELIABLE // 不可信的 = 0,                 // 成功识别
//} snake_decode_error;

typedef enum {
    ERR_NO_CODE = 0,     // 没有检测到二维码
    ERR_NO_ERROR,        // 正确
    ERR_UNRELIABLE,  // 解码结果不可信
    ERR_CODE_BROKEN, // 二维码残缺或无配对的特征圆
    ERR_CODE_SLOPE,  // 二维码倾斜或变形
    ERR_LINE_BROKEN, // 二维码方向线残缺或变形
    ERR_DATA_BROKEN  // 二维码数据残缺
}snake_decode_error;


// 货架摄像头安装后，摄像头的正向与AGV的正向所成的角度(按逆时针）
typedef enum {
    CAMERA_0,
    CAMERA_90,
    CAMERA_180,
    CAMERA_270
} snake_camera_angle;

typedef enum {
    RIGID,
    HOMOGRAPHY,
    TRANS_ERROR
}snake_transType; // 图像变换类型: 刚体，投影

typedef struct _vec2{
    int  Pix;
    int  Lin;
}snake_point,snake_vector;


// 浮点型
typedef struct _vec2f{
    float  Pix;
    float  Lin;
}snake_pointf,snake_vectorf;



typedef struct {
    snake_point pos;
    int  Len;
}snake_detectedLine;



typedef struct {

    snake_point pos;
    snake_detectedLine detectedLine[MAX_COUNT]; // 每条被检测线的位置和长度

    int  Len;
    int  DetectCount;

    float estimatedModuleSize; // 单位宽度检测线所占的像素数

}snake_detectedRing;


typedef struct {

    snake_point PointA;                   // ring A
    snake_point PointB;                   // ring B
    snake_point PointC;                   // ring C

    float theta;                          // 码图偏转角度
    snake_point mapCenter;                // 码图中心

    snake_vectorf ePix;
    snake_vectorf eLin;

    float pixPerGrid;                     // 标准色块，水平方向所占像素
    float linPerGrid;                     // 标准色块，垂直方向所占像素

    snake_transType transType;            // 根据数据确定的图像矫正变换的类型

    float widthPerPix;                    // 图像水平方向单像素所代表物理宽度
    float heightPerLin;                   // 图像垂直方向单像素所代表物理高度

}snake_mapPose;  // 码图的位姿信息


typedef struct
{

    snake_pointf center;  //椭圆的中心坐标

    int r1; //椭圆的长轴半径
    int r2; //椭圆的短轴半径
    float theta; //椭圆的长轴与 x 轴的夹角（逆时针）

}ELLIPSE_PARA;


typedef struct {

    snake_pointf updatedMapCenter;  // 码图中心

    float updatedTheta;  // 利用直线信息更新的码图偏转角度

    float updatedPixPerGrid; // 标准色块，水平方向所占像素
    float updatedLinPerGrid; // 标准色块，垂直方向所占像素


    // 码图Pix和Lin方向的方向向量
    snake_vectorf ePix;
    snake_vectorf eLin;


    /* 码图姿态精确求解相关 */
    // BA方向的直线矩形顶点
    snake_point recCornerBA[4];
    // BC方向的直线矩形顶点
    snake_point recCornerBC[4];

    // 提取的直线数据特征
    ELLIPSE_PARA recBAEllipsePara;
    ELLIPSE_PARA recBCEllipsePara;


    snake_pointf BPoint; // for test

}snake_rigidTransModel;  // 码图执行刚体变换




typedef struct {

    snake_pointf center;  // 色块元素中心

    int countBlack;   // 黑像素个数
    int countWhite;   // 白像素个数

    uint8_t color;  // 色块元素的黑白属性

}snake_infoMatrix; // 信息矩阵元素


// 输出接口
typedef struct {

    float angle;  // 偏转角度
    float deltaX; // X向偏移
    float deltaY; // Y向偏移

    int messg;

    snake_decode_error error;

}snake_infoOutput;

// 监控器, 用于统计各阶段错误情况
typedef struct{
    int ringDetectERR;
    int transTypeERR;
    int lineDetectERR;
    int infoExtractERR;
    int decodeUNRELIABLE;  // 不可信的
}snake_monitor;

/////////////////////////宏定义////////////////////////

#define  THRE_LOW1_RING_DET     (50)
#define  THRE_HIGH1_RING_DET    (150)
#define  THRE_LOW4_RING_DET     (20)
#define  THRE_HIGH4_RING_DET    (45)
#define  MIN_LEN_RING_DET       (80)
#define  RND_LEN_RING_DET       (100)

#ifdef __cplusplus
}
#endif

#endif // GLOBALDEFINE_H
