/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* FileName: xxx.C
* Author: Menghu Wang   Version: V1.0   Data:2017-09-20
* Description:REALIZE THE INTERFACE OF READ AND WRITE CONFIG FILE
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include <unistd.h>
#include "ini_rw.h"
/* Private typedef -----------------------------------------------------------*/
typedef enum _ELineType_ 
{
	LINE_IDLE,		//not ideal line
	LINE_ERROR,		//error line
	LINE_EMPTY,		//space line or annotation line
	LINE_SECTION,	//section line
	LINE_VALUE		//key-value line
} E_LINE_TYPE;
/* Private define ------------------------------------------------------------*/
#define INI_MAX_LINE		150	  
#define SIZE_FILENAME		256		
#define min(x, y)			((x <= y) ? (x) : (y))
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

static char *s_pBuffer;
static int s_iBufLen;
static pthread_mutex_t stFileLock = PTHREAD_MUTEX_INITIALIZER;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*!
*@function  string_strip
*@brief		delete the blank at the end of string and at the start of string
*@param[out] 
*@param[in]  char * pString:string  
*@return     char *  :string without blank at the begin and end of string
*/
static char *string_strip(char *pString)
{
	size_t lSize;
	char *pStart, *pEnd;

	lSize = strlen(pString);
	if (!lSize)
		return pString;

	pEnd = pString + lSize - 1;

	while ((pEnd >= pString) && isspace(*pEnd))
		pEnd--;
	*(pEnd + 1) = '\0'; //add end of line

	pStart = pString;
	while (*pStart && isspace(*pStart))
		pStart++;
	if (pString != pStart)
		memmove(pString, pStart, pEnd - pStart + 2);//add '\0'
	return pString;
}


/*!
*@function  string_case_cmp
*@brief  
*@param[out] 
*@param[in]  const char * pString1:string1  
*@param[in]  const char * pString2  :string2
*@return     int  >0 if pString1>pString2; = 0 on pString1=pString2;<0 when pString1<pString2
*/
static int string_case_cmp(const char *pString1, const char *pString2)
{
	int iCh1, iCh2;
	do
	{
		iCh1 = (unsigned char)*(pString1++);
		if ((iCh1 >= 'A') && (iCh1 <= 'Z'))
			iCh1 += 0x20;

		iCh2 = (unsigned char)*(pString2++);
		if ((iCh2 >= 'A') && (iCh2 <= 'Z'))
			iCh2 += 0x20;
	} while (iCh1 && (iCh1 == iCh2));
	return(iCh1 - iCh2);
}

/*!
*@function  get_line
*@brief		get a line without blank at the begin and tail from pBuf 
*@param[in]  const char * pBuf:the buf of content
*@param[in]  int iBufLen :the length of pBuf
*@param[out]  char * pContent  :the content of line without blank at the begin and tail
*@param[out]  char * * pCommentStart:the address of comment start ,including left blank  
*@param[out]  char * * pCommentEnd:the address of comment end   
*@param[out]  char * * pNextLine:the next line address  
*@return     E_LINE_TYPE  :the type of line
*/
static E_LINE_TYPE get_line(char *pBuf, int iBufLen, char *pContent, char **pCommentStart, char **pCommentEnd, char **pNextLine)
{
	char *pContStart, *pContEnd;//the start of line ,the end of line
	int iCntBlank, iCntCR, iCntLF;		//the number of continuous blank,newline
	char cIsQuot1, cIsQuot2;			//single quot,double quot
	int i = 0;
	char *pTmp;

	//support newline char: \r,\n,\r\n,\n\r
	iCntBlank = 0;
	iCntCR = iCntLF = 0;
	cIsQuot1 = cIsQuot2 = 0;
	pContStart = *pCommentStart = 0;
	pContent[0] = 0;
	for (i = 0, pTmp = pBuf; i < iBufLen; i++, pTmp++)
	{
		if (*pTmp == 0)
		{
			pTmp++;
			break;
		}
		//2 CR or 2 LF��end of line
		if (iCntCR == 2 || iCntLF == 2) 
		{
			//pTmp--;	//back one char
			break;
		}
		//end of line
		if (iCntCR + iCntLF >= 2)
		{
			break;
		}
		//there is not word after CR or LF��then the line end
		if ((iCntCR || iCntLF) && *pTmp != '\r' && *pTmp != '\n')
			break;

		switch (*pTmp) 
		{
		case '\r':
			iCntCR++;
			break;
		case '\n':
			iCntLF++;
			break;
		case '\'':
			if (!cIsQuot2)//for single quotation pair
				cIsQuot1 = 1 - cIsQuot1;
			break;
		case '\"':
			if (!cIsQuot1)  //for double quotation pair
				cIsQuot2 = 1 - cIsQuot2;
			break;
		case ';':
		case '#':
			if (cIsQuot1 || cIsQuot2)
				break;
			if (*pCommentStart == NULL)
				*pCommentStart = pTmp - iCntBlank;//delete annotation and right blank
			break;
		default:
			if (isspace((unsigned char)*pTmp))
			{
				iCntBlank++;
			} 
			else
			{
				iCntBlank = 0;
				if ((*pCommentStart == NULL) && (pContStart == NULL))
					pContStart = pTmp; //delete left blank
			}
			break;
		}
	}
	
	
	*pNextLine = pTmp;
	*pCommentEnd = pTmp - iCntCR - iCntLF; //the end of annotation words
	if (*pCommentStart == NULL) //there is not annotation words
	{
		*pCommentStart = *pCommentEnd;
		pContEnd = *pCommentStart - iCntBlank;  //delete right blank
	}
	else   
	{
		pContEnd = *pCommentStart;
	}

	if (pContStart == NULL) 
	{
		pContStart = pContEnd;
		return LINE_EMPTY;  //blank line or newline
	}

	i = (int)(pContEnd - pContStart);
	if (i >= INI_MAX_LINE)
		return LINE_ERROR;

	//content without blank
	memcpy(pContent, pContStart, i);
	pContent[i] = 0;

	if (pContent[0] == '[' && pContent[i - 1] == ']')
		return LINE_SECTION;
	if (strchr(pContent, '=') != NULL)
		return LINE_VALUE;
	
	return LINE_ERROR;
}

/*!
*@function  find_section
*@brief		find the section which is equal to pSection
*@param[out] 
*@param[in]  const char * pSection  :section's name to search
*@param[out]  char * * pSectStart  :the start address of the section's name
*@param[out]  char * * pSectEnd  :the end address of the the section's name 
*@param[out]  char * * pContStart :the start address of the section's context 
*@param[out]  char * * pContEnd  :the end address of the section's context 
*@param[out]  char * * pNextSect  :the address of next section
*@return     int  0 if OK, -1 on error
*/
static int find_section(const char *pSection, char **pSectStart, char **pSectEnd, char **pContStart, char **pContEnd, char **pNextSect)
{
	E_LINE_TYPE eType;
	char pSectName[INI_MAX_LINE]; //section name
	char *pCommentStart, *pCommentEnd, *pNextLine;

	char *pString;
	char *pContEndTmp;
	int iUsedLen = 0;
	char iFound = 0;

	if (s_pBuffer == NULL) 
	{
		return -1;
	}

	while (s_iBufLen - iUsedLen > 0)
	{
		pString = s_pBuffer + iUsedLen;
		eType = get_line(pString, s_iBufLen - iUsedLen, pSectName, &pCommentStart, &pCommentEnd, &pNextLine);
		iUsedLen += (int)(pNextLine - pString);

		if (LINE_SECTION == eType)
		{
			if (iFound || pSection == NULL) break;		//fine next section
			pSectName[strlen(pSectName) - 1] = 0;			//delete tail ]
			string_strip(pSectName + 1);						//delete begin and tail blank
			if (string_case_cmp(pSectName + 1, pSection) == 0)
			{
				iFound = 1;
				*pSectStart = pString;
				*pSectEnd = pCommentStart;
				*pContStart = pNextLine;
			}
			pContEndTmp = pNextLine;
		} 
		else if (LINE_VALUE == eType)
		{
			if (!iFound && pSection == NULL)
			{
				iFound = 1;
				*pSectStart = pString;
				*pSectEnd = pString;
				*pContStart = pString;
			}
			pContEndTmp = pNextLine;
		}
	}
	
	if (!iFound)
		return -1;

	*pContEnd = pContEndTmp;
	*pNextSect = pNextLine;
	return 0;
}


//��һ��ȡ����ֵ
//���룺���ݴ�(������д)
//�����������ֵ��
static void get_key_value(char *pContent, char **pKey, char **pValue)
{
	char *pTmp;

	pTmp = strchr(pContent, '=');
	*pTmp = 0;
	string_strip(pContent);
	string_strip(pTmp + 1);
	*pKey = pContent;
	*pValue = pTmp + 1;
}


/*!
*@function  free_file
*@brief     free the memory of load ini file
*@param[out] 
*@param[in]  void  
*@return     void  
*/
static void free_file(void )
{
	if (s_pBuffer != NULL) 
	{
		free(s_pBuffer);
		s_pBuffer = 0;
		s_iBufLen = 0;
	}
}


/*!
*@function  ini_load_file
*@brief		load file to memory(s_pBuffer)	
*@param[out] 
*@param[in]  const char * pFileName:the path of the ini file
*@return     int:  0 if OK ,-1 on error
*/
static int ini_load_file(const char *pFileName)
{
	FILE *pFile;
	int iLen;

	if (pFileName == (const char *)0)
		return -1;
	free_file();
	if (strlen(pFileName) >= SIZE_FILENAME)
		return -1;

	pFile = fopen(pFileName, "rb");
	if (pFile == NULL)
		return -1;

	fseek(pFile, 0, SEEK_END);
	iLen = ftell(pFile);
	s_pBuffer = malloc(iLen);
	if (s_pBuffer == NULL) 
	{
		fclose(pFile);
		return -1;
	}

	fseek(pFile, 0, SEEK_SET);
	iLen = fread(s_pBuffer, 1, iLen, pFile);
	fclose(pFile);
	s_iBufLen = iLen;
	return 0;
}



/*!
*@function  get_value
*@brief		read the original value string of key  
*@param[out] 
*@param[in]  const char * pSection  
*@param[in]  const char * pKey  
*@param[in]  char * pValue  
*@param[in]  int iMaxLen  
*@param[in]  const char * pDefValue  
*@return     int  0 if found, -1 on not found
*/
static int get_value(const char *pSection, const char *pKey, char *pValue, int iMaxLen)
{
	E_LINE_TYPE eLineType;
	char pContent[INI_MAX_LINE];
	char *rem1, *rem2, *pNextLine;
	char *pKey0, *pValue0;

	char *pOffset;
	int iUsedLen = 0;
	int iFound = 0;

	int iLen = 0;
	
	if (NULL == s_pBuffer || NULL == pKey) 
	{
		if (pValue != NULL)
			pValue[0] = 0;
		return -1;
	}
	if (iMaxLen <= 0)
		return -1;

	while (s_iBufLen - iUsedLen > 0) 
	{
		pOffset = s_pBuffer + iUsedLen;
		eLineType = get_line(pOffset, s_iBufLen - iUsedLen, pContent, &rem1, &rem2, &pNextLine);
		iUsedLen += (int)(pNextLine - pOffset);

		if (LINE_SECTION == eLineType) 
		{
			if (iFound || pSection == NULL) 
				break;	
			pContent[strlen(pContent) - 1] = 0;			//delete last ]
			string_strip(pContent + 1);						//delete section blank of begin and end
			if (string_case_cmp(pContent + 1, pSection) == 0) 
			{
				iFound = 1;
			}
		} 
		else if (LINE_VALUE == eLineType) 
		{
			if (!iFound && pSection == NULL)
			{
				iFound = 1;
			}
			if (!iFound)
				continue;
			get_key_value(pContent, &pKey0, &pValue0);
			if (string_case_cmp(pKey0, pKey) == 0)
			{
				iLen = strlen(pValue0);
				if (iLen == 0)
					break;		//equal not found
				if (pValue != NULL)
				{
					iLen = min(iLen, iMaxLen - 1);
					strncpy(pValue, pValue0, iLen);
					pValue[iLen] = 0;
				}
				return 0;
			}
		}
	}
	
	//not found key
	if (pValue != NULL) 
	{
		if (INI_DEFAULT_VALUE != NULL)
		{
			iLen = min(strlen(INI_DEFAULT_VALUE), iMaxLen - 1);
			strncpy(pValue, INI_DEFAULT_VALUE, iLen);
			pValue[iLen] = 0;
		}
		else
		{
			pValue[0] = 0;
		}
	}
	return -1;
}
/*!
*@function  ini_read
*@brief     get the string value of key filter first double/single quotation marks ,space and annotation
*@param[out] char * pValue  
*@param[in]  const char * pSection :NULL,the key without section 
*@param[in]  const char * pKey  
*@param[in]  int iMaxLen  
*@param[in]  const char * pDefValue  
*@param[in]  const char * pFilePath :the path of configure file 
*@return     int : 0 if found, -1 on not found
*/
int ini_read(const char *pFilePath, const char *pSection, const char *pKey, char *pValue, int iMaxLen)
{
	int iRet = 0 ;
	int iLen = 0;
	pthread_mutex_lock(&stFileLock);
	ini_load_file(pFilePath);
	iRet = get_value(pSection, pKey, pValue, iMaxLen);
	if (iRet == -1)
	{
		pthread_mutex_unlock(&stFileLock);
		return iRet;
	}
		

	//delete the first double quot and single quot
	iLen = strlen(pValue);
	if (pValue[0] == '\'' && pValue[iLen - 1] == '\'')
	{
		pValue[iLen - 1] = 0;
		memmove(pValue, pValue + 1, iLen - 1);
	} 
	else if (pValue[0] == '\"' && pValue[iLen - 1] == '\"') 
	{
		pValue[iLen - 1] = 0;
		memmove(pValue, pValue + 1, iLen - 1);
	}
	pthread_mutex_unlock(&stFileLock);
	return iRet;
}

/*!
*@function  ini_print_file
*@brief  
*@param[out] 
*@param[in]  const char * pFilePath:the path of file  
*@param[in]  printf_func func :printf function
*@return     void  
*/
void ini_print_file(const char *pFilePath, printf_func func)
{
	E_LINE_TYPE eLineType;
	char pContent[INI_MAX_LINE];
	char *pCommentStart, *pCommentEnd, *pNextLine;

	char *pOffset;
	int iUsedLen = 0;
	pthread_mutex_lock(&stFileLock);
	ini_load_file(pFilePath);
	while (s_iBufLen - iUsedLen > 0)
	{
		pOffset = s_pBuffer + iUsedLen;
		eLineType = get_line(pOffset, s_iBufLen - iUsedLen, pContent, &pCommentStart, &pCommentEnd, &pNextLine);
		iUsedLen += (int)(pNextLine - pOffset);
		func("%s\n", pContent);
	}
	pthread_mutex_unlock(&stFileLock);
}

/*!
*@function  ini_write
*@brief		set if find the key ,add the key append the section or file on not finding the key
			delete the key when key's value equal NULL
*@param[out] 
*@param[in]  const char * pFilePath  
*@param[in]  const char * pSection  
*@param[in]  const char * pKey  
*@param[in]  const char * pValue  :null
*@return     int  
*/
int ini_write(const char *pFilePath,const char *pSection, const char *pKey, const char *pValue)
{
	FILE *pFile;
	int iFd = 0;
	char *pSectStart, *pSectEnd, *pContStart, *pContEnd, *pNextSect;
	char *pString;
	int iLen;
	E_LINE_TYPE eType;
	char pContent[INI_MAX_LINE];
	char *pKey0, *pValue0;
	char *pCommentStart, *pCommentEnd, *pNextLine;
	char pStringNull[50];
	char pStringSection[50];
	int iCount = 0;
	char pTmpFileName[100];
	char pCmd[100];
	bzero(pCmd, sizeof(pCmd));
	bzero(pStringNull, sizeof(pStringNull));
	bzero(pStringSection, sizeof(pStringSection));
	if (pKey == NULL)
	{
		return -1;
	}
	if (pFilePath == NULL)
	{
		
		return -1;
	}
	if (pValue == NULL)
	{
		
		return -1;
	}
	///copy the configure file
	sprintf(pTmpFileName, "%s_tmp", pFilePath);
	sprintf(pCmd, "cp %s %s", pFilePath, pTmpFileName);
	pthread_mutex_lock(&stFileLock);
	if (system(pCmd) != 0)
	{
		pthread_mutex_unlock(&stFileLock);
		return -1;
	}
	pthread_mutex_unlock(&stFileLock);

	if (ini_delete(pTmpFileName, pSection, pKey) == -1)
	{
		return -1;
	}
	pthread_mutex_lock(&stFileLock);
	ini_load_file(pTmpFileName);
	if (s_pBuffer == NULL)
	{
		pthread_mutex_unlock(&stFileLock);
		return -1;
	}
	//pSection is NUll,add in the first of file
	if (pSection == NULL) 
	{
		pFile = fopen(pTmpFileName, "wb");
		if (pFile == NULL)
		{
			pthread_mutex_unlock(&stFileLock);
			return -1;
		}	
		fprintf(pFile, "%s = %s \n", pKey, pValue);
		while ((iCount = fwrite(s_pBuffer, 1, s_iBufLen, pFile)) != s_iBufLen)
		{
			usleep(50000);
			fseek(pFile,-iCount,SEEK_CUR);
		}
		iFd=fileno(pFile);
		fsync(iFd);
		fclose(pFile);
		sprintf(pCmd, "mv %s %s -f", pTmpFileName, pFilePath);
		if (system(pCmd) != 0)
		{
			pthread_mutex_unlock(&stFileLock);
			return -1;
		}
		if (system("sync") != 0)
		{
			pthread_mutex_unlock(&stFileLock);
			return -1;
		}
		pthread_mutex_unlock(&stFileLock);
		
		return 0;
	}
	///not find section
	if (find_section(pSection, &pSectStart, &pSectEnd, &pContStart, &pContEnd, &pNextSect) == -1) 
	{
		
		//append the file
		pFile = fopen(pTmpFileName, "ab");
		if (pFile == NULL)
		{
			pthread_mutex_unlock(&stFileLock);
			return -1;
		}
		fprintf(pFile, "[%s]\n%s = %s\n", pSection, pKey, pValue);//add the section and key-value			
		iFd = fileno(pFile);
		fsync(iFd);
		fclose(pFile);
		sprintf(pCmd, "mv %s %s -f", pTmpFileName, pFilePath);
		if (system(pCmd) != 0)
		{
			pthread_mutex_unlock(&stFileLock);
			return -1;
		}
		if (system("sync") != 0)
		{
			pthread_mutex_unlock(&stFileLock);
			return -1;
		}
		pthread_mutex_unlock(&stFileLock);
		return 0;
	}
	///find the section
	pFile = fopen(pTmpFileName, "wb");
	if (pFile == NULL)
	{
		pthread_mutex_unlock(&stFileLock);
		return -1;
	}		
	iLen = (int)(pContEnd - s_pBuffer);
	while (fwrite(s_pBuffer, 1, iLen, pFile)!= iLen)//write the string before the key
	{
		usleep(5000);
		truncate(pTmpFileName, 0);
	}
	fprintf(pFile, "%s = %s\n", pKey, pValue);
	while ((iCount = fwrite(s_pBuffer + iLen, 1, s_iBufLen - iLen, pFile)) != (s_iBufLen - iLen))//write the string behind the key
	{
		usleep(5000);
		fseek(pFile, -iCount, SEEK_CUR);
	}
	iFd = fileno(pFile);
	fsync(iFd);
	fclose(pFile);
	sprintf(pCmd, "mv %s %s -f", pTmpFileName, pFilePath);
	if (system(pCmd) != 0)
	{
		pthread_mutex_unlock(&stFileLock);
		return -1;
	}
	if (system("sync") != 0)
	{
		pthread_mutex_unlock(&stFileLock);
		return -1;
	}
	pthread_mutex_unlock(&stFileLock);
	return 0;
}
/*!
*@function  ini_delete
*@brief     delete the pKey line in  section of the file
*@param[out] 
*@param[in]  const char * pFilePath  :file path
*@param[in]  const char * pSection  : section of key
*@param[in]  const char * pKey  
*@return     int :0 if OK ,-1 on error
*/
int ini_delete(const char *pFilePath, const char *pSection, const char *pKey)
{
	FILE *pFile;
	int iFd = 0;
	char *pSectStart, *pSectEnd, *pContStart, *pContEnd, *pNextSect;
	char *pString;
	int iLen, iUsedLen = 0;
	E_LINE_TYPE eType;
	char pContent[INI_MAX_LINE];
	char *key0, *value0;
	char *pCommentStart, *pCommentEnd, *pNextLine;
	off_t iCount = 0;
	pthread_mutex_lock(&stFileLock);
	if (ini_load_file(pFilePath) == -1)
	{
		pthread_mutex_unlock(&stFileLock);
		return -1;
	}
	if (NULL == pSection)
	{
		iLen = s_iBufLen;
		while (s_iBufLen - iUsedLen > 0)
		{
			pString = s_pBuffer + iUsedLen;
			eType = get_line(pString, iLen, pContent, &pCommentStart, &pCommentEnd, &pNextLine);
			iUsedLen += (int)(pNextLine - pString);
			if (LINE_VALUE == eType)
			{
				get_key_value(pContent, &key0, &value0);
				if (string_case_cmp(key0, pKey) == 0)
				{
					//find key
					pFile = fopen(pFilePath, "wb");
					if (pFile == NULL)
					{
						pthread_mutex_unlock(&stFileLock);
						return -1;
					}						
					iLen = (int)(pString - s_pBuffer);
					while (fwrite(s_pBuffer, 1, iLen, pFile) != iLen)//write the string before the key
					{
						usleep(5000);
						truncate(pFilePath, 0);
					}
					iLen = (int)(pNextLine - s_pBuffer);			//delete the key ,including its annotation
					if (s_iBufLen - iLen> 0)
					{
						while ((iCount = fwrite(s_pBuffer + iLen, 1, s_iBufLen - iLen, pFile)) != (s_iBufLen - iLen))////write the string behind the key
						{
							usleep(5000);
							fseek(pFile, -iCount, SEEK_CUR);
						}
					}					
					iFd = fileno(pFile);
					fsync(iFd);
					fclose(pFile);
					pthread_mutex_unlock(&stFileLock);
					return 0;
				}
			}

		}
		pthread_mutex_unlock(&stFileLock);
		return 0;
	}
	if (find_section(pSection, &pSectStart, &pSectEnd, &pContStart, &pContEnd, &pNextSect) == -1) //not find section
	{
		pthread_mutex_unlock(&stFileLock);
		return 0;
	}

	//find section,then find key within the section
	pString = pContStart;
	iLen = (int)(pContEnd - pContStart);
	while (iLen > 0)
	{
		eType = get_line(pString, iLen, pContent, &pCommentStart, &pCommentEnd, &pNextLine);
		if (LINE_VALUE == eType)
		{
			get_key_value(pContent, &key0, &value0);
			if (string_case_cmp(key0, pKey) == 0)
			{
				//find key
				pFile = fopen(pFilePath, "wb");
				if (pFile == NULL)
				{
					pthread_mutex_unlock(&stFileLock);
					return -1;
				}
					
				iLen = (int)(pString - s_pBuffer);
				while (fwrite(s_pBuffer, 1, iLen, pFile) != iLen)//write the string before the key
				{
					usleep(5000);
					truncate(pFilePath, 0);
				}
				iLen = (int)(pNextLine - s_pBuffer);			//delete the key ,including its annotation
				if (s_iBufLen - iLen > 0)
				{
					while ((iCount = fwrite(s_pBuffer + iLen, 1, s_iBufLen - iLen, pFile)) != (s_iBufLen - iLen))////write the string behind the key
					{
						usleep(5000);
						fseek(pFile, -iCount, SEEK_CUR);
					}
				}
				
				iFd = fileno(pFile);
				fsync(iFd);
				fclose(pFile);
				pthread_mutex_unlock(&stFileLock);
				return 0;
			}
		}
		iLen -= (int)(pNextLine - pString);
		pString = pNextLine;
	}
	pthread_mutex_unlock(&stFileLock);
	return 0; // find the section but not find the key
}

#define INI_FILE "/config.ini"
int ini_test()
{

	char *sect;
	char *key;
	char value[256];
	double intval;
	ini_print_file(INI_FILE, printf);
	ini_delete(INI_FILE, "sect1", "float001");
	sect = 0;
	key = "_str0010";
	ini_read(INI_FILE, sect, key, value, sizeof(value));
	printf("[%s] %s = %s\n", sect, key, value);

	sect = "sect1";
	key = "str001";
	ini_read(INI_FILE, sect, key, value, sizeof(value));
	printf("[%s] %s = %s\n", sect, key, value);

	sect = "sect1";
	key = "str002";
	ini_read(INI_FILE, sect, key, value, sizeof(value));
	printf("[%s] %s = %s\n", sect, key, value);

	sect = "sect2";
	key = "str002";
	ini_read(INI_FILE, sect, key, value, sizeof(value));
	printf("[%s] %s = %s\n", sect, key, value);

	sect = "sect2";
	key = "float001";
	ini_read(INI_FILE, sect, key, value, sizeof(value));
	intval = atof(value);
	printf("[%s] %s = %f\n", sect, key, intval);
	ini_delete(INI_FILE, "sect2", "float001");
	ini_write(INI_FILE, "sect1", "_str003", "\"v'a;l;u#e'004\"");

	
	sect = "sect2";
	key = "str002";
	ini_read(INI_FILE, sect, key, value, sizeof(value));
	printf("[%s] %s = %s\n", sect, key, value);

	ini_write(INI_FILE, "sect2", "str003", "value003");

	ini_write(INI_FILE, "sect2", "float001", "101.12");
	ini_write(INI_FILE, "sect2", "int002", "201");
	ini_write(INI_FILE, "sect2", "int003", "11");

	getchar();
}
/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/
