#ifndef _LINKQUEUE_H__
#define _LINKQUEUE_H__

#include <stdio.h>
#include <malloc.h>
#include<stdlib.h>
#include<string.h>

typedef struct stLinkQueue linkQueue;
typedef struct stLinkQueueNode linkQueueNode;
 struct stLinkQueueNode
{
	linkQueueNode* pNext;
	int iSize;
	void* pItem;
};

struct stLinkQueue
{
	pthread_mutex_t queueMutex;
	linkQueueNode* pHead;
	linkQueueNode* pTail;
	int iLength;
} ;

extern linkQueue * linkqueue_create();
extern void linkqueue_destroy(linkQueue* pQueue);
extern int linkqueue_append(linkQueue* pQueue, const void *pItem, const int iSize);
extern int linkqueue_retrieve(linkQueue* pQueue, void * pItem);
extern int linkqueue_peek(linkQueue* pQueue, void *pItem);
extern int linkqueue_length(linkQueue* pQueue);
extern void linkqueue_clear(linkQueue* pQueue);
#endif

