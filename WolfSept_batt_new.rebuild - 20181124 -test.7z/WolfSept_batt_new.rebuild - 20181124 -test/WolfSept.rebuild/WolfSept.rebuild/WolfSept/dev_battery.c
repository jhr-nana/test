/********************************************************************************
* Copyright (C) 2025, JD.COM, Inc.
* All rights reserved.
* FileName    : dev_battery.c
* Author      : yyf   Version: V1.0   Data:2018-11-21
* Description : dev_battery.c
********************************************************************************/
	
#include "can.h"
#include "device.h"
#include "global_var.h"
#include "dev_battery.h"
#include "dev_battery_anshang.h"
#include "dev_battery_songxia.h"

/*******************************************************************************
* Function Name		 : init_battery_type
* Description	     : get the battery type
* input			     : NONE
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int init_battery_type1()
{
	int iRet = 0;
	LOG_INF("Begin to the recognize the battery\n");
	int iSongxia = songxia_battery_init_check();
	if (iSongxia > 0)
	{
		g_stAgvAttr.bms.iBattVersion = BAT_TYPE_SONGXIA;
		LOG_INF("Songxia battery initiation is success\n");
	}
	return iRet;
}		
		
/*******************************************************************************
*Function Name    :batt_dev_init
*Description      :电池初始化
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int batt_dev_init()
{
	int iRet = 0;
	
	g_stAgvAttr.bms.iBattManufactor = BAT_TYPE_SONGXIA;
	g_stAgvAttr.bms.batt_inquiry_bms_info = songxia_inquiry_bms_info;
	g_stAgvAttr.bms.batt_recv_bms_info = songxia_recv_bms_info;
	g_stAgvAttr.bms.batt_bms_info_exception_handle = songxia_bms_info_exception_handle;
	g_stAgvAttr.bms.batt_update_bms_info = songxia_update_bms_info;
	g_stAgvAttr.bms.batt_commit_bms_info = songxia_commit_bms_info;
	g_stAgvAttr.bms.batt_dump_bms_info = songxia_dump_bms_info;

	iRet = init_battery_type1();

	if (iRet<0)
	{
		LOG_ERR("init_battery_type failed!\n");
		return iRet;
	}
	
	if (g_stAgvAttr.bms.iBattManufactor == BAT_TYPE_SONGXIA)
	{		
		iRet = songxia_get_lasterfive_poweroff();
		if (iRet<0)
		{
			LOG_ERR("init lasterfive_poweroff failure\n");
		}
		iRet = songxia_get_vid_pid();
		if (iRet<0)
		{
			LOG_WRN("search vid&pid failed\n");
		}
	}
	else
	{
		g_stAgvAttr.bms.batt_inquiry_bms_info = anshang_inquiry_bms_info;
		g_stAgvAttr.bms.batt_recv_bms_info = anshang_recv_bms_info;
		g_stAgvAttr.bms.batt_bms_info_exception_handle = anshang_bms_info_exception_handle;
		g_stAgvAttr.bms.batt_update_bms_info = anshang_update_bms_info;
		g_stAgvAttr.bms.batt_commit_bms_info = anshang_commit_bms_info;
		g_stAgvAttr.bms.batt_dump_bms_info = anshang_dump_bms_info;
	}
	
	return iRet;
}

/*******************************************************************************
* Function Name      : get_manufactor_desc
* Description	     : get_manufactor_desc.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
char* get_manufactor_desc(int iManufactorid)
{
	char *pManufactorDesc = NULL;
	switch (iManufactorid)
	{
	case BAT_TYPE_ANSHANG:
		pManufactorDesc = "ANSHANG";
		break;
	case BAT_TYPE_SONGXIA:
		pManufactorDesc = "PANSONIC";
		break;
	default:
		pManufactorDesc = "UNKNOWN_MANUFACTOR";
	};
	return pManufactorDesc;
}
