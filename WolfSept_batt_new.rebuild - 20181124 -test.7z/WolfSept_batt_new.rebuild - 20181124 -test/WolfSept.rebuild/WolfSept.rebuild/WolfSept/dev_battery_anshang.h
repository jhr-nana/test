/********************************************************************************
* Copyright (C) 2025, JD.COM, Inc.
* All rights reserved.
* FileName    : dev_battery_anshang.h
* Author      : yyf   Version: V1.0   Data:2018-11-21
* Description : dev_battery_anshang.h
********************************************************************************/
#ifndef __DEV_BATTERY_ANSHANG_H__
#define __DEV_BATTERY_ANSHANG_H__

//从CAN1接收BMS信息帧并写入电池队列中
extern int anshang_recv_bms_info(struct can_frame * pCanFrame);

//安尚电池信息查询
extern int anshang_inquiry_bms_info(batt_info_t *pBattInfo);

//安尚电池概要信息查询
extern int inquiry_bms_summary_info(batt_info_t *pBattInfo);

//安尚电池单体电压信息查询
extern int inquiry_bms_cell_info(batt_info_t *pBattInfo);

//安尚电池故障信息查询
extern int inquiry_bms_fault_info(batt_info_t *pBattInfo);

//安尚电池BMS信息更新及校准，如电量，单体电压最大值/最小值/差值计算，故障标志位判别		
extern int anshang_update_bms_info(batt_info_t *pBattInfo);	

//安尚电池异常信息处理
extern int anshang_bms_info_exception_handle(batt_info_t *pBattInfo);

//安尚电池信息和故障信息写入日志和上报控制台
extern int anshang_commit_bms_info(batt_info_t *pBattInfo);	

//输出安尚电池所有信息
extern int anshang_dump_bms_info(batt_info_t *pBattInfo);

//预留
extern int anshang_start_charge();

//预留
extern int anshang_stop_charge();

//预留
extern int anshang_get_lasterfive_poweroff();

//预留
extern int anshang_get_pack_type();

//预留
extern int anshang_get_vid_pid();


#endif 