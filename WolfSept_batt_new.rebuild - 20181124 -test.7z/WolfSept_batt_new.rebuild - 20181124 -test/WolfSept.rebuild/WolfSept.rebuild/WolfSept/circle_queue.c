/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* FileName:CIRCLE_QUEUE.C
* Author: Menghu Wang   Version: V1.0   Data:2017-07-04
* Description:REALIZE THE INTERFACE OF THREAD SAFE CIRCLE QUEUE
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include "debug.h"
#include "circle_queue.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : queue_create
* Description    : create the circle queue
* Input          : iCapacity :the capacity of the circle queue
* Output         : NONE
* Return         : the address of the queue if OK, NULL on error
*******************************************************************************/
circleQueue * create_queue(int iCapacity)
{
	circleQueue * pQueue = calloc(1, sizeof(struct stQueueType));
	pQueue->iCapacity = iCapacity + 1; // one more to distinction the queue's head and tail 
	if (0 != pthread_mutex_init(&pQueue->stTailLock, NULL))
	{
		LOG_ERR("initial stTailLock error %s\n", strerror(errno));
		free(pQueue);
		return(NULL);
	}
	if (0 != pthread_mutex_init(&pQueue->stHeadLock, NULL))
	{
		LOG_ERR("initial stHeadLock error %s\n", strerror(errno));
		free(pQueue);
		return(NULL);
	}
	pQueue->pArray = calloc(iCapacity, sizeof(void *));
	return pQueue;
}
/*******************************************************************************
* Function Name  : is_empty_queue
* Description    : make sure that whether the circle queue is empty
* Input          : pQueue :the address of the circle queue
* Output         : NONE
* Return         : 1 if empty, 0 on not empty
*******************************************************************************/
bool is_empty_queue(circleQueue * pQueue)
{
	bool bRet;
	pthread_mutex_lock(&pQueue->stHeadLock);
	pthread_mutex_lock(&pQueue->stTailLock);

	bRet = (pQueue->iHead == pQueue->iTail);
	pthread_mutex_unlock(&pQueue->stTailLock);
	pthread_mutex_unlock(&pQueue->stHeadLock);
	return bRet;
}
/*******************************************************************************
* Function Name  : is_full_queue
* Description    : make sure that whether the circle queue is full
* Input          : pQueue :the address of the circle queue
* Output         : NONE
* Return         : 1 if full, 0 on not full
*******************************************************************************/
bool is_full_queue(circleQueue * pQueue)
{
	bool bRet;
	pthread_mutex_lock(&pQueue->stHeadLock);
	pthread_mutex_lock(&pQueue->stTailLock);

	bRet = (pQueue->iHead == ((pQueue->iTail + 1) % pQueue->iCapacity));
	pthread_mutex_unlock(&pQueue->stTailLock);
	pthread_mutex_unlock(&pQueue->stHeadLock);
	return bRet;
}
/*******************************************************************************
* Function Name  : push_queue
* Description    : add data to the circle queue
* Input          : pQueue :the address of the circle queue; pData:the address of the data
* Output         : NONE
* Return         : 0 if OK, -1 on error
*******************************************************************************/
int push_queue(circleQueue * pQueue, void *pData)
{
	if (!is_full_queue(pQueue))
	{
		pthread_mutex_lock(&pQueue->stTailLock);
		pQueue->pArray[pQueue->iTail++] = pData;
		pQueue->iTail = (pQueue->iTail % pQueue->iCapacity);
		pthread_mutex_unlock(&pQueue->stTailLock);
		return 0;
	}
	else
	{
		LOG_ERR("the circle queue is full \n");
		return -1;
	}
}
/*******************************************************************************
* Function Name  : pop_queue
* Description    : delete a member of the circle queue
* Input          : pQueue :the address of the circle queue; 
* Output         : NONE
* Return         : the address of data if OK, NUll on error
*******************************************************************************/
void* pop_queue(circleQueue * pQueue)
{
	void *pDate = NULL;
	if (!is_empty_queue(pQueue))
	{
		pthread_mutex_lock(&pQueue->stHeadLock);
		pDate = pQueue->pArray[pQueue->iHead++];
		pQueue->iHead = pQueue->iHead % pQueue->iCapacity;
		pthread_mutex_unlock(&pQueue->stHeadLock);
		return pDate;
	}
	else
	{
		return NULL;
	}
	
}
/*******************************************************************************
* Function Name  : destroy_queue
* Description    : destroy the circle queue
* Input          : pQueue :the address of the circle queue;free_key: the function of free memory
* Output         : NONE
* Return         : NONE
*******************************************************************************/
void destroy_queue(circleQueue * pQueue, void(*free_key)(void *))
{
	void *pDate = NULL;
	while (!is_empty_queue(pQueue)) 
	{
		pDate = pop_queue(pQueue);
		free_key(pDate);
	}
	pthread_mutex_destroy(&pQueue->stHeadLock);
	pthread_mutex_destroy(&pQueue->stTailLock);
	free(pQueue->pArray);
	free(pQueue);
}
/*******************************************************************************
* Function Name  : test_list
* Description    : test the function of the circle queue
* Input          : NONE
* Output         : NONE
* Return         : 0 if OK, -1 one error
*******************************************************************************/
int test_circle_queue(void)
{
	int i = 0;
	int *pDate = NULL;
	circleQueue * pQueue = create_queue(10);
	for ( i = 0; i < 9; i++)
	{
		pDate = calloc(1, sizeof(int));
		*pDate = i;
		if (push_queue(pQueue, pDate) != 0)
		{
			break;
		}
	}
	LOG_INF("queue is full ?:%s\n", is_full_queue(pQueue) ? "true" : "false");
	while (!is_empty_queue(pQueue)) {
		pDate = pop_queue(pQueue);
		LOG_INF("%d ", *pDate);
		free(pDate);
	}
	LOG_INF("\n");
	destroy_queue(pQueue, free);
	return 0;
}

/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/