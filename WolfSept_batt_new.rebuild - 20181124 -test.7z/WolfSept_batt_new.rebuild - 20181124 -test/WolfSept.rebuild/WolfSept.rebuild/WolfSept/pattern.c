#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "pattern.h"

/********************************************
函数功能: 开辟特征模式结构体内存
函数输入:
函数输出: 结构体指针
*********************************************/
snake_code_pattern * FuncPatternAlloc()
{
	snake_code_pattern * pattern = (snake_code_pattern*)calloc(1,sizeof(snake_code_pattern));
	if (NULL == pattern)
		printf("%s failed",__func__);
	else
		pattern->count = 1;
	return pattern;
}

/********************************************
函数功能: 比较两个特征模式是否相等
函数输入: 当前特征模式的指针，候选模式的位置及单位宽度大小
函数输出: 若模式位置相近且单位宽度大小相近则返回true
*********************************************/
bool FuncIsPatternEquals(snake_code_pattern *pattern, float moduleSize, float i, float j)
{
    float moduleSizeDiff = 0.0f;

	if (NULL == pattern)
	{
		printf("The pointer of function %s is null\n", __func__);
		return false;
	}

    if (fabs(i - pattern->posY) <= moduleSize && fabs(j - pattern->posX) <= moduleSize)
	{
        moduleSizeDiff = fabs(moduleSize - pattern->estimatedModuleSize);
        return moduleSizeDiff <= 1.0f || moduleSizeDiff <= 0.1 * pattern->estimatedModuleSize;
  	}
  	return false;
}

/********************************************
函数功能: 将候选模式与当前模式进行合并
函数输入: 当前特征模式的指针，候选模式的位置及单位宽度大小
函数输出: 合并成功返回true
*********************************************/
bool FuncPatternCombineEstimate(snake_code_pattern *pattern, float i, float j, float newModuleSize)
{
    int combinedCount = 0;

	if (NULL == pattern)
	{
		printf("The pointer of function %s is null\n", __func__);
		return false;
	}

    combinedCount = pattern->count + 1;
  	pattern->posX = (pattern->count * pattern->posX + j) / combinedCount;
  	pattern->posY = (pattern->count * pattern->posY + i) / combinedCount;
  	pattern->estimatedModuleSize = (pattern->count * pattern->estimatedModuleSize + newModuleSize) / combinedCount;
  	pattern->count = combinedCount;
  	return true;
}
