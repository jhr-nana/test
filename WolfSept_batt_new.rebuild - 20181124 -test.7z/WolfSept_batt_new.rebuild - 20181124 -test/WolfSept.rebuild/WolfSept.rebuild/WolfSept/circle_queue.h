/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* FileName:CIRCLE_QUEUE.H
* Author: Menghu Wang   Version: V1.0   Data:2017-07-04
* Description:THE INTERFACE OF THREAD SAFE CIRCLE QUEUE 
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CIRCLE_QUEUE_H_
	#define __CIRCLE_QUEUE_H_
/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <string.h>
#include <errno.h> 
/* Exported types ------------------------------------------------------------*/
typedef struct stQueueType circleQueue;

struct stQueueType
{
	int iCapacity; // the capacity of the circle queue
	int iHead; 
	int iTail;
	void **pArray; //save the address of data
	pthread_mutex_t stHeadLock;
	pthread_mutex_t stTailLock;	
};
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
 
/* Exported functions ------------------------------------------------------- */
extern bool is_full_queue(circleQueue * pQueue);
extern circleQueue * create_queue(int iCapacity);
extern bool is_empty_queue(circleQueue * pQueue);
extern int push_queue(circleQueue * pQueue, void *pData);
extern void* pop_queue(circleQueue * pQueue);
extern void destroy_queue(circleQueue * pQueue, void(*free_key)(void *));
extern int test_circle_queue(void);
#endif /* __CIRCLE_QUEUE_H_ */

/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/