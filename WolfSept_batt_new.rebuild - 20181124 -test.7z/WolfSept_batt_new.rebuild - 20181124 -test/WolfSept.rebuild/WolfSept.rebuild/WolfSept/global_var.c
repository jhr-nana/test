/*ADD FOR BOOTMETHOD BY YU START*/
#include <unistd.h>
#include <fcntl.h>
/*ADD FOR BOOTMETHOD BY YU END*/
#include "global_var.h"
#include "debug.h"
#include "device.h"
#include "version.h"
#include "netstat.h"
#include "atomic.h"

/***************global variable***************************/ 
//add by jxu 20180820-begin-recompute the soc
float g_fDischargeVoltage[7][21] = {
	{ 3.434, 3.466, 3.495, 3.523, 3.551, 3.577, 3.604, 3.646, 3.678, 3.713, 3.749, 3.785, 3.819, 3.851, 3.881, 3.915, 3.980, 4.022, 4.052, 4.073, 4.105 },
	{ 3.411, 3.456, 3.493, 3.524, 3.553, 3.580, 3.606, 3.632, 3.659, 3.691, 3.728, 3.785, 3.823, 3.859, 3.893, 3.932, 3.981, 4.028, 4.060, 4.079, 4.106 },
	{ 3.377, 3.440, 3.490, 3.515, 3.548, 3.577, 3.604, 3.631, 3.661, 3.691, 3.718, 3.764, 3.813, 3.861, 3.899, 3.973, 3.986, 4.013, 4.056, 4.080, 4.106 },
	{ 3.338, 3.395, 3.457, 3.503, 3.539, 3.569, 3.595, 3.622, 3.650, 3.682, 3.724, 3.765, 3.802, 3.850, 3.888, 3.921, 3.964, 4.017, 4.060, 4.082, 4.108 },
	{ 3.235, 3.328, 3.402, 3.460, 3.505, 3.544, 3.573, 3.600, 3.626, 3.654, 3.687, 3.732, 3.790, 3.835, 3.889, 3.922, 3.964, 4.017, 4.061, 4.084, 4.110 },
	{ 2.742, 3.248, 3.343, 3.400, 3.475, 3.519, 3.562, 3.592, 3.618, 3.646, 3.678, 3.718, 3.777, 3.827, 3.866, 3.918, 3.960, 4.014, 4.061, 4.086, 4.113 },
	{ 2.713, 3.272, 3.348, 3.401, 3.460, 3.507, 3.556, 3.590, 3.618, 3.647, 3.681, 3.722, 3.786, 3.833, 3.873, 3.909, 3.950, 4.004, 4.056, 4.086, 4.113
	}
};
float g_fChargeVoltage[7][9] = { { 3.311, 3.500, 3.576, 3.611, 3.645, 3.686, 3.766, 3.846, 3.917 },
{ 3.324, 3.472, 3.555, 3.589, 3.634, 3.712, 3.786, 3.859, 3.936 },
{ 3.333, 3.460, 3.548, 3.589, 3.637, 3.714, 3.812, 3.882, 3.964 },
{ 3.292, 3.431, 3.529, 3.584, 3.636, 3.708, 3.826, 3.898, 3.972 },
{ 3.306, 3.450, 3.549, 3.646, 3.708, 3.777, 3.858, 3.947, 4.027 },
{ 3.308, 3.423, 3.533, 3.596, 3.649, 3.717, 3.823, 3.898, 3.975 },
{ 3.319, 3.433, 3.542, 3.601, 3.650, 3.721, 3.827, 3.904, 3.989 }
};
int g_iTemperature[7] = { -20, -10, 0, 10, 25, 45, 60 };
int g_iSingleBattery[13] = { 0 };
///add by jxu 20180820-end-recompute the soc
int32_t g_i32Seq[SEQ_NUM] = { 0 }; //add  by tiger.79
pthread_mutex_t g_stChargeStatusMutexLock = PTHREAD_MUTEX_INITIALIZER; //add by tiger.41

//struct batt_info g_stBattInfoManage;   //yyf 20181124

agv_attr_t g_stAgvAttr;	// agv global attribution
agv_conf_t g_stAgvConf;	// agv configure
agv_parm_t g_stAgvParm;	// agv parameter(s)
agv_task_t g_stAgvTask = {	//the task attribution of agv,add by tiger
	.iWalkTimeout = TIME_OUT_20S,
	.enTaskType = ACTION_TYPE_NUM,
	.iSrcPoint = 0,
	.iDstPoint = 0,
	.i32TaskID = 0,
	.bSliding = false,
};

struct can_filter  g_stBatCanFilter[BATT_CAN_FIL_SIZE] =
{
	{ .can_id = BATT_ACK_CANID, .can_mask = CAN_SFF_MASK },
	//add by yyf 20181022-begin
	{ .can_id = BATT_ACK_CANID_0X11, .can_mask = CAN_SFF_MASK },
	{ .can_id = BATT_ACK_CANID_0X12, .can_mask = CAN_SFF_MASK },
	{ .can_id = BATT_ACK_CANID_0X13, .can_mask = CAN_SFF_MASK },
	{ .can_id = BATT_ACK_CANID_0X14, .can_mask = CAN_SFF_MASK },
	//add by yyf 20181022-end
	{ .can_id = BATT_ACK_CANID_0X15, .can_mask = CAN_SFF_MASK },
	//{ .can_id = BATT_REQ_CANID, .can_mask = CAN_SFF_MASK },
	//add by jxu 20180910-begin
	{ .can_id = BATT_ACK_CANID_0X1C, .can_mask = CAN_SFF_MASK },
	{ .can_id = BATT_ACK_CANID_0X19, .can_mask = CAN_SFF_MASK },
	//add by yyf 20181022-begin
	{ .can_id = BATT_ACK_CANID_0X1D, .can_mask = CAN_SFF_MASK },
	//add by yyf 20181022-end
	{ .can_id = (CAN_EFF_FLAG | BMS_INQUIRY_CANID), .can_mask = CAN_SFF_MASK },
	{ .can_id = (CAN_EFF_FLAG | BMS_FLASH_ERASE_CANID), .can_mask = CAN_SFF_MASK },
	{ .can_id = (CAN_EFF_FLAG | BMS_PACKAGE_LEN_CANID), .can_mask = CAN_SFF_MASK },
	{ .can_id = (CAN_EFF_FLAG | BMS_BINFILE_TRAS_CANID), .can_mask = CAN_SFF_MASK },
	{ .can_id = (CAN_EFF_FLAG | BMS_BINFILE_TRAS_ERR_CANID), .can_mask = CAN_SFF_MASK },
	//add by jxu 20180910-end
};

struct can_filter  g_stCtrlCanFilter[CTRL_CAN_FIL_SIZE] =
{
	{ .can_id = TC_CANID_ACK, .can_mask = CAN_SFF_MASK },
	{ .can_id = TC_CANID_FINISH, .can_mask = CAN_SFF_MASK },
	{ .can_id = TC_CANID_ERR, .can_mask = CAN_SFF_MASK },
	{ .can_id = MC_CANID_ACK, .can_mask = CAN_SFF_MASK },
	{ .can_id = MC_CANID_HEART, .can_mask = CAN_SFF_MASK },
	{ .can_id = MC_CANID_FINISH, .can_mask = CAN_SFF_MASK },
	{ .can_id = PGV_CANID_TxPDO1, .can_mask = CAN_SFF_MASK },
	{ .can_id = PGV_CANID_TxPDO2, .can_mask = CAN_SFF_MASK },
	{ .can_id = PGV_CANID_TxPDO3, .can_mask = CAN_SFF_MASK },
	{ .can_id = PGV_CAN_TESTACK, .can_mask = CAN_SFF_MASK }, //by tiger.08
	{ .can_id = ARM2TC_ANGLE_ACK, .can_mask = CAN_SFF_MASK },
	{ .can_id = MC_CAN_FLAG_PARAM_ACK_V2_CANID, .can_mask = CAN_SFF_MASK },//add by jxu
	{ .can_id = MC_CAN_ACK_V2_CANID, .can_mask = CAN_SFF_MASK },//add by jxu
	{ .can_id = MC_CAN_ERR_V2_CANID, .can_mask = CAN_SFF_MASK },//add by jxu
	{ .can_id = TP_CAN_ANGLEACK_V2_CANID, .can_mask = CAN_SFF_MASK },//add by jxu
	{ .can_id = FTP_TC_UPLOAD_CANID, .can_mask = CAN_SFF_MASK },
	{ .can_id = FTP_MC_UPLOAD_CANID, .can_mask = CAN_SFF_MASK },
	{ .can_id = TC_2MC_FINISH, .can_mask = CAN_SFF_MASK },//add tiger
	{ .can_id = TEST_CANID, .can_mask = CAN_SFF_MASK },//add tiger
	{ .can_id = MC2ARM_UPDATE_DATA_CANID, .can_mask = CAN_SFF_MASK },//add by tiger.43
	{ .can_id = MC2ARM_UPDATE_CANID, .can_mask = CAN_SFF_MASK },//add by tiger.43
};

static pthread_mutex_t seq_mutex = PTHREAD_MUTEX_INITIALIZER;

/*******************************************************************************
* Function Name      : version
* Description	     : print the version of program
* Input 		     : fp: file handle will be writen
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void version(FILE *fp)
{
	fprintf(fp, "build version  : %s\n", COMPILE_VERSION);
	fprintf(fp, "build time     : %s\n", COMPILE_TIME);
	fprintf(fp, "build by       : %s\n", COMPILE_BY);
	fprintf(fp, "gcc version    : %s\n\n", COMPILER_VERSION);

	LOG_INF("build version  : %s\n", COMPILE_VERSION);
	LOG_INF("build time     : %s\n", COMPILE_TIME);
	LOG_INF("build by       : %s\n", COMPILE_BY);
	LOG_INF("gcc version    : %s\n", COMPILER_VERSION);

	return;
}

/*******************************************************************************
* Function Name      : usage
* Description	     : print the usage of program
* Input 		     : fp: file handle will be writen
* Input 		     : rc: return code
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void usage(FILE *fp, int rc)
{
	fprintf(fp, "Usage: jdagv [-u ip] [-f ip] [-vh?]\n\n");

	fprintf(fp, "	-u ConsoleServerIp:the console server ip in flow.conf will be update, eg.-u 192.168.51.125\n");
	fprintf(fp, "	-u FtpServerIp:the ftp server ip in flow.conf will be update, eg.-f 192.168.51.150\n");
	fprintf(fp, "	-v         :print version info\n");
	fprintf(fp, "	-?         :print this help\n");

	fprintf(fp, "Default: ./jdagv\n");
	fprintf(fp, "Example: ./jdagv -u 192.168.51.125\n");
	fprintf(fp, "Example: ./jdagv -f 192.168.51.150\n");
	fprintf(fp, "       : ./jdagv -v\n");
	fprintf(fp, "       : ./jdagv -h\n");
	exit(rc);
}

/*******************************************************************************
* Function Name		 : get_current_time
* Description	     : get current time string, such as : 2018-01-23 14:15:23.931
* Input 		     : iLength: the length of time buffer
* Output 		     : pTimeBuff: the buffer for saving time string
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_current_time(char * pTimeBuff, int iLength)
{
	int year = 0, month = 0, day = 0;
	int hour = 0, min = 0, sec = 0, ms = 0;
	struct timeval  tv;
	struct timezone tz;
	struct tm *tm1, tm2;

	// such as : 2018-01-23 14:15:23.931, min length=23
	if ((pTimeBuff == NULL) || (iLength <= 23))
		return -1;

	gettimeofday(&tv, &tz);
	tm1 = localtime_r((time_t*)&tv.tv_sec, &tm2);

	ms = tv.tv_usec / 1000;
	sec = tm1->tm_sec;
	min = tm1->tm_min;
	hour = tm1->tm_hour;
	day = tm1->tm_mday;
	month = tm1->tm_mon + 1;
	year = tm1->tm_year + 1900;

	snprintf(pTimeBuff, iLength, "%04d-%02d-%02d %02d:%02d:%02d.%03d",
		year, month, day, hour, min, sec, ms);//by tiger.51 for be the  same with sta_send_action_info()

	return 0;
}

/*******************************************************************************
* Function Name		 : get_current_timestamp_ms
* Description	     : get current timestamp, such as : 1467523986800
* Input 		     : iLength: the length of time buffer
* Output 		     : pTimeBuff: the buffer for saving time string
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_current_timestamp_ms(u64 * pTimeStamp)
{
	struct timeval  tv;
	u64 u64TimeStampMs = 0;

	// such as :
	// s  : 1467523986
	// ms : 1467523986800
	// us : 1467523986800434
	if (pTimeStamp == NULL)
		return -1;

	gettimeofday(&tv, NULL);
	u64TimeStampMs = (u64)tv.tv_sec * 1000;
	u64TimeStampMs += (u64)(tv.tv_usec / 1000);
	*pTimeStamp = u64TimeStampMs;

	return 0;
}

/*******************************************************************************
* Function Name		 : get_pallet_info
* Description	     : save pallet direction in the g_stAgvAttr.iPalletDirect ,
: angle offset in the g_stAgvAttr.iGAngleOffset,
: and container number in g_stAgvAttr.cContainer
* input			     : NONE
* Output		     : NONE
* Return		     : 0 if OK, -1 on error
*******************************************************************************/
int compute_angle_offset(int iAngle)
{
	int iRet = 0;
	int iAngleOffet = 0;

	if ((iAngle >= 0) && (iAngle < 4500))
	{
		iAngleOffet = iAngle;
	}
	else if ((iAngle >= 4500) && (iAngle < 13500))
	{
		iAngleOffet = iAngle - 9000;
	}
	else if ((iAngle >= 13500) && (iAngle < 22500))
	{
		iAngleOffet = iAngle - 18000;
	}
	else if ((iAngle >= 22500) && (iAngle < 31500))
	{
		iAngleOffet = iAngle - 27000;
	}
	else if ((iAngle >= 31500) && (iAngle < 36000))
	{
		iAngleOffet = iAngle - 36000;
	}
	else
	{
		LOG_WRN("angle offset =%d, TOO big\n", iAngle);
	}

	return iAngleOffet;
}

/*******************************************************************************
* Function Name      : convert_agv_offset
* Description	     : convert agv offset
* Input 		     : g_stAgvAttr
* Output		     : g_stAgvAttr
* Return		     : NONE
*******************************************************************************/
int convert_agv_offset()
{
	int iGsDev = 0;
	int iGsDevFb = 0;
	int iGsAngle = 0;

	int iGroudyOffset = g_stAgvAttr.iGYOffset;			//unit 0.1 mm
	int iGroudxOffset = g_stAgvAttr.iGXOffset;			//unit 0.1 mm
	int iGroudangleoffset = g_stAgvAttr.iGAngleOffset;	//unit 0.1��

	if (g_stAgvAttr.iVehHeadDirect == DIRECTION_X_P)
	{
		iGsDev = iGroudyOffset;
		iGsDevFb = iGroudxOffset;
		iGsAngle = (iGroudangleoffset > 1800) ? (3600 - iGroudangleoffset) : (-iGroudangleoffset);
	}
	else if (g_stAgvAttr.iVehHeadDirect == DIRECTION_X_N)
	{
		iGsDev = -iGroudyOffset;
		iGsDevFb = -iGroudxOffset;
		iGsAngle = 1800 - iGroudangleoffset;
	}
	else if (g_stAgvAttr.iVehHeadDirect == DIRECTION_Y_P)
	{
		iGsDev = -iGroudxOffset;
		iGsDevFb = iGroudyOffset;
		iGsAngle = 2700 - iGroudangleoffset;
	}
	else if (g_stAgvAttr.iVehHeadDirect == DIRECTION_Y_N)
	{
		iGsDev = iGroudxOffset;
		iGsDevFb = -iGroudyOffset;
		iGsAngle = 900 - iGroudangleoffset;
	}

	g_stAgvAttr.iGsDevOnline = iGsDev;
	g_stAgvAttr.iGSDevFBOnline = iGsDevFb;
	g_stAgvAttr.iGSAngleOnline = iGsAngle;

	return 0;
}

/*******************************************************************************
* Function Name      : update_net_log
* Description	     : update the net info into net log
* Input 		     : NONE
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int update_net_log()
{
	static int iUpdateCount = 0;

	//if (iUpdateCount % 20 == 0)
	//	NET_LOG("AgvName\tLocation\tAgvIP\tGWIp\tApSSID\tApMAC\tSignalLevel\tConnected\n");

	iUpdateCount++;

	NET_LOG("%d\t%lld\t%s\t%s\t%s\t%s\t%d\t%d\n",
		g_stAgvAttr.iAgvName, g_stAgvAttr.iLocation, 
		g_stNetInfo.pLocalIpAddr, g_stNetInfo.pGateWayIpAddr,
		g_stNetInfo.pEssid, g_stNetInfo.pApAddr, g_stNetInfo.iSignalLevel,
		g_stNetInfo.iConnectConsoleOK);

	return 0;
}

/*******************************************************************************
* Function Name      : update_mcu_log
* Description	     : update the navgate data into mcu log
* Input 		     : NONE
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int update_mcu_log()
{
	static int iUpdateCount = 0;
	char cContainer[CONTAINER_SIZE] = "NONE";
	// add save navgate data log, inclue information:
	// DateTime			timestamp
	// AGVNo			I16
	// Location			I32
	// VehHeadDirect	I8
	// PalletDirect		I8
	// Action			I16
	// Speed			I16
	// GsDev			I32	//GXOffset
	// iGSDevFB			I32	//GYOffset
	// iGSAngle			I32 //GAngleOffset
	// TXOffset			I32
	// TYOffset			I32
	// TAngleOffset		I32
	// Battery			I32
	// Exception		I32
	// PalletStatus		I32
	// cContainer		C32
	convert_agv_offset();

	//when true,sta_send_event_info()will refresh the net-info ,by tiger
	if (false == g_stAgvConf.cSendStatistical)
	{
		update_net_stat();
	}

	if (g_stAgvAttr.iPalletStatus == PALLET_STATUS_TOP)
		memcpy(cContainer, g_stAgvAttr.cContainer, CONTAINER_SIZE);

	if (iUpdateCount % 20 == 0)
		MCU_LOG("AgvName\tLocation\tVDirect\tPDirect\tMStatus\tSpeed\tGsDev\tGsDevFB\tGSAngle\tPXO\tPYO\tPAngle\tBattery\tEvent\tPStatus\tShelfQR\tApMAC\tSignalLevel\n");
	
	iUpdateCount++;

	MCU_LOG("%d\t%lld\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s\t\%d\n",
		g_stAgvAttr.iAgvName, g_stAgvAttr.iLocation, g_stAgvAttr.iVehHeadDirect,
		g_stAgvAttr.iPalletDirect, g_stAgvAttr.iMoveStatus, g_stAgvAttr.iSpeed,
		g_stAgvAttr.iGsDevOnline, g_stAgvAttr.iGSDevFBOnline, g_stAgvAttr.iGSAngleOnline,
		g_stAgvAttr.iTXOffset, g_stAgvAttr.iTYOffset, g_stAgvAttr.iTAngleOffset / 10,
		g_stAgvAttr.bms.uSoc, g_stAgvAttr.iException, g_stAgvAttr.iPalletStatus, 
		cContainer, g_stNetInfo.pApAddr,g_stNetInfo.iSignalLevel);
}

/*******************************************************************************
* Function Name      : dump_exception_context
* Description	     : dump agv running context when exception
* Input 		     : NONE
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int dump_exception_context()
{
	char cContainer[CONTAINER_SIZE] = "000000";
	int iException = atomic_read(&g_stAgvAttr.iException);//by tiger.63
	float fVoltage = (float)g_stAgvAttr.bms.uVoltage/10;
	float fCurrent = (float)g_stAgvAttr.bms.uCurrent/10;
	convert_agv_offset();
	update_net_stat();

	if (g_stAgvAttr.iPalletStatus == PALLET_STATUS_TOP)
		memcpy(cContainer, g_stAgvAttr.cContainer, CONTAINER_SIZE);

	version(stdout);
	LOG_ERR("****************************************\n");
	LOG_ERR("AgvName       = %d\n", g_stAgvAttr.iAgvName);
	LOG_ERR("Location      = %lld\n", g_stAgvAttr.iLocation);
	LOG_ERR("VehHeadDirect = %d[%s]\n", g_stAgvAttr.iVehHeadDirect, get_direct_desc(g_stAgvAttr.iVehHeadDirect));
	LOG_ERR("PalletDirect  = %d[%s]\n", g_stAgvAttr.iPalletDirect, get_direct_desc(g_stAgvAttr.iPalletDirect));
	LOG_ERR("MoveStatus    = %d[%s]\n", g_stAgvAttr.iMoveStatus, get_move_status(g_stAgvAttr.iMoveStatus));
	LOG_ERR("Speed         = %d\n", g_stAgvAttr.iSpeed);
	LOG_ERR("GsDev         = %.2f mm\n", (float)(g_stAgvAttr.iGsDevOnline / 10));
	LOG_ERR("GSDevFB       = %.2f mm\n", (float)(g_stAgvAttr.iGSDevFBOnline / 10));
	LOG_ERR("GSAngle       = %.2f\n", (float)(g_stAgvAttr.iGSAngleOnline / 100));
	LOG_ERR("TXOffset      = %.2f mm\n", (float)(g_stAgvAttr.iTXOffset / 10));
	LOG_ERR("TYOffset      = %.2f mm\n", (float)(g_stAgvAttr.iTYOffset / 10));
	LOG_ERR("TAngleOffset  = %.2f\n", (float)(g_stAgvAttr.iTAngleOffset / 100));
	LOG_ERR("Battery       = %d\n", g_stAgvAttr.bms.uSoc);
	LOG_ERR("Exception     = %d[%s]\n", iException, get_err_str(iException));//by tiger.63
	LOG_ERR("PalletStatus  = %d[%s]\n", g_stAgvAttr.iPalletStatus, get_pallet_status_desc(g_stAgvAttr.iPalletStatus));
	LOG_ERR("ShelfQR       = %s\n", cContainer);
	// print the current network status
	LOG_ERR("NetDevName    = %s\n", g_stNetInfo.pNetDevName);
	LOG_ERR("Protocol      = %s\n", g_stNetInfo.pProtocolName);
	LOG_ERR("ESSID         = %s\n", g_stNetInfo.pEssid);
	LOG_ERR("Frequency     = %.4f GHz\n", (float)(g_stNetInfo.iFreq / 1000000000));
	LOG_ERR("BitRate       = %.4f Mbps\n", (float)(g_stNetInfo.iBitRate / 1000000));
	LOG_ERR("Channel       = %d\n", g_stNetInfo.iChannel);
	LOG_ERR("Sensitivity   = %d\n", g_stNetInfo.iSensitivity);
	LOG_ERR("LinkQuality   = %d\n", g_stNetInfo.iLinkQuality);
	LOG_ERR("SignalLevel   = %d\n", g_stNetInfo.iSignalLevel);
	LOG_ERR("NoiseLevel    = %d\n", g_stNetInfo.iNoiseLevel);
	LOG_ERR("SN            = %s\n",g_stAgvAttr.pSN ); //add by tiger.51
	LOG_ERR("IP            = %s\n", g_stAgvAttr.pIP); //add by tiger.51
	LOG_ERR("bat temper    = %dC\n", g_stAgvAttr.bms.uTemp - TEMPER_BASE);//add by tiger
	LOG_ERR("bat voltage   = %.2fV\n", fVoltage);//add by tiger
	LOG_ERR("bat current   = %.2fA\n", fCurrent);//add by tiger
	LOG_ERR("bat soc       = %d%\n", g_stAgvAttr.bms.uSoc);//add by tiger
	LOG_ERR("bat state     = %s\n", ((g_stAgvAttr.bms.uState == 1) ? "charging" : "not charging"));//add by tiger
	LOG_ERR("****************************************\n");

	return 0;
}

/*******************************************************************************
*Function Name :init_seq
*Description      :init seq of agent,MC and TC  ,by tiger.79
*Input       	  :int iAgentSeq  
*Input       	  :int iMcSeq  
*Input       	  :int iTcSeq  
*Input       	  :int iHBSeq  
*Output 		  :NONE
*Return            :NONE  
*******************************************************************************/
void init_seq(int iAgentSeq, int iMcSeq, int iTcSeq,int iHBSeq)
{
	
	g_i32Seq[AGENENT_SEQ_ID] = iAgentSeq;
	g_i32Seq[MC_SEQ_ID] = iMcSeq;
	g_i32Seq[TC_SEQ_ID] = iTcSeq;
	g_i32Seq[UDP_HEARTBEAT_SEQ_ID] = iHBSeq;
	LOG_INF("initial value: AGENENT_SEQ_ID = %d,MC_SEQ_ID = %d,TC_SEQ_ID = %d,UDP_HEARTBEAT_SEQ_ID = %d\n", iAgentSeq, iMcSeq, iTcSeq,iHBSeq);
}

/*******************************************************************************
* Function Name		 : get_seq
* Description	     : get the sequence num.
* input			     : iSeqIndex: the index of sequence number
						AGENENT_SEQ_ID
						MC_SEQ_ID
						TC_SEQ_ID
* Output		     : NONE
* Return		     : -1 on invalid, return the sequence num on success.
*******************************************************************************/
int get_seq(int iSeqIndex)
{
	int32_t i32Ret;

	if (iSeqIndex >= SEQ_NUM)
	{
		LOG_ERR("get wrong sequence id\n");
		return -1;
	}

	pthread_mutex_lock(&seq_mutex);
	i32Ret = g_i32Seq[iSeqIndex];
	g_i32Seq[iSeqIndex]++;
	pthread_mutex_unlock(&seq_mutex);

	return i32Ret;
}

/*******************************************************************************
*Function Name    :get_reg_result
*Description      :get register result,by tiger at 20180806  
*Input       	  :short i16Result  
*Output 		  :NONE
*Return           :char *  
*******************************************************************************/
char * get_reg_result(short i16Result)
{
	char *pMsgName = NULL;
	switch (i16Result)
	{
	case 0:
		pMsgName = "Accept Register";
		break;
	default:
		pMsgName = "Refuse Register";
		break;
	}
	return pMsgName;
}
/*******************************************************************************
* Function Name		 : get_msg_name
* Description	     : get message name by type.
* input			     : iMsgType: msg type
* Output		     : NONE
* Return		     : the pointer of message name
*******************************************************************************/
char * get_msg_name(int iMsgType)
{
	char *pMsgName = NULL;

	switch (iMsgType) {
	case MSG_TYPE_REGISTER:
		pMsgName = "MSG_TYPE_REGISTER";
		break;
	case MSG_TYPE_UNREGISTER:
		pMsgName = "MSG_TYPE_UNREGISTER";
		break;
	case MSG_TYPE_HEARTBEAT:
		pMsgName = "MSG_TYPE_HEARTBEAT";
		break;
	case MSG_TYPE_ERROR:
		pMsgName = "MSG_TYPE_ERROR/EVENT";
		break;
	case MSG_TYPE_EVENT_RELEASE:
		pMsgName = "MSG_TYPE_EVENT_RELEASE";
		break;
	case MSG_TYPE_FINISH:
		pMsgName = "MSG_TYPE_FINISH";
		break;
	case MSG_TYPE_ERROR_POINT:
		pMsgName = "MSG_TYPE_ERROR_POINT";
		break;
	case MSG_TYPE_POINT:
		pMsgName = "MSG_TYPE_POINT";
		break;
	case MSG_TYPE_CONFIRM:
		pMsgName = "MSG_TYPE_CONFIRM";
		break;
	case MSG_TYPE_DEBUG:
		pMsgName = "MSG_TYPE_DEBUG";
		break;
	case MSG_TYPE_OPERATE:
		pMsgName = "MSG_TYPE_OPERATE";
		break;
	case MSG_TYPE_INFO:
		pMsgName = "MSG_TYPE_INFO";
		break;
	case MSG_TYPE_GET_PARAM:
		pMsgName = "MSG_TYPE_GET_PARAM";
		break;
	case MSG_TYPE_SET_PARAM:
		pMsgName = "MSG_TYPE_SET_PARAM";
		break;
	case MSG_TYPE_UPDATE://by tiger.44
		pMsgName = "MSG_TYPE_UPDATE";
		break;
	case MSG_TYPE_UPDATE_RESULT://by tiger.44
		pMsgName = "MSG_TYPE_UPDATE_RESULT";
		break;
	case MSG_TYPE_SET_CONFIG://by tiger.44
		pMsgName = "MSG_TYPE_SET_CONFIG";
		break;
	case MSG_TYPE_GET_CONFIG://by tiger.44
		pMsgName = "MSG_TYPE_GET_CONFIG";
		break;
	default:
		pMsgName = "UNKNOWN_MSG_TYPE";
		break;
	}

	return pMsgName;
}


/*******************************************************************************
* Function Name		 : get_action_name
* Description	     : get action name by type.
* input			     : iActionType: action type
* Output		     : NONE
* Return		     : the pointer of action name
*******************************************************************************/
char * get_action_name(int iActionType)
{
	char *pActionName = NULL;

	switch (iActionType) {
	case NO_ACTION:
		pActionName = "NO_ACTION";
		break;
	case ACTION_WALK:
		pActionName = "ACTION_WALK";
		break;
	case ACTION_TURN_LEFT:
		pActionName = "ACTION_TURN_LEFT";
		break;
	case ACTION_TURN_RIGHT:
		pActionName = "ACTION_TURN_RIGHT";
		break;
	case ACTION_RISE:
		pActionName = "ACTION_RISE";
		break;
	case ACTION_LAY:
		pActionName = "ACTION_LAY";
		break;
	case ACTION_CHARGE:
		pActionName = "ACTION_CHARGE";
		break;
	case ACTION_STOP_CHARGE:
		pActionName = "ACTION_STOP_CHARGE";
		break;
	case ACTION_PARK:
		pActionName = "ACTION_PARK";
		break;
	case ACTION_CLEAN_DERAIL:
		pActionName = "ACTION_CLEAN_DERAIL";
		break;
	case ACTION_SET_ZONE:
		pActionName = "ACTION_SET_ZONE";
		break;
	case ACTION_CLEAR_SAFE:
		pActionName = "ACTION_CLEAR_SAFE";
		break;
	case ACTION_IMU:
		pActionName = "ACTION_IMU";
		break;
	case ACTION_QR:
		pActionName = "ACTION_QR";
		break;
	case ACTION_PALLET_TURN_LEFT:
		pActionName = "ACTION_PALLET_TURN_LEFT";
		break;
	case ACTION_PALLET_TURN_RIGHT:
		pActionName = "ACTION_PALLET_TURN_RIGHT";
		break;
	case ACTION_BACK_TO_CHARGE:
		pActionName = "ACTION_BACK_TO_CHARGE";
		break;
	case ACTION_FORWARD_LEAVE_CHARGE:
		pActionName = "ACTION_FORWARD_LEAVE_CHARGE";
		break;
	case ACTION_LEFT_ARC:
		pActionName = "ACTION_LEFT_ARC";
		break;
	case ACTION_RIGHT_ARC:
		pActionName = "ACTION_RIGHT_ARC";
		break;
	case ACTION_FORWARD_TO_CHARGE:
		pActionName = "ACTION_FORWARD_TO_CHARGE";
		break;
	case ACTION_BACK_LEAVE_CHARGE:
		pActionName = "ACTION_BACK_LEAVE_CHARGE";
		break;
	case ACTION_CLEAR_NAVIGATION:
		pActionName = "ACTION_CLEAR_NAVIGATION";
		break;
	default:
		pActionName = "UNKNOWN_ACTION_TYPE";
		break;
	}

	return pActionName;
}

/*******************************************************************************
* Function Name		 : get_can_desc
* Description	     : get can description by can id.
* input			     : iMsgType: can id
* Output		     : NONE
* Return		     : the pointer of can description
*******************************************************************************/
char * get_can_desc(int iCanId)
{
	char *pCanDesc = NULL;

	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		switch (iCanId) {
			// battery can id
		case BATT_REQ_CANID:
			pCanDesc = "BATT_REQ_CANID";
			break;
		case BATT_ACK_CANID:
			pCanDesc = "BATT_ACK_CANID";
			break;
		case BATT_ACK_CANID_0X15:
			pCanDesc = "BATT_ACK_CANID_0X15";
			break;
		case BATT_REQ_V2_CANID:
			pCanDesc = "BATT_REQ_V2_CANID";
			break;

			// TC can id
		case TC_CANID_REQ:
			pCanDesc = "TC_CANID_REQ";
			break;
		case TC_CANID_ACK:
			pCanDesc = "TC_CANID_ACK";
			break;
		case TC_CANID_FINISH:
			pCanDesc = "TC_CANID_FINISH";
			break;
		case TC_CANID_ERR:
			pCanDesc = "TC_CANID_ERR";
			break;
		case TC_2MC_FINISH:
			pCanDesc = "TC_2MC_FINISH";
			break;
			// MC can id
		case MC_CANID_REQ:
			pCanDesc = "MC_CANID_REQ";
			break;
		case MC_CANID_ACK:
			pCanDesc = "MC_CANID_ACK";
			break;
		case MC_CANID_HEART:
			pCanDesc = "MC_CANID_HEART";
			break;
		case MC_CANID_FINISH:
			pCanDesc = "MC_CANID_FINISH";
			break;

			// PGV can id
		case PGV_CANID_START:
			pCanDesc = "PGV_CANID_START";
			break;
		case PGV_CANID_TxPDO1:
			pCanDesc = "PGV_CANID_TxPDO1";
			break;
		case PGV_CANID_TxPDO2:
			pCanDesc = "PGV_CANID_TxPDO2";
			break;
		case PGV_CANID_TxPDO3:
			pCanDesc = "PGV_CANID_TxPDO3";
			break;
		case PGV_CANID_TxPDO4:
			pCanDesc = "PGV_CANID_TxPDO4";
			break;
		case PGV_CANID_TxTEST:
			pCanDesc = "PGV_CANID_TxTEST";
			break;
		case PGV_CAN_TESTACK:
			pCanDesc = "PGV_CAN_TESTACK";
			break;
		
		// other can description
		case TC_VERSION_F:
			pCanDesc = "MC/TC_VERSION_F";
			break;
		case PALLET_STATUS_F:
			pCanDesc = "PALLET_STATUS_F";
			break;
		case ARM2TC_ANGLE_CANID:
			pCanDesc = "ARM2TC_ANGLE_CANID";
			break;
		case ARM2TC_ANGLE_ACK:
			pCanDesc = "ARM2TC_ANGLE_ACK";
			break;

		// MCv2 can description
		case MC_CAN_ERR_V2_CANID:
			pCanDesc = "MC_CAN_ERR_V2_CANID";
			break;
		case MC_CAN_FLAG_PARAM_REQ_V2_CANID:
			pCanDesc = "MC_CAN_FLAG_PARAM_REQ_V2_CANID";
			break;
		case TP_CAN_ANGLEREQ_V2_CANID:
			pCanDesc = "TP_CAN_ANGLEREQ_V2_CANID";
			break;
		case TP_CAN_ANGLEACK_V2_CANID:
			pCanDesc = "TP_CAN_ANGLEACK_V2_CANID";
			break;
		//add by jxu 20180910-begin
		case BATT_ACK_CANID_0X1C:
			pCanDesc = "BATT_ACK_CANID_0X1C";
			break;
		case BATT_ACK_CANID_0X19:
			pCanDesc = "BATT_ACK_CANID_0X19";
			break;
		case CAN_EFF_FLAG | BMS_INQUIRY_CANID:
			pCanDesc = "BMS_INQUIRY_CANID";
			break;
		case CAN_EFF_FLAG | BMS_FLASH_ERASE_CANID:
			pCanDesc = "BMS_FLASH_ERASE_CANID";
			break;
		case CAN_EFF_FLAG | BMS_PACKAGE_LEN_CANID:
			pCanDesc = "BMS_PACKAGE_LEN_CANID";
			break;
		case CAN_EFF_FLAG | BMS_BINFILE_TRAS_CANID:
			pCanDesc = "BMS_BINFILE_TRAS_CANID";
			break;
		case CAN_EFF_FLAG | BMS_BINFILE_TRAS_ERR_CANID:
			pCanDesc = "BMS_BINFILE_TRAS_ERR_CANID";
			break;
		//add by jxu 20180910-end
		default:
			pCanDesc = "UNKNOWN_CAN_DESC";
			break;
		}
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		switch (iCanId) {
			// battery can id
		case BATT_REQ_CANID:
			pCanDesc = "BATT_REQ_CANID";
			break;
		case BATT_ACK_CANID:
			pCanDesc = "BATT_ACK_CANID";
			break;
		case BATT_ACK_CANID_0X15:
			pCanDesc = "BATT_ACK_CANID_0X15";
			break;
		case BATT_REQ_V2_CANID:
			pCanDesc = "BATT_REQ_V2_CANID";
			break;

		// MCv2 can description
		case MC_CAN_REQ_V2_CANID:
			pCanDesc = "MC_CAN_REQ_V2_CANID";
			break;
		case MC_CAN_ACK_V2_CANID:
			pCanDesc = "MC_CAN_ACK_V2_CANID";
			break;
		case MC_CAN_HEARTBEAT_V2_CANID:
			pCanDesc = "MC_CAN_HEARTBEAT_V2_CANID";
			break;
		case MC_CAN_FINISH_V2_CANID:
			pCanDesc = "MC_CAN_FINISH_V2_CANID";
			break;
		case MC_CAN_ERR_V2_CANID:
			pCanDesc = "MC_CAN_ERR_V2_CANID";
			break;
		case MC_CAN_FLAG_PARAM_REQ_V2_CANID:
			pCanDesc = "MC_CAN_FLAG_PARAM_REQ_V2_CANID";
			break;
		case MC_CAN_FLAG_PARAM_ACK_V2_CANID:
			pCanDesc = "MC_CAN_FLAG_PARAM_ACK_V2_CANID";
			break;
		case MC2ARM_UPDATE_CANID:
			pCanDesc = "MC2ARM_UPDATE_CANID";
			break;
		case ARM2MC_UPDATE_CANID:
			pCanDesc = "ARM2MC_UPDATE_CANID";
			break;
		case MC2ARM_UPDATE_DATA_CANID:
			pCanDesc = "MC2ARM_UPDATE_DATA_CANID";
			break;
		case ARM2MC_UPDATE_DATA_CANID:
			pCanDesc = "ARM2MC_UPDATE_DATA_CANID";
			break;
		case TP_CAN_ANGLEREQ_V2_CANID:
			pCanDesc = "TP_CAN_ANGLEREQ_V2_CANID";
			break;
		case TP_CAN_ANGLEACK_V2_CANID:
			pCanDesc = "TP_CAN_ANGLEACK_V2_CANID";
			break;
		//add by jxu 20180910-begin
		case BATT_ACK_CANID_0X1C:
			pCanDesc = "BATT_ACK_CANID_0X1C";
			break;
		case BATT_ACK_CANID_0X19:
			pCanDesc = "BATT_ACK_CANID_0X19";
			break;
		case CAN_EFF_FLAG | BMS_INQUIRY_CANID:
			pCanDesc = "BMS_INQUIRY_CANID";
			break;
		case CAN_EFF_FLAG | BMS_FLASH_ERASE_CANID:
			pCanDesc = "BMS_FLASH_ERASE_CANID";
			break;
		case CAN_EFF_FLAG | BMS_PACKAGE_LEN_CANID:
			pCanDesc = "BMS_PACKAGE_LEN_CANID";
			break;
		case CAN_EFF_FLAG | BMS_BINFILE_TRAS_CANID:
			pCanDesc = "BMS_BINFILE_TRAS_CANID";
			break;
		case CAN_EFF_FLAG | BMS_BINFILE_TRAS_ERR_CANID:
			pCanDesc = "BMS_BINFILE_TRAS_ERR_CANID";
			break;
		//add by jxu 20180910-end
		default:
			pCanDesc = "UNKNOWN_CAN_DESC";
			break;
		}
	}

	return pCanDesc;
}


/*******************************************************************************
*Function Name    : write_rtc
*Description      : sync sysem time with console
*Input       	  : time_t liTime:calendar time
*Output 		  :
*Return           : int:0 if OK,-1 on error
*******************************************************************************/
int write_rtc(time_t liTime)
{
	char pBuf[100] = { 0 };
	char pCMD[100] = { 0 };
	struct tm *pLocalTime = localtime(&liTime);
	if (strftime(pBuf, sizeof(pBuf), "%F %H:%M:%S", pLocalTime) < 0)
	{
		LOG_INF("ERROR:%s", strerror(errno));
	}

	if (sprintf(pCMD, "%s \"%s\"", "date -s", pBuf) < 0)
	{
		LOG_INF("error:%s\n", strerror(errno));
		return -1;
	}
	if (system(pCMD) != 0)
	{
		LOG_INF("error:%s\n", strerror(errno));
		return -1;
	}
	if (system("hwclock  -w") != 0)
	{
		LOG_INF("error:%s\n", strerror(errno));
		return -1;
	}
	LOG_INF("set system time success:%s\n", pBuf);
	return 0;
}


/*ADD FOR BOOTMETHOD BY YU START 20181024*/
/*******************************************************************************
*Function Name    : check_boot_method
*Description      : check boot method of the board
*Input       	  : stAgvAttr: agv attribute
*Output 		  : BootMethod: 1:watchdog restart system 0: mannual reboot
*Return         : 0: success, -1:failed
*******************************************************************************/
int check_boot_method(agv_attr_t* stAgvAttr)
{
	int iRet = 0;
	char* pWatchdogPath = "/tmp/timeout";	//touch timeout when watchdog restart system
	char* pRebootPath = "/tmp/reboot";			//touch reboot when cmd reboot restart system
	char* pPowerOffPath = "/tmp/poweroff";	//touch poseroff when normally power on

	if (stAgvAttr == NULL)
		return -1;

	iRet = access(pWatchdogPath, F_OK);
	if (0 == iRet)
	{
		stAgvAttr->iBootMethod = 1;
	}
	else
	{
		stAgvAttr->iBootMethod = 0;
	}

	return 0;
}
/*ADD FOR BOOTMETHOD BY YU END 20181024*/