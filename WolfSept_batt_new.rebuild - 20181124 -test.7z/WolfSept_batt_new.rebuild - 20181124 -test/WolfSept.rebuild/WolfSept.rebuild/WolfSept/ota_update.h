/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* FileName:OTA_UPDATE.H
* Author: Menghu Wang   Version: V1.0   Data:2018-01-26
* Description:REALIZE THE INTERFACE OF OTA UPDATE APP
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
#ifndef _OTA_UPDATE_H__
#define _OTA_UPDATE_H__
/* Define to prevent recursive inclusion -------------------------------------*/
/* Includes ------------------------------------------------------------------*/
#include "global_var.h"
/* Exported types ------------------------------------------------------------*/
// typedef unsigned char   u8;
// typedef unsigned short  u16;
// typedef unsigned int	u32;
// typedef signed  char	i8;
// typedef signed  short   i16;
// typedef signed  int	    i32;
typedef struct _update_master
{
	u8    pNewVersion[64];
	u8    pCurVersion[64];
	u8    pUserName[64];
	u8    pPassword[64];
	u8    pUpdateMethod[64];
	u8    pUpdateSucFilePath[64];
	u8    pMasterAppName[64];
	u8    pDownloadDir[128];//download dir
	u8	  pCurrentDir[128];//current version app dir
	u8	  pExcuteDir[128];//the execute app dir
	u8    pUpdateScriptPath[128];//the absolute path of update script
	int   iSocketId;
	u32   u32AppFileCrc32;
	struct sockaddr_in stNetAddr;
	u8	  u8ConnectTimeout;
	int(*get_new_version)(char *pNewVersion);
	int(*need_update)(const char *pCurVersion, const char *pNewVersion);
	int(*download_file)(const char *pFileName, const char *pSavePath,
		const struct sockaddr_in *pHost, const char *pUserName, const char *pPassword,int iTimeOut);
	int(*upload_file)(const char *pMasterAppName, const char *pDownloadDir);
}update_master;
/* Exported constants --------------------------------------------------------*/
extern update_master g_stUpdateMaster;
/* Exported macro ------------------------------------------------------------*/
#define CONFIGURE_FILE_PATH   "/root/jdagvclientserver/jdagvserver/flow.conf"
/* Exported functions --------------------------------------------------------*/
extern int ota_update_init(const char *pConfFilePath, update_master *pUpdateMaster);
extern int ota_update_deinit(update_master *pUpdateMaster);
extern int update_success(const char *pFilePath);
extern int ota_update_master(void);
#endif /* _OTA_UPDATE_H__ */
/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/