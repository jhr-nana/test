/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* FileName:AGV_PTHREAD.H
* Author: Menghu Wang   Version: V1.0   Data:2017-07-13
* Description:THE INTERFACE OF AGV PTHREAD FUNCTION
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _AGV_PTHREAD_H__
#define _AGV_PTHREAD_H__
/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <errno.h> 

#include "udp.h"
#include "config.h"

/* Exported macro ------------------------------------------------------------*/
#define THREAD_NUM 			12 //modified by yyf 20181120

typedef void *(*start_routine)(void *);
typedef struct work_thread {
	pthread_t iThreadId;
	pthread_attr_t stThreadAttr;
	start_routine pThreadStartRoutine;
	void  *pThreadArg;
	int iThreadState;
} work_thread_t;

extern work_thread_t gWorkThread[THREAD_NUM];

/* Exported types ------------------------------------------------------------*/
enum
{
	ThreadInitial = 0,
	ThreadStandBy = 1,
	ThreadRunning = 2,
	ThreadSuspend = 3,
	ThreadStopped = 4
} thread_state;

/* Exported constants --------------------------------------------------------*/

/* Exported functions ------------------------------------------------------- */
extern int heartbeat_thread_create();
extern int recvcan0_thread_create();//add by jxu 20180917
extern int work_thread_create();
extern int work_thread_destroy();
extern int wait_thread_ready(int iTimeOut);
#endif /* _AGV_PTHREAD_H__ */

/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/

