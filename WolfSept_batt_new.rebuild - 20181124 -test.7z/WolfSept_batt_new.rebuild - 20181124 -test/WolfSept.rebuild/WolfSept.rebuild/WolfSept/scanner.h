#ifndef SCANNER_H
#define SCANNER_H

#ifdef __cplusplus
extern "C" {
#endif


#include "globaldefine.h"


extern int IMG_WIDTH;  // 宽度

extern  uint8_t detectedRingsNum;

extern  snake_detectedRing detectedRings[MAX_RING_NUM]; // 记录检测到的圆环

extern int g_iPatternIdxArray[MAX_RING_NUM];

extern snake_mapPose mapPose; // 记录码图的位姿信息


bool FuncRingsDetect(uint8_t * pucDataStrAddr,int pixStart,int pixEnd,int linStart,int linEnd);


bool FuncCodeMapPoseEstimate(int i, int j, int k); // 特征圆配对，位姿初步估计，尺寸数据确认


// 判断当前3个特征圆环，是否满足刚体变换，用于确定采用何种方案进行后续操作（rigid or homography）
snake_transType isRigidTransform(snake_mapPose *mapPose);


#ifdef __cplusplus
}
#endif

#endif // SCANNER_H
