#ifndef _CAN_MSG_H__
#define _CAN_MSG_H__

#include "global_var.h"
#include "udp_msg.h"

#define MC_TYPE_READ_F   		0  // read flag
#define TC_CLASP_F				0x02
#define PALLET_STATUS_F			0x03
#define MC_VERSION_F			0x04
#define TC_VERSION_F			0x04
#define FTP_TC_CANFRAME_F		0x05
#define FTP_MC_CANFRAME_F		0x06
#define MC_CLEAR_DERAIL_F       0x02
#define MC_CLEAR_NAVIGATE_F     0x03
#define MC_CLEAR_LCODER_ERROR_F     0x0a
#define MC_CLEAR_RCODER_ERROR_F     0x0b
#define MC_TYPE_SET_F   		1  //set flag
#define MC_TYPE_ACTION			2
#define MC_TYPE_READ_PARA		3
#define MC_TYPE_SET_PARA		4
#define MC_ACTION_WALK   		0
#define MC_ACTION_BACK   		1
#define MC_ACTION_LEFT   		2
#define MC_ACTION_RIGHT   		3
#define MC_ACTION_PARK   		4
#define MC_ACTION_CHARGE		5
#define MC_ACTION_NCHARGE		6
#define MC_ACTION_RESET			7
#define MC_ACTION_WD			8  // enalbe watch dog

#define TC_TYPE_READ_F   		2  // read var

#define DSP_STAT_OK		1
#define DSP_STAT_ERR	0

#define CAN_RETRY_LIMIT 20
#define PGV_OPERATIONAL_STATE  0X05

extern int send_pgv_req(uint8_t u8Data);
extern int parse_groudqr(struct can_frame *pframe);
extern int parse_pgv_heartbeart(uint8_t u8Data);
extern void parse_Y_offset(struct can_frame *pframe);
extern void parse_X_offset(struct can_frame *pframe);
extern int check_pallet();
extern int init_agv_pallet_status();
extern int init_agv_location_head_direct();
extern int check_pallet_QR();
#endif/*_CAN_MSG_H__*/