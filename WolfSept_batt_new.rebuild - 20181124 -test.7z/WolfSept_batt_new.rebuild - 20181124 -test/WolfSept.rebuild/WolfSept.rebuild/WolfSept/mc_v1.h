/********************************************************************************
* Copyright (c) 2017, JD.COM, Inc .
* All rights reserved.
* FileName: mc_v1.c
* Author: tongkedong   Version: V1.0   Data:2017-12-18
* Description:
* move control low-level support api code
********************************************************************************/
#ifndef _MC_V1_H_
#define _MC_V1_H_
#include "global_var.h"
#include "device.h"
#include "debug.h"
typedef enum
{
	DSP_NOT_UPDATE_CMD = 0,
	DSP_UPDATE_CMD,
	DSP_SEND_FINISHED_CMD
}dsp_update_cmd;
typedef struct _mc_update
{
	canid_t can_id;  /* 32 bit CAN_ID + EFF/RTR/ERR flags */
	__u8    can_dlc; /* data length code: 0 .. 8 */
	u32     u32Data;//data[0~3]
	u8    u8Var;//data[4]
	u8    u8Cmd;//data[5]
	u8   u8Style;//data[6]
	u8	  u8Sequence;//data[7]
}mc_update;
typedef struct mc_can_cmd_req
{
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned short iData2;				//Byte[0-1]
	unsigned short iData1;				//Byte[2-3]
	unsigned char  iVar;				//Byte[4]
	unsigned char  iCmd;				//Byte[5]
	unsigned char  iStyle;				//Byte[6]
	unsigned char  iSeq;				//Byte[7]
} mc_can_cmd_req_t;

typedef struct mc_can_cmd_ack
{
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned short iData1;				//Byte[0-1],change by tiger
	unsigned short iData2;				//Byte[2-3],change by tiger
	unsigned char  iVar;				//Byte[4]
	unsigned char  iCmd;				//Byte[5]
	unsigned char  iStyle;				//Byte[6]
	unsigned char  iSeq;				//Byte[7]
} mc_can_cmd_ack_t;

typedef struct mc_can_cmd_fin
{
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned short iData1;				//Byte[0-1]
	unsigned short iData2;				//Byte[2-3]
	unsigned char  iReserve;			//Byte[4]
	unsigned char  iCmd;				//Byte[5]
	unsigned char  iStyle;				//Byte[6]
	unsigned char  iSeq;				//Byte[7]
} mc_can_cmd_fin_t;

typedef struct mc_can_heartbeat {
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	short    int   iSpeed;				//Byte[0-1]
	unsigned short iResDistance;		//Byte[2-3]
	unsigned char  iPath : 7;			//Byte[4].bit[6:0]
	unsigned char  iNewTag : 1;			//Byte[4].bit[7]
	unsigned char  iEvent : 6;			//Byte[5].bit[5:0]
	unsigned char  iMode : 2;			//Byte[5].bit[7:6]
	unsigned char  iHeadDirect : 4;		//Byte[6].bit[3:0]
	unsigned char  iMoveState : 4;			//Byte[6].bit[7:4]
	unsigned char  iSeq;				//Byte[7]
} mc_can_heartbeat_t;

extern int mc_v1_check_version();
extern int mc_v1_get_flag(u8 u8FlagVar);
extern int mc_v1_set_flag(u8 u8FlagVar, u32 u32Value);
extern int mc_v1_get_param(u8 u8ParamVar);
extern int mc_v1_set_param(u8 u8ParamVar, float fValue);
extern int mc_v1_enable_wdg();
extern int mc_v1_start();
extern int mc_v1_reset();
extern int mc_v1_stop();
extern void mc_v1_deal_ack(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
extern void mc_v1_deal_fin(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
extern int mc_v1_deal_heartbeat(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
extern int mc_v1_deal_exception(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);

extern int mc_v1_start_charge();
extern int mc_v1_stop_charge();

extern int mc_v1_go_forward(u8 u8Weight, u16 u16Distance, u16 u16Speed);
extern int mc_v1_go_backward(u8 u8Weight, u16 u16Distance, u16 u16Speed);
extern int mc_v1_turn_left(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed);
extern int mc_v1_turn_right(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed);
extern int mc_v1_slow_go_back(u16 u16SRemain, u16 u16QRDistance);
extern int mc_v1_slow_go_straight(u16 u16SRemain, u16 u16QRDistance);
extern int mc_v1_leftarc(u16 u16Weight);
extern int mc_v1_rightarc(unsigned short u16Weight);
extern int mc_v1_clear_derail(void);
extern int mc_v1_clear_navigation(void);
extern int mc_v1_clear_lcoder_error(void);
extern int mc_v1_clear_rcoder_error(void);
extern int mc_v1_enter_debug_mode(void);
extern int mc_v1_quit_debug_mode();
extern int mc_v1_clasp_pallet(void);
extern int mc_v1_unclasp_pallet(void);
extern int mc_v1_clasp_wheel(void);
extern int mc_v1_unclasp_wheel(void);
extern int mc_v1_cntl_update_cmd(bool bIsMC, int iCmd, size_t ulFrameCount);
#endif //_MC_V1_H_
