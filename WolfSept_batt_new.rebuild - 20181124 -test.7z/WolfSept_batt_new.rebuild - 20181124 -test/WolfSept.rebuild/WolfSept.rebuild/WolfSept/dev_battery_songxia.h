/********************************************************************************
* Copyright (C) 2025, JD.COM, Inc.
* All rights reserved.
* FileName    : dev_battery_songxia.h
* Author      : yyf   Version: V1.0   Data:2018-11-21
* Description : dev_battery_songxia.h
********************************************************************************/
#ifndef __DEV_BATTERY_SONGXIA_H__
#define __DEV_BATTERY_SONGXIA_H__

extern int songxia_recv_bms_info(struct can_frame * pBatCanData);

extern int songxia_inquiry_bms_info(batt_info_t *pBattInfo);

extern int songxia_bms_info_exception_handle(batt_info_t *pBattInfo);

extern int songxia_commit_bms_info(batt_info_t *pBattInfo);

extern int songxia_dump_bms_info(batt_info_t *pBattInfo);

extern int songxia_update_bms_info(batt_info_t *pBattInfo);

extern int songxia_start_charge();

extern int songxia_stop_charge();

extern int songxia_get_lasterfive_poweroff();

extern int songxia_get_pack_type();

extern int songxia_get_vid_pid();
		
extern int songxia_battery_init_check();

#endif 