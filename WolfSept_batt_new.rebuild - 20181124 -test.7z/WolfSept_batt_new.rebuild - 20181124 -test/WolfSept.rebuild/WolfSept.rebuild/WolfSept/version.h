#define COMPILE_VERSION "619abe11a06da535d640a92e7c944384ce965225"
#define COMPILE_TIME "2018-10-11 12:03:10"
#define COMPILE_BY "kedong"
#define COMPILER_VERSION "arm-linux-gnueabihf-gcc version 4.8.3 20140401"
