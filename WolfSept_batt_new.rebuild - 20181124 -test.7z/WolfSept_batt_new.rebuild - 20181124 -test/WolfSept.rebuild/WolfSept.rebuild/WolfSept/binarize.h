/*Copyright (C) 2008-2009  Timothy B. Terriberry (tterribe@xiph.org)
  You can redistribute this library and/or modify it under the terms of the
   GNU Lesser General Public License as published by the Free Software
   Foundation; either version 2.1 of the License, or (at your option) any later
   version.*/
#ifndef _qrcode_binarize_H
# define _qrcode_binarize_H

#ifdef __cplusplus
extern "C" {
#endif

#include "globaldefine.h"

//void qr_image_cross_masking_median_filter(unsigned char *_img,
// int _width,int _height);

//void qr_wiener_filter(unsigned char *_img,int _width,int _height);


extern uint8_t *grayImageData;     // 原始灰度图像
extern uint8_t *binaryImageData;   // 二值化后图像

/*Binarizes a grayscale image.*/
void FuncImgBinarize(int _width,int _height);

/// binarizes a grayscale image by local adaptive threshold method
void FuncAdaptiveThreshold(int _width,int _height);
#ifdef __cplusplus
}
#endif

#endif
