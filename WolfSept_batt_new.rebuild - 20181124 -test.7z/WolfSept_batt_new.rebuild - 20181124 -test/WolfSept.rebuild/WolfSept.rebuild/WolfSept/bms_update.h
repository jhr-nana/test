/********************************************************************************
* Copyright (c) 2018, JD.COM, Inc .
* All rights reserved.
* FileName: bms_update.h
* Author: Xu Jing   Version: V1.0   Data:2018-07-27
* Description:
* support the bms upgrade to the Pansonic
********************************************************************************/
#ifndef _BMS_UPDATE_H_
#define _BMS_UPDATE_H_

#include "can.h"
#include "global_var.h"
#include "ftp.h"
#include "device.h"


#define UPDATE_BMS_DIR  "/root/jdagvclientserver/jdagvserver/bms_update"
#define PANSONIC_APP_NAME  "JD_D500_BMS.bin"
#define CHANGHONG_APP_NAME "JD_AGV_F073_v99.bin"//save the interface to extend the other bms
#define BMS_VERSION_FILE_NAME "bms_version.txt"

#define PACKAGE_DATA_LENGTH             1026
#define	BMS_DATA_SECTOR					1024
#define BMS_TX_APP_COUNT				1

/* special address description flags for the CAN_ID */
#define CAN_EFF_FLAG	0x80000000U		/* EFF/SFF is set in the MSB */
#define CAN_RTR_FLAG	0x40000000U		/* remote transmission request */
#define CAN_ERR_FLAG	0x20000000U		/* error frame */

///* valid bits in CAN ID for frame formats */
//#define CAN_SFF_MASK	0x000007FFU		/* standard frame format (SFF) */
//#define CAN_EFF_MASK	0x1FFFFFFFU		/* extended frame format (EFF) */
//#define CAN_ERR_MASK	0x1FFFFFFFU		/* omit EFF, RTR, ERR flags */

extern int update_agv_bms(int iBatType);
#endif