#include <stdint.h>
#include "rigidmodel.h"


///********************************************
//函数功能:FuncMapPosePreciseCalculate函数实现,最小二乘检测
//函数输入:
//函数输出:
//*********************************************/
bool FuncMapPosePreciseCalculate(void){

    int whitePixelCount = 0;
    float blackRatio = 0.0f;
    float ellipseRadioBA = 0.0f;
    float ellipseRadioBC = 0.0f;

    float RecTheta1 = 0.0f;
    float RecTheta2 = 0.0f;
    float extendRecTheta = 0.0f;

    float errorLinePos2Org1 = 0.0f;
    float errorLinePos2Org2 = 0.0f;
    float errorLinePos2OrgExtend = 0.0f;
    float linBATheta = 0.0f;
    float linBCTheta = 0.0f;

    snake_point recCornerBA[4];
    snake_point recCornerBC[4];


    ELLIPSE_PARA recBAEllipsePara;
    ELLIPSE_PARA recBCEllipsePara;

    bool isRightBACorner = false;
    bool isRightBCCorner = false;
    bool isSuccessBA = false;
    bool isSuccessBC = false;
    int countBA = 0;
    int countBC = 0;



    isRightBACorner=FuncRecCornerDetect(mapPose.PointB, mapPose.PointA, MAP_HEIGHT, recCornerBA);

    if(false==isRightBACorner){
        return false;
    }


    countBA=FuncBlackExtract(binaryImageData, recCornerBA, tempDataPool, &whitePixelCount);

    // 计算两个特征圆之间的矩形当中，黑色像素所占的比例，理想比例为40%
    // 若所占比例不足，则认为特征圆间不存在黑色矩形区域
//    blackRatio = countBA*1.0f / (countBA + whitePixelCount);
//    if (blackRatio<0.3 || blackRatio>0.5)
//        return false;

    isSuccessBA=FuncRecPoseCalculateByEllipseFit(tempDataPool,countBA,&recBAEllipsePara);

    memset(tempDataPool,0x00,sizeof(snake_point)*countBA);


    isRightBCCorner=FuncRecCornerDetect(mapPose.PointB, mapPose.PointC, MAP_WIDTH, recCornerBC);

    if(false==isRightBCCorner){
        return false;
    }

    countBC=FuncBlackExtract(binaryImageData, recCornerBC, tempDataPool, &whitePixelCount);

    // 计算两个特征圆之间的矩形当中，黑色像素所占的比例，理想比例为40%
    // 若所占比例不足，则认为特征圆间不存在黑色矩形区域
//    blackRatio = countBC*1.0f / (countBC + whitePixelCount);
//    if (blackRatio<0.3 || blackRatio>0.5)
//        return false;

    isSuccessBC=FuncRecPoseCalculateByEllipseFit(tempDataPool,countBC,&recBCEllipsePara);

    memset(tempDataPool,0x00,sizeof(snake_point)*countBC);


    memcpy(rigidTransModel.recCornerBA,recCornerBA,sizeof(snake_point)*4);
    memcpy(rigidTransModel.recCornerBC,recCornerBC,sizeof(snake_point)*4);

    rigidTransModel.recBAEllipsePara=recBAEllipsePara;
    rigidTransModel.recBCEllipsePara=recBCEllipsePara;

    // 计算两个特征圆之间椭圆的长短轴比例，若比例超过一定阈值，则认为特征圆之间不存在矩形，理想比例为16/3
    ellipseRadioBA = 1.0*rigidTransModel.recBAEllipsePara.r1/rigidTransModel.recBAEllipsePara.r2;
    ellipseRadioBC = 1.0*rigidTransModel.recBCEllipsePara.r1/rigidTransModel.recBCEllipsePara.r2;
    if (ellipseRadioBA<4.5 || ellipseRadioBA>7.5)
        return false;
    if (ellipseRadioBC<4.5 || ellipseRadioBC>7.5)
        return false;

    if(isSuccessBA||isSuccessBC){
        // 4. 由于两个坐标系正方向定义的不同，前后两次求解的角度数据存在如下转换关系
        // 根据三角函数的性质，tan（theta）在+-90度时，数值解趋向于无穷，因此，本算法在
        // 直线角度趋近于90度时，数值精度较差。采用如下策略进行规避。

        // BA方向
        if(recBAEllipsePara.theta>0){

            RecTheta1=M_PI/2-recBAEllipsePara.theta;
            RecTheta2=RecTheta1-M_PI;
            extendRecTheta=RecTheta1+M_PI;

        }else{

            RecTheta1=M_PI/2-recBAEllipsePara.theta;;
            RecTheta2=RecTheta1-M_PI;
            extendRecTheta=RecTheta2-M_PI;
        }


        errorLinePos2Org1=fabs(mapPose.theta-RecTheta1);
        errorLinePos2Org2=fabs(mapPose.theta-RecTheta2);
        errorLinePos2OrgExtend=fabs(mapPose.theta-extendRecTheta);


        // 5. 输出精确的位姿数据 至 全局变量 mapPose
        if(errorLinePos2Org1<errorLinePos2Org2 && errorLinePos2Org1<errorLinePos2OrgExtend){

            linBATheta=RecTheta1;

        }else if(errorLinePos2Org2<errorLinePos2Org1 && errorLinePos2Org2<errorLinePos2OrgExtend){

            linBATheta=RecTheta2;

        }else{

            linBATheta=PI2PI(extendRecTheta);
        }


        // 根据直线BA确定lin方向
        rigidTransModel.eLin.Pix = -sinf(linBATheta);
        rigidTransModel.eLin.Lin = cosf(linBATheta);



        // BC方向
        if(recBCEllipsePara.theta>0){

            RecTheta1=-recBCEllipsePara.theta;
            RecTheta2=RecTheta1+M_PI;
            extendRecTheta=RecTheta1-M_PI;

        }else{

            RecTheta1=-recBCEllipsePara.theta;
            RecTheta2=RecTheta1-M_PI;
            extendRecTheta=RecTheta1+M_PI;

        }



        errorLinePos2Org1=fabs(mapPose.theta-RecTheta1);
        errorLinePos2Org2=fabs(mapPose.theta-RecTheta2);
        errorLinePos2OrgExtend=fabs(mapPose.theta-extendRecTheta);


        // 5. 输出精确的位姿数据 至 全局变量 mapPose
        if(errorLinePos2Org1<errorLinePos2Org2 && errorLinePos2Org1<errorLinePos2OrgExtend){

            linBCTheta=RecTheta1;

        }else if(errorLinePos2Org2<errorLinePos2Org1 && errorLinePos2Org2<errorLinePos2OrgExtend){

            linBCTheta=RecTheta2;

        }else{

            linBCTheta=PI2PI(extendRecTheta);
        }

        // 根据线BC确定pix方向
        rigidTransModel.ePix.Pix = cosf(linBCTheta);
        rigidTransModel.ePix.Lin = sinf(linBCTheta);


        if ((linBCTheta > -M_PI/4 && linBCTheta < M_PI/4)
                ||(linBCTheta > 3*M_PI/4)
                ||(linBCTheta < -3*M_PI/4)
                ){

            rigidTransModel.updatedTheta=linBCTheta;
            //printf("%s %d lineBC theta = %f\n",__func__, __LINE__, linBCTheta*180/M_PI);
        }else{

            rigidTransModel.updatedTheta=linBATheta;
            //printf("%s %d lineBA theta = %f\n",__func__, __LINE__, linBATheta*180/M_PI);
        }
        //printf("linBCTheta - linBATheta = %f\n", (linBCTheta-linBATheta)*180/M_PI);

        return true;

    }else{

        return false;
    }

}




// 检测包围直线的矩形框的四个顶点
bool FuncRecCornerDetect(snake_point PointA, snake_point PointB, int mapWidth, snake_point dstRec[4]){

    int i, j;
    int square;
    int temp_0, temp_1, temp_2, temp_3, temp_4;
    snake_point rec[4], temp;

    float stepFW=5.0;  // 以圆环原点为起点，前进5个标准格
    float stepLR=3.0;  // 直线左右各延伸3个标准格
    float lengthAB = 0.0f;
    float PixPerGrid = 0.0f;
    bool inBox = false;

    snake_vectorf vectorAB;

    vectorAB.Pix = PointB.Pix - PointA.Pix;
    vectorAB.Lin = PointB.Lin - PointA.Lin;

    lengthAB=sqrtf(vectorAB.Pix*vectorAB.Pix+vectorAB.Lin*vectorAB.Lin);
    PixPerGrid = lengthAB/mapWidth;


    if (PointA.Lin == PointB.Lin)
    {
        rec[0].Pix = floor(MAX(PointA.Pix, PointB.Pix) - stepFW * PixPerGrid);
        rec[0].Lin = PointA.Lin - stepLR * PixPerGrid;
        rec[1].Pix = floor(MAX(PointA.Pix, PointB.Pix) - stepFW * PixPerGrid);
        rec[1].Lin = PointA.Lin + stepLR * PixPerGrid;
        rec[2].Pix = floor(MIN(PointA.Pix, PointB.Pix) + stepFW * PixPerGrid);
        rec[2].Lin = PointA.Lin + stepLR * PixPerGrid;
        rec[3].Pix = floor(MIN(PointA.Pix, PointB.Pix) + stepFW * PixPerGrid);
        rec[3].Lin = PointA.Lin - stepLR * PixPerGrid;
    }
    else if (PointA.Pix == PointB.Pix)
    {
        rec[0].Pix = PointA.Pix - stepLR * PixPerGrid;
        rec[0].Lin = floor(MAX(PointA.Lin, PointB.Lin) - stepFW * PixPerGrid);
        rec[1].Pix = PointA.Pix - stepLR * PixPerGrid;
        rec[1].Lin = floor(MIN(PointA.Lin, PointB.Lin) + stepFW * PixPerGrid);
        rec[2].Pix = PointA.Pix + stepLR * PixPerGrid;
        rec[2].Lin = floor(MIN(PointA.Lin, PointB.Lin) + stepFW * PixPerGrid);
        rec[3].Pix = PointA.Pix + stepLR * PixPerGrid;
        rec[3].Lin = floor(MAX(PointA.Lin, PointB.Lin) - stepFW * PixPerGrid);
    }
    else
    {
        temp.Pix = PointA.Pix - PointB.Pix;
        temp.Lin = PointA.Lin - PointB.Lin;
        square = temp.Lin * temp.Lin + temp.Pix * temp.Pix;

        temp_0 = PixPerGrid * sqrtf((float)(square));
        temp_1 = temp.Lin * PointA.Lin + temp.Pix * PointA.Pix;
        temp_2 = -temp.Pix * PointA.Lin + temp.Lin * PointA.Pix;
        temp_3 = temp.Lin * PointB.Lin + temp.Pix * PointB.Pix;
        temp_4 = -temp.Pix * PointA.Lin + temp.Lin * PointA.Pix;

        rec[0].Pix = floor((temp.Pix * (temp_1 - stepFW * temp_0) + temp.Lin * (temp_2 + stepLR * temp_0)) / square);
        rec[0].Lin = floor((temp.Lin * (temp_1 - stepFW * temp_0) - temp.Pix * (temp_2 + stepLR * temp_0)) / square);
        rec[1].Pix = floor((temp.Pix * (temp_1 - stepFW * temp_0) + temp.Lin * (temp_2 - stepLR * temp_0)) / square);
        rec[1].Lin = floor((temp.Lin * (temp_1 - stepFW * temp_0) - temp.Pix * (temp_2 - stepLR * temp_0)) / square);
        rec[2].Pix = floor((temp.Pix * (temp_3 + stepFW * temp_0) + temp.Lin * (temp_4 + stepLR * temp_0)) / square);
        rec[2].Lin = floor((temp.Lin * (temp_3 + stepFW * temp_0) - temp.Pix * (temp_4 + stepLR * temp_0)) / square);
        rec[3].Pix = floor((temp.Pix * (temp_3 + stepFW * temp_0) + temp.Lin * (temp_4 - stepLR * temp_0)) / square);
        rec[3].Lin = floor((temp.Lin * (temp_3 + stepFW * temp_0) - temp.Pix * (temp_4 - stepLR * temp_0)) / square);

    }

    // 冒泡法对矩形四个顶点进行排序
    for (j = 0; j < 4; j++)
    {
        for (i = 0; i < 3-j; i++)
        {
            if (rec[i].Lin > rec[i+1].Lin)
            {
                temp = rec[i];
                rec[i] = rec[i+1];
                rec[i+1] = temp;
            }
        }
    }
    for (i = 0; i < 3; i++)
    {
        if (rec[i].Lin == rec[i+1].Lin)
        {
            if (rec[i].Pix > rec[i+1].Pix)
            {
                temp = rec[i];
                rec[i] = rec[i+1];
                rec[i+1] = temp;
            }
        }
    }


    inBox=isInBox(&rec[0],IMG_WIDTH,IMG_HEIGHT) && isInBox(&rec[1],IMG_WIDTH,IMG_HEIGHT)&&
            isInBox(&rec[2],IMG_WIDTH,IMG_HEIGHT) && isInBox(&rec[3],IMG_WIDTH,IMG_HEIGHT);

    if(inBox){

        memcpy(dstRec,rec,sizeof(rec));
        return true;

    }else{

        return false;

    }

}




/**
 * @brief FuncRecPoseCalculateByEllipseFit 将一片区域当作椭圆来估计五个几何参数
 * @param image
 * @param value
 * @param para
 */
bool FuncRecPoseCalculateByEllipseFit(const snake_point *dataHeader, int count,ELLIPSE_PARA *ellipsePara)
{
    uint64_t xSum = 0;
    uint64_t ySum = 0;
    int col = 0;
    int row = 0;
    int i = 0;
    int r1 = 0;
    int r2 = 0;
    uint64_t xSquareSum = 0;
    uint64_t ySquareSum = 0;
    uint64_t xySum = 0;
    float n01 = 0.0f;
    float n10 = 0.0f;
    float mu20 = 0.0f;
    float mu02 = 0.0f;
    float mu11 = 0.0f;
    float t1 = 0.0f;
    float t2 = 0.0f;
    float t3 = 0.0f;
    float theta = 0.0f;


    if(count<mapPose.pixPerGrid*LINE_LENGTH*0.8){ // 没有检测到有效直线

        // printf("ERR: detected wrong line\n");

        memset(ellipsePara,0x00,sizeof(*ellipsePara));

        return false;

    }

    //count;   0阶矩

    // 求解一阶矩
    for(i=0;i<count;i++){

        xSum += dataHeader[i].Pix;
        ySum += dataHeader[i].Lin;

    }

    n01 = 1.0*xSum / count;
    n10 = 1.0*ySum / count;



    // 求解二阶矩

    for(i=0;i<count;i++){
        xSquareSum += dataHeader[i].Pix * dataHeader[i].Pix;
        ySquareSum += dataHeader[i].Lin * dataHeader[i].Lin;
        xySum += dataHeader[i].Pix * dataHeader[i].Lin;
    }

    mu02 = 1.0*xSquareSum / count - n01*n01;
    mu20 = 1.0*ySquareSum / count - n10*n10;
    mu11 =  1.0*xySum / count - n01*n10;

    // 构造椭圆参数
    t1 = mu20 + mu02;
    t2 = mu20 - mu02;
    t3 = sqrt(t2 * t2 + 4 * mu11 * mu11);
    r1 = sqrt(2 * ( t1 + t3) );
    r2 = sqrt(2 * ( t1 - t3) );

    theta = - atan2(2 * mu11, mu02 - mu20) / 2.0;



    ellipsePara->r1 = r1;
    ellipsePara->r2 = r2;
    ellipsePara->theta = theta;
    ellipsePara->center.Pix = n01;
    ellipsePara->center.Lin = n10;

    return true;

}




/*  提取信息矩阵相关 */


snake_pointf FuncPointMove(snake_pointf *zeroPoint, snake_vectorf *ePix, snake_vectorf *eLin, float deltaPix,float deltaLin){

    snake_pointf currPoint;

    currPoint.Pix=zeroPoint->Pix+deltaPix*ePix->Pix+deltaLin*eLin->Pix;

    currPoint.Lin=zeroPoint->Lin+deltaPix*ePix->Lin+deltaLin*eLin->Lin;

    return currPoint;

}



snake_pointf FuncFindZeroPoint()
{
    float temp = 0.0f;
    float alphaBC = 0.0f;

    snake_pointf infoOriginPoint = {100.0,-100.0};

    snake_pointf *LineBACenter = &rigidTransModel.recBAEllipsePara.center;
    snake_pointf *LineBCCenter = &rigidTransModel.recBCEllipsePara.center;

    snake_vectorf *LineBCOrient = &rigidTransModel.ePix;
    snake_vectorf *LineBAOrient = &rigidTransModel.eLin;

    snake_vectorf LineBAVerical = {LineBAOrient->Lin, - LineBAOrient->Pix};
    snake_vectorf LineBCVerical = {LineBCOrient->Lin, - LineBCOrient->Pix};

    temp = LineBCOrient->Pix * LineBAVerical.Pix + LineBCOrient->Lin * LineBAVerical.Lin;
    if (fabs(temp)<EPSILON)
    {
        // printf("Find Zero Point Error!");
        return infoOriginPoint;
    }
    alphaBC = ((LineBACenter->Pix - LineBCCenter->Pix)* LineBAVerical.Pix + \
                      (LineBACenter->Lin - LineBCCenter->Lin) * LineBAVerical.Lin ) / temp;

    infoOriginPoint.Pix = LineBCCenter->Pix + alphaBC * LineBCOrient->Pix;
    infoOriginPoint.Lin = LineBCCenter->Lin + alphaBC * LineBCOrient->Lin;

    return infoOriginPoint;
}

void FuncSquarePixCount(snake_infoMatrix *infoElement, snake_vectorf *ePix){
    // 方法1： 取色块中尽量多的点
        //    snake_pointf *blockCenter=&infoElement->center;

        //    float PixPerGrid = mapPose.pixPerGrid;
        //    float squareHalfLength;
        //    int startPix, endPix, startLin, endLin;


        //    // 此处是否有问题？ PixPerGrid和LinPerGrid是否要区分
        //    squareHalfLength = PixPerGrid / (fabs(ePix->Pix) + fabs(ePix->Lin));

        //    startPix = ceil(blockCenter->Pix - squareHalfLength);
        //    endPix = floor(blockCenter->Pix + squareHalfLength);
        //    startLin = ceil(blockCenter->Lin - squareHalfLength);
        //    endLin = floor(blockCenter->Lin + squareHalfLength);

        //    for (int i = startLin; i < endLin+1; i++)
        //    {
        //        for (int j = startPix; j < endPix+1; j++)
        //        {
        //            if (binaryImageData[IMG_WIDTH * i + j] == BLACK)
        //                infoElement->countBlack++;
        //            else
        //                infoElement->countWhite++;
        //        }
        //    }


        // 方法2： 仅取中心点周围的25个点
        snake_pointf *Origin=&infoElement->center;
        int m,n;

        int CountBlack=0;
        int CountWhite=0;

        // 遍历origin周围25个点
        for (m = Origin->Lin - 2; m < Origin->Lin + 3; m++)
        {
            for (n = Origin->Pix - 2; n < Origin->Pix + 3; n ++)
            {
                /// 防止像素坐标越界
                if (m<0 || n<0 || m>=IMG_HEIGHT || n>=IMG_WIDTH)
                    continue;

                // 对黑白像素投票
                if (BLACK == binaryImageData[IMG_WIDTH * m + n])
                {
                    CountBlack++;
                }
                else
                {
                    CountWhite++;
                }
            }
        }

        infoElement->countBlack=CountBlack;
        infoElement->countWhite=CountWhite;
}

///********************************************
//函数功能:FuncInfoMatrixExtract函数实现,实现非旋转模式下的解码数据读取
//函数输入:
//函数输出:
//*********************************************/
bool FuncInfoMatrixExtract(void){

    // 码图横纵轴方向
    snake_vectorf *ePix = &rigidTransModel.ePix;
    snake_vectorf *eLin = &rigidTransModel.eLin;

    float pixPerGrid=mapPose.pixPerGrid;
    float linPerGrid=mapPose.linPerGrid;

    // 沿码图Pix方向和Lin方向的偏移量
    float deltaPix=0.;
    float deltaLin=0.;

    int row,col;
    bool inBox = false;

    // 1. 确定信息矩阵的00点，浮点形式
    //snake_pointf BPoint={mapPose.PointB.Pix,mapPose.PointB.Lin};  // 直接采用特征圆环坐标
    snake_pointf BPoint=FuncFindZeroPoint();  // 使用直线重新计算后的坐标

    rigidTransModel.BPoint.Pix = BPoint.Pix;
    rigidTransModel.BPoint.Lin = BPoint.Lin;

    infoZeroPoint=FuncPointMove(&BPoint,ePix,eLin,BAND_PIX*pixPerGrid,BAND_LINE*linPerGrid);  // 信息矩阵00点

    snake_pointf info01Point=FuncPointMove(&BPoint,ePix,eLin,(INFO_MATRIX_WIDTH+BAND_PIX)*pixPerGrid,BAND_LINE*linPerGrid); // 信息矩阵01点
    snake_pointf info10Point=FuncPointMove(&BPoint,ePix,eLin,BAND_PIX*pixPerGrid,(INFO_MATRIX_HEIGHT+BAND_LINE)*linPerGrid); // 信息矩阵10点
    snake_pointf info11Point=FuncPointMove(&BPoint,ePix,eLin,(INFO_MATRIX_WIDTH+BAND_PIX)*pixPerGrid,(INFO_MATRIX_HEIGHT+BAND_LINE)*linPerGrid); // 信息矩阵11点


    inBox=isInBoxf(&infoZeroPoint,IMG_WIDTH,IMG_HEIGHT) && isInBoxf(&info01Point,IMG_WIDTH,IMG_HEIGHT)&&
            isInBoxf(&info10Point,IMG_WIDTH,IMG_HEIGHT) && isInBoxf(&info11Point,IMG_WIDTH,IMG_HEIGHT);

    if (inBox){

//        // 更新码图中心坐标(单码图)
//        deltaPix=(INFO_MATRIX_WIDTH/2+BAND_PIX)*pixPerGrid;
//        deltaLin=(INFO_MATRIX_HEIGHT/2+BAND_LINE)*linPerGrid;

        // 更新码图中心坐标(多码图)
        deltaPix=MAP_WIDTH * pixPerGrid;
        deltaLin=MAP_HEIGHT * linPerGrid;

        rigidTransModel.updatedMapCenter=FuncPointMove(&BPoint,ePix,eLin,deltaPix,deltaLin);

        deltaLin = (MAP_HEIGHT - BAND_LINE)*linPerGrid;
        for (row=0;row<INFO_MATRIX_ROW-1;row++)
        {
            deltaPix = ((MAP_WIDTH - LINE_LENGTH)/2.0 - BAND_LINE + CODE_BLOCK*(row + 0.5))*pixPerGrid;
            codeIdxMatrix[row].center = FuncPointMove(&infoZeroPoint,ePix,eLin,deltaPix,deltaLin);
            FuncSquarePixCount(&codeIdxMatrix[row], ePix);

            if (codeIdxMatrix[row].countBlack>codeIdxMatrix[row].countWhite)
            {
                codeIdxMatrix[row].color=BLACK;
            }else{
                codeIdxMatrix[row].color=WHITE;
            }
        }

        for(row=0;row<INFO_MATRIX_ROW;row++){
            for(col=0;col<INFO_MATRIX_COLUMN;col++){

                deltaPix=CODE_BLOCK*col*pixPerGrid+CODE_BLOCK/2.0*pixPerGrid;
                deltaLin=CODE_BLOCK*row*linPerGrid+CODE_BLOCK/2.0*linPerGrid;

                infoMatrix[row][col].center=FuncPointMove(&infoZeroPoint,ePix,eLin,deltaPix,deltaLin);

                FuncSquarePixCount(&infoMatrix[row][col], ePix);

                if(infoMatrix[row][col].countBlack>infoMatrix[row][col].countWhite){

                    infoMatrix[row][col].color=BLACK;
                }else{

                    infoMatrix[row][col].color=WHITE;
                }

            }
        }

        for (row=4; row<INFO_MATRIX_ROW+2; row++)
        {
            codeIdxMatrix[row].color = infoMatrix[INFO_MATRIX_ROW-1][row-2].color;
        }

        return true;

    }else{

        return false;

    }

}



/////////////////////// end //////////////////////////
