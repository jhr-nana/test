#ifndef DECODER_H
#define DECODER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "globaldefine.h"


// 输出接口
extern snake_infoOutput infoOutput;

// 记录解码的错误信息
extern snake_decode_error decode_error[NUM_OF_DATAWORDS];


/* 码图解码相关 */

extern snake_infoMatrix infoMatrix[INFO_MATRIX_ROW][INFO_MATRIX_COLUMN]; // 存储信息矩阵数据
extern snake_infoMatrix codeIdxMatrix[7];

int FuncDecodeProcessing(void); // 对数据区数据进行解码流程


#ifdef __cplusplus
}
#endif

#endif // DECODER_H
