#ifndef LOCATOR_H
#define LOCATOR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "globaldefine.h"
#include "common.h"
#include "databank.h"



// 精确计算位姿数据，入口函数
bool FuncMapPosePreciseCalculate(void);

bool FuncRecCornerDetect(snake_point srcPointA, snake_point srcPointB, int srcMapWidth, snake_point dstRec[4]);

bool FuncRecPoseCalculateByEllipseFit(const snake_point *dataHeader, int count,ELLIPSE_PARA *ellipsePara);



// 码图信息矩阵读取相关，主流程
bool FuncInfoMatrixExtract(void); // 新算法，不需要旋转即可抽取解码01数据

snake_pointf FuncFindZeroPoint();


snake_pointf FuncPointMove(snake_pointf *zeroPoint, snake_vectorf *ePix,
                           snake_vectorf *eLin, float deltaPix,float deltaLin);


void FuncSquarePixCount(snake_infoMatrix *infoElement, snake_vectorf *ePix);


#ifdef __cplusplus
}
#endif

#endif // LOCATOR_H
