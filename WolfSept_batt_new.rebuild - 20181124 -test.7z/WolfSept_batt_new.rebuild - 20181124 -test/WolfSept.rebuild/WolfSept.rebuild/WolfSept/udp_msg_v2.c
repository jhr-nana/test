#include <netinet/in.h>
#include "udp_msg_v1.h"
#include "udp_msg_v2.h"
#include "device.h"
#include "debug.h"
#include "statistical_info.h"

typedef enum 
{
	DEBUG_REBOOT = 1,
	DEBUG_PALLET_CLASP = 2,
	DEBUG_PALLET_UNCLASP = 3,
	DEBUG_WHEEL_CLASP = 4,
	DEBUG_WHEEL_UNCLASP = 5,
	DEBUG_CHECK_GROUNDDIRECT = 6,
	DEBUG_UNCHECK_GROUNDDIRECT = 7,
	DEBUG_AGV_SYNC_TIME = 8,
	DEBUG_AGV_TC_RISE = 9,
	DEBUG_AGV_TC_LAY = 10,
	DEBUG_AGV_GET_LOG = 11
}enum_debug_cmd;

#define VAR_WHEEL_CLASP		0x07
#define VAR_PALLET_CLASP	0x02

/*******************************************************************************
*Function Name    :ntohll
*Description      :convert between the processor byte order and the
					network byte order for TCP/IP applications for 64 bit,by tiger
*Input       	  :unsigned long long val  
*Output 		  :NONE
*Return           :unsigned long long:64-bit integer in host byte order
*******************************************************************************/
unsigned long long ntohll(unsigned long long val)
{
	if (__BYTE_ORDER == __LITTLE_ENDIAN)
	{
		return (((unsigned long long)htonl((int)((val << 32) >> 32))) << 32) | (unsigned int)htonl((int)(val >> 32));
	}
	else if (__BYTE_ORDER == __BIG_ENDIAN)
	{
		return val;
	}
}

/*******************************************************************************
*Function Name    :htonll
*Description      :convert between the processor byte order and the
				  network byte order for TCP/IP applications for 64 bit ,by tiger
*Input       	  :unsigned long long val  
*Output 		  :NONE
*Return           :unsigned long long:64-bit integer in network byte order  
*******************************************************************************/
unsigned long long htonll(unsigned long long val)
{
		if (__BYTE_ORDER == __LITTLE_ENDIAN)
		{
			return (((unsigned long long)htonl((int)((val << 32) >> 32))) << 32) | (unsigned int)htonl((int)(val >> 32));
		}
		else if (__BYTE_ORDER == __BIG_ENDIAN)
		{
			return val;
		}
}

/*******************************************************************************
* Function Name		 : msgv2_head_dump
* Description	     : judge udp recv msg is valid.
* Input 		     : pMsgBuff: the pointer of udp msg buff
* Output		     : NONE
* Return		     : 0:valid; <0:invalid
*******************************************************************************/
int msgv2_head_dump(const char * pMsgBuff)
{
	const msgv2_head_t *pMsgHead = (const msgv2_head_t *)pMsgBuff;

	if (pMsgHead == NULL)
		return -1;

	msgv2_head_t stMsgHead =
	{
		.i16MsgType = (i16)ntohs(pMsgHead->i16MsgType),
		.i32AgvNo = ntohl(pMsgHead->i32AgvNo),
		.i32TokenNum = (i32)ntohl(pMsgHead->i32TokenNum),
		.i32Sequence = (i32)ntohl(pMsgHead->i32Sequence),
		.i8ProtoVer = pMsgHead->i8ProtoVer,
		.i8Flags = pMsgHead->i8Flags,
		.i16DataLength = (i16)ntohs(pMsgHead->i16DataLength),
	};

	LOG_INF("-----------------------\n");
	LOG_DBG("MsgType                 =%d[%s]\n", stMsgHead.i16MsgType, get_msg_name(stMsgHead.i16MsgType));
	LOG_DBG("AGVNo                   =%d\n", stMsgHead.i32AgvNo);
	LOG_DBG("TokenNum                =%d\n", stMsgHead.i32TokenNum);
	LOG_DBG("Sequence                =%d\n", stMsgHead.i32Sequence);
	LOG_DBG("TaskId                  =%d\n", stMsgHead.i32TaskID);
	LOG_DBG("ProtoVer                =%d\n", stMsgHead.i8ProtoVer);
	LOG_DBG("Flags                   =%d\n", stMsgHead.i8Flags);
	LOG_DBG("DataLength              =%d\n", stMsgHead.i16DataLength);

	if (stMsgHead.i16MsgType == MSG_TYPE_OPERATE) {
		msgv2_operate_t *pMsgOperate = (msgv2_operate_t *)pMsgHead;

		int iAction = (int)ntohs(pMsgOperate->i16Action);
		int iWeight = (int)ntohs(pMsgOperate->i16WeightLevel);
		int iSpeed = (int)ntohs(pMsgOperate->i16Speed);
		int iStepLength = (int)ntohs(pMsgOperate->i16StepLength);
		int iTotalLength = (int)ntohs(pMsgOperate->i16TotalLength);
		i64 i64SrcLocation = (i64)ntohll(pMsgOperate->i64SrcLocation);
		i64 i64DstLocation = (i64)ntohll(pMsgOperate->i64DstLocation);
		int iTurnAngle = (int)ntohs(pMsgOperate->i16TurnAngle);
		LOG_DBG("msg.Action              = %d[%s]\n", iAction, get_action_name(iAction));
		LOG_DBG("msg.Weight              = %d\n", iWeight);
		LOG_DBG("msg.Speed               = %d\n", iSpeed);
		LOG_DBG("msg.StepLength          = %d\n", iStepLength);
		LOG_DBG("msg.TotalLength         = %d\n", iTotalLength);
		LOG_DBG("msg.SrcLocation         = %lld\n", i64SrcLocation);
		LOG_DBG("msg.DstLocation         = %lld\n", i64DstLocation);
		LOG_DBG("msg.TurnAngle           = %d\n", iTurnAngle);
		LOG_DBG("msg.ShelfQR             = %s\n", pMsgOperate->i8TopQR);
		LOG_DBG("msg.i8WalkDirect        = %s\n", pMsgOperate->i8WalkDirection);//add by jxu 20180828
	}
	//add by jxu 20180828-begin
	if (stMsgHead.i16MsgType == MSG_TYPE_ADVANCE_OPERATE) {
		msgv2_operate_advanced_t *pMsgOperate = (msgv2_operate_advanced_t *)pMsgHead;

		int iAction = (int)ntohs(pMsgOperate->i16Action);
		int iWeight = (int)ntohs(pMsgOperate->i16WeightLevel);
		int iSpeed = (int)ntohs(pMsgOperate->i16Speed);
		int iStepLength = (int)ntohs(pMsgOperate->i16StepLength);
		int iTotalLength = (int)ntohs(pMsgOperate->i16TotalLength);
		i64 iSrcLocation = (i64)ntohll(pMsgOperate->i64SrcLocation);
		i64 iDstLocation = (i64)ntohll(pMsgOperate->i64DstLocation);
		int iSrcTurnAngle = (int)ntohs(pMsgOperate->iSrcTurnAngle);
		int iDstTurnAngle = (int)ntohs(pMsgOperate->iDstTurnAngle);
		i8  i8TaskPalletDir = pMsgOperate->iTaskPalletDirect;
		
		LOG_DBG("msg.Action              = %d[%s]\n", iAction, get_action_name(iAction));
		LOG_DBG("msg.Weight              = %d\n", iWeight);
		LOG_DBG("msg.Speed               = %d\n", iSpeed);
		LOG_DBG("msg.StepLength          = %d\n", iStepLength);
		LOG_DBG("msg.TotalLength         = %d\n", iTotalLength);
		LOG_DBG("msg.SrcLocation         = %lld\n", iSrcLocation);
		LOG_DBG("msg.DstLocation         = %lld\n", iDstLocation); 
		LOG_DBG("msg.iSrcAction          = %lld[%s]\n", pMsgOperate->iSrcAction, get_action_name(pMsgOperate->iSrcAction));
		LOG_DBG("msg.iSrcTAngle          = %d\n", iSrcTurnAngle);
		LOG_DBG("msg.iDstAction          = %d[%s]\n", pMsgOperate->iDstAction, get_action_name(pMsgOperate->iDstAction));
		LOG_DBG("msg.iDstTurnAngle       = %d\n", iDstTurnAngle);
		LOG_DBG("msg.i8TaskPalletDir     = %d\n", i8TaskPalletDir);
		LOG_DBG("msg.ShelfQR             = %s\n", pMsgOperate->i8TopQR);
		LOG_DBG("msg.i8WalkDirect        = %d\n", pMsgOperate->i8WalkDirection);
	}
	//add by jxu 20180828-end

	if (stMsgHead.i16MsgType == MSG_TYPE_EVENT) {
		msgv2_event_t  *pMsgEvent = (msgv2_event_t *)pMsgHead;
		int iEventType = (int)ntohs(pMsgEvent->i16EventType);
		int iErrorCode = (int)ntohl(pMsgEvent->i32ErrorCode);
		i64 iLocation = ntohll(pMsgEvent->i64Location);
		int iVehHeadDirect = (int)pMsgEvent->i8VehHeadDirect;
		int iPalletDirect = (int)pMsgEvent->i8PalletDirect;
		
		LOG_DBG("msg.iEventType          = %d\n", iEventType);
		LOG_DBG("msg.iErrorCode          = %d[%s]\n", iErrorCode, get_err_str(iErrorCode));
		LOG_DBG("msg.Location            = %lld\n", iLocation);
		LOG_DBG("msg.HDirect             = %d\n", iVehHeadDirect, get_direct_desc(iVehHeadDirect));
		LOG_DBG("msg.PDirect             = %d\n", iPalletDirect, get_direct_desc(iPalletDirect));
	}

	if (stMsgHead.i16MsgType == MSG_TYPE_POINT) {
		msgv2_point_t *pMsgPoint = (msgv2_point_t *)pMsgHead;
		i64 iLocation = ntohll(pMsgPoint->i64Location);

		LOG_DBG("msg.Location = %lld\n", iLocation);
	}

	if (stMsgHead.i16MsgType == MSG_TYPE_FINISH) {
		msgv2_finish_t *pMsgFinish = (msgv2_finish_t *)pMsgHead;
		int iHDirect = (int)pMsgFinish->i8VehHeadDirect;
		int iPDirect = (int)pMsgFinish->i8PalletDirect;
		i64 iLocation = ntohll(pMsgFinish->i64Location);
		int iAction = ntohs(pMsgFinish->i16Action);

		LOG_DBG("msg.Action   = %d[%s]\n", iAction, get_action_name(iAction));
		LOG_DBG("msg.HDirect  = %d\n", iHDirect);
		LOG_DBG("msg.PDirect  = %d\n", iPDirect);
		LOG_DBG("msg.Location = %lld\n", iLocation);
	}

	LOG_DBG("-----------------------\n");

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv2_tokennum_is_valid
* Description	     : judge udp recv msg is valid.
* Input 		     : iTokenNum: the token num of udp msg.
* Output		     : NONE
* Return		     : 0:valid; <0:invalid
*******************************************************************************/
int msgv2_tokennum_is_valid(int iTokenNum)
{
	//TODO: check TokenNum is valid
	if (g_stAgvConf.cDebugEnable == FALSE)
	{
		if ((iTokenNum != g_stAgvAttr.iTokenNum)
			&& (iTokenNum != RESERVE_TOKEN_ID)) //by tiger.34
		{
			LOG_INF("msg'token id[%d] != expect[%d]\n", iTokenNum, g_stAgvAttr.iTokenNum);
			return -1;
		}
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv2_is_valid
* Description	     : judge udp recv msg is valid.
* Input 		     : pMsgHead: the pointer of udp msg buff
* Input 		     : iMsgSize: the size of msg
* Output		     : NONE
* Return		     : 0:valid; <0:invalid
*******************************************************************************/
int msgv2_is_valid(const char * pMsgBuff, int iMsgSize)
{
	const msgv2_head_t *pMsgHead = (const msgv2_head_t *)pMsgBuff;
	msgv2_head_t stMsgHead = { 0 };
	int iTokenNum = 0;

	if ((pMsgHead == NULL) || (iMsgSize <= 0)) {
		return -1;
	}

	stMsgHead.i16MsgType = ntohs(pMsgHead->i16MsgType);
	stMsgHead.i32AgvNo = ntohl(pMsgHead->i32AgvNo);
	stMsgHead.i32TokenNum = ntohl(pMsgHead->i32TokenNum);
	stMsgHead.i32Sequence = ntohl(pMsgHead->i32Sequence);
	stMsgHead.i8ProtoVer = pMsgHead->i8ProtoVer;
	stMsgHead.i8Flags = pMsgHead->i8Flags;
	stMsgHead.i16DataLength = ntohs(pMsgHead->i16DataLength);

	if (sequence_is_valid(stMsgHead.i32Sequence, stMsgHead.i16MsgType) != 0) {
		// TODO:send error msg to console?
		// if not, the console will resend the msg req;
		LOG_WRN("msg'type[%d-%s] sequence[%d] is invalid, maybe processed\n",
			stMsgHead.i16MsgType, get_msg_name(stMsgHead.i16MsgType), stMsgHead.i32Sequence);
		return -1;
	}

	//TODO:check token id
	if (msgv2_tokennum_is_valid(stMsgHead.i32TokenNum) < 0) {
		// TODO:send error msg to console?
		// if not, the console will resend the msg req;
		LOG_WRN("msg'type[%d-%s] tokennum[%d] is invalid, maybe processed\n",
			stMsgHead.i16MsgType, get_msg_name(stMsgHead.i16MsgType), stMsgHead.i32TokenNum);
		return -1;
	}

	return stMsgHead.i16MsgType;
}

/*******************************************************************************
* Function Name		 : msgv2_agv_register
* Description	     : agv register, should execute before create work_thread_create()
                     : and execute after init_xxxx_dev()
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_agv_register()
{
	char pRecvBuff[UDP_MSG_SIZE] = { 0 };
	const msgv2_head_t *pMsgHead = (const msgv2_head_t *)pRecvBuff;
	msgv2_register_ack_t * pMsgRegAck = NULL;

	int iRet = 0;
	int iTryTime = 1;
	int iTimeOut = TIME_OUT_2S;
	int iChargeType = 0;
	int iCount = 0;
	//add by jxu 20180130: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		//MSB is the generation of DSP,add by tiger.36
		g_stAgvAttr.iMCVerDate = (g_stMcDev.iGeneration) << 24 | g_stAgvAttr.iMcVersion;
		g_stAgvAttr.iTCVerDate = g_stAgvAttr.iTcVersion;
		iChargeType = ON_GROUND;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		g_stAgvAttr.iMCVerDate = g_stAgvAttr.iMcVersion;
		g_stAgvAttr.iTCVerDate = g_stAgvAttr.iMcVersion;
		iChargeType = g_stAgvConf.cChargeType;
	}
	//add by jxu 20180130: end

	// build a register msg
	msgv2_register_req_t stMsgReg =
	{
		.stMsgHead.i16MsgType = htons(MSG_TYPE_REGISTER),
		.stMsgHead.i16Reserve = htons(0),
		.stMsgHead.i32AgvNo = htonl(g_stAgvAttr.iAgvName),	//TODO:g_stAgvAttr.iAgvName
		.stMsgHead.i32TokenNum = 0,
		.stMsgHead.i32Sequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.stMsgHead.i32TaskID = htonl(g_stAgvTask.i32TaskID),
		.stMsgHead.i8ProtoVer = 2,
		.stMsgHead.i8Flags = 1 << BIT_REQ,
		.stMsgHead.i16DataLength = htons(sizeof(msgv2_register_req_t)-sizeof(msgv2_head_t)),

		.i32MMVerDate = htonl(g_stAgvAttr.iBigVerDate),
		.i32MCVerDate = htonl(g_stAgvAttr.iMCVerDate),
		.i32TCVerDate = htonl(g_stAgvAttr.iTCVerDate),
		.i32VehStatus = htonl(g_stAgvAttr.iStatus),
		.i64Location = htonll(g_stAgvAttr.iLocation),
		.i8VehHeadDirect = (i8)g_stAgvAttr.iVehHeadDirect,
		.i8PalletDirect = (i8)g_stAgvAttr.iPalletDirect,
		.i8PalletStatus = (i8)g_stAgvAttr.iPalletStatus,
		.i8ChargingMethod = (i8)iChargeType,
		.i8BootMethod = 0,
		.i8Reserved = 0,
		.i16Reserved = htons(0),

	};

	memcpy(stMsgReg.i8VehSN, g_stAgvAttr.pSN, 32);
	memcpy(stMsgReg.i8VehType, "G0300KG0101MM01MC01TC01MD2C0", 32);

#if(DEBUG_AGV == TRUE)
	// print debug info for sending message
	LOG_DBG("send msg to console[%s:%d]\n", g_stAgvParm.cServerIp, g_stAgvParm.iMsgSendServerPort);
	msgv2_head_dump((const char *)&stMsgReg);
#endif

	while (iTryTime++) {
		if (iTryTime < 10)
			iTimeOut = TIME_OUT_2S;
		else if ((iTryTime >= 10) && (iTryTime < 20))
			iTimeOut = TIME_OUT_8S;
		else if ((iTryTime >= 20) && (iTryTime < 50))
			iTimeOut = TIME_OUT_20S;
		else
			iTimeOut = TIME_OUT_60S;
		LOG_INF("the size of register is %d\n ", sizeof(stMsgReg));
		iRet = send_msg2console(&stMsgReg, sizeof(stMsgReg));
		if (iRet < 0)
		{
			LOG_WRN("send register msg error:[%s]\n", strerror(errno));
			usleep(CYCLE_TIME * 1000); //100ms
			continue;
		}

		//wait console ack
		iCount = 10;
		while (iCount--)
		{
			int iMsgType = 0;
			int iMsgSize = 0;
			int iSequence = 0;
			int iTokenNum = 0;
			i16	i16MMRegResult = 0;
			i16 iDataLength = 0;
			bzero(pRecvBuff, sizeof(pRecvBuff));
			// default: when no console, recv udp will be blocked
			iMsgSize = recv_udp(g_stAgvParm.iMsgSocketFd, pRecvBuff, UDP_MSG_SIZE, FALSE);
			pMsgHead = (const msgv2_head_t *)pRecvBuff;
			pMsgRegAck = (msgv2_register_ack_t *)pRecvBuff;

			// Case1:recv udp msg from server failure
			if (iMsgSize <= 0) {
				usleep(100000); //100ms
				continue;
			}

			// Case2:msg type is not MSG_TYPE_REGISTER?
			iMsgType = ntohs(pMsgRegAck->stMsgHead.i16MsgType);
			iSequence = ntohl(pMsgRegAck->stMsgHead.i32Sequence);
			if (iMsgType != MSG_TYPE_REGISTER) {
				usleep(100000); //100ms
				continue;
			}

			// Case3:udp msg sequence is invalid
			iRet = sequence_is_valid(iSequence, iMsgType);
			if (iRet < 0) {
				usleep(100000); //100ms
				continue;
			}

			iTokenNum = ntohl(pMsgRegAck->stMsgHead.i32TokenNum);
			iDataLength = ntohl(pMsgRegAck->stMsgHead.i16DataLength);
			if (iDataLength > 0)
				i16MMRegResult = ntohl(pMsgRegAck->i16MMRegResult);

			g_stAgvAttr.iTokenNum = iTokenNum;

			LOG_INF("recv ack of msg[%d-%s] sequence=%d, token id=%d Reg_Result = [%d-%s]\n",
				iMsgType, get_msg_name(iMsgType), iSequence, iTokenNum, i16MMRegResult, get_reg_result(i16MMRegResult));

			g_stAgvAttr.iMoveStatus = agv_stop;
			return 0;
		}
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv2_deal_ack
* Description	     : deal the ack of udp recv msg.
* input			     : pMsgHead: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_deal_ack(const char * pMsgBuff, int iMsgSize)
{
	msgv2_ack_t * pMsgAck = (msgv2_ack_t *)pMsgBuff;
	int iRet = 0;
	int iMsgtype = 0;
	int iTokenNum = 0;
	int iSequence = 0;
	
	if (NULL == pMsgAck) {
		return -1;
	}	

	iMsgtype = ntohs(pMsgAck->stMsgHead.i16MsgType);
	iTokenNum = ntohl(pMsgAck->stMsgHead.i32TokenNum);
	iSequence = ntohl(pMsgAck->stMsgHead.i32Sequence);

	LOG_INF("recv ack of msg[%d-%s] sequence=%d\n",
		iMsgtype, get_msg_name(iMsgtype), iSequence);

	iRet = agv_sem_post(SEM_MSG_TYPE, iMsgtype, iSequence);
	if (iRet < -1)
	{
		LOG_ERR("post msg ack signal error:[%s]\n", strerror(errno));
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv2_send_heartbeat
* Description	     : send heartbeat msg to console.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_send_heartbeat()
{
	int iRet = 0;

	msgv2_heartbeat_t stHeartBeat =
	{
		.stMsgHead.i16MsgType = htons(MSG_TYPE_HEARTBEAT),
		.stMsgHead.i32AgvNo = htonl(g_stAgvAttr.iAgvName),
		.stMsgHead.i32TokenNum = htonl(g_stAgvAttr.iTokenNum),
		.stMsgHead.i32Sequence = htonl(get_seq(UDP_HEARTBEAT_SEQ_ID)),//by tiger.79
		.stMsgHead.i32TaskID = htonl(g_stAgvTask.i32TaskID),
		.stMsgHead.i8ProtoVer = 2,
		.stMsgHead.i8Flags = 1 << BIT_REQ,
		.stMsgHead.i16DataLength = htons(sizeof(msgv2_heartbeat_t)-sizeof(msgv2_head_t)),

		.i64Location = htonll(g_stAgvAttr.iLocation),
		.i8VehHeadDirect = (i8)g_stAgvAttr.iVehHeadDirect,
		.i8PalletDirect = (i8)g_stAgvAttr.iPalletDirect,
		.i16Speed = htons((i16)g_stAgvAttr.iSpeed),
		.i8Battery = (i8)(g_stAgvAttr.bms.uSoc),
		.i16Temperature = htons(g_stAgvAttr.bms.uTemp - TEMPER_BASE),
		.i8VehAttitude = (i8)enAgvState,
		.i16VehMoveStatus = htons(g_stAgvAttr.iMoveStatus),
	};

#if(DEBUG_AGV == TRUE)	//TRUE
	// print debug info for sending message
	//LOG_DBG("send msg to console[%s:%d]\n", g_stAgvParm.cServerIp, g_stAgvParm.iMsgSendServerPort);
	//msgv2_head_dump((const char *)&stHeartBeat);
#endif

	iRet = send_msg2console(&stHeartBeat, sizeof(stHeartBeat));
	if (iRet < -1)
	{
		LOG_ERR("send agv heart beat error:[%s]\n", strerror(errno));
		return -1;
	}

	return iRet;
}


/*******************************************************************************
*Function Name    :msgv2_get_event_desc
*Description      :msgv2_get_event_desc,by tiger  
*Input       	  :int iErrorCode  
*Output 		  :NONE
*Return           :char *  
*******************************************************************************/
char *msgv2_get_event_desc(int iErrorCode)
{
	char *pEventDesc = "UNKNOWN_EVNET_ERROR";
	pEventDesc = get_mc_evnet_desc(iErrorCode);
	if (strcasecmp(pEventDesc, "UNKNOWN_EVNET_ERROR") != 0)
		return pEventDesc;
	pEventDesc = get_tc_evnet_desc(iErrorCode);
	if (strcasecmp(pEventDesc, "UNKNOWN_EVNET_ERROR") != 0)
		return pEventDesc;
	pEventDesc = get_mm_evnet_desc(iErrorCode);
	if (strcasecmp(pEventDesc, "UNKNOWN_EVNET_ERROR") != 0)
		return pEventDesc;
	return pEventDesc;
}

/*******************************************************************************
*Function Name    :msgv2_get_module_type
*Description      :msgv2_get_module_type,by tiger TODO
*Input       	  :int iErrorCode  
*Output 		  :NONE
*Return           :char *  
*******************************************************************************/
char *msgv2_get_module_type(int iErrorCode)
{
	char *pModuleType = "####";
	char *pEventDesc = "UNKNOWN_EVNET_ERROR";
	pEventDesc = get_mc_evnet_desc(iErrorCode);
	if (strcasecmp(pEventDesc, "UNKNOWN_EVNET_ERROR") != 0)
		return (pModuleType = "M003");
	pEventDesc = get_tc_evnet_desc(iErrorCode);
	if (strcasecmp(pEventDesc, "UNKNOWN_EVNET_ERROR") != 0)
		return (pModuleType = "M005");
	pEventDesc = get_mm_evnet_desc(iErrorCode);
	if (strcasecmp(pEventDesc, "UNKNOWN_EVNET_ERROR") != 0)
		return (pModuleType = "M001");
	return pModuleType;
}

/*******************************************************************************
*Function Name    :msgv2_get_event_level
*Description      :msgv2_get_event_level,by tiger  TODO
*Input       	  :int iErrorCode  
*Output 		  :NONE
*Return           :event_level_enum  
*******************************************************************************/
event_level_enum msgv2_get_event_level(int iErrorCode)
{
	event_level_enum eEventLevel = DEFAULT_LEVEL;
	switch (iErrorCode)
	{
	case EVENT_ERR_AGVSAFE:
	case EVENT_ERR_NOCONTACTIMPACT:
	case EVENT_ERR_CHARGECURSAMLL:
		eEventLevel = TIPS_LEVEL;
		break;
	default:
		eEventLevel = SERIOUS_LEVEL;
		break;
	}

	return eEventLevel;
}

#define NEED_ENTER_WAREHOUSE		1
#define NOT_NEED_ENTER_WAREHOUSE	0
/*******************************************************************************
*Function Name    :msgv2_get_manual_treatment
*Description      :msgv2_get_manual_treatment,by tiger  TODO
*Input       	  :int iErrorCode  
*Output 		  :NONE
*Return           :i16:1 when enter warehose ; else 0  
*******************************************************************************/
i16 msgv2_get_manual_treatment(int iErrorCode)
{
	i16 i16ManualTreatment = NEED_ENTER_WAREHOUSE;
	switch (iErrorCode)
	{
	case EVENT_ERR_AGVSAFE:
	case EVENT_ERR_NOCONTACTIMPACT:
	case EVENT_ERR_CHARGECURSAMLL:
		i16ManualTreatment = NOT_NEED_ENTER_WAREHOUSE;
		break;
	default:
		i16ManualTreatment = NEED_ENTER_WAREHOUSE;
		break;
	}

	return i16ManualTreatment;
}

#define  GROUD_AGV_PRODUCT_TYPE "P001"

/*******************************************************************************
* Function Name		 : msgv2_send_event
* Description	     : send event msg to console.
* Input 		     : iEvent: event num.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_send_event(int iEventType, int iErrorCode)
{
	int iRet = 0;
	iErrorCode = abs(iErrorCode);

	msgv2_event_t stMsgEvent =
	{
		.stMsgHead.i16MsgType = htons(MSG_TYPE_EVENT),
		.stMsgHead.i32AgvNo = htonl(g_stAgvAttr.iAgvName),
		.stMsgHead.i32TokenNum = htonl(g_stAgvAttr.iTokenNum),
		.stMsgHead.i32Sequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.stMsgHead.i8ProtoVer = 2,
		.stMsgHead.i8Flags = 1 << BIT_REQ,
		.stMsgHead.i32TaskID = htonl(g_stAgvTask.i32TaskID),
		.stMsgHead.i16DataLength = htons(sizeof(msgv2_event_t)-sizeof(msgv2_head_t)),

		.i64Location = htonll(g_stAgvAttr.iLocation),
		.i8VehHeadDirect = (i8)g_stAgvAttr.iVehHeadDirect,
		.i8PalletDirect = (i8)g_stAgvAttr.iPalletDirect,
		.i16EventType = htons(iEventType),
		.i32ErrorCode = htonl(iErrorCode),
		.i32SubErrorCode = htonl(g_stAgvAttr.iServoSubErr),
		.i32GXOffset = htonl(g_stAgvAttr.iGXOffset),
		.i32GYOffset = htonl(g_stAgvAttr.iGXOffset),
		.i32GAngleOffset = htonl(g_stAgvAttr.iGAngleOffset),
		.i32TXOffset = htonl(g_stAgvAttr.iTXOffset),
		.i32TYOffset = htonl(g_stAgvAttr.iTYOffset),
		.i32TAngleOffset = htonl(g_stAgvAttr.iTAngleOffset),
	};
	snprintf(stMsgEvent.i8ErrorDescTab, sizeof(stMsgEvent.i8ErrorDescTab), "%s", msgv2_get_event_desc(iErrorCode));
	
	time_t iTime;
	struct tm *tmp = NULL;
	time(&iTime);
	tmp = localtime(&iTime);
	strftime(stMsgEvent.i8DateTimeTab, sizeof(stMsgEvent.i8DateTimeTab), "%F %H:%M:%S", tmp); //time 2018-08-28 16:06:06
	snprintf(stMsgEvent.i8ProductTypeTab, sizeof(stMsgEvent.i8ProductTypeTab), "%s", GROUD_AGV_PRODUCT_TYPE);//P001	
	snprintf(stMsgEvent.i8ModuleTypeTab, sizeof(stMsgEvent.i8ModuleTypeTab), "%s", msgv2_get_module_type(iErrorCode));//M001
	stMsgEvent.i16EventLevel = htons(msgv2_get_event_level(iErrorCode));
	stMsgEvent.i16ManualTreatment = htons(msgv2_get_manual_treatment(iErrorCode));
	g_stAgvAttr.iServoSubErr = 0;//reset the ServoSubErr;
	// first of all, print the error information
	LOG_INF("append error/event[%d-%s] to error rx queue\n", iErrorCode, get_err_str(iErrorCode));

	iRet = linkqueue_append(g_stAgvParm.pErrorRxQueue, &iErrorCode, sizeof(int));	// save to list
	if (iRet < 0)
	{
		LOG_ERR("append msg to Error RX queue failure\n");
	}

	iRet = linkqueue_append(g_stAgvParm.pUdpTxQueue, &stMsgEvent, sizeof(stMsgEvent));
	if (iRet < 0) {
		LOG_ERR("append error msg to udp tx queue failure\n");
		return iRet;
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv2_send_event_release
* Description	     : send event release msg to console.
* Input 		     : iEvent: event num.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_send_event_release(int iEventType, int iErrorCode)
{
	int iRet = 0;
	iErrorCode = abs(iErrorCode);

	msgv2_event_release_t stMsgEventRelease =
	{
		.stMsgHead.i16MsgType = htons(MSG_TYPE_EVENT_RELEASE),
		.stMsgHead.i32AgvNo = htonl(g_stAgvAttr.iAgvName),
		.stMsgHead.i32TokenNum = htonl(g_stAgvAttr.iTokenNum),
		.stMsgHead.i32Sequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.stMsgHead.i8ProtoVer = 2,
		.stMsgHead.i8Flags = 1 << BIT_REQ,
		.stMsgHead.i16DataLength = htons(sizeof(msgv2_event_t)-sizeof(msgv2_head_t)),

		.i64Location = htonll(g_stAgvAttr.iLocation),
		.i16EventType = htons(iEventType),
		.i16ErrorCode = htons(iErrorCode),
	};

	// first of all, print the error information
	LOG_INF("send error/event[%d-%s] release to console\n", iErrorCode, get_err_str(iErrorCode));

	iRet = linkqueue_append(g_stAgvParm.pUdpTxQueue, &stMsgEventRelease, sizeof(stMsgEventRelease));
	if (iRet < 0) {
		LOG_ERR("append error msg to udp tx queue failure\n");
		return iRet;
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv2_send_error_point
* Description	     : send error piont msg to console.
* input			     : iErrorCode: the code of error
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_send_error_point(int iErrorCode)
{
	int iRet = 0;
	if (g_stAgvConf.cDebugEnable == TRUE)
	{
		//just for test agent,TODO
		LOG_WRN("Not send EVENT_ERR_NOCONTACTIMPACT and EVENT_ERR_AGVSAFE to test agent\n");
		return 0;
	}
	msgv2_send_event(EVENT_TYPE_SAFE, iErrorCode);
	return 0;
}

/*******************************************************************************
* Function Name		 : msgv2_send_finish
* Description	     : send finish msg to console.
* input			     : iAction�� the action type of operate msg
*					 : ACTION_WALK			1
*					 : ACTION_TURN_LEFT		2
*					 : ACTION_TURN_RIGHT	3
*					 : ACTION_RISE     	  	4
*					 : ACTION_LAY      	  	5
*					 : ACTION_CHARGE		6
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_send_finish(int iAction)
{
	int iRet = 0;

	msgv2_finish_t stMsgFin =
	{
		.stMsgHead.i16MsgType = htons(MSG_TYPE_FINISH),
		.stMsgHead.i32AgvNo = htonl(g_stAgvAttr.iAgvName),
		.stMsgHead.i32TokenNum = htonl(g_stAgvAttr.iTokenNum),
		.stMsgHead.i32Sequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.stMsgHead.i8ProtoVer = 2,
		.stMsgHead.i8Flags = 1 << BIT_REQ,
		.stMsgHead.i16DataLength = htons(sizeof(msgv2_finish_t)-sizeof(msgv2_head_t)),
		.stMsgHead.i32TaskID = htonl(g_stAgvTask.i32TaskID),
	
		.i64Location = htonll(g_stAgvAttr.iLocation),
		.i8VehHeadDirect = (i8)g_stAgvAttr.iVehHeadDirect,
		.i8PalletDirect = (i8)g_stAgvAttr.iPalletDirect,
		.i16Action = htons((i16)iAction),
	};

	iRet = linkqueue_append(g_stAgvParm.pUdpTxQueue, &stMsgFin, sizeof(stMsgFin));
	if (iRet < 0) {
		LOG_WRN("append finish msg to udp tx queue failure\n");
		return iRet;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv2_send_point
* Description	     : send point msg to console.
* input			     : iLocation : the location value
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_send_point(int iLocation, int iDriverMode) //change by tiger.22
{
	int iRet = 0;

	msgv2_point_t stMsgPoint =
	{
		.stMsgHead.i16MsgType = htons(MSG_TYPE_POINT),
		.stMsgHead.i32AgvNo = htonl(g_stAgvAttr.iAgvName),
		.stMsgHead.i32TokenNum = htonl(g_stAgvAttr.iTokenNum),
		.stMsgHead.i32Sequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.stMsgHead.i8ProtoVer = 2,
		.stMsgHead.i8Flags = 1 << BIT_REQ,
		.stMsgHead.i16DataLength = htons(sizeof(msgv2_finish_t)-sizeof(msgv2_head_t)),
		.stMsgHead.i32TaskID = htonl(g_stAgvTask.i32TaskID),
		.i64Location = htonll(g_stAgvAttr.iLocation),
		.i8VehHeadDirect = (i8)g_stAgvAttr.iVehHeadDirect,
		.i8PalletDirect = (i8)g_stAgvAttr.iPalletDirect,
		.i16DriverMode = htons((i16)iDriverMode),
	};

	iRet = linkqueue_append(g_stAgvParm.pUdpTxQueue, &stMsgPoint, sizeof(stMsgPoint));
	if (iRet < 0) {
		LOG_WRN("append point msg to udp tx queue failure\n");
		return iRet;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv2_send_confirm
* Description	     : send confirm msg to console.
* input			     : iMsgType: msg type to confirm
* input			     : iSeq : msg sequence to confirm.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_send_confirm(int iMsgType, int iSeq)
{
	int iRet = 0;
	int iTryTime = 1;
	int iTimeOut = TIME_OUT_2S;
	int iSequence = get_seq(AGENENT_SEQ_ID);
	agv_sem_t *pAgvSem = NULL;

	msgv2_confirm_t stMsgConfirm =
	{
		.stMsgHead.i16MsgType = htons(MSG_TYPE_CONFIRM),
		.stMsgHead.i32AgvNo = htonl(g_stAgvAttr.iAgvName),
		.stMsgHead.i32TokenNum = htonl(g_stAgvAttr.iTokenNum),
		.stMsgHead.i32Sequence = htonl(iSequence),
		.stMsgHead.i8ProtoVer = 2,
		.stMsgHead.i8Flags = 1 << BIT_REQ,
		.stMsgHead.i32TaskID = htonl(g_stAgvTask.i32TaskID),
		.stMsgHead.i16DataLength = htons(sizeof(msgv2_finish_t)-sizeof(msgv2_head_t)),

		.i32ComfirmMsgType = htonl(iMsgType),
		.i32ComfirmSequence = htonl(iSeq),
	};

	while (iTryTime++) {
#if(DEBUG_AGV == TRUE)
		// print debug info for sending message
		LOG_DBG("send udp msg to console[%s:%d]\n", g_stAgvParm.cServerIp, g_stAgvParm.iMsgSendServerPort);
		msgv2_head_dump((const char *)&stMsgConfirm);
#endif
		if (iTryTime < 10)
			iTimeOut = TIME_OUT_4S / 10;//by tiger.75
		else if ((iTryTime >= 10) && (iTryTime < 20))
			iTimeOut = TIME_OUT_8S / 10;//by tiger.75
		else if ((iTryTime >= 20) && (iTryTime < 50))
			iTimeOut = TIME_OUT_10S / 10;//by tiger.75
		else
			iTimeOut = TIME_OUT_20S / 10;//by tiger.75

		pAgvSem = agv_sem_add(SEM_MSG_TYPE, MSG_TYPE_CONFIRM, iSequence);
		if (NULL == pAgvSem)
		{
			LOG_ERR("add sem failed\n");
		}

		iRet = send_msg2console(&stMsgConfirm, sizeof(stMsgConfirm));
		if (iRet < 0)
		{
			LOG_WRN("send confirm msg error:[%s]\n", strerror(errno));
			usleep(100000); //100ms
			continue;
		}

		// wait for confirm ack from console
		iRet = agv_sem_wait(SEM_MSG_TYPE, MSG_TYPE_CONFIRM, iSequence, iTimeOut);
		if (0 == iRet)
		{
			// must get iMsgtype, iSequence from recv msg
			int iMsgtype = ntohl(stMsgConfirm.stMsgHead.i16MsgType);
			int iSequence = ntohl(stMsgConfirm.stMsgHead.i32Sequence);

			agv_sem_clean(SEM_MSG_TYPE, iMsgtype, iSequence);

			iRet = 0;
			break;
		}
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv2_send_ack
* Description	     : send ack msg to console.
* input			     : pMsgBuff: the msg head recieved .
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_send_ack(const char * pMsgBuff)
{
	int iRet = 0;
	msgv2_ack_t stMsgAck = { 0 };

	if (pMsgBuff == NULL)
		return -1;

	stMsgAck = *((msgv2_ack_t *)pMsgBuff);
	iRet = send_msg2console(&stMsgAck, sizeof(stMsgAck));
	if (iRet < 0)
	{
		LOG_ERR("send ack msg failure\n");
		return -1;
	}

	return 0;
}
/*******************************************************************************
* Function Name		 : msgv2_send_advanced_ack
* Description	     : send ack msg to console.
* input			     : pMsgBuff: the msg head recieved .
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_send_advanced_ack(const char * pMsgBuff)
{
	int iRet = 0;
	msgv2_operate_advanced_ack_t stMsgAdvancedAck = { 0 };
	if (pMsgBuff == NULL)
		return -1;

	stMsgAdvancedAck = *((msgv2_operate_advanced_ack_t *)pMsgBuff);
	iRet = send_msg2console(&stMsgAdvancedAck, sizeof(stMsgAdvancedAck));
	if (iRet < 0)
	{
		LOG_ERR("send advanced ack msg failure\n");
		return -1;
	}
	return 0;
}
/*******************************************************************************
*Function Name    :msgv2_send_batt_info
*Description      :
*Input       	  :void
*Output 		  :
*Return           :void
*******************************************************************************/
int msgv2_send_batt_info()
{
	int iRet = 0;
	float fVoltage = 0;
	float fCurrent = 0;

	msgv2_batt_info_t stMsgBattInfo =
	{
		.stMsgHead.i16MsgType = htons(MSG_TYPE_INFO),
		.stMsgHead.i32AgvNo = htonl(g_stAgvAttr.iAgvName),
		.stMsgHead.i32TokenNum = htonl(g_stAgvAttr.iTokenNum),
		.stMsgHead.i32Sequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.stMsgHead.i8ProtoVer = 2,
		.stMsgHead.i8Flags = 1 << BIT_REQ,
		.stMsgHead.i16DataLength = htons(sizeof(msgv2_batt_info_t)-sizeof(msgv2_head_t)),
		.stMsgHead.i32TaskID = htonl(g_stAgvTask.i32TaskID),
		
		.i16InfoType = htons(TYPE_BATT_INFO),
		.i16InfoSize = htons(sizeof(msgv2_batt_info_t)-sizeof(msgv2_info_t)),

		.i32BattTemperature = htonl(g_stAgvAttr.bms.uTemp - TEMPER_BASE),
		.i32Battery = htonl(g_stAgvAttr.bms.uSoc ),
	};

	iRet = send_msg2console(&stMsgBattInfo, sizeof(stMsgBattInfo));
	if (iRet >= 0)
	{
		fVoltage = (float)g_stAgvAttr.bms.uVoltage / 10;
		fCurrent = (float)g_stAgvAttr.bms.uCurrent / 10;
		LOG_INF("send battery info:[%dC],voltage:[%.2fV],current[%.2fA],battery:[%d%],state:[%s]\n",
			ntohl(stMsgBattInfo.i32BattTemperature), fVoltage, fCurrent, g_stAgvAttr.bms.uSoc,
			(g_stAgvAttr.bms.uState == 1) ? "charging" : "not charging");
	}
	else
	{
		LOG_WRN("send battery info failure:%d-%s\n", errno, strerror(errno));
	}
}

/*******************************************************************************
*Function Name    :msgv2_send_scan_info
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :void  
*******************************************************************************/
int msgv2_send_scan_info()
{
	int iRet = 0;

	msgv2_scan_info_t stMsgScanInfo =
	{
		.stMsgHead.i16MsgType = htons(MSG_TYPE_INFO),
		.stMsgHead.i32AgvNo = htonl(g_stAgvAttr.iAgvName),
		.stMsgHead.i32TokenNum = htonl(g_stAgvAttr.iTokenNum),
		.stMsgHead.i32Sequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.stMsgHead.i8ProtoVer = 2,
		.stMsgHead.i8Flags = 1 << BIT_REQ,
		.stMsgHead.i16DataLength = htons(sizeof(msgv2_batt_info_t)-sizeof(msgv2_head_t)),
		.stMsgHead.i32TaskID = htonl(g_stAgvTask.i32TaskID),
		
		.i16InfoType = htons(TYPE_SCAN_INFO),
		.i16InfoSize = htons(sizeof(msgv2_scan_info_t)-sizeof(msgv2_info_t)),

		.i32SucScanCount = htonl(0),	//TODO:i32SucScanCount
		.i32NOScanCount = htonl(0),		//TODO:i32NOScanCount
		.i32ScanErrCount = htonl(0),	//TODO:i32ScanErrCount
	};

	iRet = send_msg2console(&stMsgScanInfo, sizeof(stMsgScanInfo));
	if (iRet< 0) {
		LOG_WRN("send scan info failure:%d-%s\n", errno, strerror(errno));
	}

	return iRet;
}

/*******************************************************************************
*Function Name    :msgv2_send_offset_info
*Description      :
*Input       	  :void
*Output 		  :
*Return           :void
*******************************************************************************/
int msgv2_send_offset_info()
{
	int iRet = 0;

	msgv2_offset_info_t stMsgOffsetInfo =
	{
		.stMsgHead.i16MsgType = htons(MSG_TYPE_INFO),
		.stMsgHead.i32AgvNo = htonl(g_stAgvAttr.iAgvName),
		.stMsgHead.i32TokenNum = htonl(g_stAgvAttr.iTokenNum),
		.stMsgHead.i32Sequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.stMsgHead.i8ProtoVer = 2,
		.stMsgHead.i8Flags = 1 << BIT_REQ,
		.stMsgHead.i16DataLength = htons(sizeof(msgv2_batt_info_t)-sizeof(msgv2_head_t)),
		.stMsgHead.i32TaskID = htonl(g_stAgvTask.i32TaskID),

		.i16InfoType = htons(TYPE_OFFSET_INFO),
		.i16InfoSize = htons(sizeof(msgv2_offset_info_t)-sizeof(msgv2_info_t)),

		.i64Location = htonll(g_stAgvAttr.iLocation),
		.i8VehHeadDirect = (i8)g_stAgvAttr.iVehHeadDirect,
		.i8PalletDirect = (i8)g_stAgvAttr.iPalletDirect,
		.i16Action = (i16)htonl(g_stAgvAttr.iMoveStatus),
		.i32GXOffset = htonl(g_stAgvAttr.iGXOffset),
		.i32GYOffset = htonl(g_stAgvAttr.iGXOffset),
		.i32GAngleOffset = htonl(g_stAgvAttr.iGAngleOffset),
		.i32TXOffset = htonl(g_stAgvAttr.iTXOffset),
		.i32TYOffset = htonl(g_stAgvAttr.iTYOffset),
		.i32TAngleOffset = htonl(g_stAgvAttr.iTAngleOffset),
	};

	iRet = send_msg2console(&stMsgOffsetInfo, sizeof(stMsgOffsetInfo));
	if (iRet< 0) {
		LOG_WRN("send offset info failure:%d-%s\n", errno, strerror(errno));
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : compute_task_head_direct
* Description	     : compute vehicle head direct in task.
* input			     : iSrcLocation: the first location point in task.
* input			     : iDstLocation: the last  location point in task.
* Output		     : NONE
* Return		     : vehicle head direction(0~4)
*******************************************************************************/
static int compute_task_head_direct(int iSrcLocation, int iDstLocation)
{
	int iTaskHeaderDirect = INVALID_DIRECTION;

	if ((iSrcLocation == INVALID_POINT) || (iDstLocation == INVALID_POINT))
		return iTaskHeaderDirect;

	if ((iDstLocation - iSrcLocation) >= 10000) //Positive direction of X axis,go and go will be 1000,2000,3000
		iTaskHeaderDirect = DIRECTION_X_P;
	else if ((iDstLocation - iSrcLocation) <= -10000)//Negative direction of X axis
		iTaskHeaderDirect = DIRECTION_X_N;
	else if ((iDstLocation - iSrcLocation) >= 1)//Positive direction of Y axis
		iTaskHeaderDirect = DIRECTION_Y_P;
	else if ((iDstLocation - iSrcLocation) <= -1)//Negative direction of Y axis
		iTaskHeaderDirect = DIRECTION_Y_N;

	return iTaskHeaderDirect;
}

/*******************************************************************************
* Function Name		 : msgv2_dump_walk_path
* Description	     : dump walk path in the operate msg
* input			     : pMsgOperate : the pointer of msgv2_operate
* Output		     : NONE
* Return		     : 0: success; <0: failure
*******************************************************************************/
int msgv2_dump_walk_path(const char * pMsgBuff)
{
	msgv2_operate_t *pMsgOperate = (msgv2_operate_t *)pMsgBuff;
	msgv2_operate_t stMsgOperate = { 0 };

	int i = 0;
	int iNum = 0;
	int iPointCurr = 0;

	if (pMsgOperate == NULL) {
		return -1;
	}

	stMsgOperate.i16Action = ntohs(pMsgOperate->i16Action);
	stMsgOperate.i16TotalLength = ntohs(pMsgOperate->i16TotalLength);
	stMsgOperate.i16StepLength = ntohs(pMsgOperate->i16StepLength);
	stMsgOperate.i64SrcLocation = ntohll(pMsgOperate->i64SrcLocation);
	stMsgOperate.i64DstLocation = ntohll(pMsgOperate->i64DstLocation);
	if (stMsgOperate.i16Action != ACTION_WALK)
	{
		LOG_ERR("the action[%d-%s] in task is not ACTION_WALK\n",
			stMsgOperate.i16Action, get_action_name(stMsgOperate.i16Action));
		return -1;
	}

	// 1000mm the distance of two point
	int iLocationLength = abs(stMsgOperate.i64SrcLocation - stMsgOperate.i64DstLocation);
	iNum = (iLocationLength >= 10000) ? (1+ iLocationLength / 10000) :(1+ iLocationLength);

	stMsgOperate.i64SrcLocation = ntohll(pMsgOperate->i64SrcLocation);
	stMsgOperate.i64DstLocation = ntohll(pMsgOperate->i64DstLocation);
	int iPointStep = 0;
	if(iNum > 1)
		iPointStep = (stMsgOperate.i64DstLocation - stMsgOperate.i64SrcLocation) / (iNum - 1);
	LOG_INF("walk path [%d] points:\n", iNum);
	LOG_INF("-----------------------\n");
	for (i = 0; i < iNum ; i++)
	{
		iPointCurr = stMsgOperate.i64SrcLocation + i * iPointStep;
		LOG_INF("[%d] = %d\n", i, iPointCurr);
	}
	LOG_INF("-----------------------\n");

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv2_check_walk_path
* Description	     : check the walking path and add the point to path queue
* input			     : pMsgOperate : the pointer of msgv2_operate
* Output		     : NONE
* Return		     : 0: success; <0: failure
*******************************************************************************/
int msgv2_check_walk_path(const char * pMsgBuff)
{
	msgv2_operate_t *pMsgOperate = (msgv2_operate_t *)pMsgBuff;
	msgv2_operate_t stMsgOperate = { 0 };

	int i = 0;
	int iRet = 0;
	int iNum = 0;
	i64 iTaskSrcPoint = 0;
	i64 iTaskDstPoint = 0;
	i64 iLastSrcLocation = g_stAgvTask.iSrcPoint;
	i64 iLastDstLocation = g_stAgvTask.iDstPoint;
	i64 iCurLocation = g_stAgvAttr.iLocation;
	int iPointPrev = 0;
	int iPointCurr = 0;
	int iLocationLength;
	int iTaskCheckPoint = 0;

	if (pMsgOperate == NULL) {
		return -1;
	}

	stMsgOperate.i16Action = ntohs(pMsgOperate->i16Action);
	stMsgOperate.i16TotalLength = ntohs(pMsgOperate->i16TotalLength);
	stMsgOperate.i64SrcLocation = ntohll(pMsgOperate->i64SrcLocation);
	stMsgOperate.i64DstLocation = ntohll(pMsgOperate->i64DstLocation);
	if (stMsgOperate.i16Action != ACTION_WALK)
	{
		LOG_ERR("the action[%d-%s] in task is not ACTION_WALK\n",
			stMsgOperate.i16Action, get_action_name(stMsgOperate.i16Action));
		return -1;
	}

	// 1000mm the distance of two point
	iLocationLength = abs(stMsgOperate.i64SrcLocation - stMsgOperate.i64DstLocation);
	iNum = (iLocationLength >= 10000) ? (1 + iLocationLength / 10000) : (1 + iLocationLength);

	if(iNum > 1)
		stMsgOperate.i16StepLength = stMsgOperate.i16TotalLength / (iNum - 1);
	msgv2_dump_walk_path(pMsgBuff);

	iTaskSrcPoint = stMsgOperate.i64SrcLocation;
	iTaskDstPoint = stMsgOperate.i64DstLocation;
	int iLocationStep = (stMsgOperate.i64SrcLocation > stMsgOperate.i64DstLocation) ? (-stMsgOperate.i16StepLength) : (stMsgOperate.i16StepLength);
	

	///start by tiger.27
	//ֱ��������Ч���ж��Ż���·������Ϊ��ʱ���������͵�ǰ��ȣ��������һ�������յ�Ƚϣ�by tiger.103
	if (linkqueue_length(g_stAgvParm.pPathQueue) <= 0)	//��ȡУ��� by tiger.103
	{
		iCurLocation = g_stAgvAttr.iLocation;
		iTaskCheckPoint = iCurLocation;
	}
	else
		iTaskCheckPoint = iLastDstLocation;
	//check iTaskSrcPoint is equal the iTaskCheckPoint?
	if (iTaskCheckPoint == iTaskSrcPoint)
	{
		LOG_INF("the task's first point[%lld]=check point[%lld],CurLocation =[%lld]\n",
			iTaskSrcPoint, iTaskCheckPoint, iCurLocation);
	}
	else
	{
		LOG_ERR("the task's first point[%lld]!=check point[%lld],CurLocation =[%lld]\n",
			iTaskSrcPoint, iTaskCheckPoint, iCurLocation);
		send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_WRONG_LOCATION);
		return -1;
	}
	///end by tiger.27

	g_stAgvTask.iSrcPoint = iTaskSrcPoint;
	g_stAgvTask.iDstPoint = iTaskDstPoint;
	int iPointStep = 0;
	if(iNum > 1)
		iPointStep = (stMsgOperate.i64DstLocation - stMsgOperate.i64SrcLocation) / (iNum - 1);
	//add task's point into pPathQueue for point report
	for (i = 1; i <= iNum-1; i++)  //change by tiger.27, drop push the first point
	{
		iPointCurr = iTaskSrcPoint + iPointStep * i;
		iRet = linkqueue_append(g_stAgvParm.pPathQueue, &(iPointCurr), sizeof(int));
		if (iRet < 0) {
			break;
		}
	}

	return iRet;
}

/*******************************************************************************
*Function Name    :msgv2_deal_action_result
*Description      :deal the result of device action ,such as :turn left
*Input       	  :int iRet  
*Input       	  :bool bNeedSendFinish: report finish msg to console if true;else need not report  
*Input       	  :int iAction:the action id of task  
*Output 		  :
*Return           :void  
*******************************************************************************/
int msgv2_deal_action_result(int iRet, bool bNeedSendFinish, int iAction)
{
	int iErrorCode = 0;
	int iResult = 0;
	
	// modified by kedong, 20180305
	// update the navgate data into mcu log every action
	// when ACTION_WALK, update_mcu_log in parse_groudqr()
	if (iAction != ACTION_WALK)
	{
		update_mcu_log();
		//start ,add by tiger.51
		//iResult = sta_send_event_info(SATISTICAL_SEND_NOW);
		iResult = sta_send_event_info(SATISTICAL_SEND_NOW);
		if (iResult < 0)
		{
			LOG_WRN("send statistical event info failed:[%d-%s]", errno, strerror(errno));
		}
		//end ,add by tiger.51
	}
		

	//when iAction == ACTION_CHARGE, CAN NOT set iMoveStatus = agv_stop
	if (iAction != ACTION_CHARGE)
		g_stAgvAttr.iMoveStatus = agv_stop;//add by tiger

	switch (iRet)
	{
	case OK: //action finished
		if (true == bNeedSendFinish)
		{
			LOG_INF("operate[%d-%s] finish\n", iAction, get_action_name(iAction));
			if (msgv2_send_finish(iAction) < 0 )
			{
				LOG_ERR("append finish msg[%d-%s] to udp tx queue failure\n", 
					iAction, get_action_name(iAction));
			}
		}
		else
		{
			if (iAction == ACTION_WALK)
			{
				LOG_INF("operate[%d-%s] with walk continue, so no need send finish msg\n",
					iAction, get_action_name(iAction));
			}
			else
			{
				LOG_INF("operate[%d-%s] may is not from console, so no need send finish msg\n",
					iAction, get_action_name(iAction));
			}
		}
		break;
	case 0:
		LOG_INF("deal [%d-%s] success\n", iAction, get_action_name(iAction));
		break;
	case -1://CAN communicate failed
		LOG_INF("send [%d-%s] CAN frame failure\n", iAction, get_action_name(iAction));
		break;
	case REFUSE:
		LOG_ERR("append error msg[%d-%s] to udp tx queue\n",
			EVENT_ERR_MCREFUSE, get_err_str(EVENT_ERR_MCREFUSE));
		if (send_error_msg(EVENT_ERR_MCREFUSE, EVENT_TYPE_ERROR) < 0)
		{
			LOG_ERR("append error msg[%d-%s] to udp tx queue failure\n",
				EVENT_ERR_MCREFUSE, get_err_str(EVENT_ERR_MCREFUSE));
		}		
		break;
	case BERROR:
		LOG_ERR("append error msg[%d-%s] to udp tx queue\n",
			EVENT_ERR_PARKPRECISION, get_err_str(EVENT_ERR_PARKPRECISION));
		if (send_error_msg(EVENT_ERR_PARKPRECISION, EVENT_TYPE_ERROR) < 0)
		{
			LOG_ERR("append error msg[%d-%s] to udp tx queue failure\n",
				EVENT_ERR_PARKPRECISION, get_err_str(EVENT_ERR_PARKPRECISION));
		}
		break;
	case IS_UP:
		LOG_INF("excute [%d-%s] finish, IS_UP\n", iAction, get_action_name(iAction));
		if (msgv2_send_finish(ACTION_RISE) < 0)
		{
			LOG_INF("append finish msg[4-ACTION_RISE] to udp tx queue failure\n");
		}
		break;
	case IS_DOWN:
		LOG_INF("excute [%d-%s] finish, IS_DOWN\n", iAction, get_action_name(iAction));
		if (msgv2_send_finish(ACTION_LAY) < 0)
		{
			LOG_INF("append finish msg[5-ACTION_LAY] to udp tx queue failure\n");
		}
		break;
	case -EVENT_ERR_MC_TIMEOUT:
		LOG_WRN("MC excute [%d-%s] timeout\n", iAction, get_action_name(iAction));
		break;
	case -EVENT_ERR_TC_TIMEOUT:
		LOG_WRN("TC excute [%d-%s] timeout\n", iAction, get_action_name(iAction));
		break;
	default: //deal exception error code
		iErrorCode = abs(iRet);
		LOG_ERR("excute action[%d-%s] finish with error[%d-%s]\n",
			iAction, get_action_name(iAction),
			iErrorCode, get_err_str(iErrorCode));
		if (send_error_msg(iErrorCode, EVENT_TYPE_ERROR) < 0)
		{
			LOG_ERR("append error msg[%d-%s] to udp tx queue failure\n", 
				iErrorCode, get_err_str(iErrorCode));
		}
		else
		{
			LOG_INF("append error msg[%d-%s] to udp tx queue success\n", 
				iErrorCode, get_err_str(iErrorCode));
		}		
		break;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : deal_operate_msg
* Description	     : parse operate msg to can msg.
* input			     : pMsg: the operate msg.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_deal_operate(const char * pMsgBuff)
{
	msgv2_operate_t stMsgOperate = { 0 };
	msgv2_operate_t * pMsgOperate = (msgv2_operate_t *)pMsgBuff;
	int iRet = 0;
	bool bNeedSendFinish = false;
	int iAction = 0;
	int iSync = 1;	//TODO:compute sync by pallet status
	static int s_i16PreTotalLength =0;
	if (NULL == pMsgOperate) {
		return -1;
	}
	my_printf("the ntohs(pMsgOperate->i16TurnAngle) :%d\n", ntohs(pMsgOperate->i16TurnAngle));
	stMsgOperate.i16Action = ntohs(pMsgOperate->i16Action);
	stMsgOperate.i16TotalLength = ntohs(pMsgOperate->i16TotalLength);
	stMsgOperate.i16StepLength = ntohs(pMsgOperate->i16StepLength);
	stMsgOperate.i16WeightLevel = ntohs(pMsgOperate->i16WeightLevel);
	stMsgOperate.i16Speed = ntohs(pMsgOperate->i16Speed);
	stMsgOperate.i16TurnAngle = ntohs(pMsgOperate->i16TurnAngle);
	stMsgOperate.i16iTaskPalletDirect = ntohs(pMsgOperate->i16iTaskPalletDirect);
	stMsgOperate.i8WalkDirection = ntohs(pMsgOperate->i8WalkDirection);//add by jxu 20180828
	strncpy(stMsgOperate.i8TopQR, pMsgOperate->i8TopQR, 30);
	iAction = stMsgOperate.i16Action;
	if (iAction >= ACTION_TYPE_NUM)
	{
		LOG_WRN("recv action %d not supported\n", iAction);
		return -1;
	}

#if(DEBUG_AGV == TRUE)
	int iMsgtype = ntohs(pMsgOperate->stMsgHead.i16MsgType);
	int iSequence = ntohl(pMsgOperate->stMsgHead.i32Sequence);

	// print debug info for sending message
	LOG_DBG("deal udp msg[%d-%s] sequence=%d\n", iMsgtype, get_msg_name(iMsgtype), iSequence);
	msgv2_head_dump(pMsgBuff);
#endif

	//LOG_INF("deal udp msg:[%d-%s],speed:%dmm/s,length:%dmm\n",
	//	iAction, get_action_name(iAction),
	//	stMsgOperate.iSpeed/10, stMsgOperate.i16TotalLength);

	g_stAgvTask.enTaskType = iAction;
	switch (iAction)
	{
	case ACTION_WALK:
		//add by jxu 20180828-begin
		if (stMsgOperate.i16Speed == SLOW_GO_BACK_SPEED)
		{
			if (stMsgOperate.i8WalkDirection == TRUE)
			{
				iRet = mc_slow_go_straight(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
				bNeedSendFinish = true;
				break;
			}
			else if (stMsgOperate.i8WalkDirection == FALSE)
			{
				iRet = mc_slow_go_back(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
				bNeedSendFinish = true;
				break;
			}
			else
			{
				iRet = OK;
				bNeedSendFinish = true;
				LOG_WRN("The i8WalkDirection[%d] is invalid\n", stMsgOperate.i8WalkDirection);
				break;
			}
		}
		else
		{
			if (0 != g_stAgvConf.cCheckPoint)
			{
				iRet = msgv2_check_walk_path(pMsgBuff);
				if (iRet < 0) {
					LOG_ERR("check_walk_path failure, the operate can not execute\n");
					return -1;
				}

				int iDirectOffset = 0;
				u16 u16Angle = 0;
				u8 u8Weight = (u8)stMsgOperate.i16WeightLevel;
				int iTaskSrcPoint = g_stAgvTask.iSrcPoint;
				int iTaskDstPoint = g_stAgvTask.iDstPoint;
				int iVehHeaderDirect = g_stAgvAttr.iVehHeadDirect;
				int iTaskHeaderDirect = compute_task_head_direct(iTaskSrcPoint, iTaskDstPoint);
				if (iTaskHeaderDirect == INVALID_DIRECTION)
				{
					LOG_ERR("compute task head direct[%d] is invalid\n", iTaskHeaderDirect);
					send_error_msg(EVENT_ERR_TASK_ERROR, EVENT_TYPE_ERROR);
					return iRet;
				}

				if (iTaskHeaderDirect != iVehHeaderDirect)
				{
					//TODO: need to optimize
					iDirectOffset = iTaskHeaderDirect - iVehHeaderDirect;
					if (iDirectOffset < 0)
						iDirectOffset += 4;
					u16Angle = iDirectOffset * 900;

					turn_left(1, u8Weight, u16Angle, 600);
					//modified by tiger,20190821
					//receive go continue cmd during turning left
					if (true == g_stAgvTask.iWalkContinue)
					{
						bNeedSendFinish = false;
						g_stAgvTask.iWalkContinue = false;
						s_i16PreTotalLength = stMsgOperate.i16TotalLength;
						return 0;
					}
				}
			
			} else {
				msgv2_dump_walk_path(pMsgBuff);
			}
		
			// modified by kedong, 20180213
			// set bNeedSendFinish=true first of all, 
			// may set to false in function go_forward() when walk continue;
			bNeedSendFinish = true;
			iRet = go_forward((u8)stMsgOperate.i16WeightLevel, s_i16PreTotalLength + stMsgOperate.i16TotalLength, stMsgOperate.i16Speed, &bNeedSendFinish);
			s_i16PreTotalLength = 0;
			break;
		}
		//add by jxu 20180828-end
	case ACTION_TURN_LEFT:
		iRet = turn_left(iSync, (u8)stMsgOperate.i16WeightLevel, stMsgOperate.i16TurnAngle, stMsgOperate.i16Speed);
		bNeedSendFinish = true;
		break;
	case ACTION_TURN_RIGHT:
		iRet = turn_right(iSync, (u8)stMsgOperate.i16WeightLevel, stMsgOperate.i16TurnAngle, stMsgOperate.i16Speed);
		bNeedSendFinish = true;
		break;
	case ACTION_RISE:
		iRet = tc_rise((u8)stMsgOperate.i16WeightLevel, stMsgOperate.i8TopQR);
		bNeedSendFinish = true;
		break;
	case ACTION_LAY:
		iRet = tc_lay((u8)stMsgOperate.i16WeightLevel, stMsgOperate.i8TopQR);
		bNeedSendFinish = true;
		break;
	case ACTION_CHARGE:
		iRet = start_charge();
		bNeedSendFinish = true;
		break;
	case ACTION_STOP_CHARGE:
		iRet = stop_charge();
		bNeedSendFinish = true;
		break;
	case ACTION_PARK:
		iRet = stop_agv(DEV_MC);
		bNeedSendFinish = false;
		break;
	case ACTION_CLEAN_DERAIL:
		iRet = clear_derail();
		bNeedSendFinish = false;
		break;
	case ACTION_PALLET_TURN_LEFT:
		g_stAgvAttr.iTaskPalletDirect = stMsgOperate.i16iTaskPalletDirect;
		g_stAgvAttr.iPalletDirect = 0;	//TODO:how to get pallect direction
		iRet = pallet_turn_left((u8)stMsgOperate.i16WeightLevel, stMsgOperate.i16TurnAngle, stMsgOperate.i16Speed);
		bNeedSendFinish = true;
		break;
	case ACTION_PALLET_TURN_RIGHT:
		g_stAgvAttr.iTaskPalletDirect = stMsgOperate.i16iTaskPalletDirect;
		g_stAgvAttr.iPalletDirect = 0;	//TODO:how to get pallect direction
		iRet = pallet_turn_right((u8)stMsgOperate.i16WeightLevel, stMsgOperate.i16TurnAngle, stMsgOperate.i16Speed);
		bNeedSendFinish = true;
		break;
	case ACTION_CLEAR_NAVIGATION:
		iRet = clear_navigation();
		bNeedSendFinish = false;
		break;
		///add by tiger.10,start
	case ACTION_BACK_TO_CHARGE:	
		//agent send qr distance = length
		iRet = mc_slow_go_back(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
		bNeedSendFinish = true;
		break;
	case  ACTION_FORWARD_LEAVE_CHARGE:	
		//agent send qr distance = length
		iRet = mc_slow_go_straight(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
		bNeedSendFinish = true;
		break;
	case ACTION_LEFT_ARC:		
		iRet = mc_leftarc(stMsgOperate.i16WeightLevel);
		bNeedSendFinish = true;
		break;
	case ACTION_RIGHT_ARC:
		iRet = mc_rightarc(stMsgOperate.i16WeightLevel);
		bNeedSendFinish = true;
		break;
	case ACTION_FORWARD_TO_CHARGE:
		//agent send qr distance = length
		iRet = mc_slow_go_straight(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
		bNeedSendFinish = true;
		break;
	case ACTION_BACK_LEAVE_CHARGE:
		//agent send qr distance = length
		iRet = mc_slow_go_back(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
		bNeedSendFinish = true;
		break;
		///end,by tiger.10
	default:
		LOG_WRN("unspported task or action type\n");
		iRet = OK;
		bNeedSendFinish = true;
		break;
	}

	msgv2_deal_action_result(iRet, bNeedSendFinish, iAction);

	return iRet;
}
/*******************************************************************************
* Function Name		 : msgv2_deal_basic_action
* Description	     : parse operate msg to can msg.
* input			     : pMsg: the operate msg.
* Output		     : NONE
* Return		     : OK:success; <0:failure
*******************************************************************************/
int msgv2_deal_basic_action(const char * pMsgBuff, int iAction, int iTurnAngle, bool *bNeedSendFinish, int iCoverFlag)
{
	int iRet = 0;
	int iSync = 1;	//TODO:compute sync by pallet status
	static int s_i16PreTotalLength = 0;
	msgv2_operate_advanced_t stMsgOperate = { 0 };
	msgv2_operate_advanced_t * pMsgOperate = (msgv2_operate_advanced_t *)pMsgBuff;
	stMsgOperate.i16Action = ntohs(pMsgOperate->i16Action);
	stMsgOperate.i16TotalLength = ntohs(pMsgOperate->i16TotalLength);
	stMsgOperate.i16StepLength = ntohs(pMsgOperate->i16StepLength);
	stMsgOperate.i16WeightLevel = ntohs(pMsgOperate->i16WeightLevel);
	stMsgOperate.i16Speed = ntohs(pMsgOperate->i16Speed);
	stMsgOperate.iTaskPalletDirect = pMsgOperate->iTaskPalletDirect;
	stMsgOperate.i8WalkDirection = pMsgOperate->i8WalkDirection;
	strncpy(stMsgOperate.i8TopQR, pMsgOperate->i8TopQR, 30);
	g_stAgvTask.enTaskType = iAction;
	switch (iAction)
	{
	case ACTION_WALK:
		//add by jxu 20180828-begin
		if (stMsgOperate.i16Speed == SLOW_GO_BACK_SPEED)
		{
			if (stMsgOperate.i8WalkDirection == TRUE)
			{
				iRet = mc_slow_go_straight(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
				break;
			}
			else if (stMsgOperate.i8WalkDirection == FALSE)
			{
				iRet = mc_slow_go_back(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
				break;
			}
			else
			{
				iRet = OK;
				LOG_WRN("The i8WalkDirection[%d] is invalid\n", stMsgOperate.i8WalkDirection);
				break;
			}
		}
		else
		{
			if (0 != g_stAgvConf.cCheckPoint)
			{
				iRet = msgv2_check_walk_path(pMsgBuff);
				if (iRet < 0) {
					LOG_ERR("check_walk_path failure, the operate can not execute\n");
					return -1;
				}

				int iDirectOffset = 0;
				u16 u16Angle = 0;
				u8 u8Weight = (u8)stMsgOperate.i16WeightLevel;
				int iTaskSrcPoint = g_stAgvTask.iSrcPoint;
				int iTaskDstPoint = g_stAgvTask.iDstPoint;
				int iVehHeaderDirect = g_stAgvAttr.iVehHeadDirect;
				int iTaskHeaderDirect = compute_task_head_direct(iTaskSrcPoint, iTaskDstPoint);
				if (iTaskHeaderDirect == INVALID_DIRECTION)
				{
					LOG_ERR("compute task head direct[%d] is invalid\n", iTaskHeaderDirect);
					send_error_msg(EVENT_ERR_TASK_ERROR, EVENT_TYPE_ERROR);
					return iRet;
				}

				if (iTaskHeaderDirect != iVehHeaderDirect)
				{
					//TODO: need to optimize
					iDirectOffset = iTaskHeaderDirect - iVehHeaderDirect;
					if (iDirectOffset < 0)
						iDirectOffset += 4;
					u16Angle = iDirectOffset * 900;

					turn_left(1, u8Weight, u16Angle, 600);
					//modified by tiger,20190821
					//receive go continue cmd during turning left
					if (true == g_stAgvTask.iWalkContinue)
					{
						g_stAgvTask.iWalkContinue = false;
						s_i16PreTotalLength = stMsgOperate.i16TotalLength;
						return 0;
					}
				}

			}
			else {
				msgv2_dump_walk_path(pMsgBuff);
			}

			// modified by kedong, 20180213
			// set bNeedSendFinish=true first of all, 
			// may set to false in function go_forward() when walk continue;
			*bNeedSendFinish = TRUE;
			iRet = go_forward((u8)stMsgOperate.i16WeightLevel, s_i16PreTotalLength + stMsgOperate.i16TotalLength, stMsgOperate.i16Speed, bNeedSendFinish);
			s_i16PreTotalLength = 0;
			break;
		}
		//add by jxu 20180828-end
	case ACTION_TURN_LEFT:
		iRet = turn_left(iSync, (u8)stMsgOperate.i16WeightLevel, iTurnAngle, 600);//speed const in MC
		break;
	case ACTION_TURN_RIGHT:
		iRet = turn_right(iSync, (u8)stMsgOperate.i16WeightLevel, iTurnAngle, 600);
		break;
	case ACTION_RISE:
		iRet = tc_rise((u8)stMsgOperate.i16WeightLevel, stMsgOperate.i8TopQR);
		break;
	case ACTION_LAY:
		iRet = tc_lay((u8)stMsgOperate.i16WeightLevel, stMsgOperate.i8TopQR);
		break;
	case ACTION_CHARGE:
		iRet = start_charge();
		break;
	case ACTION_STOP_CHARGE:
		iRet = stop_charge();
		break;
	case ACTION_PARK:
		iRet = stop_agv(DEV_MC);
		break;
	case ACTION_CLEAN_DERAIL:
		iRet = clear_derail();
		break;
	case ACTION_PALLET_TURN_LEFT:
		g_stAgvAttr.iTaskPalletDirect = stMsgOperate.iTaskPalletDirect;
		g_stAgvAttr.iPalletDirect = 0;	//TODO:how to get pallect direction
		iRet = pallet_turn_left((u8)stMsgOperate.i16WeightLevel, iTurnAngle, 600);
		break;
	case ACTION_PALLET_TURN_RIGHT:
		g_stAgvAttr.iTaskPalletDirect = stMsgOperate.iTaskPalletDirect;
		g_stAgvAttr.iPalletDirect = 0;	//TODO:how to get pallect direction
		iRet = pallet_turn_right((u8)stMsgOperate.i16WeightLevel, iTurnAngle, 600);
		break;
	case ACTION_CLEAR_NAVIGATION:
		iRet = clear_navigation();
		break;
		///add by tiger.10,start
	case ACTION_BACK_TO_CHARGE:
		//agent send qr distance = length
		iRet = mc_slow_go_back(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
		break;
	case  ACTION_FORWARD_LEAVE_CHARGE:
		//agent send qr distance = length
		iRet = mc_slow_go_straight(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
		break;
	case ACTION_LEFT_ARC:
		iRet = mc_leftarc(stMsgOperate.i16WeightLevel);
		break;
	case ACTION_RIGHT_ARC:
		iRet = mc_rightarc(stMsgOperate.i16WeightLevel);
		break;
	case ACTION_FORWARD_TO_CHARGE:
		//agent send qr distance = length
		iRet = mc_slow_go_straight(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
		break;
	case ACTION_BACK_LEAVE_CHARGE:
		//agent send qr distance = length
		iRet = mc_slow_go_back(stMsgOperate.i16TotalLength, stMsgOperate.i16TotalLength);
		break;
		///end,by tiger.10
	default:
		LOG_WRN("unspported task or action type\n");
		iRet = OK;
		break;
	}
	return iRet;
}
/*******************************************************************************
* Function Name		 : msgv2_deal_advanced_operate
* Description	     : parse operate msg to can msg.
* input			     : pMsg: the operate msg.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_deal_advanced_operate(const char * pMsgBuff)
{
	msgv2_operate_advanced_t stMsgOperate = { 0 };
	msgv2_operate_advanced_t * pMsgOperate = (msgv2_operate_advanced_t *)pMsgBuff;
	int iRet = 0;
	bool bNeedSendFinish = false;
	int iAction = 0;
	int iSync = 1;	//TODO:compute sync by pallet status
	static int s_i16PreTotalLength = 0;
	if (NULL == pMsgOperate) {
		return -1;
	}
	//my_printf("the ntohs(pMsgOperate->i16TurnAngle) :%d\n", ntohs(pMsgOperate->i16TurnAngle));
	stMsgOperate.i16Action = ntohs(pMsgOperate->i16Action);
	stMsgOperate.i16TotalLength = ntohs(pMsgOperate->i16TotalLength);
	stMsgOperate.i16StepLength = ntohs(pMsgOperate->i16StepLength);
	stMsgOperate.i16WeightLevel = ntohs(pMsgOperate->i16WeightLevel);
	stMsgOperate.i16Speed = ntohs(pMsgOperate->i16Speed);
	stMsgOperate.iSrcAction = ntohs(pMsgOperate->iSrcAction);
	stMsgOperate.iDstAction = ntohs(pMsgOperate->iDstAction);
	stMsgOperate.iSrcTurnAngle = ntohs(pMsgOperate->iSrcTurnAngle);
	stMsgOperate.iDstTurnAngle = ntohs(pMsgOperate->iDstTurnAngle);
	stMsgOperate.iTaskPalletDirect = ntohs(pMsgOperate->iTaskPalletDirect);
	stMsgOperate.i8WalkDirection = ntohl(pMsgOperate->i8WalkDirection);//add by jxu 20180828
	strncpy(stMsgOperate.i8TopQR, pMsgOperate->i8TopQR, 30);
	iAction = stMsgOperate.i16Action;
	if (iAction != ACTION_WALK)
	{
		LOG_WRN("recv action %d not supported\n", iAction);
		return -1;
	}
	if ((stMsgOperate.iSrcAction >= ACTION_TYPE_NUM) && (stMsgOperate.iSrcAction != ACTION_NONE))
	{
		LOG_WRN("recv action %d not supported\n", iAction);
		return -1;
	}
	if ((stMsgOperate.iDstAction >= ACTION_TYPE_NUM) && (stMsgOperate.iDstAction != ACTION_NONE))
	{
		LOG_WRN("recv action %d not supported\n", iAction);
		return -1;
	}

#if(DEBUG_AGV == TRUE)
	int iMsgtype = ntohs(pMsgOperate->stMsgHead.i16MsgType);
	int iSequence = ntohl(pMsgOperate->stMsgHead.i32Sequence);

	// print debug info for sending message
	LOG_DBG("deal udp msg[%d-%s] sequence=%d\n", iMsgtype, get_msg_name(iMsgtype), iSequence);
	msgv2_head_dump(pMsgBuff);
#endif
	int iCoverFlag = 0;
	if (stMsgOperate.iSrcAction != ACTION_NONE)
	{
		iAction = stMsgOperate.iSrcAction;
		iRet = msgv2_deal_basic_action(pMsgBuff, stMsgOperate.iSrcAction, stMsgOperate.iSrcTurnAngle, &bNeedSendFinish, iCoverFlag);
		if (iRet != OK)
		{
			msgv2_deal_action_result(iRet, bNeedSendFinish, stMsgOperate.iSrcAction);
			return iRet;
		}
		
	}
	if (stMsgOperate.iDstAction != ACTION_NONE)
	{
		if (0 != stMsgOperate.i16TotalLength)
		{
			iRet = msgv2_deal_basic_action(pMsgBuff, ACTION_WALK, 0, &bNeedSendFinish, iCoverFlag);
			if (iRet != OK)
			{
				msgv2_deal_action_result(iRet, bNeedSendFinish, iAction);
				return iRet;
			}
		}
		
		iRet = msgv2_deal_basic_action(pMsgBuff, stMsgOperate.iDstAction, stMsgOperate.iDstTurnAngle, &bNeedSendFinish, iCoverFlag);
		if (iRet != OK)
		{
			msgv2_deal_action_result(iRet, bNeedSendFinish, stMsgOperate.iDstAction);
			return iRet;
		}
		iAction = stMsgOperate.iDstAction;
		bNeedSendFinish = TRUE;
	}
	else
	{
		if (0 != stMsgOperate.i16TotalLength)
		{
			iRet = msgv2_deal_basic_action(pMsgBuff, ACTION_WALK, 0, &bNeedSendFinish, iCoverFlag);
			iAction = ACTION_WALK;
			bNeedSendFinish = TRUE;
		}
			
	}
	bNeedSendFinish = TRUE;
	msgv2_deal_action_result(iRet, bNeedSendFinish, iAction);

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv2_deal_advanced_operate
* Description	     : parse advance operate msg to can msg,by tiger
* input			     : pMsg: the operate msg.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_deal_advanced_operate_optimize(const char * pMsgBuff)
{
	msgv2_operate_advanced_t stMsgOperate = { 0 };
	msgv2_operate_advanced_t * pMsgOperate = (msgv2_operate_advanced_t *)pMsgBuff;
	int iRet = 0;
	bool bNeedSendFinish = false;
	int iAction = 0;
	int iSync = 1;	//TODO:compute sync by pallet status
	static int s_i16PreTotalLength = 0;
	if (NULL == pMsgOperate) {
		return -1;
	}
	//my_printf("the ntohs(pMsgOperate->i16TurnAngle) :%d\n", ntohs(pMsgOperate->i16TurnAngle));
	stMsgOperate.i16Action = ntohs(pMsgOperate->i16Action);
	stMsgOperate.i16TotalLength = ntohs(pMsgOperate->i16TotalLength);
	stMsgOperate.i16StepLength = ntohs(pMsgOperate->i16StepLength);
	stMsgOperate.i16WeightLevel = ntohs(pMsgOperate->i16WeightLevel);
	stMsgOperate.i16Speed = ntohs(pMsgOperate->i16Speed);
	stMsgOperate.iSrcAction = ntohs(pMsgOperate->iSrcAction);
	stMsgOperate.iDstAction = ntohs(pMsgOperate->iDstAction);
	stMsgOperate.iSrcTurnAngle = ntohs(pMsgOperate->iSrcTurnAngle);
	stMsgOperate.iDstTurnAngle = ntohs(pMsgOperate->iDstTurnAngle);
	stMsgOperate.iTaskPalletDirect = pMsgOperate->iTaskPalletDirect;
	stMsgOperate.i8WalkDirection = ntohl(pMsgOperate->i8WalkDirection);//add by jxu 20180828
	strncpy(stMsgOperate.i8TopQR, pMsgOperate->i8TopQR, 30);
	iAction = stMsgOperate.i16Action;
	if (iAction != ACTION_WALK)
	{
		LOG_WRN("recv action %d not supported\n", iAction);
		return -1;
	}
	if ((stMsgOperate.iSrcAction >= ACTION_TYPE_NUM) && (stMsgOperate.iSrcAction != ACTION_NONE))
	{
		LOG_WRN("recv action %d not supported\n", iAction);
		return -1;
	}
	if ((stMsgOperate.iDstAction >= ACTION_TYPE_NUM) && (stMsgOperate.iDstAction != ACTION_NONE))
	{
		LOG_WRN("recv action %d not supported\n", iAction);
		return -1;
	}

#if(DEBUG_AGV == TRUE)
	int iMsgtype = ntohs(pMsgOperate->stMsgHead.i16MsgType);
	int iSequence = ntohl(pMsgOperate->stMsgHead.i32Sequence);

	// print debug info for sending message
	LOG_DBG("deal udp msg[%d-%s] sequence=%d\n", iMsgtype, get_msg_name(iMsgtype), iSequence);
	msgv2_head_dump(pMsgBuff);
#endif
	task_type_t enActionTab[3] = { stMsgOperate.iSrcAction, ACTION_WALK, stMsgOperate.iDstAction };
	short i16TurnAngle[3] = { stMsgOperate.iSrcTurnAngle, 0, stMsgOperate.iDstTurnAngle };
	int iCoverFlag = 0,i = 0;
	for (i = 0; i < 3; i++)
	{
		if (enActionTab[i] == ACTION_NONE || ((ACTION_WALK == enActionTab[i]) && (0 == stMsgOperate.i16TotalLength)))
			continue;
		iRet = msgv2_deal_basic_action(pMsgBuff, enActionTab[i], i16TurnAngle[i], &bNeedSendFinish, iCoverFlag);
		if (iRet != OK)
		{
			LOG_INF("failed excute %s from advanced operate\n", get_action_name(enActionTab[i]));
			break;
		}
		if (true ==g_stAgvTask.iWalkContinue)
		{
			LOG_INF("receive walk continue agent cmd \n");
			return iRet;
		}
		iAction = enActionTab[i];
	}
	msgv2_deal_action_result(iRet, TRUE, iAction);
	return 0;
}

/*******************************************************************************
* Function Name		 : parse_operate_msg
* Description	     : parse the operate msg.
* input			     : pMsgHead: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv2_parse_operate(const char * pMsgBuff, int iMsgSize)
{
	msgv2_operate_t * pMsgOperate = (msgv2_operate_t *)pMsgBuff;
	int iRet = 0;

	if (pMsgOperate == NULL)
		return -1;

	int iMsgtype = ntohs(pMsgOperate->stMsgHead.i16MsgType);
	int iAction = ntohs(pMsgOperate->i16Action);
	int iTokenNum = ntohl(pMsgOperate->stMsgHead.i32TokenNum);

	LOG_DBG("\n");
	LOG_DBG(">>>>>>>>>>>>>>>>>>>>>>>>>>>task process start...\n");

	LOG_INF("recv udp msg[%d-%s]'action[%d-%s]\n",
		iMsgtype, get_msg_name(iMsgtype),
		iAction, get_action_name(iAction));

	///by tiger.40 reset the value for break the walk function wait walk finish signal
	if ((ACTION_WALK == iAction) && (agv_walk == g_stAgvAttr.iMoveStatus))
	{
		g_stAgvTask.iWalkContinue = TRUE;
	}
	///end tiger.40

	if (ACTION_SET_ZONE == iAction)
	{
		LOG_WRN("recieve operate msg,but action=[%d-%s]\n", iAction, get_action_name(iAction));
		return 0;
	}

	iRet = linkqueue_append(g_stAgvParm.pUdpRxQueue, (const void *)pMsgBuff, iMsgSize);	// save to list
	if (iRet < 0)
	{
		LOG_ERR("append msg to udp rx queue failure\n");
		return iRet;
	}

	return 0;
}
/*******************************************************************************
* Function Name		 : msgv2_parse_advanced_operate
* Description	     : parse the operate msg.
* input			     : pMsgHead: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv2_parse_advanced_operate(const char * pMsgBuff, int iMsgSize)
{
	msgv2_operate_advanced_t * pMsgOperate = (msgv2_operate_advanced_t *)pMsgBuff;
	int iRet = 0;

	if (pMsgOperate == NULL)
		return -1;

	int iMsgtype = ntohs(pMsgOperate->stMsgHead.i16MsgType);
	int iAction = ntohs(pMsgOperate->i16Action);
	int iTokenNum = ntohl(pMsgOperate->stMsgHead.i32TokenNum);
	int iSrcAction = ntohs(pMsgOperate->iSrcAction);

	LOG_DBG("\n");
	LOG_DBG(">>>>>>>>>>>>>>>>>>>>>>>>>>>task process start...\n");

	LOG_INF("recv udp msg[%d-%s]'action[%d-%s]\n",
		iMsgtype, get_msg_name(iMsgtype),
		iAction, get_action_name(iAction));

	///by tiger.40 reset the value for break the walk function wait walk finish signal
	if ((ACTION_WALK == iAction) && (ACTION_NONE == iSrcAction) && (agv_walk == g_stAgvAttr.iMoveStatus))
	{
		g_stAgvTask.iWalkContinue = TRUE;
	}
	///end tiger.40

	if (ACTION_SET_ZONE == iAction)
	{
		LOG_WRN("recieve operate msg,but action=[%d-%s]\n", iAction, get_action_name(iAction));
		return 0;
	}

	iRet = linkqueue_append(g_stAgvParm.pUdpRxQueue, (const void *)pMsgBuff, iMsgSize);	// save to list
	if (iRet < 0)
	{
		LOG_ERR("append msg to udp rx queue failure\n");
		return iRet;
	}

	return 0;
}
/*******************************************************************************
* Function Name		 : parse_debug_msg
* Description	     : parse the debug msg.
* input			     : pMsgHead: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv2_parse_debug(const char * pMsgBuff, int iMsgSize)
{
	msgv2_debug_t *pMsgDebug = (msgv2_debug_t *)pMsgBuff;
	enum_debug_cmd eCmd = -1;
	int iTokenNum = 0;
	int iRet = 0;
	int i32Parameter = 0;
	i8 i8TopQRTable[32] = { 0 };
	int iErrorCode = -1;
	if (pMsgDebug == NULL)
		return -1;

	eCmd = (enum_debug_cmd)ntohl(pMsgDebug->i32Command);
	iTokenNum = ntohl(pMsgDebug->stMsgHead.i32TokenNum);
	i32Parameter = ntohl(pMsgDebug->i32Parameter);

	//TODO: check TokenNum is valid
	iRet = msgv2_tokennum_is_valid(iTokenNum);
	if (iRet < 0)
		return -1;

	switch (eCmd)
	{
	case DEBUG_REBOOT:		
		reboot_agv();
		break;
	case DEBUG_PALLET_CLASP:
		//LOG_INF("deal with pallet clasp cmd\n");
		clasp_pallet();
		//set_flag(DEV_TC, VAR_PALLET_CLASP, 1);  //1 clasp
		break;
	case DEBUG_PALLET_UNCLASP:
		//LOG_INF("deal with pallet unclasp cmd\n");
		//set_flag(DEV_TC, VAR_PALLET_CLASP, 0);//0 unclasp
		unclasp_pallet();
		break;
	case DEBUG_WHEEL_CLASP:
		clasp_wheel();
		//LOG_INF("deal with wheel clasp cmd\n");
		//set_flag(DEV_MC, VAR_WHEEL_CLASP, 1);//1 clasp
		break;
	case DEBUG_WHEEL_UNCLASP:
		unclasp_wheel();
		//LOG_INF("deal with wheel unclasp cmd\n");
		//set_flag(DEV_MC, VAR_WHEEL_CLASP, 0); //0 unclasp
		break;
		///sync console time,start by tiger.16
	case DEBUG_AGV_SYNC_TIME:
		//start ,by tiger.72
		iRet = sync_agent_time(ntohl(pMsgDebug->i32Parameter));
		if (iRet < 0)
			LOG_WRN("sync agent time failed\n");
		else 
			LOG_INF("success sync console time\n");
		//start ,by tiger.72
		if ((g_stAgvAttr.iDSPGeneration <= GENERATION_2P0) && (g_stAgvAttr.iDSPGeneration > GENERATION_1P0))
		{
			iRet = sync_time_to_mc();
			if (iRet < 0)
				LOG_WRN("sync time to mc failure\n");
			else
				LOG_INF("sync time to mc success\n");
		
		}

		break;
		///sync console time,end by tiger.16
	case DEBUG_CHECK_GROUNDDIRECT:
		g_stAgvAttr.bCheckGroundDir = true;
		//just for save log,start by tiger
		iErrorCode = NO_EVENT_ERR;
		iRet = linkqueue_append(g_stAgvParm.pErrorRxQueue, &iErrorCode, sizeof(int));	// save to list
		if (iRet < 0)
		{
			LOG_ERR("append msg to Error RX queue failure\n");
		}
		//just for save log,start by tiger
		LOG_INF("enable check ground direction function\n");
		break;
	case DEBUG_UNCHECK_GROUNDDIRECT:
		g_stAgvAttr.bCheckGroundDir = false;
		LOG_INF("disable check ground direction function\n");
		break;
	case DEBUG_AGV_TC_RISE:
		snprintf(i8TopQRTable, sizeof(i8TopQRTable), "%d", i32Parameter);
		iRet = tc_rise(WEIGHT_LEVEL_15, i8TopQRTable);
		if (OK == iRet )
			LOG_INF("success excute rise pallet by debug\n");
		else
			LOG_INF("failed excute rise pallet by debug\n");		
		break;
	case DEBUG_AGV_TC_LAY:
		snprintf(i8TopQRTable, sizeof(i8TopQRTable), "%d", i32Parameter);
		iRet = tc_lay(WEIGHT_LEVEL_15, i8TopQRTable);
		if (OK == iRet)
			LOG_INF("success excute lay pallet by debug\n");
		else
			LOG_INF("failed excute lay pallet by debug\n");
		break;
	case DEBUG_AGV_GET_LOG:
		//just for save log,start by tiger.105
		iErrorCode = NO_EVENT_ERR;
		iRet = linkqueue_append(g_stAgvParm.pErrorRxQueue, &iErrorCode, sizeof(int));	// save to list
		if (iRet < 0)
		{
			LOG_ERR("append msg to Error RX queue failure\n");
		}
		//just for save log,start by tiger.105
		LOG_INF("recv get log cmd\n");
		break;
	default:
		LOG_ERR("unknown debug command[%d]\n", eCmd);
		break;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv2_get_msgtype
* Description	     : get msg type from msg buffer.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv2_get_msgtype(const char * pMsgBuff, int iMsgSize)
{
	msgv2_head_t *pMsgHead = (msgv2_head_t *)pMsgBuff;
	int iMsgType = (int)ntohs(pMsgHead->i16MsgType);

	return iMsgType;
}

/*******************************************************************************
* Function Name		 : msgv2_get_sequence
* Description	     : get sequence from msg buffer.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv2_get_sequence(const char * pMsgBuff, int iMsgSize)
{
	msgv2_head_t *pMsgHead = (msgv2_head_t *)pMsgBuff;
	int iSequence = ntohl(pMsgHead->i32Sequence);

	return iSequence;
}

/*******************************************************************************
* Function Name		 : msgv2_get_tokennum
* Description	     : get tokennum from msg buffer.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv2_get_tokennum(const char * pMsgBuff, int iMsgSize)
{
	msgv2_head_t *pMsgHead = (msgv2_head_t *)pMsgBuff;
	int iTokenNum = ntohl(pMsgHead->i32TokenNum);

	return iTokenNum;
}
/*******************************************************************************
*Function Name    :deal_rw_param_result
*Description      :  
*Input       	  :int iRet:such as :1002,3004  
*Output 		  :
*Return           :void  
*******************************************************************************/
static void deal_rw_param_result(int iRet)
{
	int iErrorCode = abs(iRet);
	switch (iRet)
	{
	case 0:
		LOG_INF("read/write param success\n");
		break;
	case  -1:
		LOG_ERR("send read/write param CAN frame failure\n");
	case  -EVENT_ERR_MC_TIMEOUT:
		LOG_ERR("MC excute  read/write param timeout\n");
		// when exception happen, will be cause timeout
		// in this case, no need send event to console
		if (MC_ERROR_BASE != atomic_read(&g_stAgvAttr.iException))//by tiger.67
			break;
	case -EVENT_ERR_TC_TIMEOUT:
		LOG_ERR("TC excute read/write param timeout\n");

		// when exception happen, will be cause timeout
		// in this case, no need send event to console
		if (TC_ERROR_BASE != atomic_read(&g_stAgvAttr.iException))//by tiger.67
			break;
	default:		
		LOG_INF("send read/write param timeout error to agent\n");
		if (send_error_msg(EVENT_TYPE_ERROR, iErrorCode) < 0)
		{
			LOG_ERR("append error msg[%d-%s] to udp tx queue failure\n",
				iErrorCode, get_err_str(iErrorCode));
		}
		else
		{
			LOG_INF("append error msg[%d-%s] to udp tx queue success\n",
				iErrorCode, get_err_str(iErrorCode));
		}
		break;
	}
}

/*******************************************************************************
* Function Name		 : msgv2_send_param
* Description	     : send param msg to console.
* input			     : iLocation : the location value
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv2_send_param(const char * pMsgBuff)
{
	int iRet = 0;

	msgv2_set_param_ack_t *pMsgParam = (msgv2_set_param_ack_t *)pMsgBuff;

	iRet = send_msg2console(pMsgParam, sizeof(msgv2_set_param_ack_t));
	if (iRet < 0) {
		LOG_WRN("append param ack msg to udp tx queue failure\n");
		return iRet;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv2_parse_get_param
* Description	     : parse the get param.
* input			     : pMsgHead: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv2_parse_get_param(const char * pMsgBuff, int iMsgSize)
{
	msgv2_get_param_t stMsgParamReq = { 0 };
	msgv2_get_param_ack_t stMsgParamAck = { 0 };
	int iMsgtype = 0;
	int iSequence = 0;
	int iParamID = 0;
	int iParamValue = 0;
	int iTokenNum = 0;
	int iAgvName = 0;
	int iRet = 0;
	agv_sem_t *pAgvSem = NULL;

	if (pMsgBuff == NULL)
		return -1;

	if (sizeof(stMsgParamReq) >= iMsgSize)
	{
		memcpy(&stMsgParamReq, pMsgBuff, iMsgSize);
	}
	else
	{
		LOG_WRN("sizeof(stMsgParamReq)[%dB] < iMsgSize[%dB] when memcpy",
			sizeof(stMsgParamReq), iMsgSize);
	}

	iMsgtype = ntohl(stMsgParamReq.stMsgHead.i16MsgType);
	iSequence = ntohl(stMsgParamReq.stMsgHead.i32Sequence);
	iAgvName = ntohl(stMsgParamReq.stMsgHead.i32AgvNo);
	iParamID = ntohl(stMsgParamReq.i32ParamID);
	iTokenNum = ntohl(stMsgParamReq.stMsgHead.i32TokenNum);

	iRet = msgv2_tokennum_is_valid(iTokenNum);
	if (iRet < 0)
		return -1;
	
	
#if(DEBUG_AGV == TRUE)
	// print get param info for sending message
	LOG_DBG("recv udp msg[%d-%s] sequence=%d\n",
		iMsgtype, get_msg_name(iMsgtype), iSequence);
	msgv2_head_dump(pMsgBuff);
#endif
	if (255 == iParamID)
	{	
		stMsgParamAck.i32Value = htonl((int)(g_stAgvAttr.bCheckGroundDir*PRECISION));
	}
	else
	{
		pAgvSem = agv_sem_add(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_READ_V2_PARAM, iParamID);
		if (NULL == pAgvSem)
		{
			LOG_ERR("add get param sem failed\n");
		}

		iRet = get_param(DEV_MC, (u8)iParamID);
		if (iRet < 0) {
			LOG_WRN("get param from device[%d]'paramid=%d failure\n", DEV_MC, iParamID);
			return -1;
		}

		iRet = agv_sem_wait(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_READ_V2_PARAM, iParamID, TIME_OUT_8S);
		if (iRet < 0)
		{
			LOG_WRN("get param time out\n");
			return -EVENT_ERR_MC_TIMEOUT;
		}
		agv_sem_clean(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_READ_V2_PARAM, iParamID);
		stMsgParamAck.i32Value = htonl((int)(g_stAgvAttr.stMcPropertyPram.value * PRECISION));
	}
	

	stMsgParamAck.stMsgHead = stMsgParamReq.stMsgHead;
	stMsgParamAck.i32ParamID = htonl(iParamID);

	iRet = msgv2_send_param((const char *)&stMsgParamAck);
	if (iRet < 0 )
	{
		LOG_INF("send get param ack failed\n");
	}

	return iRet;
}
#define MAXLINE 100

/*******************************************************************************
* Function Name		 : msgv2_parse_set_param
* Description	     : parse the set param.
* input			     : pMsgHead: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv2_parse_set_param(const char * pMsgBuff, int iMsgSize)
{
	msgv2_set_param_t stMsgParamReq = { 0 };
	msgv2_set_param_ack_t stMsgParamAck = { 0 };
	int iMsgtype = 0;
	int iSequence = 0;
	int iParamID = 0;
	float fParamValue = 0;
	int iTokenNum = 0;
	int iAgvName = 0;
	int iRet = 0;
	agv_sem_t *pAgvSem = NULL;

	if (pMsgBuff == NULL)
		return -1;

	if (sizeof(stMsgParamReq) >= iMsgSize)
	{
		memcpy(&stMsgParamReq, pMsgBuff, iMsgSize);
	}
	else
	{
		LOG_WRN("sizeof(stMsgParamReq)[%dB] < iMsgSize[%dB] when memcpy",
			sizeof(stMsgParamReq), iMsgSize);
	}

	iMsgtype = ntohl(stMsgParamReq.stMsgHead.i16MsgType);
	iSequence = ntohl(stMsgParamReq.stMsgHead.i32Sequence);
	iAgvName = ntohl(stMsgParamReq.stMsgHead.i32AgvNo);
	iParamID = ntohl(stMsgParamReq.i32ParamID);
	int iTmp = ntohl(stMsgParamReq.i32Value);
	int iParamValue = ntohl(stMsgParamReq.i32Value);
	fParamValue = (float)iParamValue / PRECISION;

	// modified by kedong 20180209
	// ((float)(ntohl(stMsgParamReq.iParamValue))) / PRECISION not equal int iParamValue
	//fParamValue = ((float)(ntohl(stMsgParamReq.iParamValue))) / PRECISION;
	iTokenNum = ntohl(stMsgParamReq.stMsgHead.i32TokenNum);
	iRet = msgv2_tokennum_is_valid(iTokenNum);
	if (iRet < 0)
		return -1;

#if(DEBUG_AGV == TRUE)
	// print get param info for sending message
	LOG_DBG("recv udp msg[%d-%s] sequence=%d\n",
		iMsgtype, get_msg_name(iMsgtype), iSequence);
	msgv2_head_dump(pMsgBuff);
#endif
	if (255 == iParamID)
	{
		g_stAgvAttr.bCheckGroundDir = (int)fParamValue;
		stMsgParamAck.i32Value = htonl((int)(g_stAgvAttr.bCheckGroundDir*PRECISION));
	}
	else
	{
		pAgvSem = agv_sem_add(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_SET_V2_PARAM, iParamID);
		if (NULL == pAgvSem)
		{
			LOG_ERR("add get param sem failed\n");
		}

		iRet = set_param(DEV_MC, (u8)iParamID, fParamValue);
		if (iRet < 0) {
			LOG_WRN("get param from device[%d]'paramid=%d failure\n", DEV_MC, iParamID);
			return -EVENT_ERR_MC_TIMEOUT;;
		}

		iRet = agv_sem_wait(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_SET_V2_PARAM, iParamID, TIME_OUT_8S);
		if (iRet < 0)
		{
			LOG_WRN("get param time out\n");
		}
		agv_sem_clean(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_SET_V2_PARAM, iParamID);
		stMsgParamAck.i32Value = htonl((int)(g_stAgvAttr.stMcPropertyPram.value*PRECISION));

	}	

	stMsgParamAck.stMsgHead = stMsgParamReq.stMsgHead;
	stMsgParamAck.i32ParamID = htonl(iParamID);

	iRet = msgv2_send_param((const char *)&stMsgParamAck);
	if (iRet < 0)
	{
		LOG_INF("send get param ack failed\n");
	}

	return iRet;
}

/*******************************************************************************
*Function Name    :del_str_space
*Description      :delete all space in the str, by tiger.73
*Input       	  :char * pStr
*Output 		  :char * pStr
*Return           :NONE
*******************************************************************************/
static void del_str_space(char *pStr)
{
	int iLen, k, i;
	if (NULL == pStr)
		return;
	iLen = strlen(pStr);
	k = 0;
	for (i = 0; i < iLen; i++)
	{
		if ((pStr[i] != ' ') && (pStr[i] != '\n') && (pStr[i] != '\r'))
		{
			pStr[k] = pStr[i];
			k++;
		}
	}
	pStr[k] = '\0';
}

/*******************************************************************************
*Function Name    :msgv2_parse_get_config_req
*Description      :get config by agent cmd,add by tiger.73  
*Input       	  :const char * pMsgBuff  
*Input       	  :int iMsgSize  
*Output 		  :NONE
*Return           :int:0 if ok ,-1 on error  
*******************************************************************************/
int msgv2_parse_get_config_req(const char * pMsgBuff, int iMsgSize)
{
	msgv2_config_t *pMsgConfigReq = (msgv2_config_t *)pMsgBuff;
	msgv2_config_t stMsConfigAck = { 0 };
	int iTokenNum = 0, iRet = 0,iSize = 0;
	int iMsgtype = 0;
	int iSequence = 0;
	char *pStr = NULL;
	char pSection[100] = { 0 };
	char pKey[100] = { 0 };
	char pValue[100] = { 0 };
	char pDelimiter[100] = { 0 };
	char pReadResult[100] = { 0 };
	char pReadResultContent[1000] = { 0 };
	i16 i16DataLength = 0;
	char pAckBuf[1000] = { 0 };

	if (pMsgBuff == NULL)
		return -1;

	iMsgtype = ntohl(pMsgConfigReq->stMsgHead.i16MsgType);
	iSequence = ntohl(pMsgConfigReq->stMsgHead.i32Sequence);
#if(DEBUG_AGV == TRUE)
	// print get param info for sending message
	LOG_DBG("recv udp msg[%d-%s] sequence=%d\n",
		iMsgtype, get_msg_name(iMsgtype), iSequence);
	msgv2_head_dump(pMsgBuff);
#endif

	iTokenNum = ntohl(pMsgConfigReq->stMsgHead.i32TokenNum);
	iRet = msgv2_tokennum_is_valid(iTokenNum);
	if (iRet < 0)
		return -1;

	sprintf(pDelimiter, "\"%c\"", pMsgConfigReq->i8Delimiter);
	pStr = strtok(pMsgConfigReq->i8ContentTab, pDelimiter);//pStr = "Section.key = value"
	do
	{
		del_str_space(pStr);
		iRet = sscanf(pStr, "%[^.].%s", pSection, pKey);
		if (iRet < 0)
			continue;
		iRet = ini_read(CONFIGURE_FILE, pSection, pKey, pValue, MAXLINE);
		if (iRet < 0)
		{
			LOG_ERR("config %s failed,default value = %s\n", pStr,pValue);
		}
		else
		{
			LOG_INF("read config %s success\n", pStr);
		}		
		sprintf(pReadResult, "%s.%s = %s;", pSection, pKey, pValue);
		strcat(pReadResultContent, pReadResult);
	} while (NULL != (pStr = strtok(NULL, pDelimiter)));

	stMsConfigAck.stMsgHead = pMsgConfigReq->stMsgHead;
	int iContentLength = strlen(pReadResultContent) + 1;
	i16DataLength = iContentLength + 6;//padding 1 byte
	stMsConfigAck.stMsgHead.i16DataLength = htons(i16DataLength);
	stMsConfigAck.stMsgHead.i8Flags = (pMsgConfigReq->stMsgHead.i8Flags | BIT_ACK) &(~BIT_REQ);
	stMsConfigAck.i32Length = htonl(iContentLength);
	stMsConfigAck.i8Delimiter = pMsgConfigReq->i8Delimiter;

	iSize = i16DataLength + sizeof(stMsConfigAck.stMsgHead);

	LOG_INF("Get Config ACK size = %d sizeof = %d,content:\n", iSize,sizeof(stMsConfigAck));

	memcpy(pAckBuf, &stMsConfigAck, iSize - iContentLength);
	memcpy(pAckBuf + iSize - iContentLength, pReadResultContent, iContentLength);
	LOG_INF("%s\n", pReadResultContent);
	iRet = send_msg2console(pAckBuf, iSize);
	if (iRet < 0)
	{
		LOG_ERR("send config ack msg failure\n");
		return -1;
	}
	return 0;
}


/*******************************************************************************
*Function Name    :msgv2_parse_set_config_req
*Description      :parse config req ,by tiger.73
*Input       	  :const char * pMsgBuff
*Input       	  :int iMsgSize
*Output 		  :
*Return           :int
*******************************************************************************/
int msgv2_parse_set_config_req(const char * pMsgBuff, int iMsgSize)
{
	int iRet = 0;
	msgv2_config_t	   *pMsgConfigReq = (msgv2_config_t	   *)pMsgBuff;
	msgv2_config_ack_t stMsConfigAck = { 0 };
	int iMsgtype = 0;
	int iSequence = 0;
	int iTokenNum = 0, i32Length = 0;
	char pDelimiter[100] = { 0 };
	int i8Flags = 0;
	int iResult = -1;
	char *pStr = NULL;
	char pSection[100] = { 0 };
	char pKey[100] = { 0 };
	char pValue[100] = { 0 };

	if (pMsgBuff == NULL)
		return -1;

	iMsgtype = ntohs(pMsgConfigReq->stMsgHead.i16MsgType);
	iSequence = ntohl(pMsgConfigReq->stMsgHead.i32Sequence);
#if(DEBUG_AGV == TRUE)
	// print get param info for sending message
	LOG_DBG("recv udp msg[%d-%s] sequence=%d\n",
		iMsgtype, get_msg_name(iMsgtype), iSequence);
	msgv2_head_dump(pMsgBuff);
#endif

	iTokenNum = ntohl(pMsgConfigReq->stMsgHead.i32TokenNum);
	iRet = msgv2_tokennum_is_valid(iTokenNum);
	if (iRet < 0)
		return -1;

	sprintf(pDelimiter, "\"%c\"", pMsgConfigReq->i8Delimiter);	
	pStr = strtok(pMsgConfigReq->i8ContentTab, pDelimiter);//pStr = "Section.key = value"
	do
	{
		del_str_space(pStr);
		iResult = sscanf(pStr, "%[^.].%[^=]=%s", pSection, pKey, pValue);
		if (iResult < 0)
			goto out;//failed then the result is failed
		iResult = ini_write(CONFIGURE_FILE, pSection, pKey, pValue);
		if (iResult < 0)
		{
			LOG_ERR("config %s failed:[%d-%s]", pStr, errno, strerror(errno));
			goto out;//failed then the result is failed
		}
		LOG_INF("config %s success\n", pStr);
	} while (NULL != (pStr = strtok(NULL, pDelimiter)));

out:
	if (sizeof(msgv2_head_t) <= iMsgSize)
	{
		memcpy(&stMsConfigAck.stMsgHead, pMsgBuff, sizeof(msgv2_head_t));
	}
	i8Flags = stMsConfigAck.stMsgHead.i8Flags;
	stMsConfigAck.stMsgHead.i8Flags = (i8Flags | BIT_ACK) &(~BIT_REQ);
	stMsConfigAck.stMsgHead.i16DataLength = htons(4);
	stMsConfigAck.i32Result = htonl(iResult);
	iRet = send_msg2console(&stMsConfigAck, sizeof(stMsConfigAck));
	if (iRet < 0)
	{
		LOG_ERR("send config ack msg failure\n");
		return -1;
	}
	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv2_recv
* Description	     : msg v2 recv process msg.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv2_recv(const char * pMsgBuff, int iMsgSize)
{
	msgv2_head_t *pMsgHead = (msgv2_head_t *)pMsgBuff;
	msgv2_head_t stMsgHead = { 0 };
	int iRet = 0;

	// Case1:recv udp msg from server failure
	if ((pMsgBuff == NULL) || (iMsgSize <= 0)) {
		return -1;
	}

	stMsgHead.i16MsgType = ntohs(pMsgHead->i16MsgType);
	stMsgHead.i32AgvNo = ntohl(pMsgHead->i32AgvNo);
	stMsgHead.i32TokenNum = ntohl(pMsgHead->i32TokenNum);
	stMsgHead.i32Sequence = ntohl(pMsgHead->i32Sequence);
	stMsgHead.i8ProtoVer = pMsgHead->i8ProtoVer;
	stMsgHead.i8Flags = pMsgHead->i8Flags;
	stMsgHead.i16DataLength = ntohs(pMsgHead->i16DataLength);
	stMsgHead.i32TaskID = htonl(g_stAgvTask.i32TaskID),

	// Case2:udp msg is invalid:sequence and tokenNum
	iRet = msgv2_is_valid(pMsgBuff, iMsgSize);
	if (iRet < 0)
		return -1;

	switch (stMsgHead.i16MsgType)
	{
	case MSG_TYPE_ADVANCE_OPERATE:	//REQ
		//add by jxu 20180828-begin
		iRet = msgv2_send_advanced_ack(pMsgBuff);
		msgv2_parse_advanced_operate(pMsgBuff, iMsgSize);
		break;
		//add by jxu 20180828-end
	case MSG_TYPE_OPERATE:			//REQ
		msgv2_send_ack(pMsgBuff);
		msgv2_parse_operate(pMsgBuff, iMsgSize);
		break;
	case MSG_TYPE_DEBUG:			//REQ
		//msgv2_send_ack(pMsgBuff);
		msgv2_parse_debug(pMsgBuff, iMsgSize);
		break;
	case MSG_TYPE_GET_PARAM:			//REQ
		iRet = msgv2_parse_get_param(pMsgBuff, iMsgSize);
		deal_rw_param_result(iRet);
		break;
	case MSG_TYPE_SET_PARAM:			//REQ
		iRet = msgv2_parse_set_param(pMsgBuff, iMsgSize);
		deal_rw_param_result(iRet);
		break;
	case MSG_TYPE_SET_CONFIG:
		msgv2_parse_set_config_req(pMsgBuff, iMsgSize);
		break;
	case MSG_TYPE_GET_CONFIG:
		msgv2_parse_get_config_req(pMsgBuff, iMsgSize);
		break;
	case MSG_TYPE_REGISTER:			//ACK
	case MSG_TYPE_UNREGISTER:		//ACK
	case MSG_TYPE_HEARTBEAT:		//ACK
	case MSG_TYPE_EVENT:			//ACK
	case MSG_TYPE_EVENT_RELEASE:	//ACK
	case MSG_TYPE_FINISH:			//ACK
	case MSG_TYPE_POINT:			//ACK
	case MSG_TYPE_CONFIRM:			//ACK
	default:
		msgv2_deal_ack(pMsgBuff, iMsgSize);
		break;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv2_deal
* Description	     : msg v2 deal process msg.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv2_deal(const char * pMsgBuff, int iMsgSize)
{
	const msgv2_head_t *pMsgHead = (const msgv2_head_t *)pMsgBuff;
	msgv2_head_t stMsgHead = { 0 };
	int iRet = 0;

	// Case1:recv udp msg from server failure
	if ((pMsgBuff == NULL) || (iMsgSize <= 0)) {
		return -1;
	}

	stMsgHead.i16MsgType = ntohs(pMsgHead->i16MsgType);
	stMsgHead.i32AgvNo = ntohl(pMsgHead->i32AgvNo);
	stMsgHead.i32TokenNum = ntohl(pMsgHead->i32TokenNum);
	stMsgHead.i32Sequence = ntohl(pMsgHead->i32Sequence);
	stMsgHead.i8ProtoVer = pMsgHead->i8ProtoVer;
	stMsgHead.i8Flags = pMsgHead->i8Flags;
	stMsgHead.i16DataLength = ntohs(pMsgHead->i16DataLength);

#if(DEBUG_AGV == TRUE)
	// print debug info for sending message
	msgv2_head_dump(pMsgBuff);
#endif
	switch (stMsgHead.i16MsgType)
	{
	case MSG_TYPE_OPERATE:
		//msgv2_send_confirm(stMsgHead.i16MsgType, stMsgHead.i32Sequence);//add by jxu 20180828-remove the confirm msg
		msgv2_deal_operate(pMsgBuff);
		break;
	//add by jxu 20180828-begin
	case MSG_TYPE_ADVANCE_OPERATE:
		//msgv2_deal_advanced_operate(pMsgBuff);
		msgv2_deal_advanced_operate_optimize(pMsgBuff);
		break;
	//add by jxu 20180828-end
	default:
		LOG_WRN("unknown msg type[%d]\n", stMsgHead.i16MsgType);
		break;
	}

	return 0;
}
