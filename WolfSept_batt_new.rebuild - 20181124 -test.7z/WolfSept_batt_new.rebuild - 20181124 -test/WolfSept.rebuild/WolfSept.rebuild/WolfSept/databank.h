#ifndef DATABANK_H
#define DATABANK_H

#ifdef __cplusplus
extern "C" {
#endif

#include "globaldefine.h"

extern snake_camera_angle CAMERA_ANGLE; // 摄像头与AGV正向的夹角

extern int IMG_WIDTH;  // 宽度
extern int IMG_HEIGHT; // 高度

/// 上方摄像头安装误差，以车头为X正方向建立右手系为参考系
extern float CAMERA_POS_X;
extern float CAMERA_POS_Y;
/// 逆时针为正，范围是[-pi,pi]
extern float CAMERA_POS_THETA;

/* 数据源相关 */
extern uint8_t *grayImageData;     // 原始灰度图像
extern uint8_t *binaryImageData;   // 二值化后图像
extern snake_point *tempDataPool;  // 存储旋转后图像的数据池，后续旋转操作可能并不需要对所有的数据进行旋转


/* 特征圆检测相关 */
extern  uint8_t  detectedRingsNum;

extern  snake_detectedRing detectedRings[MAX_RING_NUM];

extern int g_iPatternIdxArray[MAX_RING_NUM];

extern snake_mapPose mapPose;

extern snake_rigidTransModel rigidTransModel;   //  刚体变换模型




/* 码图解码相关 */
extern snake_pointf infoZeroPoint;
extern snake_infoMatrix infoMatrix[INFO_MATRIX_ROW][INFO_MATRIX_COLUMN]; // 存储信息矩阵数据
extern snake_infoMatrix codeIdxMatrix[INFO_MATRIX_ROW+2];

// 输出接口
extern snake_infoOutput infoOutput;

extern int g_decodeRet[STANDARD_RING_MAX_NUM];

extern int g_realMapIdx[STANDARD_RING_MAX_NUM];

// monitor
extern snake_monitor monitor;

// 记录解码的错误信息
extern snake_decode_error decode_error[NUM_OF_DATAWORDS];


#ifdef __cplusplus
}
#endif

#endif // DATABANK_H
