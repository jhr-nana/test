#ifndef _UDP_MSG_V2_H__
#define _UDP_MSG_V2_H__

#include "global_var.h"
#include "udp_msg.h"

#ifdef MSG_TYPE_V2P0
#define BIT_ACK		0
#define BIT_REQ		1
#define BIT_FIN		2
#define BIT_MODE	7

typedef struct msgv2_head
{
	i16	i16MsgType;
	i16 i16Reserve;
	i32	i32TokenNum;
	i32	i32Sequence;
	i32 i32TaskID;
	i8	i8ProtoVer;
	i8	i8Flags;
	i16	i16DataLength;
	i32	i32AgvNo;
} msgv2_head_t;

typedef struct msgv2_ack
{
	msgv2_head_t stMsgHead;
} msgv2_ack_t;

// MSG_TYPE=1, MSG_TYPE_REGISTER, REQ
typedef struct msgv2_register_req
{
	msgv2_head_t stMsgHead;
	
	i32	i32MMVerDate;
	i32	i32MCVerDate;
	i32	i32TCVerDate;
	i32	i32VehStatus;
	i64	i64Location;	
	i8 i8VehHeadDirect;
	i8 i8PalletDirect;
	i8 i8PalletStatus;
	i8 i8ChargingMethod;
	i8 i8VehSN[32];
	i8 i8VehType[32];
	i8 i8BootMethod;
	i8 i8Reserved;
	i16 i16Reserved;
}__attribute__((packed)) msgv2_register_req_t ;

// MSG_TYPE=1, MSG_TYPE_REGISTER, ACK
typedef struct msgv2_register_ack
{
	msgv2_head_t stMsgHead;
	
	i16	i16MMRegResult;
} msgv2_register_ack_t;

// MSG_TYPE=2, MSG_TYPE_UNREGISTER, REQ
typedef struct msgv2_unregister
{
	msgv2_head_t stMsgHead;

	i32	i32VehStatus;
	i64	i64Location;
	i8 i8VehHeadDirect;
	i8 i8PalletDirect;
} msgv2_unregister_t;

// MSG_TYPE=2, MSG_TYPE_UNREGISTER, ACK
typedef struct msgv2_unregister_ack
{
	msgv2_head_t stMsgHead;
	
	i32	i32MMRegResult;
} msgv2_unregister_ack_t;

// MSG_TYPE=7, MSG_TYPE_HEARTBEAT, REQ
typedef struct msgv2_heartbeart
{
	msgv2_head_t stMsgHead;
	
	i64	i64Location;
	i16	i16Speed;
	i16 i16VehMoveStatus;
	i16 i16Temperature;
	i8 i8VehHeadDirect;
	i8 i8PalletDirect;
	i8 i8Battery;
	i8 i8VehAttitude;
} msgv2_heartbeat_t;
typedef enum
{
	DEFAULT_LEVEL = 0,
	FATAL_LEVEL = 1,
	SERIOUS_LEVEL = 2,
	SLIGHT_LEVEL = 3,
	TIPS_LEVEL = 4
}event_level_enum;
// MSG_TYPE=13, MSG_TYPE_EVENT, REQ
typedef struct msgv2_event
{
	msgv2_head_t stMsgHead;

	i64	i64Location;
	i8  i8VehHeadDirect;
	i8  i8PalletDirect;
	i16	i16EventType;
	i32	i32ErrorCode;
	i32 i32SubErrorCode;
	i8  i8ErrorDescTab[128];
	i8  i8DateTimeTab[24];
	i8 i8ProductTypeTab[8];
	i8 i8ModuleTypeTab[8];
	i16 i16EventLevel;
	i16 i16ManualTreatment;

	i32	i32GXOffset;
	i32	i32GYOffset;
	i32	i32GAngleOffset;
	i32	i32TXOffset;
	i32	i32TYOffset;
	i32	i32TAngleOffset;
} msgv2_event_t;

// MSG_TYPE=13, MSG_TYPE_EVENT, ACK
typedef struct msgv2_event_ack
{
	msgv2_head_t stMsgHead;
} msgv2_event_ack_t;

// MSG_TYPE=14, MSG_TYPE_EVENT_RELEASE, REQ
typedef struct msgv2_event_release
{
	msgv2_head_t stMsgHead;
	
	i64	i64Location;
	i16	i16EventType;
	i16	i16ErrorCode;
} msgv2_event_release_t;

// MSG_TYPE=14, MSG_TYPE_EVENT_RELEASE, ACK
typedef struct msgv2_event_release_ack
{
	msgv2_head_t stMsgHead;
} msgv2_event_release_ack_t;

// MSG_TYPE=19, MSG_TYPE_OPERATE, REQ
typedef struct msgv2_operate
{
	msgv2_head_t stMsgHead;

	i64	i64SrcLocation;
	i64	i64DstLocation;
	i16	i16Action;
	i16	i16WeightLevel;
	i16	i16Speed;
	i16	i16StepLength;
	i16	i16TotalLength;
	i16 i16TurnAngle;
	i16 i16iTaskPalletDirect;
	i8  i8WalkDirection;//add by jxu 20180828
	i8 i8TopQR[32];
} msgv2_operate_t;

// MSG_TYPE=19, MSG_TYPE_OPERATE, ACK
typedef struct msgv2_operate_ack
{
	msgv2_head_t stMsgHead;
} msgv2_operate_ack_t;
//add by jxu 20180828-begin
// MSG_TYPE=19, MSG_TYPE_OPERATE, REQ
typedef struct msgv2_operate_advanced
{
	msgv2_head_t stMsgHead;

	i64 i64SrcLocation;
	i64 i64DstLocation;
	i16	i16Action;
	i16	i16WeightLevel;
	i16	i16Speed;
	i16	i16StepLength;	
	i16	i16TotalLength;
	i16 iSrcAction;
	i16 iDstAction;
	i16  iSrcTurnAngle;
	i16  iDstTurnAngle;
	i8  iTaskPalletDirect;
	i8  i8WalkDirection;
	//i16 iCoverFlag;
	i8 i8TopQR[32];
} msgv2_operate_advanced_t;

// MSG_TYPE=19, MSG_TYPE_OPERATE, ACK
typedef struct msgv2_operate_advanced_ack
{
	msgv2_head_t stMsgHead;
	//i16 iCoverFlag;
} msgv2_operate_advanced_ack_t;
//add by jxu 20180828-end

// MSG_TYPE=20, MSG_TYPE_COMPLETE, REQ
typedef struct msgv2_finish
{
	msgv2_head_t stMsgHead;

	i64	i64Location;
	i8 i8VehHeadDirect;
	i8 i8PalletDirect;
	i16	i16Action;	
} msgv2_finish_t;

// MSG_TYPE=20, MSG_TYPE_COMPLETE, ACK
typedef struct msgv2_finish_ack
{
	msgv2_head_t stMsgHead;
} msgv2_finish_ack_t;

// MSG_TYPE=23, MSG_TYPE_POINT, REQ
typedef struct msgv2_point
{
	msgv2_head_t stMsgHead;

	i64	i64Location;
	i8 i8VehHeadDirect;
	i8 i8PalletDirect;
	i16	i16DriverMode;
} msgv2_point_t;

// MSG_TYPE=23, MSG_TYPE_POINT, ACK
typedef struct msgv2_point_ack
{
	msgv2_head_t stMsgHead;
} msgv2_point_ack_t;

// MSG_TYPE=24, MSG_TYPE_CONFIRM, REQ
typedef struct msgv2_confirm
{
	msgv2_head_t stMsgHead;

	i32	i32ComfirmMsgType;
	i32	i32ComfirmSequence;
} msgv2_confirm_t;

// MSG_TYPE=24, MSG_TYPE_CONFIRM, ACK
typedef struct msgv2_confirm_ack
{
	msgv2_head_t stMsgHead;
} msgv2_confirm_ack_t;

// MSG_TYPE=25, MSG_TYPE_DEBUG, REQ
typedef struct msgv2_debug
{
	msgv2_head_t stMsgHead;
	
	i32 i32Command;
	i32 i32Parameter;
} msgv2_debug_t;

// MSG_TYPE=26, MSG_TYPE_INFO, REQ
typedef struct msgv2_info {
	msgv2_head_t stMsgHead;
	i16 i16InfoType;
	i16 i16InfoSize;
} msgv2_info_t;

#define TYPE_BATT_INFO		0
#define TYPE_SCAN_INFO		1
#define TYPE_OFFSET_INFO	2

// MSG_TYPE=26, MSG_TYPE_INFO, REQ
typedef struct msgv2_batt_info {
	msgv2_head_t stMsgHead;

	i16 i16InfoType;
	i16 i16InfoSize;	
	i32 i32BattTemperature;
	i32 i32Battery;
} msgv2_batt_info_t;

// MSG_TYPE=26, MSG_TYPE_INFO, REQ
typedef struct msgv2_scan_info {
	msgv2_head_t stMsgHead;
	i16 i16InfoType;
	i16 i16InfoSize;
	
	i32 i32SucScanCount;
	i32 i32NOScanCount;
	i32 i32ScanErrCount;
} msgv2_scan_info_t;

// MSG_TYPE=26, MSG_TYPE_INFO, REQ
typedef struct msgv2_offset_info {
	msgv2_head_t stMsgHead;

	i64	i64Location;
	i16 i16InfoType;
	i16 i16InfoSize;
	i8 i8VehHeadDirect;
	i8 i8PalletDirect;
	i16	i16Action;
	i32	i32GXOffset;
	i32	i32GYOffset;
	i32	i32GAngleOffset;
	i32	i32TXOffset;
	i32	i32TYOffset;
	i32	i32TAngleOffset;
} msgv2_offset_info_t;

// MSG_TYPE=27, MSG_TYPE_UPDATE, REQ
typedef struct msgv2_update {
	msgv2_head_t stMsgHead;

	i8 i8ExpectVerDate[64];
} msgv2_update_t;

// MSG_TYPE=27, MSG_TYPE_UPDATE, ACK
typedef struct msgv2_update_ack {
	msgv2_head_t stMsgHead;
} msgv2_update_ack_t;

// MSG_TYPE=28, MSG_TYPE_UPDATE_RESULT, REQ
typedef struct msgv2_update_result {
	msgv2_head_t stMsgHead;

	i32	i32MMVerDate;
	i32	i32MMVerStatus;
	i32	i32MCVerDate;
	i32	i32MCVerStatus;
	i32	i32TCVerDate;
	i32	i32TCVerStatus;
} msgv2_update_result_t;

// MSG_TYPE=28, MSG_TYPE_UPDATE_RESULT, ACK
typedef struct msgv2_update_result_ack {
	msgv2_head_t stMsgHead;
} msgv2_update_result_ack_t;

// MSG_TYPE=31&32, MSG_TYPE_SET/GET_CONFIG, REQ
typedef struct msgv2_config {
	msgv2_head_t stMsgHead;

	i32	i32Length;
	i8	i8Delimiter;
	i8	i8ContentTab[];
} msgv2_config_t;

// MSG_TYPE=31&32, MSG_TYPE_SET/GET_CONFIG, ACK
typedef struct msgv2_config_ack {
	msgv2_head_t stMsgHead;

	i32 i32Result;
} msgv2_config_ack_t;




// MSG_TYPE=2000, MSG_TYPE_GET_PARAM, REQ
typedef struct msgv2_get_param {
	msgv2_head_t stMsgHead;

	i32 i32ParamID;
} msgv2_get_param_t;

// MSG_TYPE=2000, MSG_TYPE_GET_PARAM, ACK
typedef struct msgv2_get_param_ack {
	msgv2_head_t stMsgHead;

	i32 i32ParamID;
	i32 i32Value;
} msgv2_get_param_ack_t;

// MSG_TYPE=2001, MSG_TYPE_SET_PARAM, REQ
typedef struct msgv2_set_param {
	msgv2_head_t stMsgHead;

	i32 i32ParamID;
	i32 i32Value;
} msgv2_set_param_t;

// MSG_TYPE=2001, MSG_TYPE_SET_PARAM, ACK
typedef struct msgv2_set_param_ack {
	msgv2_head_t stMsgHead;

	i32 i32ParamID;
	i32 i32Value;
} msgv2_set_param_ack_t;
#define PRECISION   100000
extern int msgv2_head_dump(const char * pMsgBuff);
extern int msgv2_tokennum_is_valid(int iTokenNum);
extern int msgv2_is_valid(const char * pMsgBuff, int iMsgSize);
extern int msgv2_agv_register();
extern int msgv2_deal_ack(const char * pMsgBuff, int iMsgSize);
extern int msgv2_send_heartbeat();
extern int msgv2_send_event(int iEventType, int iErrorCode);
extern int msgv2_send_event_release(int iEventType, int iErrorCode);
extern int msgv2_send_finish(int iAction);
extern int msgv2_send_point(int iLocation, int iDriverMode);
extern int msgv2_send_error_point(int iErrorCode);
extern int msgv2_send_confirm(int iType, int iSeq);
extern int msgv2_send_ack(const char * pMsgBuff);
extern int msgv2_send_batt_info();
extern int msgv2_send_scan_info();
extern int msgv2_send_offset_info();
extern int msgv2_dump_walk_path(const char * pMsgBuff);
extern int msgv2_check_walk_path(const char * pMsgBuff);
extern int msgv2_deal_action_result(int iRet, bool bNeedSendFinish, int iAction);
extern int msgv2_deal_operate(const char * pMsgBuff);
extern int msgv2_parse_operate(const char * pMsgBuff, int iMsgSize);
extern int msgv2_parse_debug(const char * pMsgBuff, int iMsgSize);

extern int msgv2_get_msgtype(const char * pMsgBuff, int iMsgSize);
extern int msgv2_get_sequence(const char * pMsgBuff, int iMsgSize);
extern int msgv2_get_tokennum(const char * pMsgBuff, int iMsgSize);

extern int msgv2_recv(const char * pMsgBuff, int iMsgSize);
extern int msgv2_deal(const char * pMsgBuff, int iMsgSize);

#endif	//MSG_TYPE_V2P0

#endif/*_UDP_MSG_V2_H__*/
