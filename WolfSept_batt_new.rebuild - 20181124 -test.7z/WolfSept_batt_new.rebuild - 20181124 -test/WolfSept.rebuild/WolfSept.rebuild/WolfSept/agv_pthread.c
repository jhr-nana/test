/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* FileName:AGV_PTHREAD.H
* Author: Menghu Wang   Version: V1.0   Data:2017-07-13
* Description:REALIZE THE INTERFACE OF AGV PTHREAD FUNCTION
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/


/* Includes ------------------------------------------------------------------*/
#include "global_var.h"
#include "udp_msg.h"
#include "device.h"
#include "netstat.h"
#include "sem.h"
#include "ftp.h"
#include "ota_mc.h"
#include "statistical_info.h"
#include "dev_battery.h"
#include "dev_battery_anshang.h"
#include "dev_battery_songxia.h"
#include "debug.h"

//BMS MACRO
#define INQUIRE_PERIOD_SECONDS		1 
#define BATTERY_CHARGE_SOC_100		100 //by tiger.83
#define BATTERY_CHARGE_SOC_70		70 //by tiger.83
#define BATTERY_CHARGE_SOC_60		60 //by kedong, 20181030

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define RESEND_MAX_NUM		45
#define MINUTE_240	(4*60*60) // 240 minute = 14400s ,by tiger.31
#define MINUTE_60	(60*60) // 60 minute = 3600s ,by tiger.31
#define MINUTE_5	(5*60) // 5 minute = 300s ,by tiger.31
#define MINUTE_0P5	(30) // 30s ,by tiger.51
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/

#define NETWORK_DISCONNECT_SECONDS		60
#define WIFI_MONITOR_PERIOD_SECONDS     30

int g_iNotReport3019 = FALSE;

/*******************************************************************************
* Function Name		 : thread_wifi_monitor
* Description	     : work thread for monitor wifi
* Input 		     : pArg: the parameter of work thread
* Output		     : NONE
* Return		     : NULL
*******************************************************************************/
void * thread_wifi_monitor(void *pArg)
{
	int iRet = 0;
	int iErrCout = 0;
	int iTimerCount = 0;
	int iCurStat = 0;
	int iPreStat = 0;
	struct work_thread * pWorkThread = NULL;

	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		update_net_stat();

		iRet = check_net_stat();
		if (iRet != 0)
		{
			LOG_WRN("wifi network is disconnected\n");
			LOG_WRN("AGV'IP[%s] connect AP'SSID=%s,MAC=%s,SignalLevel=%d\n",
				g_stNetInfo.pLocalIpAddr, g_stNetInfo.pEssid, g_stNetInfo.pApAddr, g_stNetInfo.iSignalLevel);
			///network continuous is disconnected more than 1 min,then save log,start by tiger.93
			if (NETWORK_DISCONNECT_SECONDS / WIFI_MONITOR_PERIOD_SECONDS == iTimerCount)
			{
				iRet = save_log_arm(EVENT_ERR_NETWORK_DISCONNECT);
				LOG_INF("save ARM xxx.tgz log %s,when EVENT_ERR_NETWORK_DISCONNECT\n", (0 == iRet) ? "success" : "failed");
			}
			iTimerCount++;
			//end by tiger.93
		}
		else
		{
			///network recovery from disconnected state, then save log, start by tiger.93
			if (NETWORK_DISCONNECT_SECONDS / WIFI_MONITOR_PERIOD_SECONDS < iTimerCount)
			{
				iRet = save_log_arm(EVENT_ERR_NETWORK_RECOVERY);
				LOG_INF("save ARM xxx.tgz log,when EVENT_ERR_NETWORK_RECOVERY %s\n", (0 == iRet) ? "success" : "failed");
			}
			iTimerCount = 0;
			//end by tiger.93
		}
		update_net_log();

		sleep(WIFI_MONITOR_PERIOD_SECONDS);

	}

	return NULL;
}

/*******************************************************************************
* Function Name		 : thread_send_heartbeat
* Description	     : work thread for send the agv'heartbeat to console
* Input 		     : pArg: the parameter of work thread
* Output		     : NONE
* Return		     : NULL
*******************************************************************************/
void * thread_send_heartbeat(void *pArg)
{
	int iRet = 0;
	int iErrCout = 0;
	int iTimerCount = 0;
	struct work_thread * pWorkThread = NULL;

	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		iRet = send_heartbeat_msg();
		if (iRet < 0)
		{
			iErrCout++;
			if (iErrCout > 10)
			{
				LOG_WRN("send heartbeat msg failure\n");
			}
		}
		else
		{
			iErrCout = 0;
		}		 
		sleep(1);
		///send bat temperature to agent every 5 minute start by tiger.31
		iTimerCount++;
		//start,add by tiger.51
		if (iTimerCount % MINUTE_0P5 == 0)
		{
			iRet = sta_send_network_info(SATISTICAL_SEND_NOW);
			if (iRet < 0)
			{
				LOG_WRN("send statistical network info failed:[%d-%s]\n", errno, strerror(errno));
			}
		}
		//end ,add by tiger.51


		//start, add by tiger.31
		if (iTimerCount % MINUTE_5 == 0)
		{
			send_battery_info();

			//start,add by tiger.51
			iRet = sta_send_battery_info(SATISTICAL_SEND_NOW);
			if (iRet < 0)
			{
				LOG_WRN("send statistical battery info failed:[%d-%s]\n", errno, strerror(errno));
			}
		}
		//end by tiger.31


		//start, add by kedong, 2018-05-22
		if (iTimerCount % MINUTE_240 == 0)
		{
			// add by kedong 20180522
			// sync time to mc every 60 minute
			if ((g_stAgvAttr.iDSPGeneration <= GENERATION_2P0) && (g_stAgvAttr.iDSPGeneration > GENERATION_1P0))
			{
				iRet = sync_time_to_mc();
				if (iRet < 0)
					LOG_WRN("sync time to mc failure\n");
				else
					LOG_INF("sync time to mc success\n");
			}
		}
		//end by kedong, 2018-05-22
	}

	return NULL;
}

/*******************************************************************************
* Function Name		 : thread_send_udp
* Description	     : work thread for send the udp message to console
* Input 		     : pArg: the parameter of work thread
* Output		     : NONE
* Return		     : NULL
*******************************************************************************/
void * thread_send_udp(void *pArg)
{
	int iRet = 0;
	int iMsgSize = 0;
	char pMsgBuff[UDP_MSG_SIZE] = {0};
	int iIsSend = FALSE;
	struct work_thread * pWorkThread = NULL;

	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		if ( FALSE == iIsSend)
		{
			bzero(pMsgBuff, sizeof(pMsgBuff));
			if ((iMsgSize = linkqueue_retrieve(g_stAgvParm.pUdpTxQueue, pMsgBuff)) > 0)
			{
				iIsSend = TRUE;
#if(DEBUG_AGV == TRUE)
				// print debug info for sending message
				LOG_DBG("send msg to console[%s:%d]\n", g_stAgvParm.cServerIp, g_stAgvParm.iMsgSendServerPort);
				msg_dump((const char *)pMsgBuff, iMsgSize);
#endif
			}
			else
			{
				usleep(CYCLE_TIME * 1000);//100ms
			}
		}

		if (TRUE == iIsSend) // some data is sending 
		{
			iRet = msg_send(pMsgBuff, iMsgSize);
			if (iRet < 0) {
				usleep(100000); //100ms
				continue;
			}

			iIsSend = FALSE;
		}
	}

	return NULL;
}


/*******************************************************************************
* Function Name		 : thread_recv_udp
* Description	     : work thread for recv the udp message from console
* Input 		     : pArg: the parameter of work thread
* Output		     : NONE
* Return		     : NULL
*******************************************************************************/
void * thread_recv_udp(void *pArg)
{
	char pMsgBuff[UDP_MSG_SIZE] = {0};
	int iMsgSize = 0;
	int iRet = 0;
	struct work_thread * pWorkThread = NULL;

	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		bzero(pMsgBuff, sizeof(pMsgBuff));
		iMsgSize = recv_udp(g_stAgvParm.iMsgSocketFd, pMsgBuff, UDP_MSG_SIZE, TRUE);
		if (iMsgSize <= 0) {
			usleep(100000); //100ms
			continue;
		}

		iRet = msg_recv(pMsgBuff, iMsgSize);
		if (iRet < 0)
		{
			LOG_INF("recv with the udp package failed\n");
		}
	}

	return NULL;
}


/*******************************************************************************
*Function Name    :deal_immediate_can_msg
*Description      :  
*Input       	  :struct can_frame * pCanFrame  
*Output 		  :
*Return           :void  
*******************************************************************************/
void deal_immediate_can_msg(struct can_frame *pCanFrame)
{	
	int iRet = 0;

	//LOG_INF("control can recv [0x%x-%s]\n", 
	//	pCanFrame->can_id, get_can_desc(pCanFrame->can_id));

	switch (pCanFrame->can_id)
	{
	case TC_CANID_ACK:
		deal_tc_ack(pCanFrame);
		break;
	case TC_CANID_ERR:
		iRet = deal_tc_exception(pCanFrame);
		// modified by kedong, 20180301
		// when (pCanFrame == NULL), iRet = -1
		// iRet == -1, cannot send error msg 
		if (iRet < -1)
		{
			if (send_error_msg(EVENT_TYPE_ERROR, iRet)<0)
			{
				LOG_ERR("append %s to udp Tx queue failed\n",get_err_str(abs(iRet)));
			}
		}
		break;
	case MC_CANID_ACK:
		deal_mc_ack(pCanFrame);
		break;
	case MC_CANID_HEART:
		iRet = deal_mc_heartbeat(pCanFrame);
		// modified by kedong, 20180301
		// when (pCanFrame == NULL), iRet = -1
		// iRet == -1, cannot send error msg 
		if (iRet < -1)
		{
			if (send_error_msg(EVENT_TYPE_ERROR, abs(iRet)) < 0)
			{
				LOG_ERR("append %s to udp Tx queue failed\n", get_err_str(abs(iRet)));
			}
		}
		break;
	case PGV_CANID_TxPDO1:
		parse_Y_offset(pCanFrame);
		break;
	case PGV_CANID_TxPDO2:
		parse_X_offset(pCanFrame);
		break;
	case PGV_CANID_TxPDO3:
		// modified by kedong 20180209
		// PGV will send two can frame
		// the first can frame maybe is invalid, the second will be valid
		// when is invalid QR, no need send offset statistic info to console
		iRet = parse_groudqr(pCanFrame);
		if (iRet < 0)
			break;

		//add by kedong 20180207:add the curve statistic begin
		if (TRUE == g_stAgvConf.cDebugEnable)
		{
			LOG_INF("recv can frame[0x388-PGV_CANID_TxPDO3]\n");
			print_can_frame(pCanFrame);

			send_offset_statistic_msg(-1); 
		}
		//add by kedong 20180207:add the curve statistic end

		break;
	case PGV_CAN_TESTACK:
		parse_pgv_heartbeart(pCanFrame->data[0]);
		break;
	case ARM2TC_ANGLE_ACK:
		deal_tc_angle_ack(pCanFrame);
		break;
	case TC_2MC_FINISH:
		LOG_INF("Receive %s CAN Frame\n", get_can_desc(TC_2MC_FINISH));
		print_can_frame(pCanFrame);
		break;
	case FTP_TC_UPLOAD_CANID:
		deal_tc_upload(pCanFrame);
		break;
	case FTP_MC_UPLOAD_CANID:
		deal_mc_upload(pCanFrame);
		break;
	case TEST_CANID:
		LOG_INF("control can recv test canid[0x%x]\n", pCanFrame->can_id);
		break;
	default:
		LOG_WRN("control can recv unkonwn canid[0x%x]\n", pCanFrame->can_id);
		break;
	}
}

/*******************************************************************************
*Function Name    :deal_process_can_msg
*Description      :  
*Input       	  :struct can_frame * pCanFrame  
*Output 		  :
*Return           :int  0:the msg can be deal ;else -1
*******************************************************************************/
int deal_process_can_msg(struct can_frame *pCanFrame)
{
	int iRet = -1;

	if ((TC_CANID_FINISH == pCanFrame->can_id) || (MC_CANID_FINISH == pCanFrame->can_id))
	{
		iRet = linkqueue_append(g_stAgvParm.pCanRxQueue, pCanFrame, sizeof(struct can_frame));	// save to list
		if (iRet < -1)
		{
			LOG_ERR("append msg to can RX queue failure\n");
		}
		return 0;
	}

	return -1;
}
/*******************************************************************************
*Function Name    :deal_immediate_can_v2_msg
*Description      :
*Input       	  :struct can_frame * pCanFrame
*Output 		  :
*Return           :void
*******************************************************************************/
void deal_immediate_can_v2_msg(struct can_frame *pCanFrame)
{
	int iRet = 0;

	switch (pCanFrame->can_id)
	{
	case MC_CAN_ACK_V2_CANID:
		deal_mc_v2_ack(pCanFrame);
		break;
	case MC_CAN_FLAG_PARAM_ACK_V2_CANID:
		deal_mc_rw_flag_param_v2_ack(pCanFrame);
		break;
	case TP_CAN_ANGLEACK_V2_CANID:
		deal_mc_angle_v2_ack(pCanFrame);
		break;
	case MC_CAN_HEARTBEAT_V2_CANID:
		deal_mc_heartbeat_v2(pCanFrame);
		break;
	case PGV_CANID_TxPDO1:
		parse_Y_offset(pCanFrame);
		break;
	case PGV_CANID_TxPDO2:
		parse_X_offset(pCanFrame);
		break;
	case PGV_CANID_TxPDO3:
		// modified by kedong 20180209
		// PGV will send two can frame
		// the first can frame maybe is invalid, the second will be valid
		// when is invalid QR, no need send offset statistic info to console
		iRet = parse_groudqr(pCanFrame);
		if (iRet < 0)
			break;

		//add by kedong 20180207:add the curve statistic begin
		if (TRUE == g_stAgvConf.cDebugEnable)
		{
			LOG_INF("recv can frame[0x388-PGV_CANID_TxPDO3]\n");
			print_can_frame(pCanFrame);

			send_offset_statistic_msg(-1); 
		}
		//add by kedong 20180207:add the curve statistic end

		break;
	case PGV_CAN_TESTACK:
		parse_pgv_heartbeart(pCanFrame->data[0]);
		break;
	case MC_CAN_ERR_V2_CANID:
		iRet = deal_mc_exception(pCanFrame);
		// modified by kedong, 20180301
		// when (pCanFrame == NULL), iRet = -1
		// iRet == -1, cannot send error msg 
		if (iRet < -1)
		{
			if ((iRet == -EVENT_ERR_AGVSAFE) || (iRet == -EVENT_ERR_NOCONTACTIMPACT))
			{
				int iErrorCode = abs(iRet);
				LOG_INF("append error point msg[%d-%s] to udp tx queue\n", abs(iRet), get_err_str(abs(iRet)));
				if (send_error_point_msg(iErrorCode) < 0)
				{
					LOG_ERR("append error point msg[%d-%s] to udp tx queue failed\n", abs(iRet), get_err_str(abs(iRet)));
				}
			}
			else
			{
				LOG_INF("append error msg[%d-%s] to udp tx queue\n", abs(iRet), get_err_str(abs(iRet)));
				if (send_error_msg_suberror(EVENT_TYPE_ERROR, iRet, g_stAgvAttr.iServoSubErr) <0)//add by jxu 20180511
				{
					LOG_ERR("append error msg[%d-%s] to udp tx queue failed\n", abs(iRet), get_err_str(abs(iRet)));
				}
			}			
		}
		break;
	case TEST_CANID:
		LOG_INF("control can recv test canid[0x%x]\n", pCanFrame->can_id);
		break;
	default:
		LOG_WRN("control can recv unkonwn canid[0x%x]\n", pCanFrame->can_id);
		break;
	}
}

/*******************************************************************************
*Function Name    :deal_process_can_v2_msg
*Description      :
*Input       	  :struct can_frame * pCanFrame
*Output 		  :
*Return           :int  0:the msg can be deal ;else -1
*******************************************************************************/
int deal_process_can_v2_msg(struct can_frame *pCanFrame)
{
	int iRet = -1;

	if (MC_CAN_FINISH_V2_CANID == pCanFrame->can_id)
	{
		iRet = linkqueue_append(g_stAgvParm.pCanRxQueue, pCanFrame, sizeof(struct can_frame));	// save to list
		if (iRet < -1)
		{
			LOG_ERR("append msg to can RX queue failure\n");
		}
		return 0;
	}

	return -1;
}

/*******************************************************************************
* Function Name		 : thread_recv_can0
* Description	     : work thread for recv the can frame from can bus 0
* Input 		     : pArg: the parameter of work thread
* Output		     : NONE
* Return		     : NULL
*******************************************************************************/
#define MC_HEARTBEAT_TIMEOUT	60*1000	// 60s
void * thread_recv_can0(void * pArg)
{
	int iRet = -1;
	struct can_frame stCtrlCanData = {0};
	struct work_thread * pWorkThread = NULL;
	u32 u32RecvCountTest = 0;
	u32 u32RecvCountFail = 0;
	u32 u32RecvCountSucc = 0;
	u32 u32RecvCountAll = 0;

	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		// add by kedong, 20180224
		// monitor thread_recv_can0 running status: 
		// 1) thread cycle running times
		// 2) recv can frame success times and failure times
		// 3) monitor thread_recv_can0 is alive?
		// 4) evaluate the performance of processing each can frame
		u32RecvCountAll++;
		if (u32RecvCountAll % 50000 == 0)
		{
			LOG_INF("thread is alive, recv [Test/Nomal:%8d/%8d]can frames in [%10d]times\n",
				u32RecvCountTest, u32RecvCountSucc, u32RecvCountAll);

			// add by kedong, 20180301
			// monitor mc'heartbeat, 
			// will reset mc when no mc'heartbeat a long time
			u64	u64CurTimeStampMs = 0;
			u64	u64TmpTimeStampMs = 0;
			get_current_timestamp_ms(&u64CurTimeStampMs);

			u64TmpTimeStampMs = u64CurTimeStampMs - g_stMcDev.iMcHeartBeatTs;
			if (u64TmpTimeStampMs >= MC_HEARTBEAT_TIMEOUT)
			{
				LOG_WRN("recv mc'heartbeat timeout[%lld >= %d ms]\n", 
					u64TmpTimeStampMs, MC_HEARTBEAT_TIMEOUT);
			}
		}

		// no need memset stCtrlCanData, because if iRet < 0, will not continue
		// memset(&stCtrlCanData, 0, sizeof(struct can_frame));
		iRet = recv_can(CTRL_CAN_DEV, &stCtrlCanData);
		if (iRet < 0) {
			u32RecvCountFail++;

			// modified by kedong, 20180224
			// cannot sleep too long, may loss can frame when sleep
			usleep(1000);
			continue;
		}

		u32RecvCountSucc++;
		if (TEST_CANID == stCtrlCanData.can_id)
			u32RecvCountTest++;

		// can_recv ok
		// add by jxu 20180115:recv the can and deal the can msg begin
		int iGeneration = g_stMcDev.iGeneration;
		if ((iGeneration <= GENERATION_1P0) && (iGeneration != GENERATION_ERR))
		{
			if (deal_process_can_msg(&stCtrlCanData) != 0)
			{
				deal_immediate_can_msg(&stCtrlCanData);
			}
		}
		else if ((iGeneration <= GENERATION_2P0) && (iGeneration > GENERATION_1P0))
		{

			//if ((stCtrlCanData.can_id == MC_CAN_ACK_V2_CANID) || (stCtrlCanData.can_id == MC_CAN_FINISH_V2_CANID)
			//	|| (stCtrlCanData.can_id == MC_CAN_FLAG_PARAM_REQ_V2_CANID) || (stCtrlCanData.can_id == MC_CAN_FLAG_PARAM_ACK_V2_CANID)
			//	|| (stCtrlCanData.can_id == TP_CAN_ANGLEACK_V2_CANID)|| (stCtrlCanData.can_id == MC_CAN_ERR_V2_CANID))
			//{
			//	LOG_INF("recv can frame[0x%x-%s]\n", stCtrlCanData.can_id, get_can_desc(stCtrlCanData.can_id));
			//	print_can_frame(&stCtrlCanData);
			//}

			if (deal_process_can_v2_msg(&stCtrlCanData) != 0)
			{
				deal_immediate_can_v2_msg(&stCtrlCanData);
			}
		}
		// add by jxu 20180115:recv the can and deal the can msg end
	}

	return NULL;
}

/*******************************************************************************
* Function Name		 : thread_proc_can0
* Description	     : work thread for process the can frame from can bus 0
* Input 		     : pArg: the parameter of work thread
* Output		     : NONE
* Return		     : NULL
*******************************************************************************/
void * thread_proc_can0(void * pArg)
{
	int iRet = -1;
	struct can_frame stCtrlCanData = { 0 };
	struct work_thread * pWorkThread = NULL;
	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		iRet = linkqueue_retrieve(g_stAgvParm.pCanRxQueue, &stCtrlCanData);
		if (iRet <= 0) 
		{
			usleep(CYCLE_TIME * 1000); //100ms
			continue;
		}
		//add by jxu 20180117: begin
		int iGeneration = g_stMcDev.iGeneration;
		if ((iGeneration <= GENERATION_1P0) && (iGeneration != GENERATION_ERR))
		{
			switch (stCtrlCanData.can_id)
			{
			case TC_CANID_FINISH:
				deal_tc_completion(&stCtrlCanData);
				break;
			case MC_CANID_FINISH:
				deal_mc_completion(&stCtrlCanData);
				break;
			default:
				LOG_WRN("control can recv unkonwn canid[0x%x]\n", stCtrlCanData.can_id);
				break;
			}
		}
		else if ((iGeneration <= GENERATION_2P0) && (iGeneration > GENERATION_1P0))
		{
			switch (stCtrlCanData.can_id)
			{
			case MC_CAN_FINISH_V2_CANID:
				deal_mc_completion(&stCtrlCanData);
				break;
			default:
				LOG_WRN("control can recv unkonwn canid[0x%x]\n", stCtrlCanData.can_id);
				break;
			}
		}
		//add by jxu 20180117: end
	}

	return NULL;
}

void * thread_stop_car(void * pArg)
{
	int iRet = -1;
	int iErrorCode = 0;
	agv_sem_t *pAgvSem = NULL;
	
	struct work_thread * pWorkThread = NULL;
	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	pAgvSem = agv_sem_add(SEM_MSG_TYPE, MSG_TYPE_STOP, STOP_AGV_SEM_SEQ);
	if (NULL == pAgvSem)
	{
		LOG_ERR("add sem failed\n");
	}
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		iRet = agv_sem_wait(SEM_MSG_TYPE, MSG_TYPE_STOP, STOP_AGV_SEM_SEQ, TIME_OUT_60S);
		if (iRet < 0)
			continue;

		iRet= stop_agv(DEV_MC);
		if(iRet < 0)
		{
			LOG_ERR("stop agv failed,error code = %d\n",iRet);
		}

	}
	return NULL;
}


/*******************************************************************************
*Function Name    :thread_save_error_log
*Description      :just for save master log and Tc/Mc log  
*Input       	  :void * pArg  
*Output 		  :NONE
*Return           :void *  
*******************************************************************************/
void * thread_save_error_log(void * pArg)
{
	int iRet = -1;
	int iErrorCode = 0;
	int iCount = 0;
	struct work_thread * pWorkThread = NULL;
	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		iRet = linkqueue_retrieve(g_stAgvParm.pErrorRxQueue, &iErrorCode);
		if (iRet <= 0) 
		{
			usleep(CYCLE_TIME * 1000); //100ms
			continue;
		}

		if ((EVENT_ERR_TPERR != iErrorCode) && (EVENT_ERR_AGVSAFE != iErrorCode) 
			&& (EVENT_ERR_NOCONTACTIMPACT != iErrorCode))//tiger.21
		{
			///add network station ,by tiger.09
			LOG_ERR("save log for error[%d-%s]\n", iErrorCode, get_err_str(iErrorCode));
			LOG_ERR("****************************************\n");
			///end,by tiger.09
			iRet = save_log_arm(iErrorCode);
			LOG_INF("save ARM xxx.tgz log %s\n", (0 == iRet) ? "success" : "failed");
		}
		iCount = 0;
		while ((iCount < 2) && (upload_log() != 0))
		{
			sleep(1); // 1s
			iCount++; // update 2 times if upload failed
		}

		//add by jxu 20180126begin
		if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
		{
			if ((EVENT_ERR_TPERR != iErrorCode) && (EVENT_ERR_AGVSAFE != iErrorCode)
				&& (EVENT_ERR_NOCONTACTIMPACT != iErrorCode))//tiger.21
			{
				iRet = save_log_dsp(iErrorCode);
				LOG_INF("save DSP xxx.tgz log %s\n", (0 == iRet) ? "success" : "failed");
			}			
		}
		//add by jxu 20180126 end
	}

	return NULL;
}

/*******************************************************************************
* Function Name		 : thread_recv_can1
* Description	     : work thread for recv the can frame from can bus 1
*                    : BaudRate:5000bps
*                    : battery\pgv on the bus
* Input 		     : pArg: the parameter of work thread
* Output		     : NONE
* Return		     : NULL
*******************************************************************************/
void * thread_recv_can1(void * pArg)
{
	int iRet = -1;
	struct can_frame stCtrlCanData = { 0 };
	struct work_thread * pWorkThread = NULL;
	u32 u32RecvCountTest = 0;
	u32 u32RecvCountFail = 0;
	u32 u32RecvCountSucc = 0;
	u32 u32RecvCountAll = 0;


	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	LOG_INF("thread[%d-%-25s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		//// ����������Ӳ������δ��ɵ������, ���߳̿�ת�ȴ�
		//if (pWorkThread->iThreadState == ThreadInitial)
		//{
		//	usleep(1000000);			// 1000ms
		//	continue;
		//}

		// add by kedong, 20180224
		// monitor thread_recv_can running status: 
		// 1) thread cycle running times
		// 2) recv can frame success times and failure times
		// 3) monitor thread_recv_can is alive?
		// 4) evaluate the performance of processing each can frame
		u32RecvCountAll++;
		if (u32RecvCountAll % 50000 == 0)
		{
			LOG_INF("thread is alive, recv [Test/Nomal:%8d/%8d]can frames in [%10d]times\n",
				u32RecvCountTest, u32RecvCountSucc, u32RecvCountAll);

			// add by kedong, 20180301
			// monitor mc'heartbeat, 
			// will reset mc when no mc'heartbeat a long time
			i64	i64CurTimeStampMs = 0;
			i64	i64TmpTimeStampMs = 0;
			get_current_timestamp_ms(&i64CurTimeStampMs);

			i64TmpTimeStampMs = i64CurTimeStampMs - i64TmpTimeStampMs;
		}

		// no need memset stCtrlCanData, because if iRet < 0, will not continue
		// memset(&stCtrlCanData, 0, sizeof(struct can_frame));
		iRet = recv_can(CAN1, &stCtrlCanData);
		if (iRet < 0) {
			u32RecvCountFail++;

			// modified by kedong, 20180224
			// cannot sleep too long, may loss can frame when sleep
			usleep(1000);
			continue;
		}

		u32RecvCountSucc++;
		if (TEST_CANID == stCtrlCanData.can_id)
			u32RecvCountTest++;

		// ͨ��CAN_ID������NODE_ID
		u32 iNodeID = stCtrlCanData.can_id & 0x7F;
		switch (iNodeID)
		{
		//case NODEID_BATTERY:
		case BATT_ACK_CANID_0X19:
		case BATT_ACK_CANID_0X1C:
		case BATT_ACK_CANID_0X1D:
		case BATT_ACK_CANID:
		case BATT_ACK_CANID_0X11:
		case BATT_ACK_CANID_0X12:
		case BATT_ACK_CANID_0X13:
		case BATT_ACK_CANID_0X14:
		case BATT_ACK_CANID_0X15:
			// �洢��ص�CAN֡����
			iRet = g_stAgvAttr.bms.batt_recv_bms_info(&stCtrlCanData);
			break;
		//case NODEID_PGV:
			// ��PGV��CAN֡���д���
			iRet = PGVRxCanFrameProc(&stCtrlCanData);
			break;
		default:
			LOG_WRN("can[1] recv unkonwn nodeid[0x%x]\n", iNodeID);
			break;
		}
	}

	return NULL;
}

struct app_info
{
	char pAppPath[100];
	char PAppVersion[100];

}app_info_st;

#define MASTER_MODULE 1
int get_update_file(const char *pVersionStr)
{
	int iRet = 0;
	int iVersionLen = 0;
	char pVersion[100] = { 0 };
	char *pStr = NULL;
	char pRemotePath[100] = { 0 };
	char pFileName[100] = { 0 };
	char pZipCmd[200] = { 0 };
	int iModule = 0;
	int iGenerate = 0;
	update_method stUpdateMethod = { 0 };
	char *pPath = NULL;
	if (pVersionStr == NULL)
		return -1;
	strcpy(pVersion, pVersionStr);

	iRet = ini_read(CONFIGURE_FILE_PATH, "autoflow_conf", "update_method", stUpdateMethod.pUpdateMethod, sizeof(stUpdateMethod.pUpdateMethod));
	if (iRet < 0)
	{
		strcpy(stUpdateMethod.pUpdateMethod, "ftp");
	}

	if (strcasecmp(stUpdateMethod.pUpdateMethod, "ftp") != 0)
		return -1;

	iRet = _ftp_mc_init(CONFIGURE_FILE_PATH, &stUpdateMethod);
	if (iRet < 0)
	{
		LOG_ERR("init ftp configure failure\n");
		return iRet;
	}
	sprintf(stUpdateMethod.pDownloadDir, "%s", UPDATE_PATH);

	pStr = strtok(pVersion, "_");//such as :01D012017020114
	if (pStr == NULL)
		return -1;
	do
	{
		bzero(pRemotePath, sizeof(pRemotePath));
		bzero(pFileName, sizeof(pFileName));
		memcpy(pRemotePath, pStr, 5);
		strcat(pRemotePath, "/");
		sprintf(pFileName, "%s%s.zip", pRemotePath, pStr);
		int iRet = sscanf(pRemotePath, "%02dD%02d/", &iModule, &iGenerate);
		if (iRet < 0)
			return -1;

		sprintf(stUpdateMethod.pMasterAppName, "%s", pFileName);
		iRet = stUpdateMethod.download_file(pFileName, stUpdateMethod.pDownloadDir, &stUpdateMethod.stNetAddr, stUpdateMethod.pUserName, stUpdateMethod.pPassword, stUpdateMethod.u8ConnectTimeout);
		if (iRet < 0)
			return -1;
		pPath = strrchr(pFileName, '/');//such as :/01D01/01D012017020114
		bzero(pZipCmd, sizeof(pZipCmd));
		iRet = sprintf(pZipCmd, "unzip -qo %s%s -d %s", UPDATE_PATH, (char *)(pPath+1), (MASTER_MODULE == iModule) ? MASTER_FILE_PATH : MC_TC_FILE_PATH);
		if (iRet<0)
		{
			LOG_ERR("error:%d-%s\n", errno, strerror(errno));
		}
		if (system(pZipCmd) != 0)
			return -1;
	} while ((pStr=strtok(NULL, "_") )!= NULL);

	return 0;
}

void * thread_update_app(void * pArg) // by tiger.44
{
	int iRet = -1;
	int iErrorCode = 0;
	agv_sem_t *pAgvSem = NULL;
	
	struct work_thread * pWorkThread = NULL;
	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	pAgvSem = agv_sem_add(SEM_MSG_TYPE, MSG_TYPE_UPDATE, UPDATE_MSG_SEQ);
	if (NULL == pAgvSem)
	{
		LOG_ERR("add sem failed\n");
	}
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		iRet = agv_sem_wait(SEM_MSG_TYPE, MSG_TYPE_UPDATE, UPDATE_MSG_SEQ, TIME_OUT_60S);
		if (iRet < 0)
			continue;
		get_update_file(g_stAgvAttr.pVersion);

	}
	return NULL;
}

/*******************************************************************************
* Function Name		 : thread_proc_config
* Description	     : work thread for process the config
* Input 		     : pArg: the parameter of work thread
* Output		     : NONE
* Return		     : NULL
*******************************************************************************/
#define CFG_MSG_LEN		10
void * thread_proc_config(void *pArg)
{
	int iCfgSocket = g_stAgvParm.iCfgSocketFd;
	int flags = 0;	// or flags = MSG_DONTWAIT
	char pMsgBuff[UDP_MSG_SIZE] = { 0 };
	char pSendBuff[UDP_MSG_SIZE] = { 0 };
	int iRet = 0;
	char *pStr = NULL;
	struct work_thread * pWorkThread = NULL;

	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		struct sockaddr_in stClientAddr;
		int iLen = sizeof(stClientAddr);

		bzero(pMsgBuff, sizeof(pMsgBuff));
		iRet = recvfrom(iCfgSocket, (void *)pMsgBuff, UDP_MSG_SIZE, flags, (struct sockaddr *)&stClientAddr, (socklen_t *)&iLen);
		if (iRet < 0) {
			LOG_WRN("recv configure error:[%s]\n", strerror(errno));
			usleep(CYCLE_TIME * 1000); //100ms
			continue;
		}

		if (iRet <= CFG_MSG_LEN) {
			LOG_WRN("recv configure too short\n");
			usleep(CYCLE_TIME * 1000); //100ms
			continue;
		}

		// recv configuire msg length > CFG_MSG_LEN(10)
		LOG_INF("recv configure from[%s-%d]\n", inet_ntoa(stClientAddr.sin_addr), ntohs(stClientAddr.sin_port));
		pStr = strtok(pMsgBuff, ",");
		if (pStr != NULL)
		{
			if (strcmp(pStr, "config") == 0) //is a config cmd
			{
				char cKey[40] = { 0 };
				char cPara[40] = { 0 };
				while ((pStr = strtok(NULL, ",")) != NULL)
				{
					sscanf(pStr, "%[^=]=%[^=]", cKey, cPara); // TO DO 
					set_value(cKey, cPara, CONFIGURE_FILE);
				}
				iRet = sendto(iCfgSocket, "config=ok,", sizeof("config=ok,"), flags, (struct sockaddr *)&stClientAddr, sizeof(stClientAddr));
				if (iRet < 0)
				{
					LOG_WRN("send configure feedback error\n");
				}
			}
			else if (strcmp(pStr, "readconfig") == 0)
			{
				char buffer1[40] = { 0 };
				char buffer2[40] = { 0 };
				strcat(pSendBuff, "configback,");
				while ((pStr = strtok(NULL, ",")) != NULL)
				{
					get_value(pStr, buffer1, CONFIGURE_FILE);
					sprintf(buffer2, "%s=%s\n", pStr, buffer1);
					strcat(pSendBuff, buffer2);
				}
				iRet = sendto(iCfgSocket, pSendBuff, strlen(pSendBuff) + 1, flags, (struct sockaddr *)&stClientAddr, sizeof(stClientAddr));
				if (iRet < 0)
				{
					LOG_WRN("send configure error\n");
				}
			}
			else
			{
				LOG_WRN("recv configure unknown\n");
			}
		}
	}

	return NULL;
}

/*******************************************************************************
* Function Name		 : thread_proc_udp
* Description	     : work thread for process udp message
* Input 		     : pArg: the parameter of work thread
* Output		     : NONE
* Return		     : NULL
*******************************************************************************/
void * thread_proc_udp(void *pArg)
{
	int iMsgSize = 0;
	char pMsgBuff[UDP_MSG_SIZE] = {0};
	struct work_thread * pWorkThread = NULL;

	if (pArg == NULL) {
		return NULL;
	}

	pWorkThread = (struct work_thread *)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);
	while (pWorkThread->iThreadState != ThreadStopped)
	{
		bzero(pMsgBuff, sizeof(pMsgBuff));
		iMsgSize = linkqueue_retrieve(g_stAgvParm.pUdpRxQueue, pMsgBuff);
		if (iMsgSize <= 0) {
			usleep(CYCLE_TIME * 1000); //100ms
			continue;
		}

		msg_deal(pMsgBuff, iMsgSize);
	}

	return NULL;
}

/*******************************************************************************
* Function Name		 : thread_bms_monitor
* Description	     : battery management system thread.
* Input 		     : pArg: the parameter of work thread
* Output		     : NONE
* Return		     : NULL
*******************************************************************************/
void* thread_bms_monitor(void *pArg)
{
	int iRet = 0;
	static time_t s_iStartCalTime = 0;
	time_t iCurCalTime = 0;
	u32 uFailCount = 0;
	struct work_thread *pWorkThread = NULL;
	batt_info_t *pBattInfo = &g_stAgvAttr.bms;  //�����Ϣ����

	if (NULL == pArg)   //���������Χ�ж�
	{
		return NULL;
	}

	pWorkThread = (struct work_thread*)pArg;
	pWorkThread->iThreadState = ThreadRunning;
	LOG_INF("thread[%d-%s] start success\n", pWorkThread->iThreadId, __FUNCTION__);

	while (pWorkThread->iThreadState != ThreadStopped)
	{
		pBattInfo->uInquiryCount++;
		sleep(INQUIRE_PERIOD_SECONDS);
		iRet = g_stAgvAttr.bms.batt_inquiry_bms_info(pBattInfo);
		if (iRet < 0)
		{
			LOG_BATTERY("% dth battery inquiry bms info failed ,errorid = %d\n", pBattInfo->uInquiryCount, iRet);
			uFailCount++;
			if (uFailCount > 60)
			{
				LOG_WRN("can not inquiry battery bms info, uFailCount=%d\n", uFailCount);
				send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BATCOMMUNISTOP);    //�ϱ�4004����
			}
			continue;
		}
		uFailCount = 0;

		g_stAgvAttr.bms.batt_bms_info_exception_handle(pBattInfo);

		g_stAgvAttr.bms.batt_update_bms_info(pBattInfo);

		g_stAgvAttr.bms.batt_commit_bms_info(pBattInfo);

		time(&iCurCalTime);
		(0 == s_iStartCalTime) ? (s_iStartCalTime = iCurCalTime) : (s_iStartCalTime = s_iStartCalTime);
		if (iCurCalTime - s_iStartCalTime >= 600)
		{
			LOG_ERR("dump batt info at %d every 600s\n", iCurCalTime);
			g_stAgvAttr.bms.batt_dump_bms_info(pBattInfo);
			s_iStartCalTime = 0;
		}
	}
}

work_thread_t gWorkThread[THREAD_NUM] = {
	{ .pThreadStartRoutine = thread_wifi_monitor, .pThreadArg = NULL },
	{ .pThreadStartRoutine = thread_send_heartbeat, .pThreadArg = NULL },
	{ .pThreadStartRoutine = thread_recv_can0, .pThreadArg = NULL },//add by jxu 2080917-start the recv_can0 thread in advanced
	{ .pThreadStartRoutine = thread_recv_can1, .pThreadArg = NULL }, //add by yyf 20181120
	{ .pThreadStartRoutine = thread_send_udp, .pThreadArg = NULL },
	{ .pThreadStartRoutine = thread_proc_can0, .pThreadArg = NULL },//add by tiger
	{ .pThreadStartRoutine = thread_proc_udp, .pThreadArg = NULL },
	{ .pThreadStartRoutine = thread_bms_monitor, .pThreadArg = NULL },
	{ .pThreadStartRoutine = thread_recv_udp, .pThreadArg = NULL },
	{ .pThreadStartRoutine = thread_save_error_log, .pThreadArg = NULL },//add by tiger
	{ .pThreadStartRoutine = thread_update_app, .pThreadArg = NULL },//add by tiger.44
	{ .pThreadStartRoutine = thread_stop_car, .pThreadArg = NULL },//add by tiger.48
};

/*******************************************************************************
* Function Name		 : work_thread_destroy
* Description	     : destroy work thread, then recycling thread'resources
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int work_thread_destroy()
{
	int iCount = 0;
	int iRet = 0;

	for (iCount = 0; iCount < THREAD_NUM; iCount++)
	{
		struct work_thread * pWorkThread = &gWorkThread[iCount];

		// turn off all the work thread
		pWorkThread->iThreadState = ThreadStopped;
		if (pWorkThread->iThreadId != 0) {
			iRet = pthread_join(pWorkThread->iThreadId, NULL);  
		}
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : heartbeat_thread_create
* Description	     : create heartbeat thread
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int heartbeat_thread_create()
{
	int iCount = 0;
	int iRet = 0;

	for (iCount = 0; iCount < 2; iCount++) {
		// gWorkThread[0] == heartbeat thread
		struct work_thread * pWorkThread = &gWorkThread[iCount];

		pWorkThread->pThreadArg = (void *)pWorkThread;
		// turn on all the work thread'iThreadState => ThreadInitial
		pWorkThread->iThreadState = ThreadInitial;
		pthread_attr_init(&pWorkThread->stThreadAttr);
		pthread_attr_setscope(&pWorkThread->stThreadAttr, PTHREAD_SCOPE_SYSTEM);

		iRet = pthread_create(&pWorkThread->iThreadId, &pWorkThread->stThreadAttr,
			pWorkThread->pThreadStartRoutine, pWorkThread->pThreadArg);
		if (iRet < 0)
		{
			LOG_ERR("create the [%d]th thread failure:%s\n", iCount, strerror(errno));
		}
	}

	return iRet;
}
/*******************************************************************************
* Function Name		 : recvcan0_thread_create
* Description	     : create can recv thread
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int recvcan0_thread_create()
{
	int iCount = 2;
	int iRet = 0;

	// gWorkThread[0] == heartbeat thread
	struct work_thread * pWorkThread = &gWorkThread[iCount];

	pWorkThread->pThreadArg = (void *)pWorkThread;
	// turn on all the work thread'iThreadState => ThreadInitial
	pWorkThread->iThreadState = ThreadInitial;
	pthread_attr_init(&pWorkThread->stThreadAttr);
	pthread_attr_setscope(&pWorkThread->stThreadAttr, PTHREAD_SCOPE_SYSTEM);

	iRet = pthread_create(&pWorkThread->iThreadId, &pWorkThread->stThreadAttr,
		pWorkThread->pThreadStartRoutine, pWorkThread->pThreadArg);
	if (iRet < 0)
	{
		LOG_ERR("create the [%d]th thread failure:%s\n", iCount, strerror(errno));
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : recvcan1_thread_create
* Description	     : create can recv thread
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int recvcan1_thread_create()
{
	int iCount = 3;
	int iRet = 0;

	// gWorkThread[0] == heartbeat thread
	struct work_thread * pWorkThread = &gWorkThread[iCount];

	pWorkThread->pThreadArg = (void *)pWorkThread;
	// turn on all the work thread'iThreadState => ThreadInitial
	pWorkThread->iThreadState = ThreadInitial;
	pthread_attr_init(&pWorkThread->stThreadAttr);
	pthread_attr_setscope(&pWorkThread->stThreadAttr, PTHREAD_SCOPE_SYSTEM);

	iRet = pthread_create(&pWorkThread->iThreadId, &pWorkThread->stThreadAttr,
		pWorkThread->pThreadStartRoutine, pWorkThread->pThreadArg);
	if (iRet < 0)
	{
		LOG_ERR("create the [%d]th thread failure:%s\n", iCount, strerror(errno));
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : work_thread_create
* Description	     : create work thread
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int work_thread_create()
{
	int iCount = 4;  //modified by yyf 20181120
	int iRet = 0;

	for (iCount = 4; iCount < THREAD_NUM; iCount++)//add by jxu 20180917 modify init iCount from 2 to 3
	{
		struct work_thread * pWorkThread = &gWorkThread[iCount];

		pWorkThread->pThreadArg = (void *)pWorkThread;
		// turn on all the work thread'iThreadState => ThreadInitial
		pWorkThread->iThreadState = ThreadInitial;
		pthread_attr_init(&pWorkThread->stThreadAttr);
		pthread_attr_setscope(&pWorkThread->stThreadAttr, PTHREAD_SCOPE_SYSTEM); 
		
		iRet = pthread_create(&pWorkThread->iThreadId, &pWorkThread->stThreadAttr,
			pWorkThread->pThreadStartRoutine, pWorkThread->pThreadArg);
		if (iRet < 0)
		{
			LOG_ERR("create the [%d]th thread failure:%s\n", iCount, strerror(errno));
			goto error_0;
		}
	}

	return iRet;

error_0:
	work_thread_destroy();
	return iRet;
}

/*******************************************************************************
* Function Name      : wait_thread_ready
* Description	     : wait for all thread is inited;
* Input 		     : iTimeOut: time out, in second
* Output		     : NONE
* Return		     : 0 on ok;-1 on error
*******************************************************************************/
int wait_thread_ready(int iTimeOut)
{
	int i = 0;
	int iTryTime = 0;

	// wait for all the thread init done
	while (TRUE) {
		int iInitDoneThreadNum = 0;
		for (i = 0; i < THREAD_NUM; i++)
		{
			struct work_thread * pWorkThread = &gWorkThread[i];
			if (pWorkThread->iThreadState == ThreadRunning) {
				iInitDoneThreadNum++;
			}
		}

		// all the thread init done?
		if (iInitDoneThreadNum >= THREAD_NUM) {
			break;
		}
		else {
			iTryTime++;
			sleep(1);
		}

		// retry 20 time, return error;
		if (iTryTime >= iTimeOut) {
			LOG_WRN("maybe some thread is not running correctly\n");
			return -1;
		}
	}

	return 0;
}

/******************* (C) COPYRIGHT 2018  Jd.Com, Inc . *****END OF FILE****/