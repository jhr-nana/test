/********************************************************************************
* Copyright (c) 2020, JD.COM, Inc .
* All rights reserved.
* FileName: netstat.h
* Author: tongkedong   Version: V1.0   Data:2018-03-07
* Description:
* monitor wireless interface performance and status
********************************************************************************/
#ifndef _NETSTAT_H_
#define _NETSTAT_H_

#include "iwlib.h"

#include "global_var.h"
#include "device.h"
#include "debug.h"

extern char * get_ip_addr(char *pNetDevName);
extern int check_net_stat();
extern int update_net_stat();
extern int print_net_stat();

#endif //_NETSTAT_H_
