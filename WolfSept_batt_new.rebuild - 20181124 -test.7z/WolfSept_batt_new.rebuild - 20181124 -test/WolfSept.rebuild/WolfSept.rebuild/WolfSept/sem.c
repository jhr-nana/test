#include <semaphore.h> 

#include "global_var.h"
#include "sem.h"

agv_sem_t g_AgvSem[MAX_SEM_NUM];
static int g_iFreeSemNum = MAX_SEM_NUM;

pthread_mutex_t g_AgvSemMutex;

struct signal_t g_signal;

const char *g_pSignalName[] = {
	"SIG_SEND_ID",
	"SIG_MSG_ID",
	"SIG_CAN_ID"
};

const char *g_pSemType[] = {
	"SEM_MSG_TYPE",
	"SEM_CAN_TYPE"
};

/*******************************************************************************
* Function Name		 : add_timer_ms
* Description	     : add timer by ms.
* input			     : pOutTime: output time ,uiMs: Millisecond
* input			     : uiMs: wait time, in ms;
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void add_timer_ms(struct timespec *pOutTime, uint uiMs)
{
	struct timeval stCurTime;

	gettimeofday(&stCurTime, NULL);

	pOutTime->tv_sec = stCurTime.tv_sec;
	pOutTime->tv_nsec = stCurTime.tv_usec * 1000;

	pOutTime->tv_sec += uiMs / 1000;
	pOutTime->tv_nsec += (uiMs % 1000) * 1000 * 1000;

	pOutTime->tv_sec += pOutTime->tv_nsec / 1000 / 1000 / 1000;
	pOutTime->tv_nsec %= 1000 * 1000 * 1000;
}

/*******************************************************************************
* Function Name		 : wait_signal
* Description	     : wait signal.
* input			     : iID: signal id;
* input			     : iSignal:
* input			     : iMs: wait time, in ms; 0 ms means NONBLOCK
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int wait_signal(int iID, int iSignal, uint iMs) //TODO
{
	int iRet = 0;
	struct timespec ts = { 0 };

	if (iID >= SIGNAL_NUM)
	{
		LOG_ERR("error signal id[%d]\n", iID);
		return -1;
	}

	// sem_wait or sem_timedwait
	if (iMs == 0)
	{
		iRet = sem_wait(&g_signal.sSem[iID]);
	}
	else
	{
		add_timer_ms(&ts, iMs);
		iRet = sem_timedwait(&g_signal.sSem[iID], &ts);
	}

	// check return value
	if (iRet < 0) {
		switch (iID) {
		case SIG_SEND_ID:
		case SIG_MSG_ID:
			LOG_WRN("wait signal[%d-%s], MsgType[%d-%s] error[%d-%s]\n",
				iID, g_pSignalName[iID], iSignal, get_msg_name(iSignal), errno, strerror(errno));
			break;
		case SIG_CAN_ID:
			LOG_WRN("wait signal[%d-%s], CanDesc[%d-%s] error[%d-%s]\n",
				iID, g_pSignalName[iID], iSignal, get_can_desc(iSignal), errno, strerror(errno));
			break;
		default:
			break;
		}

		return iRet;
	}

	if (g_signal.iSignal[iID] != iSignal) {
		LOG_INF("get wrong signal [%d]\n", g_signal.iSignal[iID]); //TO DO 
		iRet = -1;
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : post_signal
* Description	     : post signal.
* input			     : iID: signal id;
* input			     : iSignal:
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int post_signal(int iID, int iSignal)
{
	int iRet = 0;

	if (iID >= SIGNAL_NUM)
	{
		LOG_ERR("error signal ID [%d]\n", iID);
		return -1;
	}
	g_signal.iSignal[iID] = iSignal;
	iRet = sem_post(&g_signal.sSem[iID]);

	return iRet;
}

/*******************************************************************************
* Function Name		 : init_signal
* Description	     : init signal.
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int init_signal()
{
	int iIndex = 0;
	int iRet = 0;

	for (iIndex = 0; iIndex < SIGNAL_NUM; iIndex++)
	{
		// pshared = 0:only shared by all thread in this pid
		iRet = sem_init(&g_signal.sSem[iIndex], 0, 0);
		if (-1 == iRet)
		{
			break;
		}
	}
	return iRet;
}

/*******************************************************************************
* Function Name		 : clean_signal
* Description	     : clean signal.
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int clean_signal(int iID)
{
	return sem_init(&g_signal.sSem[iID], 0, 0);
}

/*******************************************************************************
* Function Name		 : destroy_signal
* Description	     : destroy signal.
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int destroy_signal()
{
	int iIndex = 0;
	int iRet = 0;

	for (iIndex = 0; iIndex < SIGNAL_NUM; iIndex++)
	{
		iRet = sem_destroy(&g_signal.sSem[iIndex]);
		if (iRet < 0)
		{
			break;
		}
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : agv_sem_init
* Description	     : int semaphore for agv.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure.
*******************************************************************************/
int agv_sem_init()
{
	int iIndex = 0;
	int iRet = 0;

	for (iIndex = 0; iIndex < MAX_SEM_NUM; iIndex++)
	{
		// pshared = 0:only shared by all thread in this pid
		g_AgvSem[iIndex].iSemType = INVALID_SEM_TYPE;
		g_AgvSem[iIndex].iSemId = INVALID_SEM_ID;
		g_AgvSem[iIndex].iSequence = INVALID_SEQUENCE;

		iRet = sem_init(&g_AgvSem[iIndex].stSem, 0, 0);
		if (-1 == iRet)
		{
			LOG_WRN("g_AgvSem[%d].stSem init failure\n", iIndex);
		}
	}
	g_iFreeSemNum = MAX_SEM_NUM;
	
	// init mutex for read/write g_AgvSem[]
	pthread_mutex_init(&g_AgvSemMutex, NULL);
	
	return iRet;
}

/*******************************************************************************
* Function Name		 : agv_sem_clean
* Description	     : clean sem for agv.
* input			     : iSemType: SEM_MSG_TYPE, SEM_CAN_TYPE
* input			     : iSemId: such as MSG_TYPE_REGISTER, TC_CANID_REQ, ...
* input			     : iSequence: the sequence id of msg
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int agv_sem_clean(int iSemType, int iSemId, int iSequence)
{
	int iIndex = 0;
	int iRet = 0;
	
	for (iIndex = 0; iIndex < MAX_SEM_NUM; iIndex++) {
		if ((g_AgvSem[iIndex].iSemType == iSemType) 
			&& (g_AgvSem[iIndex].iSemId == iSemId)
			&& (g_AgvSem[iIndex].iSequence == iSequence)){
			g_AgvSem[iIndex].iSemType = INVALID_SEM_TYPE;
			g_AgvSem[iIndex].iSemId = INVALID_SEM_ID;
			g_AgvSem[iIndex].iSequence = INVALID_SEQUENCE;

			iRet = sem_init(&g_AgvSem[iIndex].stSem, 0, 0);

			g_iFreeSemNum++;

			LOG_DBG("free  sem type[%d], id[%d], seq[%d], iIndex=%d, iFreeSemNum=%d\n", 
				iSemType, iSemId, iSequence, iIndex, g_iFreeSemNum);

			return iRet;
		}
	}
	
	return 0;
}

/*******************************************************************************
* Function Name		 : agv_sem_destroy
* Description	     : destroy sem for agv.
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int agv_sem_destroy()
{
	int iIndex = 0;
	int iRet = 0;

	for (iIndex = 0; iIndex < MAX_SEM_NUM; iIndex++)
	{
		g_AgvSem[iIndex].iSemType = INVALID_SEM_TYPE;
		g_AgvSem[iIndex].iSemId = INVALID_SEM_ID;
		g_AgvSem[iIndex].iSequence = INVALID_SEQUENCE;

		iRet = sem_destroy(&g_AgvSem[iIndex].stSem);
		if (iRet < 0)
		{
			break;
		}

		g_iFreeSemNum++;
	}

	pthread_mutex_destroy(&g_AgvSemMutex);
	
	return iRet;
}

/*******************************************************************************
* Function Name		 : agv_sem_get
* Description	     : get the pointer of agv_sem_t.
* input			     : iSemType: SEM_MSG_TYPE, SEM_CAN_TYPE
* input			     : iSemId: such as MSG_TYPE_REGISTER, TC_CANID_REQ, ...
* input			     : iSequence: the sequence id of msg
* Output		     : NONE
* Return		     : NOT NULL:success; NULL:failure.
*******************************************************************************/
agv_sem_t * agv_sem_get(int iSemType, int iSemId, int iSequence)
{
	int iIndex = 0;
	agv_sem_t * pAgvSem = NULL;

	
	pthread_mutex_lock(&g_AgvSemMutex);
	for (iIndex = 0; iIndex < MAX_SEM_NUM; iIndex++) {
		if ((g_AgvSem[iIndex].iSemType == iSemType) 
			&& (g_AgvSem[iIndex].iSemId == iSemId)
			&& (g_AgvSem[iIndex].iSequence == iSequence)) {
			pAgvSem = &g_AgvSem[iIndex];
			break;
		}
	}
	pthread_mutex_unlock(&g_AgvSemMutex);

	return pAgvSem;
}

/*******************************************************************************
* Function Name		 : agv_sem_add
* Description	     : add a new sem into g_AgvSem, if ok, return the pointer of agv_sem_t.
* input			     : iSemType: SEM_MSG_TYPE, SEM_CAN_TYPE
* input			     : iSemId: such as MSG_TYPE_REGISTER, TC_CANID_REQ, ...
* input			     : iSequence: the sequence id of msg
* Output		     : NONE
* Return		     : NOT NULL:success; NULL:failure.
*******************************************************************************/
agv_sem_t * agv_sem_add(int iSemType, int iSemId, int iSequence)
{
	int iIndex = 0;
	agv_sem_t * pAgvSem = NULL;

	pAgvSem = agv_sem_get(iSemType, iSemId, iSequence);
	if (pAgvSem != NULL)
		return pAgvSem;

	// the iSemType is not exist, then add it
	pthread_mutex_lock(&g_AgvSemMutex);
	for (iIndex = 0; iIndex < MAX_SEM_NUM; iIndex++) {		
		if ((g_AgvSem[iIndex].iSemType == INVALID_SEM_TYPE) 
			&& (g_AgvSem[iIndex].iSemId == INVALID_SEM_ID)
			&& (g_AgvSem[iIndex].iSequence == INVALID_SEQUENCE)) {
			g_AgvSem[iIndex].iSemType = iSemType;
			g_AgvSem[iIndex].iSemId = iSemId;
			g_AgvSem[iIndex].iSequence = iSequence;
			pAgvSem = &g_AgvSem[iIndex];

			g_iFreeSemNum--;

			LOG_DBG("alloc sem type[%d], id[%d], seq[%d], iIndex=%d, iFreeSemNum=%d\n",
				iSemType, iSemId, iSequence, iIndex, g_iFreeSemNum);

			break;
		}
	}
	pthread_mutex_unlock(&g_AgvSemMutex);

	if (pAgvSem == NULL) {
		sleep(1);
		LOG_ERR("g_AgvSem[] is full, can't add new sem\n");
	}

	return pAgvSem;
}

/*******************************************************************************
* Function Name		 : agv_sem_wait
* Description	     : wait semaphore for agv.
* input			     : iSemType: SEM_MSG_TYPE, SEM_CAN_TYPE
* input			     : iSemId: such as MSG_TYPE_REGISTER, TC_CANID_REQ, ...
* input			     : iSequence: the sequence id of msg
* input			     : iMs: time out, in ms;
* Output		     : NONE
* Return		     : 0:success; <0:failure.
*******************************************************************************/
int agv_sem_wait(int iSemType, int iSemId, int iSequence, int iMs)
{
	int iRet = 0;
	struct timespec ts = { 0 };
	agv_sem_t * pAgvSem = agv_sem_add(iSemType, iSemId, iSequence);

	if (pAgvSem == NULL) {
		return -1;
	}

	// sem_wait or sem_timedwait
	if (iMs == 0)
	{
		iRet = sem_wait(&pAgvSem->stSem);
	}
	else
	{
		add_timer_ms(&ts, iMs);
		iRet = sem_timedwait(&pAgvSem->stSem, &ts);
	}

	// check return value
	if (iRet < 0) {
		switch (iSemType) {
		case SEM_MSG_TYPE:
			// add by kedong, 2018-05-15
			// don't print this log info:
			// [2018-05-15 14:56:46.991 WRN sem.c      402  agv_sem_wait    ] 
			// wait signal[0-SEM_MSG_TYPE] 60000ms, MsgType[28-MSG_TYPE_UPDATE_RESULT] Seq[1] Err[110-Connection timed out]
			if ((MSG_TYPE_UPDATE == iSemId) || (MSG_TYPE_STOP == iSemId))
				break;	// skip print
			else
			{
				LOG_WRN("wait signal[%d-%s] %dms, MsgType[%d-%s] Seq[%d] Err[%d-%s]\n",
					iSemType, g_pSemType[iSemType], iMs, iSemId, get_msg_name(iSemId), iSequence, errno, strerror(errno));
				break;
			}
		case SEM_CAN_TYPE:
			LOG_WRN("wait signal[%d-%s] %dms, CanDesc[%d-%s] Seq[%d] Err[%d-%s]\n",
				iSemType, g_pSemType[iSemType], iMs, iSemId, get_can_desc(iSemId), iSequence, errno, strerror(errno));
			break;
		default:
			break;
		}
	}

	return iRet;
}


/*******************************************************************************
* Function Name		 : agv_sem_post
* Description	     : post semaphore for agv.
* input			     : iSemType: SEM_MSG_TYPE, SEM_CAN_TYPE
* input			     : iSemId: such as MSG_TYPE_REGISTER, TC_CANID_REQ, ...
* input			     : iSequence: the sequence id of msg
* Output		     : NONE
* Return		     : 0:success; <0:failure.
*******************************************************************************/
int agv_sem_post(int iSemType, int iSemId, int iSequence)
{
	int iRet = 0;
	agv_sem_t * pAgvSem = agv_sem_get(iSemType, iSemId, iSequence);

	if (pAgvSem == NULL) {
		return -1;
	}

	iRet = sem_post(&pAgvSem->stSem);

	return iRet;
}

/*******************************************************************************
* Function Name		 : _sem_wait
* Description	     : wait semaphore for agv.
* input			     : pSem: the pointer of semaphore
* input			     : iMs: time out, in ms;
* Output		     : NONE
* Return		     : 0:success; <0:failure.
*******************************************************************************/
int _sem_wait(sem_t * pSem, int iMs)
{
	int iRet = 0;
	struct timespec ts = { 0 };

	if (pSem == NULL) {
		return -1;
	}

	// sem_wait or sem_timedwait
	if (iMs == 0)
	{
		iRet = sem_wait(pSem);
	}
	else
	{
		add_timer_ms(&ts, iMs);
		iRet = sem_timedwait(pSem, &ts);
	}

	return iRet;
}


/*******************************************************************************
* Function Name		 : _sem_post
* Description	     : post semaphore for agv.
* input			     : pSem: the pointer of semaphore
* Output		     : NONE
* Return		     : 0:success; <0:failure.
*******************************************************************************/
int _sem_post(sem_t * pSem)
{
	int iRet = 0;

	if (pSem == NULL) {
		return -1;
	}

	iRet = sem_post(pSem);

	return iRet;
}
