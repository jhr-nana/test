/********************************************************************************
* Copyright (C) 2025, JD.COM, Inc.
* All rights reserved.
* FileName    : dev_battery.h
* Author      : yyf   Version: V1.0   Data:2018-11-21
* Description : dev_battery.h
********************************************************************************/
#ifndef DEV_BATTERY_H
#define DEV_BATTERY_H

#include "global_var.h"
#include "device.h"

//电池初始化
extern int batt_dev_init();

extern char* get_manufactor_desc(int iManufactorid);

#endif


