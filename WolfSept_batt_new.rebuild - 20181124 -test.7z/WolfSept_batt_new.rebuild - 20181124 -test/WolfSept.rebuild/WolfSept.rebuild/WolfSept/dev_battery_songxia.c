﻿/********************************************************************************
* Copyright (C) 2025, JD.COM, Inc.
* All rights reserved.
* FileName    : dev_battery_songxia.c
* Author      : yyf   Version: V1.0   Data:2018-11-21
* Description : dev_battery_songxia.c
********************************************************************************/
#include "can.h"
#include "device.h"
#include "global_var.h"
#include "dev_battery_songxia.h"

static bool s_bBatteryFull = FALSE;
extern int g_iNotReport3019;

/*******************************************************************************
* Function Name      : write_batt_summary_info
* Description	     : write battery summary info to battery_monitor.log
* Input 		     : batt_info_t *pBattInfo
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
static int write_batt_summary_info(batt_info_t *pBattInfo)
{
	float fVoltage = 0.0;
	float fCurrent = 0.0;

	fVoltage = ((float)pBattInfo->uVoltage) / 10.0;
	fCurrent = ((float)pBattInfo->uCurrent) / 10.0;
	LOG_BATTERY("battery temperature:[%dC],voltage:[%.2fV],current[%.2fA],battery:[act:%d%, mod:%d%],state:[%s]\n",
		pBattInfo->uTemp - TEMPER_BASE, fVoltage, fCurrent, g_stAgvAttr.iOriginalSocVal, pBattInfo->uSoc,
		((pBattInfo->uState == 1) ? "charging" : "not charging"));

	return 0;
}

/*******************************************************************************
*Function Name    :songxia_recv_bms_info
*Description      :CAN1记录电池BMS信息帧到队列中
*Input       	  :struct can_frame * pBatCanData
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int songxia_recv_bms_info(struct can_frame * pCanFrame)
{
	int iRet = 0;
	
	if (pCanFrame == NULL)
		return -1;
	
	iRet = linkqueue_append(g_stAgvParm.pBmsCanFrameQueue, pCanFrame, sizeof(struct can_frame));
	if (iRet < 0)
	{
		LOG_WRN("append can frame[0x%x] to pBmsCanFrameQueue failed\n", pCanFrame->can_id);
		return iRet;
	}
	
	return 0;
}

/*******************************************************************************
* Function Name      : inquiry_bms_info
* Description	     : send inquiry information cmd to bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int inquiry_bms_info()
{
	struct can_frame stBatCanData = { 0 };
	int iCount = -1;

	stBatCanData.can_id = BATT_REQ_CANID;
	stBatCanData.can_dlc = 8;
	stBatCanData.data[0] = 0x16;
	stBatCanData.data[1] = 0xBB;
	stBatCanData.data[7] = 0x7E;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery info can frame\n");
	print_can_frame(&stBatCanData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanData);//change by tiger
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name      : get_bms_info
* Description	     : wait and get the information sent by bms.
* Input 		     : pBatCanData is the obtained data.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int get_bms_info(struct can_frame * pBatCanData)
{
	int iRet = -1;
	int iTryCount = 0;

	if (pBatCanData == NULL) {
		return -1;
	}

	iTryCount = TRY_COUNT_LIMIT;
	while (iTryCount--)
	{
		usleep(500);

		memset(pBatCanData, 0, sizeof(struct can_frame));
		iRet = linkqueue_retrieve(g_stAgvParm.pBmsCanFrameQueue, pBatCanData);
		if (iRet < 0)
			continue;

		if (pBatCanData->can_id >= BATT_ACK_CANID && pBatCanData->can_id <= BATT_ACK_CANID_0X15)
		{
			iRet = 0;
			break;
		}
	}

	if (iTryCount <= 0)
	{
		iRet = -1;
	}

	return iRet;
}

/*******************************************************************************
*Function Name    :parse_bms_summary_info
*Description      :CAN1发送松下电池概要信息查询帧
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int parse_bms_summary_info(struct can_frame *pBattCanData, batt_info_t *pBattInfo)
{
	if (pBattCanData == NULL || pBattInfo == NULL)
		return -1;

#if(DEBUG_AGV == 333)
	LOG_INF("recv battery info can frame\n");
	print_can_frame(pBatCanData);
#endif

	pBattInfo->uVoltage = htons(*(int16_t *)(&pBattCanData->data[0]));	   //字节0,1
	pBattInfo->uCurrent = htons(*(int16_t *)(&pBattCanData->data[2]));	   //字节2,3
	pBattInfo->uSoc = pBattCanData->data[4];							   //字节4
	pBattInfo->uTemp = pBattCanData->data[5];							   //字节5
	pBattInfo->uState = pBattCanData->data[6];							   //字节6
	pBattInfo->uCellNum = pBattCanData->data[7];						   //字节7
	g_stAgvAttr.iOriginalSocVal = pBattInfo->uSoc;

	if (pBattInfo->uCurrent >= PANSONIC_CURRENT_HIGHESTBIT)
	{
		pBattInfo->uCurrent = pBattInfo->uCurrent - PANSONIC_CURRENT_HIGHESTBIT;
	}

	return 0;
}

/*******************************************************************************
*Function Name    :prase_bms_cell_info
*Description      :CAN1发送松下电池单体信息查询帧
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int prase_bms_cell_info(struct can_frame *pBattCanData, batt_info_t *pBattInfo)
{
	int i = 0;
	uint16_t iCellGrpIdx = 0;

	if (pBattCanData == NULL || pBattInfo == NULL)
	{
		return -1;
	}

	if ((pBattCanData->can_id > BATT_ACK_CANID_0X15) || (pBattCanData->can_id < BATT_ACK_CANID))
	{
		return -2;
	}


	iCellGrpIdx = pBattCanData->can_id - 0x11;

	pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 0] = htons(*(int16_t *)(&pBattCanData->data[0]));		// 字节0,1
	pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 1] = htons(*(int16_t *)(&pBattCanData->data[2]));		// 字节2,3
	pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 2] = htons(*(int16_t *)(&pBattCanData->data[4]));		// 字节4,5
	pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 3] = htons(*(int16_t *)(&pBattCanData->data[6]));	// 字节6,7

	if (3 == iCellGrpIdx)
	{
		if ((pBattInfo->uInquiryCount % DUMP_BATT_INFO_CYCLES) == 0)
		{
			for (i = 0; i < BATT_CELL_NUM / 4; ++i)
			{
				LOG_BATTERY("battery cell group[%d]'voltage:%4d, %4d, %4d, %4d mV\n",
					i,
					pBattInfo->iBattCellVolt[i * 4 + 0],
					pBattInfo->iBattCellVolt[i * 4 + 1],
					pBattInfo->iBattCellVolt[i * 4 + 2],
					pBattInfo->iBattCellVolt[i * 4 + 3]);
			}
		}
	}

	return 0;
}

/*******************************************************************************
*Function Name    :prase_bms_fault_info
*Description      :CAN1发送松下电池故障信息查询帧
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int prase_bms_fault_info(struct can_frame *pBattCanData, batt_info_t *pBattInfo)
{
	int8_t iTState = 0;
	int8_t iCState = 0;
	int8_t iVState = 0;
	int8_t iSoftVersion = 0;
	int16_t iCycleTimes = 0;

	if (pBattCanData == NULL || pBattInfo == NULL)
	{
		return -1;
	}

	iTState = pBattCanData->data[0];							// 字节0
	iCState = pBattCanData->data[1];							// 字节1
	iVState = pBattCanData->data[2];							// 字节2
	iSoftVersion = pBattCanData->data[4];						// 字节6
	iCycleTimes = htons(*(int16_t *)(&pBattCanData->data[6]));	// 字节7,8

	if ((pBattInfo->uInquiryCount % DUMP_BATT_INFO_CYCLES) == 0)
	{
		LOG_BATTERY("battery fault:iTState=0x%04x, iCState=0x%04x, iVState=0x%04x, iSoftVersion=0x%02x, iCycleTimes=0x%02x\n",
			iTState, iCState, iTState, iSoftVersion, iCycleTimes);
	}
	
	if ((pBattInfo->iTState == iTState) && (pBattInfo->iCState == iCState)
		&& (pBattInfo->iVState == iVState) && (pBattInfo->iPreVoltDiffProtectUser == pBattInfo->iVoltDiffProtectUser))
	{
		return -2;  
	}

	LOG_WRN("battery fault info:iVState.............[0x%04x-->0x%04x]\n", pBattInfo->iVState, iVState);
	LOG_WRN("battery fault info:iCState.............[0x%04x-->0x%04x]\n", pBattInfo->iCState, iCState);
	LOG_WRN("battery fault info:iTState.............[0x%04x-->0x%04x]\n", pBattInfo->iTState, iTState);
	LOG_WRN("battery fault info:VoltDiffProtectUser.[0x%04x-->0x%04x]\n", pBattInfo->iPreVoltDiffProtectUser, pBattInfo->iVoltDiffProtectUser);

	pBattInfo->iTState = iTState;
	pBattInfo->iCState = iCState;
	pBattInfo->iVState = iVState;
	pBattInfo->iSoftVersion = iSoftVersion;
	pBattInfo->iCycleTimes = iCycleTimes;

	pBattInfo->iVoltDiffProtectSys = iTState & 0x0001;						 //电压不平衡
	pBattInfo->iChargeOverTempProtection = iTState & 0x0002;				 //充电过温保护
	pBattInfo->iDischargeOverTempProtection = iTState & 0x0004;				 //放电过温保护
	pBattInfo->iChargeOverTempWarn = iTState & 0x0008;					 //充电过温报警
	pBattInfo->iDischargeOverTempWarn = iTState & 0x0010;						 //放电过温报警
	pBattInfo->iChargeUnderTempProtection = iTState & 0x0020;				 //充电欠温保护
	pBattInfo->iDischargeUnderTempProtection = iTState & 0x0040;			 //放电欠温保护

	// iCState
	pBattInfo->iChargeOverVolFlag = iCState & 0x0001;			//充电过压标志
	pBattInfo->iDischargeUnderVolFlag = iCState & 0x0002;				//放电欠压标志
	pBattInfo->iChargeOverCurrentFlag = iCState & 0x0004;		//充电过流
	pBattInfo->iChargeUnderTempWarn = iCState & 0x0020;             //充电欠温报警
	pBattInfo->iDischargeUnderTempWarn = iCState & 0x0040;				//放电欠温报警

	// iTState
	pBattInfo->iChargeErrFlag = iVState & 0x0001;        //充电器故障标志
	pBattInfo->iDishargeOverCurrentFlag = iVState & 0x0002;       //放电过流标志
	pBattInfo->iChargeSwitchState = iVState & 0x0004;		//充电开关状态
	pBattInfo->iBatteryCapacityLowFlag = iVState & 0x0008;	//容量低标志位
	pBattInfo->iBatteryFullFlag = iVState & 0x0010;			//电池充满标志

	pBattInfo->iSoftVersion = iSoftVersion;                       //软件版本
	pBattInfo->iCycleTimes = iCycleTimes;							//循环次数  

	return 1;
}

/*******************************************************************************
* Function Name      : prase_bms_info
* Description	     : prase battery information from battery bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int prase_bms_info(struct can_frame *pBattCanData, batt_info_t *pBattInfo)
{
	int iRet = -1;

	if (pBattCanData == NULL || pBattInfo == NULL)
	{
		return -1;
	}

	if (BATT_ACK_CANID == pBattCanData->can_id)
	{
		iRet = parse_bms_summary_info(pBattCanData, pBattInfo); //CANID等于0x10,解析BMS上报当前电池总体信息
		if (iRet < 0) 
		{
			LOG_INF("parse bms summary info failed!\n");
			return iRet;
		}
	}
	else if (pBattCanData->can_id >= 0x11 && pBattCanData->can_id <= 0x14)
	{
		iRet = prase_bms_cell_info(pBattCanData, pBattInfo);
		if (iRet < 0) 
		{
			LOG_INF("prase bms cell info failed!\n");
			return iRet;
		}
	}
	else if (BATT_ACK_CANID_0X15 == pBattCanData->can_id)
	{
		iRet = prase_bms_fault_info(pBattCanData, pBattInfo);
		if (1 == iRet)
		{
			LOG_ERR("songxia battery has a new fault info:>>>>>\n");
			songxia_dump_bms_info(pBattInfo);
			songxia_commit_bms_info(pBattInfo);
		}
	}
	else
	{
		
	}

	return 0;
}

/*******************************************************************************
*Function Name    :songxia_inquiry_batt_summary_info
*Description      :获取松下电池BMS信息
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int songxia_inquiry_bms_info(batt_info_t *pBattInfo)
{
	int i = 0;
	int iRet = -1;
	struct can_frame stBattCanData = { 0 };

	if (pBattInfo == NULL)
	{
		return -1;
	}

	iRet = inquiry_bms_info();
	if (iRet < 0) 
	{
		LOG_ERR("songxia battery inquiry bms info failed, errorid = %d\n",iRet);
		return -2;
	}

	for(i = 0; i < 6; i++)
	{
		iRet = get_bms_info(&stBattCanData);
		if (iRet < 0)
		{
			LOG_ERR("songxia battery get bms info failed, errorid = %d\n", iRet);
			return -3;
		}
		else
		{
			iRet = prase_bms_info(&stBattCanData, pBattInfo);  //处理0x10 - 0x15共5帧
			if (iRet < 0)
			{
				LOG_ERR("songxia battery parse bms info failed, errorid = %d\n", iRet);
				return -4;
			}
		}
	}
	
	return 0;
}

/*******************************************************************************
*Function Name    :calc_cell_max_and_min_voltage
*Description      :计算单体电池电压最大值、最小值、压差
*Input       	  :bat_info_t * pBattInfo
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
static int calc_cell_max_and_min_voltage(batt_info_t *pBattInfo)
{
	int i = 0;
	int16_t iBattCellVolt = 0;
	int16_t iTmpVoltMax	= 0;	// 单体电压的最大值
	int16_t iTmpVoltMin = 0;	// 单体电压的最小值
	int16_t iVoltDiff = 0;
	int16_t	*pBattCellVoltArray = NULL;

	if (pBattInfo == NULL)
	{
		return -1;
	}

	pBattCellVoltArray = pBattInfo->iBattCellVolt;
	
	iTmpVoltMax = pBattCellVoltArray[8];
	iTmpVoltMin = pBattCellVoltArray[8];

	for (i = 1; i < BATT_CELL_NUM; i++)
	{
		iBattCellVolt = pBattCellVoltArray[i];

		if (iBattCellVolt == 0)
			continue;

		if (iBattCellVolt > iTmpVoltMax)
		{
			iTmpVoltMax = iBattCellVolt;
		}
		else if (iBattCellVolt < iTmpVoltMin)
		{
			iTmpVoltMin = iBattCellVolt;
		}
	}

	pBattInfo->iBattCellVoltMax = iTmpVoltMax;
	pBattInfo->iBattCellVoltMin = iTmpVoltMin;
	pBattInfo->iBattCellVoltDelt = iTmpVoltMax - iTmpVoltMin;
	
	return 0;
}

/*******************************************************************************
*Function Name    :songxia_update_bms_info
*Description      :更新松下电池BMS信息
*Input       	  :bat_info_t * pBattInfo
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int songxia_update_bms_info(batt_info_t *pBattInfo)
{
	int iRet = 0;
	
	if (pBattInfo == NULL)
	{
		return -1;
	}

	iRet = calc_cell_max_and_min_voltage(pBattInfo);
	
	//1.单体电压值超出正常范围
	if ((pBattInfo->iBattCellVoltMin <= ANSHANG_BMS_MIN_SINGLEVOL ) || (pBattInfo->iBattCellVoltMax >= ANSHANG_BMS_MAX_SINGLEVOL))
	{
		LOG_WRN("The single vol is invalid-iTmpVoltMin[%d] iTmpVoltMax[%d]\n", pBattInfo->iBattCellVoltMin, pBattInfo->iBattCellVoltMax);
		pBattInfo->iVoltDiffProtectUser = 0;
		pBattInfo->iPreVoltDiffProtectUser = 0;
		return -2;
	}

	//2.单体电压的（最大值 - 最小值）超过300mv，则需进行压差保护异常上报
	if (pBattInfo->iBattCellVoltDelt >= MAX_VOLT_DIFF)
	{
		LOG_INF("battery cell voltage : max[%d]mv, min[%d]mv, diff[%d]mv > %dmv, set iVoltDiffProtect == TRUE\n",
			pBattInfo->iBattCellVoltMax, pBattInfo->iBattCellVoltMin, pBattInfo->iBattCellVoltDelt, MAX_VOLT_DIFF);
		pBattInfo->iPreVoltDiffProtectUser = pBattInfo->iVoltDiffProtectUser;
		pBattInfo->iVoltDiffProtectUser = 0x0100;
	}
	else
	{
		pBattInfo->iPreVoltDiffProtectUser = pBattInfo->iVoltDiffProtectUser;
		pBattInfo->iVoltDiffProtectUser = 0;
	}

	// 3. 单体电压最小于ANSHANG_BMS_LOW_SINGLEVOL（3450mv）电量置成29%，由控制台调度充电
	if (pBattInfo->iBattCellVoltMin < ANSHANG_BMS_LOW_SINGLEVOL)
	{
		if (pBattInfo->iMoidfySocFlag == FALSE)
		{
			LOG_INF("the min voltage[%d]mv of all battery cell < [%d]mv, then correct soc to %d\n",
				pBattInfo->iBattCellVoltMin, ANSHANG_BMS_LOW_SINGLEVOL, ANSHANG_BMS_LOW_SOC_29);
		}

		pBattInfo->iMoidfySocFlag = TRUE;
		pBattInfo->uSocModified = ANSHANG_BMS_LOW_SOC_29;	
	}
	else
	{
		pBattInfo->iMoidfySocFlag = FALSE;
	}

	//4.电池充电完成后，判断电量是否小于60%
	if ((true == s_bBatteryFull) &&(g_stAgvAttr.iMoveStatus == agv_charge)&& (BATT_STATE_CHARGING != pBattInfo->uState))
	{
		if (pBattInfo->uSocOrg >= BATTERY_CHARGE_SOC_60) //电池充电保护状态，电量校准到100%，以便控制台调度小车离开
		{
			LOG_INF("during charging, correct battery'soc:[%d->%d] when soc is incorrect\n", pBattInfo->uSocOrg, BATTERY_CHARGE_SOC_100);
			pBattInfo->uSoc = BATTERY_CHARGE_SOC_100;
		}
	}

	//5.每隔 DUMP_BATT_INFO_CYCLES 秒打印一次，电池总体信息
	if ((pBattInfo->uInquiryCount % DUMP_BATT_INFO_CYCLES) == 0)
	{
		write_batt_summary_info(pBattInfo);
	}

	return 0;
}

/*******************************************************************************
*Function Name    :calibrate_battery
*Description      : 校准BMS信息
*Input       	  :bat_info_t * pBattery
*Output 		  :
*Return           :int:1:calibrate finish
0:on calibrating,
-1: need not calibrate,
-2:calibrate timeout
*******************************************************************************/
static int calibrate_battery(batt_info_t *pBattery, int iCalibrationPeriod)
{
	if (NULL == pBattery || iCalibrationPeriod <= 0)
	{
		return NEED_NOT_CALIBRATION;
	}

	int iCalibrationTime = (pBattery->uCalibrateTime)*iCalibrationPeriod;

	if (pBattery->uVoltage < CALIBRATE_VOLTAGE_V)
	{
		LOG_INF("need not wait calibrate battery,for battery voltage = %dV \n", pBattery->uVoltage / 10);
		pBattery->uCalibrateTime = 0;
		return NEED_NOT_CALIBRATION;
	}

	if (pBattery->uSoc >= CALIBRATION_FINISH_SOC)
	{
		LOG_INF("calibrate battery finish,for battery voltage = %dV Soc = %d ,calibation_time = %d\n",
			pBattery->uVoltage / 10, pBattery->uSoc, iCalibrationTime);
		pBattery->uCalibrateTime = 0;
		return CALIBRATION_FINISHED;
	}

	if (++pBattery->uCalibrateTime > CALIBRATION_SECONDS / iCalibrationPeriod)
	{
		LOG_INF("calibrate battery timeout,for %ds\n", iCalibrationTime);
		pBattery->uCalibrateTime = 0;
		return CALIBRATION_TIMEOUT;
	}

	LOG_INF("calibrating battery ,for %ds\n", iCalibrationTime);
	return CALIBRATING;

}

/*******************************************************************************
*Function Name    :query_charge_status
*Description      : query charge status 1 times
*Input       	  :bat_info_t * pBattery
*Output 		  :
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
static int query_charge_status(struct bat_info *pBattInfo)
{
	static int iLowChargeCurCount = 0;
	static int iRetryChargeCount = 0;
	int iRet = -1;

	iLowChargeCurCount++;

	if (iLowChargeCurCount >= LOW_CHARGE_CUR_COUNT)
	{
		LOG_WRN("battery charging failure, stop charging, trytime=%d\n", iLowChargeCurCount);
		write_batt_summary_info(pBattInfo);
		iLowChargeCurCount = 0;

		iRet = songxia_stop_charge();
		if (iRet < 0)
		{
			return iRet;
		}
		if (g_stAgvAttr.iStopChargeConflict == TRUE)
		{
			g_stAgvAttr.iStopChargeConflict = FALSE;
			LOG_WRN("Filter the EVENT_ERR_CHARGECURSAMLL and stop to retry when the stop charge conflict\n");
			return iRet;
		}

		if (iRetryChargeCount < RETRY_CHARGE_TIMES )
		{
			LOG_INF("detect 3010-EVENT_ERR_CHARGECURSAMLL,start change again\n");
			iRet = songxia_start_charge();
			if (iRet != OK)
			{
				if (BERROR == iRet)
				{
					send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_PARKPRECISION);
				}
				return iRet;
			}
			iRetryChargeCount++;
			LOG_INF("%dth start change by MM2.0 success\n",iRetryChargeCount);					
		}
		else
		{
			iRetryChargeCount = 0;
			iRet = 0;

		}			
	}
	return iRet;
}

/*******************************************************************************
*Function Name    :monitor_soc_variety_on_charge
*Description      :充电过程中查询充电情况
*Input       	  :bat_info_t * pBattInfo，u32 uTime
*Output 		  :NONE  
*Return           :int:0 if OK;-1 on error  
*******************************************************************************/
int monitor_soc_variety_on_charge(batt_info_t *pBattInfo,u32 uTime)
{
	int iRet = 0;
	static time_t s_iStartCalTime = 0;
	time_t iCurCalTime = 0;

	if ((agv_charge == g_stAgvAttr.iMoveStatus) &&(BATT_STATE_CHARGING == pBattInfo->uState)
		&& (pBattInfo->uSoc < uTime))
	{
		time(&iCurCalTime);
		(0 == s_iStartCalTime) ? (s_iStartCalTime = iCurCalTime) : (s_iStartCalTime = s_iStartCalTime);
		if (iCurCalTime - s_iStartCalTime >= HOURS_1_5)
		{
			set_check_soc_flag("1");
			iRet = songxia_stop_charge();
			if (iRet < 0)
			{
				return iRet;
			}
		}
	}
	else
	{
		s_iStartCalTime = 0;
	}

	return 0;
}


/*******************************************************************************
*Function Name    :songxia_batt_exception_handle
*Description      :电池信息异常处理
*Input       	  :bat_info_t * pBattInfo
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int songxia_bms_info_exception_handle(batt_info_t *pBattInfo)
{
	int iRet = -1;
	float fVoltage = 0.0f;
	static bool s_bCurSmallErr = FALSE;
	static time_t s_iStartCalTime = 0;
	time_t iCurCalTime = 0;

	//1.上次充电1.5小时以上，电量未到CHARGE_HOURS_1_5_SOC（80）
	if (TRUE == pBattInfo->uNeedCheckSoc)
	{
		pBattInfo->uNeedCheckSoc = FALSE;
		if (pBattInfo->uSoc < CHARGE_HOURS_1_5_SOC)
		{
			LOG_ERR("batt'soc[%d] < expect[%d] when charge time > 1.5h at reboot\n", pBattInfo->uSoc, CHARGE_HOURS_1_5_SOC);
			songxia_dump_bms_info(pBattInfo);//dump bat info
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_NEED_OFFLINE);
		}
		else
		{
			set_check_soc_flag("0");
		}
	}

	//2.监测充电1.5小时，电量状态
	iRet = monitor_soc_variety_on_charge(pBattInfo, CHARGE_HOURS_1_5_SOC);
	{
		LOG_ERR("batt'soc[%d] < expect[%d] when charge time > 1.5h\n", pBattInfo->uSoc, CHARGE_HOURS_1_5_SOC);
		songxia_dump_bms_info(pBattInfo);
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHECK_FAILED);
	}

	if (g_stAgvAttr.iMoveStatus == agv_charge) //控制台为充电任务状态
	{
		if (pBattInfo->uState != BATT_STATE_CHARGING)  //电池处于非充电状态
		{
			g_stAgvAttr.iStopChargeFromMM = TRUE; //控制台为充电状态

			//3.充电时尝试充电2次
			if ((BATTERY_CHARGE_SOC_100 != pBattInfo->uSoc))
			{
				LOG_INF("query_charge_status\n");
				iRet = query_charge_status(pBattInfo);
				if (0 == iRet)
				{
					s_bCurSmallErr = true;
					LOG_INF("s_bCurSmallErr = true\n");
				}
			}
		}
	}
	else
	{
		//4.控制台不在充电状态，标志为置为false
		s_bBatteryFull = false;

		//5.电池充电完成后，判断电量是否小于60%
		if ((true == s_bBatteryFull) && (BATT_STATE_CHARGING != pBattInfo->uState))
		{
			if (pBattInfo->uVoltage > CALIBRATE_VOLTAGE_V && pBattInfo->uSoc < BATTERY_CHARGE_SOC_60)
			{
				fVoltage = (float)pBattInfo->uVoltage / 10.0;
				LOG_WRN("3010-EVENT_ERR_BMS_SOC_DISTORTION: fVoltage[act:%.2fV, exp:%.2fV, Soc[act:%3d%, exp:%3d%\n",
					fVoltage, CALIBRATE_VOLTAGE_V / 10.0f, pBattInfo->uSoc, BATTERY_CHARGE_SOC_60);
				//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CHARGECURSAMLL);   //上报3010错误
			}
		}
	}

	//6. 停止充电校准
	if (true == s_bCurSmallErr)
	{
		iRet = calibrate_battery(pBattInfo, 1);
		if (iRet == CALIBRATION_FINISHED)
		{
			s_bCurSmallErr = false;
		}
		else if (iRet == CALIBRATION_TIMEOUT)
		{
			s_bCurSmallErr = false;
			s_bBatteryFull = true;
		}
		else if (iRet == NEED_NOT_CALIBRATION)
		{
			s_bCurSmallErr = false;
			LOG_WRN("battery charging failure, send error msg[%d-%s] to console\n",
				EVENT_ERR_CHARGECURSAMLL, get_err_str(EVENT_ERR_CHARGECURSAMLL));
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CHARGECURSAMLL);
		}
		else
		{
			LOG_INF("keep on  calibratint battery\n");
		}
	}
		
	return 0;
}

/*******************************************************************************
*Function Name    songxia_commit_bms_info
*Description      :电池信息上报控制台并记录到日志里
*Input       	  :batt_info_t * pBattInfo
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int songxia_commit_bms_info(batt_info_t *pBattInfo)
{
	if (pBattInfo == NULL)
	{
		return -1;
	}
	// 电池故障:压差保护/电压不平衡
	if (pBattInfo->iVoltDiffProtectSys != 0)
	{
		LOG_ERR("BMS Exception Songxia:voltage diff protect in system\n");
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_VOLDISBALANCE);
	}

	if ((pBattInfo->iVoltDiffProtectUser != 0) && (pBattInfo->iPreVoltDiffProtectUser != pBattInfo->iVoltDiffProtectUser))
	{
		LOG_ERR("BMS Exception Songxia:voltage diff protect in user\n");
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_VOLDISBALANCE);
	}

	// 电池故障:放电过温告警及过温保护
	if (pBattInfo->iDischargeOverTempProtection != 0)
	{
		LOG_ERR("BMS Exception Songxia:discharge over temperture protect\n");
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERTEMP);
	}
	// 电池故障:充电过温保护及过温警告
	if (pBattInfo->iChargeOverTempProtection != 0)
	{
		LOG_ERR("BMS Exception Songxia:charge over temperture protect\n");
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEOVERTEMP);
	}
	// 电池故障:充电过压标志及放电欠压标志
	if (pBattInfo->iDischargeUnderVolFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:charge/discharge over/under voltage flag\n");
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERVOL);
	}
	// 电池故障:充电过流及放电过流标志
	if (pBattInfo->iDishargeOverCurrentFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:discharge over current flag\n");
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERCUR);
	}
	// 电池故障:充电器故障标志
	if (pBattInfo->iChargeErrFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia: charge err flag\n");
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEERR);
	}
	// 电池故障:充电过压标志
	if (pBattInfo->iChargeOverVolFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:charge over voltage flag\n");
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEOVERVOL);
	}

	// 电池故障:充电欠温保护及欠温报警
	if ((pBattInfo->iChargeUnderTempProtection != 0) ||
		(pBattInfo->iChargeUnderTempWarn != 0))
	{
		LOG_ERR("BMS Exception Songxia: charge under temperture warn/protect\n");
	}
	// 电池故障:放电欠温保护及欠温报警
	if ((pBattInfo->iDischargeUnderTempProtection != 0) ||
		(pBattInfo->iDischargeUnderTempWarn != 0))
	{
		LOG_ERR("BMS Exception Songxia: discharge under temperture warn/protect\n");
	}
	// 电池故障:充电过流标志
	if (pBattInfo->iChargeOverCurrentFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:charge over current flag\n");
	}
	// 电池故障:容量低标志位
	if (pBattInfo->iBatteryCapacityLowFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:battery capacity low flag\n");
	}
	// 电池故障:电池充满标志
	if (pBattInfo->iBatteryFullFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:battery full flag\n");
	}
	// 电池故障:充电开关状态
	if ( pBattInfo->iChargeSwitchState != 0 )
	{
		LOG_ERR("BMS Exception Songxia:charge switch state\n");
	}
	
	return 0;
}

/*******************************************************************************
*Function Name    songxia_dump_bms_info
*Description      :电池信息记录日志
*Input       	  :batt_info_t * pBattInfo
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int songxia_dump_bms_info(batt_info_t *pBattInfo)
{
	int i = 0;
	if (pBattInfo == NULL)
		return -1;

	LOG_INF("battery base information\n");
	LOG_INF("iBattManufactor               : %s\n", get_manufactor_desc(pBattInfo->iBattManufactor));
	LOG_INF("iBattVersion                  : %d\n", pBattInfo->iBattVersion);//add by jxu 20181017
	LOG_INF("uVoltage                      : %.2f V\n", (float)pBattInfo->uVoltage / 10.0);
	LOG_INF("uCurrent                      : %.2f A\n", (float)pBattInfo->uCurrent / 10.0);
	LOG_INF("uSoc                          : %d\n", pBattInfo->uSoc);
	LOG_INF("uTemperature                  : %d\n", pBattInfo->uTemp - TEMPER_BASE);
	LOG_INF("uState                        : %d\n", pBattInfo->uState);
	LOG_INF("uCellNum                      : %d\n", pBattInfo->uCellNum);

	LOG_INF("battery cell information\n");
	for (i = 0; i < BATT_CELL_NUM; i++)
	{
		LOG_INF("iBattCellVolt[%02d]             : %5d mv\n", i, pBattInfo->iBattCellVolt[i]);
	}
	LOG_INF("iBattCellVoltMax              : %5d mv\n", pBattInfo->iBattCellVoltMax);
	LOG_INF("iBattCellVoltMin              : %5d mv\n", pBattInfo->iBattCellVoltMin);
	LOG_INF("iBattCellVoltDelta            : %5d mv\n", pBattInfo->iBattCellVoltMax - pBattInfo->iBattCellVoltMin);

	LOG_INF("Songxia BMS:battery fault information\n");

	LOG_INF("iVoltDiffProtectSys             : 0x%04x\n", pBattInfo->iVoltDiffProtectSys);
	LOG_INF("iChargeOverTempProtection       : 0x%04x\n", pBattInfo->iChargeOverTempProtection);
	LOG_INF("iDischargeOverTempProtection    : 0x%04x\n", pBattInfo->iDischargeOverTempProtection);
	LOG_INF("iChargeOverTempWarn             : 0x%04x\n", pBattInfo->iChargeOverTempWarn);
	LOG_INF("iDischargeOverTempWarn          : 0x%04x\n", pBattInfo->iDischargeOverTempWarn);
	LOG_INF("iChargeUnderTempProtection      : 0x%04x\n", pBattInfo->iChargeUnderTempProtection);
	LOG_INF("iDischargeUnderTempProtect      : 0x%04x\n", pBattInfo->iDischargeUnderTempProtection);

	LOG_INF("iChargeOverVolFlag              : 0x%04x\n", pBattInfo->iChargeOverVolFlag);
	LOG_INF("iDischargeUnderVolFlag          : 0x%04x\n", pBattInfo->iDischargeUnderVolFlag);
	LOG_INF("iChargeOverCurrentFlag          : 0x%04x\n", pBattInfo->iChargeOverCurrentFlag);
	LOG_INF("iChargeUnderTempWarn            : 0x%04x\n", pBattInfo->iChargeUnderTempWarn);
	LOG_INF("iDischargeUnderTempWarn         : 0x%04x\n", pBattInfo->iDischargeUnderTempWarn);

	LOG_INF("iChargeErrFlag                  : 0x%04x\n", pBattInfo->iChargeErrFlag);
	LOG_INF("iDishargeOverCurrentFlag        : 0x%04x\n", pBattInfo->iDishargeOverCurrentFlag);
	LOG_INF("iChargeSwitchState              : 0x%04x\n", pBattInfo->iChargeSwitchState);
	LOG_INF("iBatteryCapacityLowFlag         : 0x%04x\n", pBattInfo->iBatteryCapacityLowFlag);
	LOG_INF("iBatteryFullFlag                : 0x%04x\n", pBattInfo->iBatteryFullFlag);

	LOG_INF("iTState                         : 0x%04x\n", pBattInfo->iTState);
	LOG_INF("iCState                         : 0x%04x\n", pBattInfo->iCState);
	LOG_INF("iVState                         : 0x%04x\n", pBattInfo->iVState);
	LOG_INF("iSoftVersion                    : 0x%04x\n", pBattInfo->iSoftVersion);
	LOG_INF("iCycleTimes                     : 0x%04x\n", pBattInfo->iCycleTimes);

	return 0;
}

/*******************************************************************************
*Function Name    :songxia_start_charge
*Description      :CAN1发送松下电池充电指令
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int songxia_start_charge()
{
	int iCount = 0;

	struct can_frame stFrameCharge =
	{
		.can_id = BATT_REQ_V2_CANID,
		.can_dlc = MC_DATA_DLC_V2,
		.data[0] = BATT_CHARGE_FLAG,
		.data[1] = MC_CAN_RESERVE_V2,
		.data[2] = MC_CAN_RESERVE_V2,
		.data[3] = MC_CAN_RESERVE_V2,
		.data[4] = MC_CAN_RESERVE_V2,
		.data[5] = MC_CAN_RESERVE_V2,
		.data[6] = MC_CAN_RESERVE_V2,
		.data[7] = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:panasonic start charge request\n");
	print_can_frame(&stFrameCharge);

	iCount = send_can(BATT_CAN_DEV, &stFrameCharge);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}

	return 0;
}

/*******************************************************************************
*Function Name    :songxia_stop_charge
*Description      :CAN1发送松下电池停止充电指令
*Input       	  :NONE
*Output 		  :NONE
*Return           :int:0 if OK;-1 on error
*******************************************************************************/
int songxia_stop_charge()
{
		int iCount = 0;

	struct can_frame sFrameStopCharge =
	{
		.can_id = BATT_REQ_V2_CANID,
		.can_dlc = MC_DATA_DLC_V2,
		.data[0] = BATT_STOP_CHARGE_FLAG,
		.data[1] = MC_CAN_RESERVE_V2,
		.data[2] = MC_CAN_RESERVE_V2,
		.data[3] = MC_CAN_RESERVE_V2,
		.data[4] = MC_CAN_RESERVE_V2,
		.data[5] = MC_CAN_RESERVE_V2,
		.data[6] = MC_CAN_RESERVE_V2,
		.data[7] = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:panasonic stop charge request\n");
	print_can_frame(&sFrameStopCharge);

	iCount = send_can(BATT_CAN_DEV, &sFrameStopCharge);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name      : inquiry_bms_lasterfive_poweroff_info
* Description	     : send inquiry information cmd to bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int inquiry_bms_lasterfive_poweroff_info()
{
	struct can_frame stBatCanData = { 0 };
	int iCount = -1;

	stBatCanData.can_id = BATT_REQ_CANID_0X18;
	stBatCanData.can_dlc = 8;
	stBatCanData.data[0] = 0x5B;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery info can frame\n");
	print_can_frame(&stBatCanData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanData);//change by tiger
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name      : get_bms_lasterfive_poweroff_info
* Description	     : wait and get the information sent by bms.
* Input 		     : pBatCanData is the obtained data.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int get_bms_lasterfive_poweroff_info(struct can_frame * pBatCanData)
{
	int iRet = -1;
	int iTryCount = 0;

	if (pBatCanData == NULL) {
		return -1;
	}

	iTryCount = 1000;//ms
	while (iTryCount--)
	{
		usleep(1000);
		memset(pBatCanData, 0, sizeof(struct can_frame));
		iRet = iRet = linkqueue_retrieve(g_stAgvParm.pBmsCanFrameQueue, pBatCanData);
		if (iRet < 0)
			continue;
		if (pBatCanData->can_id == BATT_ACK_CANID_0X19)
		{
			print_can_frame(pBatCanData);
			int ilatestOne = pBatCanData->data[0];
			int ilatestTwo = pBatCanData->data[1];
			int ilatestThree = pBatCanData->data[2];
			int ilatestFour = pBatCanData->data[3];
			int ilatestFive = pBatCanData->data[4];
			LOG_INF("BMS Exception Pansonic:ilatestOne =%d ilatestTwo=%d ilatestThree=%d ilatestFour=%d ilatestFive=%d\n",
				ilatestOne, ilatestTwo, ilatestThree, ilatestFour, ilatestFive);
			iRet = 0;
			break;
		}
	}
	if (iTryCount <= 0)
	{
		iRet = -1;
	}

	return iRet;
}

/*******************************************************************************
* Function Name      : songxia_get_lasterfive_poweroff
* Description	     : The function get songxia battery lasterfive poweroff
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int songxia_get_lasterfive_poweroff()
{
	int iTimeOut = 3; // s
	struct can_frame stCanFrame = { 0 };
	u32 u32Count = 0;
	u32 u32FailCount = 0;
	int iRet = -1;
	struct can_frame stBattCanData = { 0 };

	while (iTimeOut--)
	{
		u32Count++;
		iRet = inquiry_bms_lasterfive_poweroff_info();
		if (iRet < 0) {
			if (u32Count % 20 == 0)
				LOG_WRN("query lasterfive_poweroff info failure\n");
			usleep(1000);
			continue;
		}
		iRet = get_bms_lasterfive_poweroff_info(&stBattCanData);
		if (iRet < 0)
		{
			u32FailCount++;
			LOG_INF("Do not get the 0x19 frame u32FailCount=%d\n", u32FailCount);
		}
		else
		{
			LOG_INF("The songxia battery lasterfive_poweroff is following\n");
			print_can_frame(&stBattCanData);
			break;
		}
	}
	if (iTimeOut <= 0)
	{
		LOG_WRN("get lasterfive_poweroff timeout\n");
		return -1;
	}
	return 0;

}

/*******************************************************************************
* Function Name      : inquiry_bms_pack_type_info
* Description	     : send inquiry pcak type cmd to bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int inquiry_bms_pack_type_info()
{
	struct can_frame stBatCanData = { 0 };
	int iCount = -1;

	stBatCanData.can_id = BATT_REQ_CANID_0X18;
	stBatCanData.can_dlc = 8;
	stBatCanData.data[0] = 0xBA;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery pack model info can frame\n");
	print_can_frame(&stBatCanData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanData);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name      : get_bms_pack_type_info
* Description	     : wait and get the information sent by bms.
* Input 		     : pBatCanData is the obtained data.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int get_bms_pack_type_info(struct can_frame * pBatCanData)
{
	int iRet = -1;
	int iTryCount = 0;

	if (pBatCanData == NULL) {
		return -1;
	}

	iTryCount = 1000;//ms
	while (iTryCount--)
	{
		usleep(1000);
		memset(pBatCanData, 0, sizeof(struct can_frame));
		iRet = iRet = linkqueue_retrieve(g_stAgvParm.pBmsCanFrameQueue, pBatCanData);
		if (iRet < 0)
			continue;
		if (pBatCanData->can_id == BATT_ACK_CANID_0X1D)
		{
			print_can_frame(pBatCanData);
			LOG_INF("BMS Pack Model:%s\n", pBatCanData->data);
			iRet = 0;
			break;
		}
	}
	if (iTryCount <= 0)
	{
		iRet = -1;
	}

	return iRet;
}

/*******************************************************************************
* Function Name      : songxia_get_pack_type
* Description	     : The function get pack type about the songxia battery
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int songxia_get_pack_type()
{
	int iTimeOut = 3; // s
	struct can_frame stCanFrame = { 0 };
	u32 u32Count = 0;
	u32 u32FailCount = 0;
	int iRet = -1;
	struct can_frame stBattCanData = { 0 };

	while (iTimeOut--)
	{
		u32Count++;
		iRet = inquiry_bms_pack_type_info();
		if (iRet < 0) {
			if (u32Count % 20 == 0)
				LOG_WRN("inquiry bms pack model info failure\n");
			usleep(1000);
			continue;
		}
		iRet = get_bms_pack_type_info(&stBattCanData);
		if (iRet < 0)
		{
			u32FailCount++;
			LOG_INF("Do not get the 0x19 frame u32FailCount=%d\n", u32FailCount);
		}
		else
		{
			LOG_INF("The songxia battery get pack model is following\n");
			print_can_frame(&stBattCanData);
			break;
		}
	}
	if (iTimeOut <= 0)
	{
		LOG_WRN("get pack model timeout\n");
		return -1;
	}
	return 0;

}

/*******************************************************************************
* Function Name      : inquiry_bms_vid
* Description	     : send inquiry information cmd to bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int inquiry_bms_vid()
{
	struct can_frame stBatCanData = { 0 };
	int iCount = -1;

	stBatCanData.can_id = BATT_REQ_CANID_0X18;
	stBatCanData.can_dlc = 8;
	stBatCanData.data[0] = 0xBB;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery VID can frame\n");
	print_can_frame(&stBatCanData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanData);//change by tiger
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name      : get_bms_vid_info
* Description	     : wait and get the information sent by bms.
* Input 		     : pBatCanData is the obtained data.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int get_bms_vid_info(struct can_frame * pBatCanData)
{
	int iRet = -1;
	int iTryCount = 0;

	if (pBatCanData == NULL) {
		return -1;
	}

	iTryCount = 1000;//ms
	while (iTryCount--)
	{
		usleep(1000);
		memset(pBatCanData, 0, sizeof(struct can_frame));
		iRet = linkqueue_retrieve(g_stAgvParm.pBmsCanFrameQueue, pBatCanData);
		if (iRet < 0)
			continue;
		if (pBatCanData->can_id == BATT_ACK_CANID_0X1C)
		{
			g_stAgvAttr.iBmsVID = htons(*(int16_t *)(&pBatCanData->data[0]));
			iRet = 0;
			break;
		}
	}
	if (iTryCount <= 0)
	{
		iRet = -1;
	}

	return iRet;
}

/*******************************************************************************
* Function Name      : songxia_get_vid_pid
* Description	     : The function get pack vid&pid about the songxia battery
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int songxia_get_vid_pid()
{
	int iTimeOut = 3; // s
	struct can_frame stCanFrame = { 0 };
	u32 u32Count = 0;
	u32 u32FailCount = 0;
	int iRet = -1;
	struct can_frame stBattCanData = { 0 };

	while (iTimeOut--)
	{
		u32Count++;
		iRet = inquiry_bms_vid();
		if (iRet < 0) {
			if (u32Count % 20 == 0)
				LOG_WRN("query battery info failure\n");
			usleep(1000);
			continue;
		}
		iRet = get_bms_vid_info(&stBattCanData);
		if (iRet < 0)
		{
			u32FailCount++;
			LOG_INF("Do not get the 0x1C frame u32FailCount=%d\n", u32FailCount);
		}
		else
		{
			LOG_INF("The songxia battery vid is following\n");
			print_can_frame(&stBattCanData);
			break;
		}
	}
	if (iTimeOut <= 0)
	{
		LOG_WRN("get battery type timeout\n");
		return -1;
	}
	return 0;

}

/*******************************************************************************
* Function Name      : songxia_battery_init_check
* Description	     : The function recoginize the songxia battery
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int songxia_battery_init_check()
{
	int iTimeOut = 3; // s
	int iRet = -1;
	struct can_frame stCanFrame = { 0 };
	u32 u32Count = 0;
	struct can_frame stBattCanData = { 0 };
	int iTryCount = 0;

	while (iTimeOut--)
	{
		u32Count++;
		iRet = inquiry_bms_info();
		if (iRet < 0) {
			if (u32Count % 20 == 0)
				LOG_WRN("query battery info failure\n");
			usleep(1000);
			continue;
		}

		iTryCount = TRY_COUNT_LIMIT;
		while (iTryCount--)
		{
			usleep(500);

			memset(&stBattCanData, 0, sizeof(struct can_frame));
			iRet = linkqueue_retrieve(g_stAgvParm.pBmsCanFrameQueue, &stBattCanData);
			if (iRet < 0)
				continue;

			if (stBattCanData.can_id == BATT_ACK_CANID_0X15)
			{
				LOG_INF("The battery type is songxia\n");
				print_can_frame(&stBattCanData);
				break;
			}
		}
	}
	if (iTimeOut <= 0)
	{
		LOG_WRN("get battery type timeout\n");
		return -1;
	}

	return 0;

}
