#ifndef _UDP_MSG_H__
#define _UDP_MSG_H__

#define MSG_TYPE_V1P0					1
#define MSG_TYPE_V2P0					2

#define MSG_TYPE_BASE                   (0)
#define MSG_TYPE_REGISTER               (MSG_TYPE_BASE + 1)
#define MSG_TYPE_UNREGISTER             (MSG_TYPE_BASE + 2)
#define MSG_TYPE_LOCK                   (MSG_TYPE_BASE + 3)
#define MSG_TYPE_UNLOCK                 (MSG_TYPE_BASE + 4)
#define MSG_TYPE_STOP                   (MSG_TYPE_BASE + 5)
#define MSG_TYPE_PASS                   (MSG_TYPE_BASE + 6)
#define MSG_TYPE_HEARTBEAT              (MSG_TYPE_BASE + 7)
#define MSG_TYPE_PRECHARGE              (MSG_TYPE_BASE + 8)
#define MSG_TYPE_CONGESTION             (MSG_TYPE_BASE + 9)
#define MSG_TYPE_TASKREPORT             (MSG_TYPE_BASE + 10)
#define MSG_TYPE_TASKCOMPLETE           (MSG_TYPE_BASE + 11)
#define MSG_TYPE_QUERYFAULTPOINT        (MSG_TYPE_BASE + 12)
#define MSG_TYPE_ERROR		            (MSG_TYPE_BASE + 13)	// MSG_TYPE_ERROR
#define MSG_TYPE_EVENT		            (MSG_TYPE_BASE + 13)	// MSG_TYPE_EVENT
#define MSG_TYPE_EVENT_RELEASE          (MSG_TYPE_BASE + 14)
#define MSG_TYPE_CHARGE                 (MSG_TYPE_BASE + 15)
#define MSG_TYPE_CHARGECOMPLETE         (MSG_TYPE_BASE + 16)
#define MSG_TYPE_LOCKEX                 (MSG_TYPE_BASE + 17)
#define MSG_TYPE_ADVANCE_OPERATE        (MSG_TYPE_BASE + 19)	// advance operate
#define MSG_TYPE_FINISH			        (MSG_TYPE_BASE + 20)
#define MSG_TYPE_ERROR_POINT            (MSG_TYPE_BASE + 21)
#define MSG_TYPE_TRANSMITRETDATA        (MSG_TYPE_BASE + 22)
#define MSG_TYPE_POINT			        (MSG_TYPE_BASE + 23)
#define MSG_TYPE_CONFIRM                (MSG_TYPE_BASE + 24)
#define MSG_TYPE_DEBUG			        (MSG_TYPE_BASE + 25)
#define MSG_TYPE_INFO			        (MSG_TYPE_BASE + 26)
#define MSG_TYPE_UPDATE    				(MSG_TYPE_BASE + 27)
#define MSG_TYPE_UPDATE_RESULT			(MSG_TYPE_BASE + 28)
#define MSG_TYPE_SET_CONFIG     		(MSG_TYPE_BASE + 31)//by tiger.73
#define MSG_TYPE_GET_CONFIG     		(MSG_TYPE_BASE + 32)//by tiger.73

#define MSG_TYPE_OPERATE                (MSG_TYPE_BASE + 1010) // basic operate
#define MSG_TYPE_TRANSMIT               (MSG_TYPE_BASE + 1011)
#define MSG_TYPE_GET_PARAM              (MSG_TYPE_BASE + 2000)
#define MSG_TYPE_SET_PARAM              (MSG_TYPE_BASE + 2001)

typedef enum
{
	NO_ACTION = 0,
	ACTION_WALK = 1,
	ACTION_TURN_LEFT = 2,
	ACTION_TURN_RIGHT = 3,
	ACTION_RISE = 4,
	ACTION_LAY = 5,
	ACTION_CHARGE = 6,
	ACTION_STOP_CHARGE = 7,
	ACTION_PARK = 8,
	ACTION_CLEAN_DERAIL = 9,
	ACTION_SET_ZONE = 10,
	ACTION_CLEAR_SAFE = 11,
	ACTION_IMU = 12,
	ACTION_QR = 13,
	ACTION_PALLET_TURN_LEFT = 14,
	ACTION_PALLET_TURN_RIGHT = 15,
	ACTION_CLEAR_NAVIGATION = 17,
	ACTION_BACK_TO_CHARGE = 19,
	ACTION_FORWARD_LEAVE_CHARGE = 20,
	ACTION_LEFT_ARC = 21,
	ACTION_RIGHT_ARC = 22,
	ACTION_FORWARD_TO_CHARGE = 23,
	ACTION_BACK_LEAVE_CHARGE = 24,
	ACTION_TYPE_NUM
} task_type_t;

#define EVENT_TYPE_ERROR		0
#define EVENT_TYPE_SAFE			1

#define DRIVER_MODE_AUTO		0
#define DRIVER_MODE_MANUAL		1

//the udp msg sequence buffer size, used to judge whether the msg repetitive
#define UDP_SEQ_BUF_SIZE	20
#define UDP_RCV_TIMEOUT		30

typedef struct seq_buff_item
{
	int iSeq;
	int iMsgType;
} seq_buff_item_t;

extern struct seq_buff_item g_iSeqBuff[UDP_SEQ_BUF_SIZE + 1];

extern int sequence_buff_init();
extern int sequence_is_valid(int iSequence, int iMsgType);

extern int agv_register();
extern int msg_recv(const char * pMsgBuff, int iMsgSize);
extern int msg_deal(const char * pMsgBuff, int iMsgSize);
extern int msg_send(const char * pMsgBuff, int iMsgSize);
extern int msg_dump(const char * pMsgBuff, int iMsgSize);

extern int send_battery_info();
extern int send_heartbeat_msg();
extern int send_error_msg(int iEventType, int iErrorCode);
extern int send_error_msg_suberror(int iEventType, int iErrorCode, int iSubErrorcode);///add by jxu 20180510
extern int send_point_msg(int iLocation, int iDriverMode);
extern int send_error_point_msg(int iErrorCode);
extern int send_offset_statistic_msg(int iAction);
extern int send_finish_msg(int iAction);


#endif/*_UDP_MSG_H__*/
