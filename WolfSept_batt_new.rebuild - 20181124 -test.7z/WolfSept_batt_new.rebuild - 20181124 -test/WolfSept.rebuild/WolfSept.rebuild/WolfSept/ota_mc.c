/********************************************************************************
* Copyright (c) 2018, Jd.Com, Inc .
* FileName: xxx.C
* Author: Menghu Wang   Version: V1.0   Data:2018-02-11
* Description:REALIZE THE INTERFACE OF OTA MOVE CONTROL
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include "ota_mc.h"
#include "ftp.h"
#include "device.h"
#include "can_msg.h"
#include "global_var.h"
#include "mc_v2.h"
#include "wget_update.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define  TX_APP_COUNT		2
#define	 DATA_SECTOR		512
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
ota_mc stOtaMc = { 0 };
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
*Function Name    :ota_mc_get_current_version
*Description      :get mc current version  
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int ota_mc_get_current_version()
{
	int iRet = 0;
	iRet = sprintf(stOtaMc.stUpdateMethod.pCurVersion, "%d", g_stAgvAttr.iMcVersion);
	if (iRet < 0)
	{
		LOG_ERR("get mc current version failed:[%d-%s]\n",errno,strerror(errno));
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :ota_mc_get_new_version
*Description      :get mc new version for server 
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int ota_mc_get_new_version(bool bWgetResult)
{
	int iRet = 0;
	char pFilePath[200] = { 0 };
	char pCrc32[100] = {0};
	int iDownloadCount = 5;
	if (false == bWgetResult) //by tiger.101
	{
		while (--iDownloadCount >= 0)
		{
			iRet = stOtaMc.stUpdateMethod.download_file(stOtaMc.stUpdateMethod.pVersionFileName, stOtaMc.stUpdateMethod.pDownloadDir,
				&stOtaMc.stUpdateMethod.stNetAddr, stOtaMc.stUpdateMethod.pUserName, stOtaMc.stUpdateMethod.pPassword, stOtaMc.stUpdateMethod.u8ConnectTimeout);
			if (iRet < 0)
			{
				LOG_WRN("[%d]th download %s file failed\n", (5 - iDownloadCount), stOtaMc.stUpdateMethod.pVersionFileName);
				continue;;
			}
			break;
		}
	}
	
	iRet = sprintf(pFilePath, "%s/%s", stOtaMc.stUpdateMethod.pDownloadDir, stOtaMc.stUpdateMethod.pVersionFileName);
	if (iRet < 0)
		return -1;

	if (iDownloadCount < 0)
	{
		LOG_ERR("download %s file failed\n", stOtaMc.stUpdateMethod.pVersionFileName);
		unlink(pFilePath);
		return -1;
	}

	iRet = ini_read(pFilePath, NULL, "version", stOtaMc.stUpdateMethod.pNewVersion, sizeof(stOtaMc.stUpdateMethod.pNewVersion));
	if (iRet < 0)
		return -1;

	iRet = ini_read(pFilePath, NULL, "CRC", pCrc32,sizeof(pCrc32));
	if (iRet < 0)
		return -1;

	stOtaMc.stUpdateMethod.u32AppFileCrc32 = strtoul(pCrc32, NULL, 0);

	return 0;
}

/*******************************************************************************
*Function Name    :ota_mc_get_app
*Description      :get D500-20 mc app ,by tiger.63  
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int ota_mc_get_app(bool bWgetResult)
{
	int iRet = 0;
	int iCrc32 = 0;
	int iDownloadCount = 5;
	char pAppPath[100] = { 0 };
	struct stat stAppInfo = { 0 };
	int iFileCrc32 = stOtaMc.stUpdateMethod.u32AppFileCrc32;

	sprintf(pAppPath, "%s/%s", stOtaMc.stUpdateMethod.pDownloadDir, stOtaMc.stUpdateMethod.pMasterAppName);

	while ((iCrc32 != iFileCrc32) && (--iDownloadCount>=0))
	{
		if (false == bWgetResult) //by tiger.101
		{
			iRet = stOtaMc.stUpdateMethod.download_file(stOtaMc.stUpdateMethod.pMasterAppName, stOtaMc.stUpdateMethod.pDownloadDir,
				&stOtaMc.stUpdateMethod.stNetAddr, stOtaMc.stUpdateMethod.pUserName, stOtaMc.stUpdateMethod.pPassword, stOtaMc.stUpdateMethod.u8ConnectTimeout);
			if (iRet < 0)
			{
				LOG_WRN("download %s file failed\n", stOtaMc.stUpdateMethod.pMasterAppName);
				continue;
			}
		}		
		iCrc32 = get_crc(pAppPath);
	}

	if (iDownloadCount <0)
	{
		unlink(pAppPath);
		LOG_WRN("download failed,the crc is wrong!\n");
		return  -1;		
	}

	stat(pAppPath, &stAppInfo);
	stOtaMc.stUpdateMethod.u32AppFileSize = stAppInfo.st_size;
	LOG_INF("download %s success,file size = %d bytes\n", stOtaMc.stUpdateMethod.pMasterAppName, stOtaMc.stUpdateMethod.u32AppFileSize);

	return 0;
}


/*******************************************************************************
*Function Name    :ota_mc_start_update
*Description      :start D500-20 mc update  ,by tiger.63
*Input       	  :ota_mc * pOtaMc  
*Output 		  :NONE
*Return           :int:0 if OK ,-1 on error ,-MC_CONNECT_ERROR when send can frame failed  
*******************************************************************************/
int ota_mc_start_update()
{
	int iRet = 0;

	iRet = mc_v2_update_crc_cmd(stOtaMc.stUpdateMethod.u32AppFileCrc32);
	if (iRet < 0 )
	{
		LOG_ERR("send D500_20 update crc cmd failed\n");
		return -1;
	}
	iRet = ftp_recv_can_v2(MC2ARM_UPDATE_CANID, TIME_OUT_8S / 1000);
	if (iRet < 0)
	{
		LOG_WRN("get D500_20 update crc cmd ACK time out\n");
		return -EVENT_ERR_MC_TIMEOUT;
	}

	if (g_stAgvAttr.iAppCrc != stOtaMc.stUpdateMethod.u32AppFileCrc32)
	{
		LOG_ERR("get D500_20 mc update crc cmd ACK wrong the crc [%d] != except[%d]\n", g_stAgvAttr.iAppCrc, stOtaMc.stUpdateMethod.u32AppFileCrc32);
		return -1;
	}

	iRet = mc_v2_update_length_cmd(stOtaMc.stUpdateMethod.u32AppFileSize);
	if (iRet < 0)
	{
		LOG_ERR("send D500_20 update length cmd failed\n");
		return -1;
	}
	iRet = ftp_recv_can_v2(MC2ARM_UPDATE_CANID, TIME_OUT_8S / 1000);
	if (iRet < 0)
	{
		LOG_WRN("get D500_20 update length cmd ACK time out\n");
		return -EVENT_ERR_MC_TIMEOUT;
	}
	if (g_stAgvAttr.iFileSize != stOtaMc.stUpdateMethod.u32AppFileSize)
	{
		LOG_ERR("get D500_20 mc update length cmd ACK wrong the file size��%d�� != except��%d��", g_stAgvAttr.iFileSize, stOtaMc.stUpdateMethod.u32AppFileSize);
		return -1;
	}

	return 0;
}

/*******************************************************************************
*Function Name    :ota_mc_end_update
*Description      :send end update cmd to mc,by tiger.63   
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int ota_mc_end_update()
{
	int iRet = 0;
	
	iRet = mc_v2_update_abort_cmd();
	if (iRet < 0)
	{
		LOG_ERR("send update abort cmd failed\n");
		return -1;
	}
	iRet = ftp_recv_can_v2(MC2ARM_UPDATE_CANID, TIME_OUT_8S / 1000);
	if (iRet < 0)
	{
		LOG_WRN("get update abort cmd ACK time out\n");
		return -EVENT_ERR_MC_TIMEOUT;
	}

	return 0;
}

/*******************************************************************************
*Function Name    :ota_mc_tx_app
*Description      :send app to D500-20 to mc ,by tiger.63 
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int ota_mc_tx_app()
{
	char pAppPath[100] = { 0 };
	int iFd = 0,iRet = 0,i = 0,iCount = 0;
	char pSrcData[DATA_SECTOR] = { 0 };
	ssize_t iSize = 0, iSizePadding = 0;
	struct can_frame stCanFrame = {
		.can_id = ARM2MC_UPDATE_DATA_CANID,
		.can_dlc = MC_DATA_DLC,
	};
	iRet = sprintf(pAppPath, "%s/%s", stOtaMc.stUpdateMethod.pDownloadDir, stOtaMc.stUpdateMethod.pMasterAppName);
	if (iRet < 0)
		return -1;

	iFd = open(pAppPath, O_RDONLY);
	if (iFd < 0 )
	{
		LOG_INF("open file error:[%d-%s]\n",errno,strerror(errno));
		return -1;
	}

	iRet = lseek(iFd, 0, SEEK_SET);
	if (iRet < 0 )
	{
		LOG_ERR("SEEK_SET the file faild:%d-%s", errno, strerror(errno));
		return -1;
	}
	
	do
	{
		bzero(pSrcData, DATA_SECTOR);
		iSize = read(iFd, pSrcData, DATA_SECTOR);
		iSizePadding = (iSize + MC_DATA_DLC - 1) &  ~(MC_DATA_DLC - 1);//padding MC_DATA_DLC*n bytes
		for (i = 0; i < iSizePadding / MC_DATA_DLC; i++)
		{
			usleep(1000);//sleep for 1ms
			memcpy(stCanFrame.data, pSrcData + i*MC_DATA_DLC, MC_DATA_DLC);
			iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
			if (iCount != sizeof(struct can_frame))
			{
				LOG_ERR("send app data can frame failed\n");
				return -1;
			}			
		}
		if (DATA_SECTOR == iSize)
		{
			iRet = ftp_recv_can_v2(MC2ARM_UPDATE_CANID, TIME_OUT_8S/1000);
			if (iRet < 0)
			{
				LOG_ERR("get update data ACK time out\n");
				return -EVENT_ERR_MC_TIMEOUT;
			}
		}
		
	} while (DATA_SECTOR == iSize);

	iRet = ftp_recv_can_v2(MC2ARM_UPDATE_DATA_CANID , TIME_OUT_8S/1000);
	if (iRet < 0)
	{
		LOG_ERR("get update data check ACK time out\n");
		return -EVENT_ERR_MC_TIMEOUT;
	}	
	if (g_stAgvAttr.iCrcCheckRet != 0 )
	{
		LOG_ERR("mc check the app crc wrong\n");
		return -1;
	}

	LOG_INF("send %s to mc success\n", stOtaMc.stUpdateMethod.pMasterAppName);
	return 0;
}

/*******************************************************************************
*Function Name    :ota_mc_excute_app
*Description      :send excute app cmd to D500-20 mc  
*Input       	  :void  
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int ota_mc_excute_app(void)
{
	int iRet = 0;
	iRet = mc_v2_restart();
	if (iRet < 0)
	{
		LOG_ERR("send reset cmd to D500_20 mc failed:[%d-%s]\n",errno,strerror(errno));
		return iRet;
	}
	
	iRet = ftp_recv_can_v2(MC_CAN_ACK_V2_CANID, TIME_OUT_10S/1000);
	if (iRet < 0)
	{
		LOG_ERR("get D500_20 mc restart ack failed\n");
		return -EVENT_ERR_MC_TIMEOUT;
	}
	
	return iRet;
}

/*******************************************************************************
*Function Name    :ota_mc_deinit
*Description      :deinit D500_20  mc update var����stOtaMc
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int ota_mc_deinit()
{
	bzero(&stOtaMc, sizeof(ota_mc));
	return 0;
}

/*******************************************************************************
*Function Name    :ota_mc_init
*Description      :init D500_20  mc update var����stOtaMc  
*Input       	  :char * pConfFilePath  
*Output 		  :NONE
*Return           :int:0 if OK ,-1 on error  
*******************************************************************************/
int ota_mc_init(char *pConfFilePath)
{
	int iRet = 0;
	char pVersionFilePath[100] = { 0 };
	update_method stUpdateMethod = { 0 };
	if (NULL == pConfFilePath)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}

	bzero(&stOtaMc, sizeof(ota_mc));
	stOtaMc.deinit = ota_mc_deinit;
	stOtaMc.end_update = ota_mc_end_update;
	stOtaMc.get_current_version = ota_mc_get_current_version;
	stOtaMc.get_new_version = ota_mc_get_new_version;
	stOtaMc.get_app = ota_mc_get_app;
	stOtaMc.tx_app = ota_mc_tx_app;
	stOtaMc.excute_app = ota_mc_excute_app;
	stOtaMc.init = ota_mc_init;
	stOtaMc.start_update = ota_mc_start_update;
	stOtaMc.end_update = ota_mc_end_update;

	iRet = ini_read(pConfFilePath, "autoflow_conf", "update_method", stUpdateMethod.pUpdateMethod, sizeof(stUpdateMethod.pUpdateMethod));
	if (iRet < 0)
	{
		strcpy(stUpdateMethod.pUpdateMethod, "ftp");
	}

	if (strcasecmp(stUpdateMethod.pUpdateMethod, "ftp") == 0)
	{
		iRet = _ftp_mc_init(pConfFilePath, &stUpdateMethod);
		if (iRet < 0)
		{
			LOG_ERR("init ftp configure failure\n");
			return iRet;
		}
	}
	sprintf(stUpdateMethod.pDownloadDir, "%s", MC_UPDATE_DCU);
	sprintf(stUpdateMethod.pMasterAppName, "%s", MC_APP_NAME);
	sprintf(stUpdateMethod.pVersionFileName, "%s", MC_VERSION_FILE_NAME);
	stOtaMc.stUpdateMethod = stUpdateMethod;
	return 0;
}

/*******************************************************************************
*Function Name    :ota_update_d500_20
*Description      :update D500-20,by tiger.63  
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int ota_update_d500_20()
{
	int iRet = 0,iTryTime = 0;
	char pPWD[200] = { 0 };
	char pStr[200] = { 0 };
	char *Pointer = NULL;
	int iResult = 0;
	Pointer = getcwd(pPWD, sizeof(pPWD));
	if (NULL == Pointer)
	{
		LOG_WRN("get current worker path failed,use default /\n");
		strcpy(pPWD, "/");
	}
	///add wget update,start by tiger.101 
	g_bMcAppWgetOK = false;
	iRet = wget_download_file(MC_APP_URL_V2, MC_TGZ, TRY_5_TIMES);
	LOG_INF("wget %s %s\n", MC_TGZ, (0 == iRet) ? "Success" : "Failed");
	if (0 == iRet)
	{
		iRet = wget_untar_file(MC_TGZ, MC_UPDATE_DCU);
		if (iRet<0)
		{
			g_bMcAppWgetOK = false;
		}
		LOG_INF("untar %s %s\n", MC_TGZ, (g_bMcAppWgetOK == true) ? ("Success") : ("Failed"));
	}
	/////add wget update,end by tiger.101 
	iRet = ota_mc_init(CONFIGURE_FILE_PATH);
	if (iRet < 0 )
	{
		LOG_ERR("ota mc init failed\n");
		return -1;
	}
	iRet = stOtaMc.get_current_version();
	if (iRet < 0 )
	{
		LOG_ERR("ota mc get current version failed\n");
		iResult = -1;
		goto out;
	}
	iRet = stOtaMc.get_new_version(g_bMcAppWgetOK);
	if (iRet < 0)
	{
		LOG_ERR("ota mc get new version failed\n");
		iResult = -1;
		goto out;
	}
	iRet = strcasecmp(stOtaMc.stUpdateMethod.pNewVersion, stOtaMc.stUpdateMethod.pCurVersion);
	if (iRet <= 0)
	{
		LOG_INF("need no update ,the new version(%s) = the cur version(%s)\n", stOtaMc.stUpdateMethod.pNewVersion, stOtaMc.stUpdateMethod.pCurVersion);
		iResult = 0;
		goto out;
	}

	iRet = stOtaMc.get_app(g_bMcAppWgetOK);
	if (iRet < 0 )
	{
		LOG_ERR("get mc app[%s] failed\n",stOtaMc.stUpdateMethod.pMasterAppName);
		iResult = -1;
		goto out;
	}

	LOG_INF("make mc to be ready to update\n");
	iRet = stOtaMc.end_update();//enable interrupt the processing during updating mc
	if (iRet < 0)
	{
		iResult = iRet;
		goto out;
	}

	iRet = stOtaMc.start_update();
	if (iRet < 0)
	{
		stOtaMc.end_update();
		iResult = iRet;
		goto out;
	}

	iTryTime = 0;
	while ((iTryTime++ < TX_APP_COUNT) && (iRet = stOtaMc.tx_app()) < 0) //send app twice
	{
		LOG_WRN("%dth send %s to mc failed\n", iTryTime,stOtaMc.stUpdateMethod.pMasterAppName);
		if (TX_APP_COUNT == iTryTime)
		{
			stOtaMc.end_update();
			iResult = iRet;
			goto out;
		}
	}

	iRet = stOtaMc.excute_app();
	if (iRet < 0)
	{
		LOG_ERR("excute mc app failed\n");
		iResult = -1;
		goto out;
	}

	iRet = ftp_recv_can_v2(MC2ARM_UPDATE_DATA_CANID, TIME_OUT_180S/1000);
	if (iRet < 0)
	{
		LOG_ERR("get update success ACK time out\n");
		iResult = -EVENT_ERR_MC_TIMEOUT;
		goto out;
	}
out:	
	//unlink tmp file and dir
	iRet = sprintf(pStr, "%s/%s", MC_UPDATE_DCU, MC_VERSION_FILE_NAME);
	if (iRet > 0)
		unlink(pStr);
	iRet = sprintf(pStr, "%s/%s", MC_UPDATE_DCU, MC_APP_NAME);
	if (iRet > 0)
		unlink(pStr);
	chdir(pPWD);
	iRet = rmdir(MC_UPDATE_DCU);
	if (iRet < 0)
	{
		LOG_WRN("remove dir %s failed:[%d-%s]\n", MC_UPDATE_DCU,errno, strerror(errno));
	}
	return iResult;
}
/******************* (C) COPYRIGHT 2018  Jd.Com, Inc . *****END OF FILE****/