#include "udp_msg_v1.h"
#include "device.h"
#include "debug.h"
#include "statistical_info.h"

#define PRECISION   100000

typedef enum 
{
	DEBUG_REBOOT = 1,
	DEBUG_PALLET_CLASP = 2,
	DEBUG_PALLET_UNCLASP = 3,
	DEBUG_WHEEL_CLASP = 4,
	DEBUG_WHEEL_UNCLASP = 5,
	DEBUG_CHECK_GROUNDDIRECT = 6,
	DEBUG_UNCHECK_GROUNDDIRECT = 7,
	DEBUG_AGV_SYNC_TIME = 8,
	DEBUG_AGV_TC_RISE = 9,
	DEBUG_AGV_TC_LAY = 10,
	DEBUG_AGV_GET_LOG = 11,
}enum_debug_cmd;


/*******************************************************************************
* Function Name		 : get_debug_cmd_name
* Description	     : get debug cmd name by type.
* input			     : iCmd: cmd type
* Output		     : NONE
* Return		     : the pointer of message name
*******************************************************************************/
char * get_debug_cmd_name(int iCmd)
{
	char *pCmdName = NULL;

	switch (iCmd) {
	case DEBUG_REBOOT:
		pCmdName = "DEBUG_REBOOT";
		break;
	case DEBUG_PALLET_CLASP:
		pCmdName = "DEBUG_PALLET_CLASP";
		break;
	case DEBUG_PALLET_UNCLASP:
		pCmdName = "DEBUG_PALLET_UNCLASP";
		break;
	case DEBUG_WHEEL_CLASP:
		pCmdName = "DEBUG_WHEEL_CLASP";
		break;
	case DEBUG_WHEEL_UNCLASP:
		pCmdName = "DEBUG_WHEEL_UNCLASP";
		break;
	case DEBUG_AGV_SYNC_TIME:
		pCmdName = "DEBUG_AGV_SYNC_TIME";
		break;
	default:
		pCmdName = "UNKNOWN_DEBUG_CMD";
		break;
	}

	return pCmdName;
}

/*******************************************************************************
* Function Name		 : msgv1_head_dump
* Description	     : print message head information.
* input			     : pMsgHead: the pointer of message head.
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int msgv1_head_dump(const char * pMsgBuff)
{
	int iMsgtype = 0;

	const msgv1_head_t *pMsgHead = (const msgv1_head_t *)pMsgBuff;

	if (pMsgHead != NULL) {
		iMsgtype = ntohl(pMsgHead->iMsgtype);
		LOG_INF("-----------------------\n");
		LOG_INF("msg.AgvName    = %d\n", ntohl(pMsgHead->iAgvName));
		LOG_INF("msg.Msgtype    = %d[%s]\n", iMsgtype, get_msg_name(iMsgtype));
		LOG_INF("msg.Sequence   = %d\n", ntohl(pMsgHead->iSequence));

		switch (iMsgtype) {
		case MSG_TYPE_REGISTER:
		{
			msgv1_register_t *pMsgReg = (msgv1_register_t *)pMsgHead;
			int iLocation = ntohl(pMsgReg->iLocation);
			int iStatus = ntohl(pMsgReg->iStatus);
			int iVehHeadDirect = ntohl(pMsgReg->iVehHeadDirect);
			int iChargeType = ntohl(pMsgReg->iChargeType);
			//int iPalletStatus = ntohl(pMsgReg->iPalletStatus);

			LOG_INF("msg.Location   = %d\n", iLocation);
			LOG_INF("msg.Status     = %d\n", iStatus);
			LOG_INF("msg.HDirect    = %d[%s]\n", iVehHeadDirect, get_direct_desc(iVehHeadDirect));
			LOG_INF("msg.ChargeType = %d\n", iChargeType);
			//LOG_INF("msg.PStatus    = %d[%s]\n", iPalletStatus, get_pallet_status_desc(iPalletStatus));
			break;
		}
		case MSG_TYPE_OPERATE:
		{
			msgv1_operate_t *pMsgOperate = (msgv1_operate_t *)pMsgHead;

			int iAction = ntohl(pMsgOperate->iAction);
			int iLength = ntohl(pMsgOperate->iLength);
			int iWeight = ntohl(pMsgOperate->iWeight);
			int iSpeed = ntohl(pMsgOperate->iSpeed);
			int iPara = ntohl(pMsgOperate->iPara);

			LOG_INF("msg.Action     = %d[%s]\n", iAction, get_action_name(iAction));
			LOG_INF("msg.Length     = %d\n", iLength);
			LOG_INF("msg.Weight     = %d\n", iWeight);
			LOG_INF("msg.Speed      = %d\n", iSpeed);

			if ((iAction == ACTION_LAY) || (iAction == ACTION_RISE))
			{
				LOG_INF("msg.Direct     = %d[%s]\n", iPara, get_direct_desc(iPara));
				LOG_INF("msg.Container  = %s\n", pMsgOperate->cContainer);
			}
			else if ((iAction == ACTION_TURN_LEFT) || (iAction == ACTION_TURN_RIGHT)
				|| (iAction == ACTION_PALLET_TURN_LEFT) || (iAction == ACTION_PALLET_TURN_RIGHT))
				LOG_INF("msg.Angle      = %d\n", iPara);
			else
				LOG_INF("msg.Param      = %d\n", iPara);

			break;
		}
		case MSG_TYPE_CONFIRM:
		{
			msgv1_confirm_t *pMsgConfirm = (msgv1_confirm_t *)pMsgHead;
			int iConType = ntohl(pMsgConfirm->iConType);
			int iSequence = ntohl(pMsgConfirm->iSequence);

			LOG_INF("msg.ConMsgType = %d\n", iConType);
			LOG_INF("msg.ConSequeue = %d\n", iSequence);
			break;
		}
		case MSG_TYPE_EVENT:
		{
			msgv1_error_t  *pMsgError = (msgv1_error_t *)pMsgHead;
			int iErrorCode = ntohl(pMsgError->iError);

			LOG_INF("msg.ErrorCode  = %d[%s]\n", iErrorCode, get_err_str(iErrorCode));
			break;
		}
		case MSG_TYPE_ERROR_POINT:
		{
			msgv1_error_point_t *pMsgErrPoint = (msgv1_error_point_t *)pMsgHead;
			int iLocation = ntohl(pMsgErrPoint->iLocation);
			int iErrorCode = ntohl(pMsgErrPoint->iErrorCode);

			LOG_INF("msg.Location   = %d\n", iLocation);
			LOG_INF("msg.ErrorCode  = %d[%s]\n", iErrorCode, get_err_str(iErrorCode));
			break;
		}
		case MSG_TYPE_POINT:
		{
			msgv1_point_t *pMsgPoint = (msgv1_point_t *)pMsgHead;
			int iLocation = ntohl(pMsgPoint->iLocation);

			LOG_INF("msg.Location   = %d\n", iLocation);
			break;
		}
		case MSG_TYPE_FINISH:
		{
			msgv1_finish_t *pMsgFinish = (msgv1_finish_t *)pMsgHead;
			int iVehHeadDirect = ntohl(pMsgFinish->iVehHeadDirect);
			int iPalletDirect = ntohl(pMsgFinish->iPalletDirect);
			int iLocation = ntohl(pMsgFinish->iLocation);
			int iAction = ntohl(pMsgFinish->iAction);

			LOG_INF("msg.Action     = %d[%s]\n", iAction, get_action_name(iAction));
			LOG_INF("msg.HDirect    = %d\n", iVehHeadDirect);
			LOG_INF("msg.PDirect    = %d\n", iPalletDirect);
			LOG_INF("msg.Location   = %d\n", iLocation);
			break;
		}
		case MSG_TYPE_DEBUG:
		{
			msgv1_debug_t *pMsgDebug = (msgv1_debug_t *)pMsgBuff;
			enum_debug_cmd eCmd = (enum_debug_cmd)ntohl(pMsgDebug->iCmd);

			LOG_INF("msg.command    = %d[%s]\n", eCmd, get_debug_cmd_name(eCmd));
			break;
		}
		case MSG_TYPE_GET_PARAM:
		{
			msgv1_param_get_req_t *pMsgParam = (msgv1_param_get_req_t *)pMsgBuff;
			int iParamID = ntohl(pMsgParam->iParamID);
			LOG_INF("msg.ParamID    = %d\n", iParamID);
			break;
		}
			
		case MSG_TYPE_SET_PARAM:
		{
			msgv1_param_set_req_t *pMsgSetParam = (msgv1_param_set_req_t *)pMsgBuff;
			int iParamID = ntohl(pMsgSetParam->iParamID);
			int iParamValue = ntohl(pMsgSetParam->iParamValue);
			float fParamValue = (float)iParamValue / PRECISION;
			LOG_INF("msg.ParamID    = %d\n", iParamID);
			LOG_INF("msg.ParamValue = %.4f\n", fParamValue);
			break;
		}
			
		default:
			LOG_WRN("Unknow msg type\n");//add by tiger.44
			break;
		}
		LOG_INF("-----------------------\n");
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_tokennum_is_valid
* Description	     : judge udp recv msg is valid.
* Input 		     : iTokenNum: the token num of udp msg.
* Output		     : NONE
* Return		     : 0:valid; <0:invalid
*******************************************************************************/
int msgv1_tokennum_is_valid(int iTokenNum)
{
	//TODO: check TokenNum is valid
	if (g_stAgvConf.cDebugEnable == FALSE)
	{
		if ((iTokenNum != g_stAgvAttr.iTokenNum)
			&& (iTokenNum != RESERVE_TOKEN_ID)) //by tiger.34
		{
			LOG_INF("msg'token id[%d] != expect[%d]\n", iTokenNum, g_stAgvAttr.iTokenNum);
			return -1;
		}
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_is_valid
* Description	     : judge udp recv msg is valid.
* Input 		     : pMsgHead: the pointer of udp msg buff
* Input 		     : iMsgSize: the size of msg
* Output		     : NONE
* Return		     : 0:valid; <0:invalid
*******************************************************************************/
int msgv1_is_valid(const char * pMsgBuff, int iMsgSize)
{
	const msgv1_head_t * pMsgHead = (const msgv1_head_t *)pMsgBuff;
	msgv1_head_t stMsgHead = { 0 };

	if (pMsgHead == NULL) {
		LOG_WRN("pMsgHead is NULL\n");//add by jxu 20180709
		return -1;
	}

	stMsgHead.iMsgtype = ntohl(pMsgHead->iMsgtype);
	stMsgHead.iSequence = ntohl(pMsgHead->iSequence);

	if (sequence_is_valid(stMsgHead.iSequence, stMsgHead.iMsgtype) != 0) {
		// TODO:send error msg to console?
		// if not, the console will resend the msg req;
		LOG_WRN("msg'type[%d-%s] sequence[%d] is invalid, maybe processed\n", 
			stMsgHead.iMsgtype, get_msg_name(stMsgHead.iMsgtype), stMsgHead.iSequence);
		return -1;
	}

	//TODO:check token id

	return stMsgHead.iMsgtype;
}

/*******************************************************************************
* Function Name		 : msgv1_agv_register
* Description	     : agv register, should execute before create work_thread_create()
                     : and execute after init_xxxx_dev()
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_agv_register()
{
	char pMsgBuff[UDP_MSG_SIZE] = {0};
	msgv1_ack_t *pMsgRegAck = NULL;
	
	int iRet = 0;
	int iTryTime = 1;
	int iTimeOut = TIME_OUT_2S;
	int iCount = 0;
	int iChargeType = 0;
	
	//add by jxu 20180130: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		//MSB is the generation of DSP,add by tiger.36
		g_stAgvAttr.iMCVerDate = (g_stMcDev.iGeneration ) << 24 | g_stAgvAttr.iMcVersion;
		g_stAgvAttr.iTCVerDate = g_stAgvAttr.iTcVersion;
		iChargeType = ON_GROUND;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		g_stAgvAttr.iMCVerDate = g_stAgvAttr.iMcVersion;
		g_stAgvAttr.iTCVerDate = g_stAgvAttr.iMcVersion;
		iChargeType = g_stAgvConf.cChargeType;
	}
	//add by jxu 20180130: end

	// build a register msg
	msgv1_register_t stMsgReg =
	{
		.iMsgType = htonl(MSG_TYPE_REGISTER),
		.iSequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.iAgvName = htonl(g_stAgvAttr.iAgvName),
		.iLocation = htonl(g_stAgvAttr.iLocation),
		.iStatus = htonl(g_stAgvAttr.iStatus),
		.iBigVer = htonl(g_stAgvAttr.iBigVer),
		.iBigVerDate = htonl(g_stAgvAttr.iBigVerDate),
		.iMCVerDate = htonl(g_stAgvAttr.iMCVerDate),
		.iTCVerDate = htonl(g_stAgvAttr.iTCVerDate),
		.iDSPStatus = htonl(g_stAgvAttr.iDSPStatus),//add by tiger.54
		.iVehHeadDirect = htonl(g_stAgvAttr.iVehHeadDirect), //add by tiger.13
		.iChargeType = htonl(iChargeType), //add by tiger.40
		.iPalletStatus = htonl(g_stAgvAttr.iPalletStatus),
		.iBootMethod = htonl(g_stAgvAttr.iBootMethod),
		.iPalletDirection = htonl(g_stAgvAttr.iPalletDirect),//by tiger.105
	};
	LOG_INF("agv is %s,when register to console\n", ((AGV_OK == g_stAgvAttr.iDSPStatus)?"OK":"NOT OK"));//add by tiger.54

#if(DEBUG_AGV == TRUE)
	// print debug info for sending message
	LOG_DBG("send msg to console[%s:%d]\n", g_stAgvParm.cServerIp, g_stAgvParm.iMsgSendServerPort);
	msgv1_head_dump((const char *)&stMsgReg);
#endif

	while (iTryTime++) {
		if (iTryTime < 10)
			iTimeOut = TIME_OUT_2S;
		else if ((iTryTime >= 10) && (iTryTime < 20))
			iTimeOut = TIME_OUT_8S;
		else if ((iTryTime >= 20) && (iTryTime < 50))
			iTimeOut = TIME_OUT_20S;
		else
			iTimeOut = TIME_OUT_60S;

		iRet = send_msg2console(&stMsgReg, sizeof(stMsgReg));
		if (iRet < 0)
		{
			LOG_WRN("send register msg error:[%s]\n", strerror(errno));
			usleep(iTimeOut*1000); //100ms
			continue;
		}

		//wait console ack
		iCount = 10;
		while(iCount--)
		{
			int iMsgType = 0;
			int iMsgSize = 0;
			int iSequence = 0;
			int iTokenNum = 0;
			time_t iServerTime = 0;
		
			bzero(pMsgBuff, sizeof(pMsgBuff));
			// default: when no console, recv udp will be blocked
			iMsgSize = recv_udp(g_stAgvParm.iMsgSocketFd, pMsgBuff, UDP_MSG_SIZE, FALSE);
			pMsgRegAck = (msgv1_ack_t *)pMsgBuff;

			// Case1:recv udp msg from server failure
			if (iMsgSize <= 0) {
				usleep(100000); //100ms
				continue;
			}

			// Case2:msg type is not MSG_TYPE_REGISTER?
			iMsgType = ntohl(pMsgRegAck->iMsgtype);
			iSequence = ntohl(pMsgRegAck->iSequence);
			if (iMsgType != MSG_TYPE_REGISTER) {
				usleep(100000); //100ms
				continue;
			}

			// Case3:udp msg sequence is invalid
			iRet = sequence_is_valid(iSequence, iMsgType);
			if (iRet < 0) {
				usleep(100000); //100ms
				continue;
			}

			iTokenNum = ntohl(pMsgRegAck->iTokenNum);
			g_stAgvAttr.iTokenNum = iTokenNum;

			//start by tiger.72
			if (sizeof(msgv1_ack_t) <= iMsgSize)
			{
				iServerTime = ntohl(pMsgRegAck->iServerTime);
				if (write_rtc(iServerTime) == 0)
					LOG_INF("success sync console time\n");
				else
					LOG_WRN("!!!failed sync console time\n");
			}
			//end by tiger.72

			LOG_INF("recv ack of msg[%d-%s] sequence=%d, token id=%d\n",
				iMsgType, get_msg_name(iMsgType), iSequence, iTokenNum);

			g_stAgvAttr.iMoveStatus = agv_stop;
			return 0;
		}
		LOG_INF("recv ack of msg failed\n");
		usleep(iTimeOut * 1000);
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv1_deal_ack
* Description	     : deal the ack of udp recv msg.
* input			     : pMsgHead: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_deal_ack(const char * pMsgBuff, int iMsgSize)
{
	msgv1_ack_t * pMsgAck = (msgv1_ack_t *)pMsgBuff;
	int iRet = 0;
	int iMsgtype = 0;
	int iTokenNum = 0;
	int iSequence = 0;
	
	if (NULL == pMsgAck) {
		return -1;
	}	

	iMsgtype = ntohl(pMsgAck->iMsgtype);
	iTokenNum = ntohl(pMsgAck->iTokenNum);
	iSequence = ntohl(pMsgAck->iSequence);

	LOG_INF("recv ack of msg[%d-%s] sequence=%d\n",
		iMsgtype, get_msg_name(iMsgtype), iSequence);

	//TODO: check TokenNum is valid
	iRet = msgv1_tokennum_is_valid(iTokenNum);
	//modified by kedong, 20180212
	//we no need to check tokennum, when recv ack from console
	//msg'token id[1518416493] != expect[1518415658], 20180212 nanxiaoying agvname=462
	//if (iRet < 0)
	//	return -1;

	iRet = agv_sem_post(SEM_MSG_TYPE, iMsgtype, iSequence);
	if (iRet < -1)
	{
		LOG_ERR("post msg ack signal error:[%s]\n", strerror(errno));
		return -1;
	}

	return 0;
}
///end by tiger.31
/*******************************************************************************
* Function Name		 : msgv1_send_heartbeat
* Description	     : send heartbeat msg to console.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_send_heartbeat()
{
	int iRet = 0;
	int iException = atomic_read(&g_stAgvAttr.iException);//by tiger.67

	if (g_stAgvConf.cDebugEnable == TRUE)
	{
		msgv1_heartbeat_debug_t stHeartBeatDebug =
		{
			.iMsgType = htonl(MSG_TYPE_HEARTBEAT),
			.iSequence = htonl(get_seq(UDP_HEARTBEAT_SEQ_ID)),//by tiger.79
			.iAgvName = htonl(g_stAgvAttr.iAgvName),
			.iBattery = htonl((g_stAgvAttr.bms.uSoc)),
			.iSpeed = htonl(g_stAgvAttr.iSpeed),
			.iVehHeadDirect = htonl(g_stAgvAttr.iVehHeadDirect),
			.iLocation = htonl(g_stAgvAttr.iLocation),
			.iStatus = htonl(g_stAgvAttr.iStatus),
			.iGXOffset = htonl(g_stAgvAttr.iGXOffset),
			.iGYOffset = htonl(g_stAgvAttr.iGYOffset),
			.iGAngleOffset = htonl(g_stAgvAttr.iGAngleOffset),

			.iGsdev = htonl(g_stAgvAttr.iGsDev),
			.iGSdevFB = htonl(g_stAgvAttr.iGSDevFB),
			.iGSangle = htonl(g_stAgvAttr.iGSAngle),
			.iTAngleOffset = htonl(g_stAgvAttr.iTAngleOffset),
			.iSreamin = htonl(g_stAgvAttr.iSreamin),
			.iEvent = htonl(iException),//by tiger.63
			.iPath = htonl(g_stAgvAttr.iPath),
			.iNewTag = htonl(g_stAgvAttr.iNewTag),
			.iFinishTag = htonl(g_stAgvAttr.iFinishTag),

			.iMoveStatus = htonl(g_stAgvAttr.iMoveStatus),
			.iBatTemper = htonl(g_stAgvAttr.bms.uTemp - TEMPER_BASE),//add by jxu 20180709
			.iTokenNum = htonl(g_stAgvAttr.iTokenNum)// by tiger.34
		};

		iRet = send_msg2console(&stHeartBeatDebug, sizeof(stHeartBeatDebug));
		if (iRet < -1)
		{
			LOG_ERR("send agv heart beat error:[%s]\n", strerror(errno));
			return -1;
		}
	}
	else
	{
		msgv1_heartbeat_t stHeartBeat =
		{
			.iMsgType = htonl(MSG_TYPE_HEARTBEAT),
			.iSequence = htonl(get_seq(UDP_HEARTBEAT_SEQ_ID)),//by tiger.79
			.iAgvName = htonl(g_stAgvAttr.iAgvName),
			.iBattery = htonl((g_stAgvAttr.bms.uSoc)),
			.iSpeed = htonl(g_stAgvAttr.iSpeed),
			.iVehHeadDirect = htonl(g_stAgvAttr.iVehHeadDirect),
			.iLocation = htonl(g_stAgvAttr.iLocation),
			.iStatus = htonl(g_stAgvAttr.iStatus),
			.iGXOffset = htonl(g_stAgvAttr.iGXOffset),
			.iGYOffset = htonl(g_stAgvAttr.iGYOffset),
			.iGAngleOffset = htonl(g_stAgvAttr.iGAngleOffset),
			.iTXOffset = htonl(g_stAgvAttr.iTXOffset),
			.iTYOffset = htonl(g_stAgvAttr.iTYOffset),
			.iTAngleOffset = htonl(g_stAgvAttr.iTAngleOffset),
			.iMoveStatus = htonl(g_stAgvAttr.iMoveStatus),
			.iBatTemper = htonl(g_stAgvAttr.bms.uTemp - TEMPER_BASE),//add by jxu 20180709
			//.iBatUnitMaxVoltage =  htonl(g_stAgvAttr.bms.iBattCellVoltMax), //add by tiger.98
			.iTokenNum = htonl(g_stAgvAttr.iTokenNum)// by tiger.34
		};

		iRet = send_msg2console(&stHeartBeat, sizeof(stHeartBeat));
		if (iRet < -1)
		{
			LOG_ERR("send agv heart beat error:[%s]\n", strerror(errno));
			return -1;
		}
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv1_send_event
* Description	     : send error msg to console.
* Input 		     : iErrorCode: error num.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_send_event(int iEventType, int iErrorCode)
{
	int iRet = 0;
	iErrorCode = abs(iErrorCode);

	msgv1_error_t stMsgErr =
	{
		.iMsgType = htonl(MSG_TYPE_EVENT),
		.iSequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.iAgvName = htonl(g_stAgvAttr.iAgvName),
		.iLocation = htonl(g_stAgvAttr.iLocation),
		.iError = htonl(iErrorCode),
		.iXoffset = htonl(g_stAgvAttr.iGXOffset),
		.iYoffset = htonl(g_stAgvAttr.iGYOffset),
		.iAngle = htonl(g_stAgvAttr.iGAngleOffset),
		.iTokenNum = htonl(g_stAgvAttr.iTokenNum),// by tiger.34
		.iSubErrorCode = htonl(0)//add by jxu 20180510
	};

	// first of all, print the error information
	LOG_INF("append error/event msg[%d-%s] to error rx queue\n", iErrorCode, get_err_str(iErrorCode));

	if (iErrorCode == EVENT_ERR_AGVSAFE || iErrorCode == EVENT_ERR_NOCONTACTIMPACT)
	{
		iRet = msgv1_send_error_point(iErrorCode);
		return iRet;
	}

	iRet = linkqueue_append(g_stAgvParm.pErrorRxQueue, &iErrorCode, sizeof(int));	// save to list
	if (iRet < 0)
	{
		LOG_ERR("append msg to Error RX queue failure\n");
	}

	iRet = linkqueue_append(g_stAgvParm.pUdpTxQueue, &stMsgErr, sizeof(stMsgErr));
	if (iRet < 0) {
		LOG_ERR("append error msg to udp tx queue failure\n");
		return iRet;
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv1_send_event_suberror
* Description	     : send error msg to console.
* Input 		     : iErrorCode: error num.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_send_event_suberror(int iEventType, int iErrorCode,int iSubError)
{
	int iRet = 0;
	iErrorCode = abs(iErrorCode);

	msgv1_error_t stMsgErr =
	{
		.iMsgType = htonl(MSG_TYPE_EVENT),
		.iSequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.iAgvName = htonl(g_stAgvAttr.iAgvName),
		.iLocation = htonl(g_stAgvAttr.iLocation),
		.iError = htonl(iErrorCode),
		.iXoffset = htonl(g_stAgvAttr.iGXOffset),
		.iYoffset = htonl(g_stAgvAttr.iGYOffset),
		.iAngle = htonl(g_stAgvAttr.iGAngleOffset),
		.iTokenNum = htonl(g_stAgvAttr.iTokenNum),// by tiger.34
		.iSubErrorCode = htonl(iSubError)//add by jxu 20180510
	};

	// first of all, print the error information
	LOG_INF("append error/event msg[%d-%s] to error rx queue\n", iErrorCode, get_err_str(iErrorCode));

	if (iErrorCode == EVENT_ERR_AGVSAFE || iErrorCode == EVENT_ERR_NOCONTACTIMPACT)
	{
		iRet = msgv1_send_error_point(iErrorCode);
		return iRet;
	}

	iRet = linkqueue_append(g_stAgvParm.pErrorRxQueue, &iErrorCode, sizeof(int));	// save to list
	if (iRet < 0)
	{
		LOG_ERR("append msg to Error RX queue failure\n");
	}

	iRet = linkqueue_append(g_stAgvParm.pUdpTxQueue, &stMsgErr, sizeof(stMsgErr));
	if (iRet < 0) {
		LOG_ERR("append error msg to udp tx queue failure\n");
		return iRet;
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv1_send_error_point
* Description	     : send error piont msg to console.
* input			     : iErrorCode: the code of error
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_send_error_point(int iErrorCode)
{
	int iRet = 0;

	//TODO: check TokenNum is valid
	if (g_stAgvConf.cDebugEnable == TRUE)
	{
		//just for test agent,TODO
		LOG_WRN("Not send EVENT_ERR_NOCONTACTIMPACT and EVENT_ERR_AGVSAFE to test agent\n");
		return 0;
	}

	//Safe event and Non-contact impact
	msgv1_error_point_t stErrPoint =
	{
		.iMsgType = htonl(MSG_TYPE_ERROR_POINT),
		.iSequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.iAgvName = htonl(g_stAgvAttr.iAgvName),
		.iLocation = htonl(g_stAgvAttr.iLocation),
		.iVehHeadDirect = htonl(g_stAgvAttr.iVehHeadDirect),
		.iTokenNum = htonl(g_stAgvAttr.iTokenNum), // by tiger.34
		.iErrorCode = htonl(iErrorCode) // add by kedong. 20180321
	};

	iRet = linkqueue_append(g_stAgvParm.pUdpTxQueue, &stErrPoint, sizeof(stErrPoint));
	if (iRet < 0)
	{
		LOG_ERR("append error point msg to udp tx queue failure\n");
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_send_finish
* Description	     : send finish msg to console.
* input			     : iAction�� the action type of operate msg
*					 : ACTION_WALK			1
*					 : ACTION_TURN_LEFT		2
*					 : ACTION_TURN_RIGHT	3
*					 : ACTION_RISE     	  	4
*					 : ACTION_LAY      	  	5
*					 : ACTION_CHARGE		6
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_send_finish(int iAction)
{
	int iRet = 0;

	msgv1_finish_t stFin =
	{
		.iMsgType = htonl(MSG_TYPE_FINISH),
		.iSequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.iAgvName = htonl(g_stAgvAttr.iAgvName),
		.iAction = htonl(iAction),
		.iPalletDirect = htonl(g_stAgvAttr.iPalletDirect),
		.iVehHeadDirect = htonl(g_stAgvAttr.iVehHeadDirect),
		.iLocation = htonl(g_stAgvAttr.iLocation),
		.iTokenNum = htonl(g_stAgvAttr.iTokenNum)// by tiger.34
	};

	iRet = linkqueue_append(g_stAgvParm.pUdpTxQueue, &stFin, sizeof(stFin));
	if (iRet < 0) {		
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_send_point
* Description	     : send point msg to console.
* input			     : iLocation : the location value
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_send_point(int iLocation, int iDriverMode) //change by tiger.22
{
	int iRet = 0;

	msgv1_point_t stPoint =
	{
		.iMsgType = htonl(MSG_TYPE_POINT),
		.iSequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.iAgvName = htonl(g_stAgvAttr.iAgvName),
		.iVehHeadDirect = htonl(g_stAgvAttr.iVehHeadDirect),
		.iLocation = htonl(iLocation),
		.iTokenNum = htonl(g_stAgvAttr.iTokenNum)// by tiger.34
	};

	iRet = linkqueue_append(g_stAgvParm.pUdpTxQueue, &stPoint, sizeof(stPoint));
	if (iRet < 0) {
		LOG_WRN("append point msg to udp tx queue failure\n");
		return iRet;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_send_param
* Description	     : send param msg to console.
* input			     : iLocation : the location value
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_send_param(const char * pMsgBuff)
{
	int iRet = 0;

	msgv1_param_ack_t *pMsgParam = (msgv1_param_ack_t *)pMsgBuff;

	iRet = send_msg2console(pMsgParam, sizeof(msgv1_param_ack_t));
	if (iRet < 0) {
		LOG_WRN("append param ack msg to udp tx queue failure\n");
		return iRet;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_send_confirm
* Description	     : send confirm msg to console.
* input			     : iType: msg type to confirm
* input			     : iSeq : msg sequence to confirm.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_send_confirm(int iMsgType, int iSeq)
{
	int iRet = 0;
	int iTryTime = 1;
	int iTimeOut = TIME_OUT_2S;
	int iSequence = get_seq(AGENENT_SEQ_ID);
	agv_sem_t *pAgvSem = NULL;

	msgv1_confirm_t stMsgConfirm =
	{
		.iMsgType = htonl(MSG_TYPE_CONFIRM),
		.iSequence = htonl(iSequence),
		.iAgvName = htonl(g_stAgvAttr.iAgvName),
		.iConType = htonl(iMsgType),
		.iConSeq = htonl(iSeq),
		.iTokenNum = htonl(g_stAgvAttr.iTokenNum)// by tiger.34
	};

	while (iTryTime++) {
#if(DEBUG_AGV == TRUE)
		// print debug info for sending message
		LOG_DBG("send udp msg[24-MSG_TYPE_CONFIRM] sequence=%d to console[%s:%d]\n",
			iSequence, g_stAgvParm.cServerIp, g_stAgvParm.iMsgSendServerPort);
		//msgv1_head_dump((const char *)&stMsgConfirm);
#endif
		if (iTryTime < 10)
			iTimeOut = TIME_OUT_4S / 10;//by tiger.75
		else if ((iTryTime >= 10) && (iTryTime < 20))
			iTimeOut = TIME_OUT_8S / 10;//by tiger.75
		else if ((iTryTime >= 20) && (iTryTime < 50))
			iTimeOut = TIME_OUT_10S / 10;//by tiger.75
		else
			iTimeOut = TIME_OUT_20S / 10;//by tiger.75

		//add sem before send confirm udp msg to console
		pAgvSem = agv_sem_add(SEM_MSG_TYPE, MSG_TYPE_CONFIRM, iSequence);
		if (NULL == pAgvSem)
		{
			LOG_ERR("add get param sem failed\n");
		}
		iRet = send_msg2console(&stMsgConfirm, sizeof(stMsgConfirm));
		if (iRet < 0)
		{
			LOG_WRN("send confirm msg error:[%s]\n", strerror(errno));
			usleep(iTimeOut * 1000); //iTimeOut
			continue;
		}

		// wait for confirm ack from console
		iRet = agv_sem_wait(SEM_MSG_TYPE, MSG_TYPE_CONFIRM, iSequence, iTimeOut);
		if (0 == iRet)
		{
			// must get iMsgtype, iSequence from recv msg
			int iMsgtype = ntohl(stMsgConfirm.iMsgType);
			int iSequence = ntohl(stMsgConfirm.iSequence);

			agv_sem_clean(SEM_MSG_TYPE, iMsgtype, iSequence);

			iRet = 0;
			break;
		}
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv1_send_ack
* Description	     : send ack msg to console.
* input			     : pMsgHead: the msg head recieved .
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_send_ack(const char * pMsgBuff)
{
	msgv1_operate_ack_t stAckMsg = { 0 };
	int iMsgtype = 0;
	int iSequence = 0;
	int iRet = 0;

	if (pMsgBuff == NULL)
		return -1;

	stAckMsg = *((msgv1_operate_ack_t *)pMsgBuff);
	stAckMsg.iTokenNum = htonl(g_stAgvAttr.iTokenNum);//add by tiger.34

	iMsgtype = ntohl(stAckMsg.iMsgtype);
	iSequence = ntohl(stAckMsg.iSequence);	

#if(DEBUG_AGV == TRUE)
	// print debug info for sending message
	LOG_DBG("send udp msg[%d-%s]'ACK sequence=%d to console[%s:%d]\n",
		iMsgtype, get_msg_name(iMsgtype), iSequence,
		g_stAgvParm.cServerIp, g_stAgvParm.iMsgSendServerPort);
	//msgv1_head_dump((const char *)&stAckMsg);
#endif

	iRet = send_msg2console(&stAckMsg, sizeof(stAckMsg));
	if (iRet < 0)
	{
		LOG_ERR("send ack msg failure\n");
		return -1;
	}

	return 0;
}

/*******************************************************************************
*Function Name    :msgv1_send_batt_info
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :void  
*******************************************************************************/
int msgv1_send_batt_info()
{
	int iRet = 0;
	float fVoltage = 0;
	float fCurrent = 0;

	msgv1_batt_info_t stMsgBatt =
	{
		.iMsgtype = htonl(MSG_TYPE_INFO),
		.iSequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.iAgvName = htonl(g_stAgvAttr.iAgvName),
		.iTemp = htonl(g_stAgvAttr.bms.uTemp - TEMPER_BASE),
		.iTokenNum = htonl(g_stAgvAttr.iTokenNum) //by tiger.34
	};

	iRet = send_msg2console(&stMsgBatt, sizeof(stMsgBatt));
	if (iRet >= 0)
	{
		fVoltage = (float)g_stAgvAttr.bms.uVoltage / 10;
		fCurrent = (float)g_stAgvAttr.bms.uCurrent / 10;
		LOG_INF("send battery temperature:[%dC],voltage:[%.2fV],current[%.2fA],battery:[%d%],state:[%s]\n",
			ntohl(stMsgBatt.iTemp), fVoltage, fCurrent, g_stAgvAttr.bms.uSoc,
			(g_stAgvAttr.bms.uState == 1) ? "charging" : "not charging");
	}
	else
	{
		LOG_WRN("send battery temperature failure:%s\n", strerror(errno));
	}
	
	return iRet;
}

/*******************************************************************************
* Function Name		 : compute_task_head_direct
* Description	     : compute vehicle head direct in task.
* input			     : iSrcLocation: the first location point in task.
* input			     : iDstLocation: the last  location point in task.
* Output		     : NONE
* Return		     : vehicle head direction(0~4)
*******************************************************************************/
static int compute_task_head_direct(int iSrcLocation, int iDstLocation)
{
	int iTaskHeaderDirect = INVALID_DIRECTION;

	if ((iSrcLocation == INVALID_POINT) || (iDstLocation == INVALID_POINT))
		return iTaskHeaderDirect;

	if ((iDstLocation - iSrcLocation) >= 10000) //Positive direction of X axis,go and go will be 1000,2000,3000
		iTaskHeaderDirect = DIRECTION_X_P;
	else if ((iDstLocation - iSrcLocation) <= -10000)//Negative direction of X axis
		iTaskHeaderDirect = DIRECTION_X_N;
	else if ((iDstLocation - iSrcLocation) >= 1)//Positive direction of Y axis
		iTaskHeaderDirect = DIRECTION_Y_P;
	else if ((iDstLocation - iSrcLocation) <= -1)//Negative direction of Y axis
		iTaskHeaderDirect = DIRECTION_Y_N;

	return iTaskHeaderDirect;
}

/*******************************************************************************
* Function Name		 : check_task_point_valid
* Description	     : check vehicle head direct and next to.
* input			     : iFirstPoint: the first location point in task.
* input			     : iSecondPoint: the second location point in task.
* Output		     : NONE
* Return		     : int 0 if OK,-1 on error
*******************************************************************************/
static int check_task_point_valid(int iFirstPoint, int iSecondPoint)
{
	int iAbs = 0;

	if ((iFirstPoint == INVALID_POINT) || (iSecondPoint == INVALID_POINT))
		return -1;

	iAbs = abs(iSecondPoint - iFirstPoint);
	if ((iAbs == 10000) || (iAbs == 1))
		return 0;
	else
		return -1;

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_dump_walk_path
* Description	     : dump walk path in the operate msg
* input			     : pMsgOperate : the pointer of msgv1_operate
* Output		     : NONE
* Return		     : 0: success; <0: failure
*******************************************************************************/
int msgv1_dump_walk_path(const char * pMsgBuff)
{
	msgv1_operate_t *pMsgOperate = (msgv1_operate_t *)pMsgBuff;
	msgv1_operate_t stMsgOperate = { 0 };
	int i = 0;
	int iNum = 0;
	int iPointCurr = 0;

	if (pMsgOperate == NULL) {
		return -1;
	}

	stMsgOperate.iAction = ntohl(pMsgOperate->iAction);
	stMsgOperate.iLength = ntohl(pMsgOperate->iLength);
	if (stMsgOperate.iAction != ACTION_WALK)
	{
		LOG_ERR("the action[%d-%s] in task is not ACTION_WALK\n",
			stMsgOperate.iAction, get_action_name(stMsgOperate.iAction));
		return -1;
	}

	LOG_INF("-----------------------\n");

	///get the value and the number of point,start by tiger.45
	for (i = 0; i < MAX_WALK_POINT; i++)
	{
		iPointCurr = ntohl(pMsgOperate->iPoint[i]);
		if (0 == iPointCurr )
		{
			iNum = i;
			break;
		}
		LOG_INF("[%d] = %d\n", i, iPointCurr);
	}
	//if (0!=iNum)
		//g_stAgvTask.iQRDistance = stMsgOperate.iLength / iNum; //add by jxu 20180719
	LOG_INF("-----------------------\n");
	//LOG_INF("walk path [%d] points g_stAgvTask.iQRDistance=%d\n", iNum, stMsgOperate.iLength);//add by jxu 20180719
	///end by tiger.45
	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_check_walk_path
* Description	     : check the walking path and add the point to path queue
* input			     : pMsgOperate : the pointer of msgv1_operate
* Output		     : NONE
* Return		     : 0: success; <0: failure
*******************************************************************************/
int msgv1_check_walk_path(const char * pMsgBuff)
{
	msgv1_operate_t *pMsgOperate = (msgv1_operate_t *)pMsgBuff;
	msgv1_operate_t stMsgOperate = { 0 };
	int i = 0;
	int iRet = 0;
	int iNum = 0;
	int iTaskSrcPoint = 0;
	int iTaskCheckPoint = 0;
	int iTaskDstPoint = 0;
	int iLastSrcLocation = g_stAgvTask.iSrcPoint;
	int iLastDstLocation = g_stAgvTask.iDstPoint;
	int iCurLocation = 0;
	int iPointPrev = 0;
	int iPointCur = 0;

	if (pMsgOperate == NULL) {
		return -1;
	}

	stMsgOperate.iAction = ntohl(pMsgOperate->iAction);
	stMsgOperate.iLength = ntohl(pMsgOperate->iLength);
	if (stMsgOperate.iAction != ACTION_WALK) 
	{
		LOG_ERR("the action[%d-%s] in task is not ACTION_WALK\n", 
			stMsgOperate.iAction, get_action_name(stMsgOperate.iAction));
		return -1;
	}


	LOG_INF("-----------------------\n");
	for (i = 1; i < MAX_WALK_POINT; i++) //change by tiger.27, drop push the first point	
	{
		iPointPrev = ntohl(pMsgOperate->iPoint[i-1]);
		iPointCur = ntohl(pMsgOperate->iPoint[i]);

		if (0 == iPointCur)//get the num of point,add by tiger.45
		{
			iNum = i - 1;
			break;
		}
			
		//save the first point in iTaskSrcPoint
		if (i == 1)
		{
			LOG_INF("[%d] = %d\n", 0, iPointPrev);
			iTaskSrcPoint = iPointPrev;
		}

		iRet = check_task_point_valid(iPointPrev, iPointCur);
		if (iRet < 0) {
			LOG_ERR("check task point valid failure, the point[%d->%d] is invalid\n", iPointPrev, iPointCur);
			break;
		}

		//save the last point in iTaskDstPoint
		iTaskDstPoint = iPointCur;

		LOG_INF("[%d] = %d\n", i, iPointCur);
	}
	LOG_INF("-----------------------\n");
	if(0 != iNum)
		g_stAgvTask.iQRDistance = stMsgOperate.iLength / iNum; //add by jxu 20180719
	LOG_INF("walk path [%d] points g_stAgvTask.iQRDistance=%d\n", iNum, g_stAgvTask.iQRDistance); //add by jxu 20180719

	if (iRet < 0)
	{
		LOG_ERR("the action[%d-%s] in task is not ACTION_WALK\n",
			stMsgOperate.iAction, get_action_name(stMsgOperate.iAction));
		send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_TASK_ERROR);
		return iRet;
	}
	///start by tiger.27
	//ֱ��������Ч���ж��Ż���·������Ϊ��ʱ���������͵�ǰ��ȣ��������һ�������յ�Ƚϣ�by tiger.103
	if (linkqueue_length(g_stAgvParm.pPathQueue) <= 0)	//��ȡУ��� by tiger.103
	{
		iCurLocation = g_stAgvAttr.iLocation;
		iTaskCheckPoint = iCurLocation;
	}		
	else
		iTaskCheckPoint = iLastDstLocation;
	//check iTaskSrcPoint is equal the iTaskCheckPoint?
	if (iTaskCheckPoint == iTaskSrcPoint)
	{
		LOG_INF("the task's first point[%d]=check point[%d],CurLocation =[%d]\n", 
			iTaskSrcPoint, iTaskCheckPoint,iCurLocation);
	}	
	else
	{
		LOG_ERR("the task's first point[%d]!=check point[%d],CurLocation =[%d]\n",
			iTaskSrcPoint, iTaskCheckPoint, iCurLocation);
		send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_WRONG_LOCATION);
		return -1;
	}
	///end by tiger.27

	g_stAgvTask.iSrcPoint = iTaskSrcPoint;
	g_stAgvTask.iDstPoint = iTaskDstPoint;

	//add task's point into pPathQueue for point report
	for (i = 1; i <= iNum && i < MAX_WALK_POINT; i++)  //change by tiger.27, drop push the first point
	{
		iPointCur = ntohl(pMsgOperate->iPoint[i]);
		iRet = linkqueue_append(g_stAgvParm.pPathQueue, &(iPointCur), sizeof(int));
		if (iRet < 0) {
			break;
		}
	}

	return iRet;
}

/*******************************************************************************
*Function Name    :msgv1_deal_action_result
*Description      :deal the result of device action ,such as :turn left
*Input       	  :int iRet  
*Input       	  :bool bNeedSendFinish: report finish msg to console if true;else need not report  
*Input       	  :int iAction:the action id of task  
*Output 		  :
*Return           :void  
*******************************************************************************/
int msgv1_deal_action_result(int iRet, bool bNeedSendFinish, int iAction)
{
	int iErrorCode = abs(iRet);
	int iResult = 0;
	int iMcError = 0;
	int iException = NO_EVENT_ERR;//by tiger.81
	// modified by kedong, 20180305
	// update the navgate data into mcu log every action
	// when ACTION_WALK, update_mcu_log in parse_groudqr()
	if (iAction != ACTION_WALK)
	{
		update_mcu_log();
		//start ,add by tiger.51
		//iResult = sta_send_event_info(SATISTICAL_SEND_PERIOD_30S);
		iResult = sta_send_event_info(SATISTICAL_SEND_NOW);
		if (iResult < 0)
		{
			LOG_WRN("send statistical event info failed:[%d-%s]", errno, strerror(errno));
		}
		//end ,add by tiger.51

	}
		

	//when iAction == ACTION_CHARGE, CAN NOT set iMoveStatus = agv_stop
	if (iAction != ACTION_CHARGE)
		g_stAgvAttr.iMoveStatus = agv_stop;//add by tiger

	switch (iRet)
	{
	case OK: //action finished
		if (true == bNeedSendFinish)
		{
			LOG_INF("operate[%d-%s] finish\n", iAction, get_action_name(iAction));
			if (msgv1_send_finish(iAction) < 0 )
			{
				LOG_ERR("append finish msg[%d-%s] to udp tx queue failure\n",
					iAction, get_action_name(iAction));
			}
		}
		else
		{
			if (iAction == ACTION_WALK)
			{
				LOG_INF("operate[%d-%s] with walk continue, so no need send finish msg\n",
					iAction, get_action_name(iAction));
			}
			else
			{
				LOG_INF("operate[%d-%s] may is not from console, so no need send finish msg\n",
					iAction, get_action_name(iAction));
			}
		}
		break;
	case 0:
		LOG_INF("deal [%d-%s] success\n", iAction, get_action_name(iAction));
		break;
	case -1://CAN communicate failed
		LOG_INF("send [%d-%s] CAN frame failure\n", iAction, get_action_name(iAction));
		break;
	case REFUSE:
		LOG_INF("append error msg[%d-%s] to udp tx queue\n",
			EVENT_ERR_MCREFUSE, get_err_str(EVENT_ERR_MCREFUSE));
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_MCREFUSE) < 0)
		{
			LOG_ERR("append error msg[%d-%s] to udp tx queue failure\n",
				EVENT_ERR_MCREFUSE, get_err_str(EVENT_ERR_MCREFUSE));
		}		
		break;
	case BERROR:
		LOG_INF("append send error msg[%d-%s] to udp tx queue\n",
			EVENT_ERR_PARKPRECISION, get_err_str(EVENT_ERR_PARKPRECISION));
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_PARKPRECISION) < 0)
		{
			LOG_ERR("append error msg[%d-%s] to udp tx queue failure\n",
				EVENT_ERR_PARKPRECISION, get_err_str(EVENT_ERR_PARKPRECISION));
		}				
		break;
	case IS_UP:
		LOG_INF("append finish msg[%d-%s] to udp tx queue\n", iAction, get_action_name(iAction));
		if (msgv1_send_finish(ACTION_RISE) < 0)
		{
			LOG_INF("append finish msg[4-ACTION_RISE] to udp tx queue failure\n");
		}
		break;
	case IS_DOWN:
		LOG_INF("append finish msg[%d-%s] finish msg to udp tx queue\n", iAction, get_action_name(iAction));
		if (msgv1_send_finish(ACTION_LAY) < 0)
		{
			LOG_WRN("append finish msg[5-ACTION_LAY] to udp tx queue failure\n");
		}
		break;
	case -EVENT_ERR_MC_TIMEOUT:
		LOG_WRN("MC excute [%d-%s] timeout\n", iAction, get_action_name(iAction));
		iMcError = EVENT_ERR_MC_TIMEOUT; //by tiger.81

	case -EVENT_ERR_TC_TIMEOUT:
		if(EVENT_ERR_MC_TIMEOUT != iMcError)
			LOG_WRN("TC excute [%d-%s] timeout\n", iAction, get_action_name(iAction));
		iException = atomic_read(&g_stAgvAttr.iException);//by tiger.81
		// when exception happen, will be cause timeout
		// in this case, no need send event to console
		if (!((NO_EVENT_ERR == iException) || (EVENT_ERR_NOCONTACTIMPACT == iException) || (EVENT_ERR_AGVSAFE == iException)))//by tiger.81
			break;
	default: //deal exception error code
		LOG_INF("execute action[%d-%s] with result[%d-%s], NeedSendFinish=%d\n",
			iAction, get_action_name(iAction), iErrorCode, get_err_str(iErrorCode), bNeedSendFinish);

		if (send_error_msg(EVENT_TYPE_ERROR, iErrorCode) < 0)
		{
			LOG_ERR("append error msg[%d-%s] to udp tx queue failure\n", 
				iErrorCode, get_err_str(iErrorCode));
		}
		else
		{
			LOG_INF("append error msg[%d-%s] to udp tx queue success\n", 
				iErrorCode, get_err_str(iErrorCode));
		}		
		break;
	}
}

/*******************************************************************************
*Function Name    :msgv1_deal_action_v2_result
*Description      :deal the result of device action ,such as :turn left
*Input       	  :int iRet
*Input       	  :bool bNeedSendFinish: report finish msg to console if true;else need not report
*Input       	  :int iAction:the action id of task
*Output 		  :
*Return           :void
*******************************************************************************/
void msgv1_deal_action_v2_result(int iRet, bool bNeedSendFinish, int iAction)
{
	int iErrorCode = abs(iRet);
	int iResult = 0;
	int iException = NO_EVENT_ERR; //by tiger.81
	// modified by kedong, 20180305
	// update the navgate data into mcu log every action
	// when ACTION_WALK, update_mcu_log in parse_groudqr()
	if (iAction != ACTION_WALK)
	{
		update_mcu_log();
		
		//start ,add by tiger.51
		//iResult = sta_send_event_info(SATISTICAL_SEND_PERIOD_30S);
		iResult = sta_send_event_info(SATISTICAL_SEND_NOW);
		if (iResult < 0)
		{
			LOG_WRN("send statistical event info failed:[%d-%s]", errno, strerror(errno));
		}
		//end ,add by tiger.51
	}
		

	//when iAction == ACTION_CHARGE, CAN NOT set iMoveStatus = agv_stop
	if (iAction != ACTION_CHARGE)
		g_stAgvAttr.iMoveStatus = agv_stop;//add by tiger

	switch (iRet)
	{
	case OK://action finished
		if (true == bNeedSendFinish)
		{
			LOG_INF("append finish msg[%d-%s] to udp tx queue\n",
				iAction, get_action_name(iAction));
			if (send_finish_msg(iAction) < 0)
			{
				LOG_ERR("append [%d-%s] fininsh msg to udp tx queue failure\n", iAction, get_action_name(iAction));
			}
		}
		else
		{
			LOG_INF("the [%d-%s] is not from console, and need not send finish msg\n", iAction, get_action_name(iAction));
		}
		break;
	case 0:
		LOG_INF("deal [%d-%s] success\n", iAction, get_action_name(iAction));
		break;
	case -1://CAN communicate failed
		LOG_INF("send [%d-%s] CAN frame failure\n", iAction, get_action_name(iAction));
		break;
	case MC_ACTION_ACK_PARAM_ERR_V2:
		LOG_WRN("MC excute [%d-%s] parmeter error\n", iAction, get_action_name(iAction));
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_PARAM_ERROR) < 0)
		{
			LOG_ERR("append EVENT_ERR_PARAM_ERROR to udp Tx queue failed\n");
		}
		break;
	case MC_ACTION_ACK_MC_ERR_V2:
		LOG_WRN("MC excute [%d-%s] error\n", iAction, get_action_name(iAction));
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_MC_EXCEPTION) < 0)
		{
			LOG_ERR("append EVENT_ERR_MC_EXCEPTION to udp Tx queue failed\n");
		}
		break;
	case MC_ACTION_ACK_PARK_PRECESION_ERR_V2:
		LOG_INF("send EVENT_ERR_PARKPRECISION fininsh msg to console\n");
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_PARKPRECISION) < 0)
		{
			LOG_ERR("append EVENT_ERR_PARKPRECISION to udp tx queue failure\n");
		}
		break;
	case MC_ACTION_ACK_PLATE_UP_LEVEL_V2:
		LOG_INF("send [%d-%s] finish msg to console\n", iAction, get_action_name(iAction));
		if (send_finish_msg(ACTION_RISE) < 0)
		{
			LOG_INF("append ACTION_RISE to udp tx queue failure\n");
		}
		break;
	case MC_ACTION_ACK_PLATE_DOWN_LEVEL_V2:
		LOG_INF("send [%d-%s] finish msg to console\n", iAction, get_action_name(iAction));
		if (send_finish_msg(ACTION_LAY) < 0)
		{
			LOG_INF("append ACTION_LAY to udp tx queue failure\n");
		}
		break;
	case MC_ACTION_ACK_REFUSE_V2:
		LOG_INF("send EVENT_ERR_MCREFUSE fininsh msg to console\n");
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_MCREFUSE) < 0)
		{
			LOG_ERR("append EVENT_ERR_MCREFUSE to udp tx queue failure\n");
		}
		break;
	case -EVENT_ERR_MC_TIMEOUT:
		LOG_WRN("MC excute [%d-%s] timeout\n", iAction, get_action_name(iAction));
		iException = atomic_read(&g_stAgvAttr.iException);//by tiger.81
		// when exception happen, will be cause timeout
		// in this case, no need send event to console
		if (!((NO_EVENT_ERR == iException) || (EVENT_ERR_NOCONTACTIMPACT == iException) || (EVENT_ERR_AGVSAFE == iException)))//by tiger.81
			break;
	default: //deal exception error code
		LOG_INF("execute action[%d-%s] with result[%d-%s], NeedSendFinish=%d\n",
			iAction, get_action_name(iAction), iErrorCode, get_err_str(iErrorCode), bNeedSendFinish);

		if (send_error_msg(EVENT_TYPE_ERROR, iErrorCode) < 0)
		{
			LOG_ERR("append error msg[%d-%s] to tx queue failure\n", iErrorCode, get_err_str(iErrorCode));
		}
		else
		{
			LOG_INF("send [%d-%s] error msg to console\n", iErrorCode, get_err_str(iErrorCode));
		}
		break;
	}
}

/*******************************************************************************
* Function Name		 : msgv1_deal_operate
* Description	     : parse operate msg to can msg.
* input			     : pMsg: the operate msg.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_deal_operate(const char * pMsgBuff)
{
	msgv1_operate_t stMsgOperate = { 0 };
	msgv1_operate_t * pMsgOperate = (msgv1_operate_t *)pMsgBuff;
	int iRet = 0;
	bool bNeedSendFinish = false;
	int iAction = 0;

	if (NULL == pMsgOperate) {
		return -1;
	}

	stMsgOperate.iMsgtype = ntohl(pMsgOperate->iMsgtype);
	stMsgOperate.iSequence = ntohl(pMsgOperate->iSequence);

	stMsgOperate.iAction = ntohl(pMsgOperate->iAction);
	stMsgOperate.iLength = ntohl(pMsgOperate->iLength);
	stMsgOperate.iWeight = ntohl(pMsgOperate->iWeight);
	stMsgOperate.iSpeed = ntohl(pMsgOperate->iSpeed);
	stMsgOperate.iPara = ntohl(pMsgOperate->iPara);
	stMsgOperate.iTokenNum = ntohl(pMsgOperate->iTokenNum);//add by tiger.34

	iAction = stMsgOperate.iAction;

	if (iAction >= ACTION_TYPE_NUM)
	{
		LOG_WRN("recv action %d not supported\n", iAction);
		return -1;
	}

	//add by jxu 20180820-begin-solve 3002 when rececive the action is not STOP_CHARGE in charging mode.
	if ((agv_charge == g_stAgvAttr.iMoveStatus) && (iAction != ACTION_STOP_CHARGE))
	{
		LOG_WRN("The action[%d-%s] which is not STOP_CHARGE when the agv is in charge mode\n", 
			iAction, get_action_name(iAction));
		iRet = stop_charge();
		if (iRet < 0)
		{
			LOG_WRN("stop_charge is failed iRet[%d] in charge mode\n", iRet);
			if (iRet != -1)
			{
				send_error_msg(EVENT_TYPE_ERROR, abs(iRet));
			}	
			return iRet;
		}
	}
	//add by jxu 20180820-end

#if(DEBUG_AGV == TRUE)
	// print debug info for sending message
	LOG_DBG("deal udp msg[%d-%s] sequence=%d\n", 
		stMsgOperate.iMsgtype, get_msg_name(stMsgOperate.iMsgtype), stMsgOperate.iSequence);
	msgv1_head_dump(pMsgBuff);
#endif

	//LOG_INF("deal udp msg:[%d-%s],speed:%dmm/s,length:%dmm\n",
	//	iAction, get_action_name(iAction),
	//	stMsgOperate.iSpeed/10, stMsgOperate.iLength);

	g_stAgvTask.enTaskType = iAction;
	switch (iAction)
	{
	case ACTION_WALK:
		if (0 != g_stAgvConf.cCheckPoint)
		{
			iRet = msgv1_check_walk_path(pMsgBuff);
			if (iRet < 0) {
				LOG_ERR("msgv1_check_walk_path failure, the operate can not execute\n");
				return -1;
			}

			int iDirectOffset = 0;
			u16 u16Angle = 0;
			u8 u8Weight = stMsgOperate.iWeight;
			int iTaskSrcPoint = g_stAgvTask.iSrcPoint;
			int iTaskDstPoint = g_stAgvTask.iDstPoint;
			int iVehHeaderDirect = g_stAgvAttr.iVehHeadDirect;
			int iTaskHeaderDirect = compute_task_head_direct(iTaskSrcPoint, iTaskDstPoint);
			if (iTaskHeaderDirect == INVALID_DIRECTION)
			{
				LOG_ERR("compute task head direct[%d] is invalid\n", iTaskHeaderDirect);
				send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_TASK_ERROR);
				return iRet;
			}
			g_stAgvTask.iTaskDir = iTaskHeaderDirect; //add by tiger.49

			if (iTaskHeaderDirect != iVehHeaderDirect)
			{
				LOG_INF("detected iTaskHeaderDirect[%d] != iVehHeaderDirect[%d]\n", iTaskHeaderDirect, iVehHeaderDirect);
				//TODO: need to optimize
				iDirectOffset = iTaskHeaderDirect - iVehHeaderDirect;
				if (iDirectOffset < 0)
					iDirectOffset += 4;
				u16Angle = iDirectOffset * 900;

				turn_left(1, u8Weight, u16Angle, 600);
			}
		} else {
			msgv1_dump_walk_path(pMsgBuff);
		}

		// modified by kedong, 20180213
		// set bNeedSendFinish=true first of all, 
		// may set to false in function go_forward() when walk continue;
		bNeedSendFinish = true;
		iRet = go_forward(stMsgOperate.iWeight, stMsgOperate.iLength, stMsgOperate.iSpeed, &bNeedSendFinish);
		break;
	case ACTION_TURN_LEFT:
		iRet = turn_left(stMsgOperate.iPara, stMsgOperate.iWeight, stMsgOperate.iLength, stMsgOperate.iSpeed);
		bNeedSendFinish = true;
		break;
	case ACTION_TURN_RIGHT:
		iRet = turn_right(stMsgOperate.iPara, stMsgOperate.iWeight, stMsgOperate.iLength, stMsgOperate.iSpeed);
		bNeedSendFinish = true;
		break;
	case ACTION_RISE:
		iRet = tc_rise(stMsgOperate.iWeight, pMsgOperate->cContainer);
		bNeedSendFinish = true;
		break;
	case ACTION_LAY:
		iRet = tc_lay(stMsgOperate.iWeight, pMsgOperate->cContainer);
		bNeedSendFinish = true;
		break;
	case ACTION_CHARGE:
		iRet = start_charge();
		bNeedSendFinish = true;
		break;
	case ACTION_STOP_CHARGE:
		iRet = stop_charge();
		bNeedSendFinish = true;
		break;
	case ACTION_PARK:
		iRet = stop_agv(DEV_MC);
		bNeedSendFinish = false;
		break;
	case ACTION_CLEAN_DERAIL:
		iRet = clear_derail();
		bNeedSendFinish = true;
		break;
	case ACTION_PALLET_TURN_LEFT:
		g_stAgvAttr.iPalletDirect = stMsgOperate.iPara;
		g_stAgvAttr.iTaskPalletDirect = stMsgOperate.iPara;
		iRet = pallet_turn_left(stMsgOperate.iWeight, stMsgOperate.iLength, stMsgOperate.iSpeed);
		bNeedSendFinish = true;
		break;
	case ACTION_PALLET_TURN_RIGHT:
		g_stAgvAttr.iPalletDirect = stMsgOperate.iPara;
		g_stAgvAttr.iTaskPalletDirect = stMsgOperate.iPara;
		iRet = pallet_turn_right(stMsgOperate.iWeight, stMsgOperate.iLength, stMsgOperate.iSpeed);
		bNeedSendFinish = true;
		break;
	case ACTION_CLEAR_NAVIGATION:
		iRet = clear_navigation();
		bNeedSendFinish = true;
		break;
		///add by tiger.10,start
	case ACTION_BACK_TO_CHARGE:	
		//agent send qr distance = length
		iRet = mc_slow_go_back(stMsgOperate.iLength, stMsgOperate.iLength);
		bNeedSendFinish = true;
		break;
	case  ACTION_FORWARD_LEAVE_CHARGE:	
		//agent send qr distance = length
		iRet = mc_slow_go_straight(stMsgOperate.iLength, stMsgOperate.iLength);
		bNeedSendFinish = true;
		break;
	case ACTION_LEFT_ARC:		
		iRet = mc_leftarc(stMsgOperate.iWeight);
		bNeedSendFinish = true;
		break;
	case ACTION_RIGHT_ARC:
		iRet = mc_rightarc(stMsgOperate.iWeight);
		bNeedSendFinish = true;
		break;
	case ACTION_FORWARD_TO_CHARGE:
		//agent send qr distance = length
		iRet = mc_slow_go_straight(stMsgOperate.iLength, stMsgOperate.iLength);
		bNeedSendFinish = true;
		break;
	case ACTION_BACK_LEAVE_CHARGE:
		//agent send qr distance = length
		iRet = mc_slow_go_back(stMsgOperate.iLength, stMsgOperate.iLength);
		bNeedSendFinish = true;
		break;
		///end,by tiger.10
	default:
		LOG_WRN("unspported task or action type\n");
		iRet = OK;
		bNeedSendFinish = true;
		break;
	}

	// add by jxu 20180205: cuve statistics begin
	if (TRUE == g_stAgvConf.cDebugEnable)
	{
		if ((OK == iRet) && (true == bNeedSendFinish))
			msgv1_send_offset_statistic(iAction);
	}
	// add by jxu 20180205: cuve statistics end

	//add by jxu 20180121:begin
	//LOG_INF("g_stMcDev.iGeneration=%02x\n", g_stMcDev.iGeneration);
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		msgv1_deal_action_result(iRet, bNeedSendFinish, iAction);
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		msgv1_deal_action_v2_result(iRet, bNeedSendFinish, iAction);
	}
	//add by jxu 20180121:end

	return iRet;
}



/*******************************************************************************
* Function Name		 : msg_is_process
* Description	     : judge whether the msg is a process type.
* Input 		     : pMsgHead: the pointer of udp msg buff
* Output		     : NONE
* Return		     : 0:TRUE; <0:FALSE
*******************************************************************************/
int msg_is_process(const msgv1_head_t * pMsgHead)
{
	int iRet = -1;
	int iAction = 0;
	msgv1_head_t stMsgHead = { 0 };
	msgv1_operate_t *pMsgOperate = NULL;

	if (pMsgHead == NULL) {
		return -1;
	}

	stMsgHead.iAgvName = ntohl(pMsgHead->iAgvName);
	stMsgHead.iMsgtype = ntohl(pMsgHead->iMsgtype);
	stMsgHead.iSequence = ntohl(pMsgHead->iSequence);

	if (stMsgHead.iMsgtype != MSG_TYPE_OPERATE) {
		return -1;
	}

	pMsgOperate = (msgv1_operate_t *)pMsgHead;
	iAction = ntohl(pMsgOperate->iAction);
	if (ACTION_SET_ZONE == iAction)
	{
		LOG_WRN("recieve operate msg,but action=[%d-%s]\n", iAction, get_action_name(iAction));
		iRet = -1;
	}
	else {
		iRet = 0;
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv1_parse_operate
* Description	     : parse the operate msg.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv1_parse_operate(const char * pMsgBuff, int iMsgSize)
{
	msgv1_operate_t * pMsgOperate = (msgv1_operate_t *)pMsgBuff;
	int iRet = 0;

	if (pMsgOperate == NULL)
	{
		LOG_WRN("pMsgOperate is NULL\n");//add by jxu 20180709
		return -1;
	}


	int iMsgtype = ntohl(pMsgOperate->iMsgtype);
	int iAction = ntohl(pMsgOperate->iAction);
	int iTokenNum = ntohl(pMsgOperate->iTokenNum);

	//TODO: check TokenNum is valid
	iRet = msgv1_tokennum_is_valid(iTokenNum);
	if (iRet < 0)
		return -1;

	///by tiger.40 reset the value for break the walk function wait walk finish signal
	if ((ACTION_WALK == iAction) && (g_stAgvAttr.iMoveStatus == agv_walk))
	{
		g_stAgvTask.iWalkContinue = TRUE;
	}
	///end tiger.40

	if (ACTION_SET_ZONE == iAction)
	{
		LOG_WRN("recieve operate msg,but action=[%d-%s]\n", iAction, get_action_name(iAction));
		return 0;
	}

	iRet = linkqueue_append(g_stAgvParm.pUdpRxQueue, (const void *)pMsgBuff, iMsgSize);	// save to list
	if (iRet < 0)
	{
		LOG_ERR("append msg to udp rx queue failure\n");
		return iRet;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_parse_debug
* Description	     : parse the debug msg.
* input			     : pMsgHead: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv1_parse_debug(const char * pMsgBuff, int iMsgSize)
{
	msgv1_debug_t *pMsgDebug = (msgv1_debug_t *)pMsgBuff;
	enum_debug_cmd eCmd = -1;
	int iMsgtype = 0;
	int iTokenNum = 0;
	int iRet = 0;
	int iErrorCode = -1;

	if (pMsgDebug == NULL)
		return -1;

	iMsgtype = ntohl(pMsgDebug->iMsgtype);
	eCmd = (enum_debug_cmd)ntohl(pMsgDebug->iCmd);
	iTokenNum = ntohl(pMsgDebug->iTokenNum);

	//TODO: check TokenNum is valid
	iRet = msgv1_tokennum_is_valid(iTokenNum);
	if (iRet < 0)
		return -1;

	switch (eCmd)
	{
	case DEBUG_REBOOT:
		reboot_agv();
		break;
	case DEBUG_PALLET_CLASP:
		clasp_pallet();
		break;
	case DEBUG_PALLET_UNCLASP:
		unclasp_pallet();
		break;
	case DEBUG_WHEEL_CLASP:
		clasp_wheel();
		break;
	case DEBUG_WHEEL_UNCLASP:
		unclasp_wheel();
		break;
	case DEBUG_CHECK_GROUNDDIRECT:
		g_stAgvAttr.bCheckGroundDir = true;
		//just for save log,start by tiger
		iErrorCode = NO_EVENT_ERR;
		iRet = linkqueue_append(g_stAgvParm.pErrorRxQueue, &iErrorCode, sizeof(int));	// save to list
		if (iRet < 0)
		{
			LOG_ERR("append msg to Error RX queue failure\n");
		}
		//just for save log,start by tiger
		LOG_INF("enable check ground direction function\n");
		break;
	case DEBUG_UNCHECK_GROUNDDIRECT:
		g_stAgvAttr.bCheckGroundDir = false;
		LOG_INF("disable check ground direction function\n");
		break;
		///sync console time,start by tiger.16
	case DEBUG_AGV_SYNC_TIME:		
		iRet = sync_agent_time(ntohl(pMsgDebug->iAgvValue));//modefied by tiger.72
		if (iRet < 0)
		{
			LOG_WRN("sync agent time failed\n");
		}
		break;
		///sync console time,end by tiger.16
	case DEBUG_AGV_GET_LOG:
		//just for save log,start by tiger.105
		iErrorCode = NO_EVENT_ERR;
		iRet = linkqueue_append(g_stAgvParm.pErrorRxQueue, &iErrorCode, sizeof(int));	// save to list
		if (iRet < 0)
		{
			LOG_ERR("append msg to Error RX queue failure\n");
		}
		//just for save log,start by tiger.105
		LOG_INF("recv get log cmd\n");
		break;
	default:
		LOG_ERR("unknown debug command[%d]\n", eCmd);
		break;
	}

	LOG_DBG(">>>>>>>>>>>>>>>>>>>>>>>>>>>debug process complete\n");
	LOG_DBG("\n");

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_parse_get_param
* Description	     : parse the get param.
* input			     : pMsgHead: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv1_parse_get_param(const char * pMsgBuff, int iMsgSize)
{
	msgv1_param_get_req_t stMsgParamReq = { 0 };
	msgv1_param_ack_t stMsgParamAck = { 0 };
	int iMsgtype = 0;
	int iSequence = 0;
	int iParamID = 0;
	int iParamValue = 0;
	int iTokenNum = 0;
	int iAgvName = 0;
	int iRet = 0;
	agv_sem_t *pAgvSem = NULL;

	if (pMsgBuff == NULL)
		return -1;

	if (sizeof(stMsgParamReq) >= iMsgSize)
	{
		memcpy(&stMsgParamReq, pMsgBuff, iMsgSize);
	}
	else
	{
		LOG_WRN("sizeof(stMsgParamReq)[%dB] < iMsgSize[%dB] when memcpy",
			sizeof(stMsgParamReq), iMsgSize);
	}

	iMsgtype = ntohl(stMsgParamReq.iMsgtype);
	iSequence = ntohl(stMsgParamReq.iSequence);
	iAgvName = ntohl(stMsgParamReq.iAgvName);
	iParamID = ntohl(stMsgParamReq.iParamID);
	iTokenNum = ntohl(stMsgParamReq.iTokenNum);

	iRet = msgv1_tokennum_is_valid(iTokenNum);
	if (iRet < 0)
		return -1;
	
	
#if(DEBUG_AGV == TRUE)
	// print get param info for sending message
	LOG_DBG("recv udp msg[%d-%s] sequence=%d\n",
		iMsgtype, get_msg_name(iMsgtype), iSequence);
	msgv1_head_dump(pMsgBuff);
#endif

	pAgvSem = agv_sem_add(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_READ_V2_PARAM, iParamID);
	if (NULL == pAgvSem)
	{
		LOG_ERR("add get param sem failed\n");
	}

	iRet = get_param(DEV_MC, (u8)iParamID);
	if (iRet < 0) {
		LOG_WRN("get param from device[%d]'paramid=%d failure\n", DEV_MC, iParamID);
		return -1;
	}

	iRet = agv_sem_wait(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_READ_V2_PARAM, iParamID, TIME_OUT_8S);
	if (iRet < 0)
	{
		LOG_WRN("get param time out\n");
		return -EVENT_ERR_MC_TIMEOUT;
	}
	agv_sem_clean(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_READ_V2_PARAM, iParamID);

	stMsgParamAck.iSequence = htonl(iSequence);
	stMsgParamAck.iMsgtype = htonl(iMsgtype);
	stMsgParamAck.iAgvName = htonl(iAgvName);
	stMsgParamAck.iParamID = htonl(iParamID);
	//stMsgParamAck.iTokenNum = htonl(iTokenNum);
	stMsgParamAck.iParamValue = htonl((int)(g_stAgvAttr.stMcPropertyPram.value * PRECISION));

	iRet = msgv1_send_param((const char *)&stMsgParamAck);
	if (iRet < 0 )
	{
		LOG_INF("send get param ack failed\n");
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv1_parse_set_param
* Description	     : parse the set param.
* input			     : pMsgHead: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv1_parse_set_param(const char * pMsgBuff, int iMsgSize)
{
	msgv1_param_set_req_t stMsgParamReq = { 0 };
	msgv1_param_ack_t stMsgParamAck = { 0 };
	int iMsgtype = 0;
	int iSequence = 0;
	int iParamID = 0;
	float fParamValue = 0;
	int iTokenNum = 0;
	int iAgvName = 0;
	int iRet = 0;
	agv_sem_t *pAgvSem = NULL;

	if (pMsgBuff == NULL)
		return -1;

	if (sizeof(stMsgParamReq) >= iMsgSize)
	{
		memcpy(&stMsgParamReq, pMsgBuff, iMsgSize);
	}
	else
	{
		LOG_WRN("sizeof(stMsgParamReq)[%dB] < iMsgSize[%dB] when memcpy",
			sizeof(stMsgParamReq), iMsgSize);
	}

	iMsgtype = ntohl(stMsgParamReq.iMsgtype);
	iSequence = ntohl(stMsgParamReq.iSequence);
	iAgvName = ntohl(stMsgParamReq.iAgvName);
	iParamID = ntohl(stMsgParamReq.iParamID);
	int iTmp = ntohl(stMsgParamReq.iParamValue);
	int iParamValue = ntohl(stMsgParamReq.iParamValue);
	fParamValue = (float)iParamValue / PRECISION;

	// modified by kedong 20180209
	// ((float)(ntohl(stMsgParamReq.iParamValue))) / PRECISION not equal int iParamValue
	//fParamValue = ((float)(ntohl(stMsgParamReq.iParamValue))) / PRECISION;
	iTokenNum = ntohl(stMsgParamReq.iTokenNum);

	iRet = msgv1_tokennum_is_valid(iTokenNum);
	if (iRet < 0)
		return -1;


#if(DEBUG_AGV == TRUE)
	// print get param info for sending message
	LOG_DBG("recv udp msg[%d-%s] sequence=%d\n",
		iMsgtype, get_msg_name(iMsgtype), iSequence);
	msgv1_head_dump(pMsgBuff);
#endif

	pAgvSem = agv_sem_add(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_SET_V2_PARAM, iParamID);
	if (NULL == pAgvSem)
	{
		LOG_ERR("add get param sem failed\n");
	}

	iRet = set_param(DEV_MC, (u8)iParamID, fParamValue);
	if (iRet < 0) {
		LOG_WRN("get param from device[%d]'paramid=%d failure\n", DEV_MC, iParamID);
		return -EVENT_ERR_MC_TIMEOUT;;
	}

	iRet = agv_sem_wait(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_SET_V2_PARAM, iParamID, TIME_OUT_8S);
	if (iRet < 0)
	{
		LOG_WRN("get param time out\n");
	}
	agv_sem_clean(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_SET_V2_PARAM, iParamID);

	stMsgParamAck.iSequence = htonl(iSequence);
	stMsgParamAck.iMsgtype = htonl(iMsgtype);
	stMsgParamAck.iAgvName = htonl(iAgvName);
	stMsgParamAck.iParamID = htonl(iParamID);
	//stMsgParamAck.iTokenNum = htonl(iTokenNum);
	stMsgParamAck.iParamValue = htonl((int)(g_stAgvAttr.stMcPropertyPram.value*PRECISION));

	iRet = msgv1_send_param((const char *)&stMsgParamAck);
	if (iRet < 0)
	{
		LOG_INF("send get param ack failed\n");
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : msgv2_get_msgtype
* Description	     : get msg type from msg buffer.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv1_get_msgtype(const char * pMsgBuff, int iMsgSize)
{
	msgv1_head_t *pMsgHead = (msgv1_head_t *)pMsgBuff;
	int iMsgType = ntohl(pMsgHead->iMsgtype);

	return iMsgType;
}

/*******************************************************************************
* Function Name		 : msgv2_get_sequence
* Description	     : get sequence from msg buffer.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv1_get_sequence(const char * pMsgBuff, int iMsgSize)
{
	msgv1_head_t *pMsgHead = (msgv1_head_t *)pMsgBuff;
	int iSequence = ntohl(pMsgHead->iSequence);

	return iSequence;
}

/*******************************************************************************
* Function Name		 : msgv2_get_tokennum
* Description	     : get tokennum from msg buffer.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv1_get_tokennum(const char * pMsgBuff, int iMsgSize)
{
	msgv1_head_t *pMsgHead = (msgv1_head_t *)pMsgBuff;
	int iMsgtype = 0;
	int iTokenNum = 0;

	if (pMsgHead != NULL) {
		iMsgtype = ntohl(pMsgHead->iMsgtype);

		if (iMsgtype == MSG_TYPE_OPERATE) {
			msgv1_operate_t *pMsgOperate = (msgv1_operate_t *)pMsgHead;
			
			iTokenNum = ntohl(pMsgOperate->iTokenNum);
		}

		if (iMsgtype == MSG_TYPE_EVENT) {
			msgv1_error_t  *pMsgError = (msgv1_error_t *)pMsgHead;

			iTokenNum = ntohl(pMsgError->iTokenNum);
		}

		if (iMsgtype == MSG_TYPE_ERROR_POINT) {
			msgv1_error_point_t *pMsgErrorPoint = (msgv1_error_point_t *)pMsgHead;

			iTokenNum = ntohl(pMsgErrorPoint->iTokenNum);
		}

		if (iMsgtype == MSG_TYPE_POINT) {
			msgv1_point_t *pMsgPoint = (msgv1_point_t *)pMsgHead;

			iTokenNum = ntohl(pMsgPoint->iTokenNum);
		}

		if (iMsgtype == MSG_TYPE_FINISH) {
			msgv1_finish_t *pMsgFinish = (msgv1_finish_t *)pMsgHead;

			iTokenNum = ntohl(pMsgFinish->iTokenNum);
		}
	}
	
	return iTokenNum;
}

/*******************************************************************************
*Function Name    :deal_rw_param_result
*Description      :  
*Input       	  :int iRet:such as :1002,3004  
*Output 		  :
*Return           :void  
*******************************************************************************/
static void deal_rw_param_result(int iRet)
{
	int iErrorCode = abs(iRet);
	switch (iRet)
	{
	case 0:
		LOG_INF("read/write param success\n");
		break;
	case  -1:
		LOG_ERR("send read/write param CAN frame failure\n");
	case  -EVENT_ERR_MC_TIMEOUT:
		LOG_ERR("MC excute  read/write param timeout\n");
		// when exception happen, will be cause timeout
		// in this case, no need send event to console
		if (0 != atomic_read(&g_stAgvAttr.iException))//by tiger.67
			break;
	case -EVENT_ERR_TC_TIMEOUT:
		LOG_ERR("TC excute read/write param timeout\n");

		// when exception happen, will be cause timeout
		// in this case, no need send event to console
		if (0 != atomic_read(&g_stAgvAttr.iException))//by tiger.67
			break;
	default:
		LOG_INF("send read/write param timeout error to agent\n");
		if (send_error_msg(EVENT_TYPE_ERROR, iErrorCode) < 0)
		{
			LOG_ERR("append error msg[%d-%s] to udp tx queue failure\n",
				iErrorCode, get_err_str(iErrorCode));
		}
		else
		{
			LOG_INF("append error msg[%d-%s] to udp tx queue success\n",
				iErrorCode, get_err_str(iErrorCode));
		}
		break;
	}
}
typedef struct msgv1_update_req
{
	int iMsgtype;
	int iSequence;
	int iAgvName;
	char pVersionNo[64];
	int iTokenNum;
} msgv1_update_req_t;

typedef struct msgv1_update_ack
{
	int iMsgtype;
	int iSequence;
	int iAgvName;
	int iTokenNum;
} msgv1_update_ack_t;
#define VERSION_LEN 64
int msgv1_parse_update_req(const char * pMsgBuff, int iMsgSize)
{
	msgv1_update_req_t stMsgUpdateReq = { 0 };
	msgv1_update_ack_t stMsUpdateAck = { 0 };
	int iMsgtype = 0;
	int iSequence = 0;
	int iTokenNum = 0;
	int iRet = 0;

	if (pMsgBuff == NULL)
		return -1;

	if (sizeof(stMsgUpdateReq) >= iMsgSize)
	{
		memcpy(&stMsgUpdateReq, pMsgBuff, iMsgSize);
	}
	else
	{
		LOG_WRN("sizeof(stMsgUpdateReq)[%dB] < iMsgSize[%dB] when memcpy",
			sizeof(stMsgUpdateReq), iMsgSize);
	}

	iTokenNum = ntohl(stMsgUpdateReq.iTokenNum);
	iMsgtype = ntohl(stMsgUpdateReq.iMsgtype);
	iSequence = ntohl(stMsgUpdateReq.iSequence);
	bzero(g_stAgvAttr.pVersion, sizeof(g_stAgvAttr.pVersion));
	memcpy(g_stAgvAttr.pVersion, stMsgUpdateReq.pVersionNo, VERSION_LEN);
	
	stMsUpdateAck.iMsgtype = stMsgUpdateReq.iMsgtype;
	stMsUpdateAck.iAgvName = stMsgUpdateReq.iAgvName;
	stMsUpdateAck.iTokenNum = stMsgUpdateReq.iTokenNum;
	stMsUpdateAck.iSequence = stMsgUpdateReq.iSequence;
	
	msgv1_send_ack(pMsgBuff);
	iRet = msgv1_tokennum_is_valid(iTokenNum);
	if (iRet < 0)
		return -1;

#if(DEBUG_AGV == TRUE)
	// print get param info for sending message
	LOG_DBG("recv udp msg[%d-%s] sequence=%d\n",
		iMsgtype, get_msg_name(iMsgtype), iSequence);
	msgv1_head_dump(pMsgBuff);
#endif
	iRet = agv_sem_post(SEM_MSG_TYPE, MSG_TYPE_UPDATE, UPDATE_MSG_SEQ);
	if (iRet < -1)
	{
		LOG_ERR("post agent update cmd  signal error:[%s]\n", strerror(errno));
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_recv
* Description	     : msg v1 recv process msg.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv1_recv(const char * pMsgBuff, int iMsgSize)
{
	msgv1_head_t *pMsgHead = (msgv1_head_t *)pMsgBuff;
	msgv1_head_t stMsgHead = { 0 };
	int iRet = 0;

	// Case1:recv udp msg from server failure
	if ((pMsgBuff == NULL) || (iMsgSize <= 0)) {
		return -1;
	}

	stMsgHead.iMsgtype = ntohl(pMsgHead->iMsgtype);
	stMsgHead.iSequence = ntohl(pMsgHead->iSequence);
	if ((stMsgHead.iMsgtype == MSG_TYPE_OPERATE) || (stMsgHead.iMsgtype == MSG_TYPE_DEBUG))
	{
		LOG_DBG("\n");
		LOG_DBG(">>>>>>>>>>>>>>>>>>>>>>>>>>>task process start...\n");

#if(DEBUG_AGV == TRUE)		
		LOG_INF("recv udp msg[%d-%s]\n",
			stMsgHead.iMsgtype, get_msg_name(stMsgHead.iMsgtype));
		msgv1_head_dump(pMsgBuff);
#endif
		if (stMsgHead.iMsgtype == MSG_TYPE_OPERATE) //by tiger.87
		{
			msgv1_send_ack(pMsgBuff);
		}
		
	}

	// Case2:udp msg is invalid
	iRet = msgv1_is_valid(pMsgBuff, iMsgSize);
	if (iRet < 0)
		return -1;

	switch (stMsgHead.iMsgtype)
	{
	case MSG_TYPE_OPERATE:			//REQ
		msgv1_parse_operate(pMsgBuff, iMsgSize);
		break;
	case MSG_TYPE_DEBUG:			//REQ
		msgv1_parse_debug(pMsgBuff, iMsgSize);
		break;
	case MSG_TYPE_GET_PARAM:			//REQ
		iRet = msgv1_parse_get_param(pMsgBuff, iMsgSize);
		deal_rw_param_result(iRet);
		break;
	case MSG_TYPE_SET_PARAM:			//REQ
		iRet = msgv1_parse_set_param(pMsgBuff, iMsgSize);
		deal_rw_param_result(iRet);
		break;
	///add agent cmd parse ,start by tiger.44
	case MSG_TYPE_UPDATE:
		iRet = msgv1_parse_update_req(pMsgBuff, iMsgSize);
		break;
	case MSG_TYPE_UPDATE_RESULT:
		break;
	///end by tiger.44
	case MSG_TYPE_REGISTER:			//ACK
	case MSG_TYPE_UNREGISTER:		//ACK
	case MSG_TYPE_HEARTBEAT:		//ACK
	case MSG_TYPE_EVENT:			//ACK
	case MSG_TYPE_EVENT_RELEASE:	//ACK
	case MSG_TYPE_FINISH:			//ACK
	case MSG_TYPE_ERROR_POINT:		//ACK
	case MSG_TYPE_POINT:			//ACK
	case MSG_TYPE_INFO:				//ACK
	case MSG_TYPE_CONFIRM:			//ACK
	default:
		msgv1_deal_ack(pMsgBuff, iMsgSize);
		break;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_deal
* Description	     : msg v2 deal process msg.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msgv1_deal(const char * pMsgBuff, int iMsgSize)
{
	const msgv1_head_t *pMsgHead = (const msgv1_head_t *)pMsgBuff;
	msgv1_head_t stMsgHead = { 0 };
	int iMsgtype = 0;
	int iSequence = 0;
	int iRet = 0;

	// Case1:recv udp msg from server failure
	if ((pMsgBuff == NULL) || (iMsgSize <= 0)) {
		return -1;
	}

	pMsgHead = (const msgv1_head_t *)pMsgBuff;
	iMsgtype = ntohl(pMsgHead->iMsgtype);
	iSequence = ntohl(pMsgHead->iSequence);

	switch (iMsgtype)
	{
	case MSG_TYPE_OPERATE:
		msgv1_send_confirm(iMsgtype, iSequence);
		msgv1_deal_operate(pMsgBuff);
		break;
	default:
		LOG_WRN("unknown msg type[%d]\n", iMsgtype);
		break;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv1_send_offset_statistic
* Description	     : send offset statistic to testing console tool.
* Input 		     : iAction.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int msgv1_send_offset_statistic(int iAction)
{
	int iRet = 0;
	int iGsDev = 0;
	int iGsDevFb = 0;
	int iGsAngle = 0;
	float fGsDev = 0;
	float fGsDevFb = 0;
	float fGsAngle = 0;
	float iGroudyOffset = g_stAgvAttr.iGYOffset*0.1;
	float iGroudxOffset = g_stAgvAttr.iGXOffset*0.1;
	float iGroudangleoffset = g_stAgvAttr.iGAngleOffset*0.1;
	int iMoveType = 0;

	if (g_stAgvAttr.iVehHeadDirect == DIRECTION_X_P)
	{
		fGsDev = iGroudyOffset;
		fGsDevFb = iGroudxOffset;
		fGsAngle = (iGroudangleoffset > 180.0f) ? (360.0f - iGroudangleoffset) : (-iGroudangleoffset);
	}
	else if (g_stAgvAttr.iVehHeadDirect == DIRECTION_X_N)
	{
		fGsDev = -iGroudyOffset;
		fGsDevFb = -iGroudxOffset;
		fGsAngle = 180.0f - iGroudangleoffset;
	}
	else if (g_stAgvAttr.iVehHeadDirect == DIRECTION_Y_P)
	{
		fGsDev = -iGroudxOffset;
		fGsDevFb = iGroudyOffset;
		fGsAngle = 270.0f - iGroudangleoffset;
	}
	else if (g_stAgvAttr.iVehHeadDirect == DIRECTION_Y_N)
	{
		fGsDev = iGroudxOffset;
		fGsDevFb = -iGroudyOffset;
		fGsAngle = 90.0f - iGroudangleoffset;
	}

	iGsDev = fGsDev * 1000;
	iGsDevFb = fGsDevFb * 1000;
	iGsAngle = fGsAngle * 1000;

	if (iAction == ACTION_WALK)
		iMoveType = MOVE_TYPE_GO_FINISH;
	else if (iAction == ACTION_TURN_LEFT)
		iMoveType = MOVE_TYPE_TURN_FINISH;
	else if (iAction == ACTION_TURN_RIGHT)
		iMoveType = MOVE_TYPE_TURN_FINISH;
	else
		iMoveType = MOVE_TYPE_GOING;

	msgv1_ground_offset_st stMsgOffset =
	{
		.iMsgtype = htonl(MSG_TYPE_INFO),
		.iSeq = htonl(get_seq(AGENENT_SEQ_ID)),
		.iAgvName = htonl(g_stAgvAttr.iAgvName),
		.iPointId = htonl(g_stAgvAttr.iLocation),
		.iGXOffset = htonl(g_stAgvAttr.iGXOffset),
		.iGYOffset = htonl(g_stAgvAttr.iGYOffset),
		.iGAngleOffset = htonl(g_stAgvAttr.iGAngleOffset),
		.iGsDev = htonl(iGsDev),
		.iGSDevFB = htonl(iGsDevFb),
		.iGSAngle = htonl(iGsAngle),
		.iHeadDirect = htonl(g_stAgvAttr.iVehHeadDirect),
		.iAction = htonl(iMoveType),
	};

	LOG_INF("iPointId=%d iGsDev=%d iGsDevFb=%d iGsAngle=%d fGsDev=%f fGsDevFb=%f fGsAngle=%f\n",
		g_stAgvAttr.iLocation, iGsDev, iGsDevFb, iGsAngle, fGsDev, fGsDevFb, fGsAngle);

	iRet = linkqueue_append(g_stAgvParm.pUdpTxQueue, &stMsgOffset, sizeof(stMsgOffset));
	if (iRet < 0) {
		LOG_ERR("append stMsgOffset to udp tx queue failure\n");
		return iRet;
	}

	return iRet;
}
