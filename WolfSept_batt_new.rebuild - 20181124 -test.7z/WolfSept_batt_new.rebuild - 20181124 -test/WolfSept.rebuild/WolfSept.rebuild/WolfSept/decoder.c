#include "decoder.h"

// 判断是否匹配
int SameSyndrome(unsigned char * a, unsigned char * b)
{
    int i;
    for(i=0;i<CODE_BITS-INFO_BITS;i++)
        if(a[i]!=b[i])
            return 0;
    return 1;
}


// 校验并解码
snake_decode_error find_syndrome_and_correct(unsigned char syndrome_of_received[CODE_BITS-INFO_BITS], unsigned char syndrome_table[CODE_BITS][CODE_BITS-INFO_BITS], unsigned char *received_codeword)
{
    snake_decode_error err;

    int i;

    unsigned char no_error_pattern[CODE_BITS-INFO_BITS]={0};
    if (SameSyndrome(no_error_pattern,syndrome_of_received) )
    {

        err=ERR_NO_ERROR;

        return err;
    }
    for (i=0; i<CODE_BITS; i++)
    {

        if (SameSyndrome(syndrome_table[i],syndrome_of_received) )
        {
            received_codeword[i] = received_codeword[i]^1;

            err=ERR_NO_ERROR;

            return err;
        }
    }

    err=ERR_UNRELIABLE;

    return err;
}

int Bin2Dec22bits(unsigned char *binChain){
    int i,decValue=0;
    int res = 0;

    for( i=0; i<20; i++ ){
        decValue=decValue+((binChain[i]-'0')<<i);
    }
    res += (binChain[i++]-'0')*1000 + decValue%1000;
    res += (binChain[i++]-'0')*10000000 + decValue/1000*10000;
    return res;
}

int HammingCode74Decode(int *binChain, int nBinChain)
{
    if (nBinChain!=7 || NULL==binChain)
        return -1;

    int p1 = (binChain[0] + binChain[2] + binChain[4] + binChain[6])%2;
    int p2 = (binChain[1] + binChain[2] + binChain[5] + binChain[6])%2;
    int p4 = (binChain[3] + binChain[4] + binChain[5] + binChain[6])%2;
    int res = (p4<<2) + (p2<<1) + p1;

    if (res)
    {
        res -= 1;
        binChain[res] = (binChain[res] + 1)%2;
    }

    binChain[0] = binChain[2];
    binChain[1] = binChain[4];
    binChain[2] = binChain[5];
    binChain[3] = binChain[6];
    memset(&binChain[4],0xff,sizeof(binChain[4])*3);

    res = (binChain[0]<<3) + (binChain[1]<<2) + (binChain[2]<<1) + binChain[3];
    if (res==5)
        return 0;
    else if (res==6)
        return 1;
    else if (res==9)
        return 2;
    else if (res==10)
        return 3;
    else
        return -1;
}

int ConservativeHammingCode74Decode(int *binChain, int nBinChain)
{
    int res;
    if (nBinChain!=7 || NULL==binChain)
        return -1;
#if 0
    binChain[0] = binChain[2];
    binChain[1] = binChain[4];
    binChain[2] = binChain[5];
    binChain[3] = binChain[6];
    memset(&binChain[4],0xff,sizeof(binChain[4])*3);

    res = (binChain[0]<<3) + (binChain[1]<<2) + (binChain[2]<<1) + binChain[3];
    if (res==5)
        return 0;
    else if (res==6)
        return 1;
    else if (res==9)
        return 2;
    else if (res==10)
        return 3;
    else
        return -1;
#else
    res = (binChain[0]<<6)
            + (binChain[1]<<5)
            + (binChain[2]<<4)
            + (binChain[3]<<3)
            + (binChain[4]<<2)
            + (binChain[5]<<1)
            + (binChain[6]);
    if (res==37)
        return 0;
    else if (res==102)
        return 1;
    else if (res==25)
        return 2;
    else if (res==90)
        return 3;
    else
        return -1;
#endif
}


//********************************************
//函数功能:FuncDecodeProcessing函数实现
//函数输出:
//*********************************************/
int FuncDecodeProcessing(void){

    int i,j;
    int codeIdx = -1;
    unsigned char decodeBinaryValue[INFO_MATRIX_ROW*INFO_MATRIX_COLUMN];
    int idx = 0;
    int decodeCodeIdx[7];

    memset(decodeBinaryValue,0,sizeof(decodeBinaryValue));
    for (i=0; i<INFO_MATRIX_ROW; i++) {
        for(j=0; j<INFO_MATRIX_COLUMN; j++) {
            decodeBinaryValue[idx++]=((infoMatrix[i][j].color&1)^1) + '0';
        }
    }

    for (i=0; i<7; i++)
    {
        if (codeIdxMatrix[i].color==BLACK)
            decodeCodeIdx[i] = 1;
        else
            decodeCodeIdx[i] = 0;
    }

    infoOutput.messg=Bin2Dec22bits(decodeBinaryValue);

#ifdef CONSERVATIVE_DECODE
    /// conservative decode method without hamming error correction
    codeIdx = ConservativeHammingCode74Decode(decodeCodeIdx, 7);
#else
    /// decode method with hamming error correction
    codeIdx = HammingCode74Decode(decodeCodeIdx, 7);
#endif

    return codeIdx;
}




/////////////////////// end //////////////////////////
