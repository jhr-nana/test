#include "common.h"


bool isInBox(snake_point *point, int width,int height){

    if(point->Pix > 3 && point->Pix< (width-3) && point->Lin > 3 && point->Lin < (height-3)){

        return true;

    }else{

        return false;
    }

}

bool isInBoxf(snake_pointf *point, int width,int height){

    if(point->Pix > 3 && point->Pix< (width-3) && point->Lin > 3 && point->Lin < (height-3)){

        return true;

    }else{

        return false;
    }

}



// Math
float PI2PI(const float angle){

    float newangle=angle;

    if(angle>M_PI){

        newangle=angle-2*M_PI;

    }else if(angle<-1*M_PI){

        newangle=angle+2*M_PI;

    }

    return newangle;

}



// 提取矩形框内的黑色数据（需要重新修改）
int FuncBlackExtract(const uint8_t *binaryImageData, snake_point rec[4], snake_point *recBlackData, int *pWhiteCount){

    int i,j;
    int minPart, maxPart;

    //int numLin, numPix;
    int blackCount = 0;		// 最终输出黑色像素点个数
    int whiteCount = 0;     // 最终输出白色像素点个数

    int a = 0;	// 用于判断三个等式条件是否满足，若满足，对应变量为1
    int b = 0;
    int c = 0;

    int line_12 = 0;
    int line_13 = 0;
    int line_24 = 0;
    int line_34 = 0;

    int temp;



    if (rec[0].Lin == rec[1].Lin){
        a = 1;
    }
    if (rec[1].Lin == rec[2].Lin){
        b = 1;
    }
    if (rec[2].Lin == rec[3].Lin){
        c = 1;
    }
    temp = a*4 + b*2 + c;	// 将abc转为二进制，用于区分8种情况

    switch(temp){
    case 0:
        for (i = rec[0].Lin; i < rec[1].Lin; i++)
        {
            line_12 = floor((i - rec[0].Lin) * (rec[1].Pix - rec[0].Pix) / (rec[1].Lin - rec[0].Lin) + rec[0].Pix);
            line_13 = floor((i - rec[0].Lin) * (rec[2].Pix - rec[0].Pix) / (rec[2].Lin - rec[0].Lin) + rec[0].Pix);
            minPart = MIN(line_12, line_13);
            maxPart = MAX(line_12, line_13);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        for (i = rec[1].Lin; i < rec[2].Lin; i++)
        {
            line_24 = floor((i - rec[1].Lin) * (rec[3].Pix - rec[1].Pix) / (rec[3].Lin - rec[1].Lin) + rec[1].Pix);
            line_13 = floor((i - rec[0].Lin) * (rec[2].Pix - rec[0].Pix) / (rec[2].Lin - rec[0].Lin) + rec[0].Pix);
            minPart = MIN(line_13, line_24);
            maxPart = MAX(line_13, line_24);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        for (i = rec[2].Lin; i < rec[3].Lin + 1; i++)
        {
            line_24 = floor((i - rec[1].Lin) * (rec[3].Pix - rec[1].Pix) / (rec[3].Lin - rec[1].Lin) + rec[1].Pix);
            line_34 = floor((i - rec[2].Lin) * (rec[3].Pix - rec[2].Pix) / (rec[3].Lin - rec[2].Lin) + rec[2].Pix);
            minPart = MIN(line_24, line_34);
            maxPart = MAX(line_24, line_34);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        break;

    case 1:
        for (i = rec[0].Lin; i < rec[1].Lin; i++)
        {
            line_12 = floor((i - rec[0].Lin) * (rec[1].Pix - rec[0].Pix) / (rec[1].Lin - rec[0].Lin) + rec[0].Pix);
            line_13 = floor((i - rec[0].Lin) * (rec[2].Pix - rec[0].Pix) / (rec[2].Lin - rec[0].Lin) + rec[0].Pix);
            minPart = MIN(line_12, line_13);
            maxPart = MAX(line_12, line_13);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        for (i = rec[1].Lin; i < rec[2].Lin + 1; i++)
        {
            line_24 = floor((i - rec[1].Lin) * (rec[3].Pix - rec[1].Pix) / (rec[3].Lin - rec[1].Lin) + rec[1].Pix);
            line_13 = floor((i - rec[0].Lin) * (rec[2].Pix - rec[0].Pix) / (rec[2].Lin - rec[0].Lin) + rec[0].Pix);
            minPart = MIN(line_13, line_24);
            maxPart = MAX(line_13, line_24);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        break;

    case 2:
        for (i = rec[0].Lin; i < rec[1].Lin; i++)
        {
            line_12 = floor((i - rec[0].Lin) * (rec[1].Pix - rec[0].Pix) / (rec[1].Lin - rec[0].Lin) + rec[0].Pix);
            line_13 = floor((i - rec[0].Lin) * (rec[2].Pix - rec[0].Pix) / (rec[2].Lin - rec[0].Lin) + rec[0].Pix);
            minPart = MIN(line_12, line_13);
            maxPart = MAX(line_12, line_13);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        for (i = rec[2].Lin; i < rec[3].Lin + 1; i++)
        {
            line_24 = floor((i - rec[1].Lin) * (rec[3].Pix - rec[1].Pix) / (rec[3].Lin - rec[1].Lin) + rec[1].Pix);
            line_34 = floor((i - rec[2].Lin) * (rec[3].Pix - rec[2].Pix) / (rec[3].Lin - rec[2].Lin) + rec[2].Pix);
            minPart = MIN(line_24, line_34);
            maxPart = MAX(line_24, line_34);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        break;

    case 3:
        for (i = rec[0].Lin; i < rec[1].Lin + 1; i++)
        {
            line_12 = floor((i - rec[0].Lin) * (rec[1].Pix - rec[0].Pix) / (rec[1].Lin - rec[0].Lin) + rec[0].Pix);
            line_13 = floor((i - rec[0].Lin) * (rec[2].Pix - rec[0].Pix) / (rec[2].Lin - rec[0].Lin) + rec[0].Pix);
            minPart = MIN(line_12, line_13);
            maxPart = MAX(line_12, line_13);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        break;

    case 4:
        for (i = rec[1].Lin; i < rec[2].Lin; i++)
        {
            line_24 = floor((i - rec[1].Lin) * (rec[3].Pix - rec[1].Pix) / (rec[3].Lin - rec[1].Lin) + rec[1].Pix);
            line_13 = floor((i - rec[0].Lin) * (rec[2].Pix - rec[0].Pix) / (rec[2].Lin - rec[0].Lin) + rec[0].Pix);
            minPart = MIN(line_13, line_24);
            maxPart = MAX(line_13, line_24);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        for (i = rec[2].Lin; i < rec[3].Lin + 1; i++)
        {
            line_24 = floor((i - rec[1].Lin) * (rec[3].Pix - rec[1].Pix) / (rec[3].Lin - rec[1].Lin) + rec[1].Pix);
            line_34 = floor((i - rec[2].Lin) * (rec[3].Pix - rec[2].Pix) / (rec[3].Lin - rec[2].Lin) + rec[2].Pix);
            minPart = MIN(line_24, line_34);
            maxPart = MAX(line_24, line_34);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        break;

    case 5:
        for (i = rec[1].Lin; i < rec[2].Lin + 1; i++)
        {
            line_24 = floor((i - rec[1].Lin) * (rec[3].Pix - rec[1].Pix) / (rec[3].Lin - rec[1].Lin) + rec[1].Pix);
            line_13 = floor((i - rec[0].Lin) * (rec[2].Pix - rec[0].Pix) / (rec[2].Lin - rec[0].Lin) + rec[0].Pix);
            minPart = MIN(line_13, line_24);
            maxPart = MAX(line_13, line_24);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        break;

    case 6:
        for (i = rec[2].Lin; i < rec[3].Lin + 1; i++)
        {
            line_24 = floor((i - rec[1].Lin) * (rec[3].Pix - rec[1].Pix) / (rec[3].Lin - rec[1].Lin) + rec[1].Pix);
            line_34 = floor((i - rec[2].Lin) * (rec[3].Pix - rec[2].Pix) / (rec[3].Lin - rec[2].Lin) + rec[2].Pix);
            minPart = MIN(line_24, line_34);
            maxPart = MAX(line_24, line_34);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[blackCount].Pix = j;
                    recBlackData[blackCount].Lin = i;
                    blackCount++;
                }
                else
                    whiteCount++;
            }
        }
        break;

    case 7:
        minPart = MIN(MIN(MIN(rec[0].Pix, rec[1].Pix), rec[2].Pix), rec[3].Pix);
        maxPart = MAX(MAX(MAX(rec[0].Pix, rec[1].Pix), rec[2].Pix), rec[3].Pix);

        for (j = minPart; j < maxPart + 2; j++)
        {
            if (binaryImageData[IMG_WIDTH * rec[0].Lin + j] == BLACK)		// Value[i][j]代表ij处的像素值
            {
                recBlackData[blackCount].Pix = j;
                recBlackData[blackCount].Lin = rec[0].Lin;
                blackCount++;
            }
            else
                whiteCount++;
        }

        break;

    }

    *pWhiteCount = whiteCount;
    return blackCount;	// 返回零阶几何矩

}

/*
int FuncBlackExtract(const uint8_t *binaryImageData, snake_point rec[4], snake_point *recBlackData){

    int i,j;
    int count = 0;		// 最终输出黑色像素点个数


    if (rec[0].Lin == rec[1].Lin)		// 特殊情况，矩形的边与坐标轴平行
    {
        for (i = rec[0].Lin; i < rec[2].Lin + 1; i++)
        {
            for (j = rec[0].Pix; j < rec[1].Pix + 1; j++)
            {
                if (binaryImageData[IMG_WIDTH * i + j] == BLACK)		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[count].Pix = j;
                    recBlackData[count].Lin = i;
                    count++;
                }
            }
        }
    }
    else		// 将矩形分成三块，进行检测
    {
        for (i = rec[0].Lin; i < rec[1].Lin ; i++)
        {
            int line_12 = floor((i - rec[0].Lin) * (rec[1].Pix - rec[0].Pix) / (rec[1].Lin - rec[0].Lin) + rec[0].Pix);
            int line_13 = floor((i - rec[0].Lin) * (rec[2].Pix - rec[0].Pix) / (rec[2].Lin - rec[0].Lin) + rec[0].Pix);
            int minPart = MIN(line_12, line_13);
            int maxPart = MAX(line_12, line_13);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (BLACK == binaryImageData[IMG_WIDTH * i + j])		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[count].Pix = j;
                    recBlackData[count].Lin = i;
                    count++;
                }
            }
        }
        for (i = rec[1].Lin; i < rec[2].Lin ; i++)
        {
            int line_24 = floor((i - rec[1].Lin) * (rec[3].Pix - rec[1].Pix) / (rec[3].Lin - rec[1].Lin) + rec[1].Pix);
            int line_13 = floor((i - rec[0].Lin) * (rec[2].Pix - rec[0].Pix) / (rec[2].Lin - rec[0].Lin) + rec[0].Pix);
            int minPart = MIN(line_13, line_24);
            int maxPart = MAX(line_13, line_24);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (BLACK == binaryImageData[IMG_WIDTH * i + j])
                {
                    recBlackData[count].Pix = j;
                    recBlackData[count].Lin = i;
                    count++;
                }
            }
        }
        for (i = rec[2].Lin; i < rec[3].Lin + 1; i++)
        {
            int line_24 = floor((i - rec[1].Lin) * (rec[3].Pix - rec[1].Pix) / (rec[3].Lin - rec[1].Lin) + rec[1].Pix);
            int line_34 = floor((i - rec[2].Lin) * (rec[3].Pix - rec[2].Pix) / (rec[3].Lin - rec[2].Lin) + rec[2].Pix);
            int minPart = MIN(line_24, line_34);
            int maxPart = MAX(line_24, line_34);

            for (j = minPart; j < maxPart + 2; j++)
            {
                if (BLACK == binaryImageData[IMG_WIDTH * i + j])		// Value[i][j]代表ij处的像素值
                {
                    recBlackData[count].Pix = j;
                    recBlackData[count].Lin = i;
                    count++;
                }
            }
        }
    }

    return count; // 返回零阶几何矩
}
*/
