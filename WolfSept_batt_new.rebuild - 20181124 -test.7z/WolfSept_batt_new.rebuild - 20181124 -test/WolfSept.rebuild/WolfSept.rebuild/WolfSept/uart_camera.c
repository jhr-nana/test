/********************************************************************************
* Copyright (c) 2017, JD.COM, Inc .
* All rights reserved.
* FileName: uart_camera.c
* Author: tongkedong   Version: V1.0   Data:2017-12-18
* Description:
* uart_camera low-level support api code
********************************************************************************/
#include "uart_camera.h"

/*******************************************************************************
* Function Name      : uart_camera_start
* Description	     : start v4l2 camera
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int uart_camera_start()
{
	int iRet = 0;
	char cUartData[3] = { 0x16, 0x54, 0x0D };
	size_t uiSize = 0;

	uiSize = send_uart(g_stAgvParm.iUartFd, cUartData, sizeof(cUartData));
	LOG_INF("start uart camera: %s\n", (uiSize == sizeof(cUartData)) ? "success" : "failure");

	return iRet;
}

/*******************************************************************************
* Function Name      : uart_camera_stop
* Description	     : stop v4l2 camera
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int uart_camera_stop()
{
	int iRet = 0;
	char cUartData[3] = { 0x16, 0x55, 0x0D };
	size_t uiSize = 0;

	uiSize = send_uart(g_stAgvParm.iUartFd, cUartData, sizeof(cUartData));
	LOG_INF("stop uart camera: %s\n", (uiSize == sizeof(cUartData)) ? "success" : "failure");

	return iRet;
}

/*******************************************************************************
* Function Name      : uart_camera_get_qrinfo
* Description	     : get qr info from v4l2 camera
* Input 		     : NONE
* Output		     : pQRInfo: the qr info pointer
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int uart_camera_get_qrinfo(qr_info_t * pQRInfo)
{
	int iRet = 0;
	char cGetData[3] = { 0x16, 0x54, 0x0D };
	char cReset[3] = { 0x16, 0x55, 0x0D };

	char cDatabuf[UART_RET_SIZE] = { 0 };
	char cAngle[UART_RET_SIZE] = { 0 };

	//char cCount = GET_PALLET_ANGLE_COUNT;
	char *pTmp = NULL;
	float fAngle = 0.0;
	size_t uiSize = 0;
	fd_set stReadFds;
	int iQR = 0;
	if (pQRInfo == NULL)
		return -1;
	
	struct timeval stTimeOut = { 8, 0 }; //5s  TO DO
	bzero(cDatabuf, sizeof(cDatabuf));

	//get pallet angle

	FD_ZERO(&stReadFds);
	FD_SET(g_stAgvParm.iUartFd, &stReadFds);
	stTimeOut.tv_sec = 8;
	// send get data cmd to PGV
	uiSize = send_uart(g_stAgvParm.iUartFd, cGetData, sizeof(cGetData));

	LOG_INF("send getting pallet angle to camera\n");
	iRet = select(g_stAgvParm.iUartFd + 1, &stReadFds, NULL, NULL, &stTimeOut);
	if (iRet <= 0) //get pallet angle for 8s each time.
	{
		uiSize = send_uart(g_stAgvParm.iUartFd, cReset, sizeof(cReset));
		usleep(500000);
		LOG_INF("getting pallet angle failed\n");
		return -1;
		
	}
	uiSize = recv_uart(g_stAgvParm.iUartFd, cDatabuf, UART_RET_SIZE - 1);// modified by jason
	if (uiSize <= 0)
	{
		LOG_ERR("receive pallet info failure\n");
		return -1;
	}
	cDatabuf[uiSize] = '\0';

	//cDatabuf = "100891;3.1,180.0"
	//get direction of pallet and pallet angle offset,in the initial����Direction A:g_stAgvAttr.iPalletDirect = g_stAgvAttr.iDirection = FORWARD 
	pTmp = strtok(cDatabuf, ";");
	if (pTmp == NULL)
	{
		LOG_ERR("get shelf'QR from camera data failure\n");
		return -1;
	}
	strcpy(g_stAgvAttr.cContainer, pTmp); //cContain = "100891"
	iQR = atoi(g_stAgvAttr.cContainer);

	pTmp = strtok(NULL, ";");
	if (pTmp == NULL)
	{
		LOG_ERR("get shelf'Angle(such as:3.1,180.0) from camera data failure\n");
		return -1;
	}
	if (g_stTopCameraDev.iUartVersion == CAMERA_VERSION_CHECK)//add by du 20181023 for top video version 42bba, support QR and DM 
	{
		int   iXDiff = 0;
		int   iYDiff = 0;
		char *pTmp1 = NULL;
		char *pTmp2 = NULL;
		char *pTmp3 = NULL;

		strcpy(cAngle, pTmp);
		LOG_INF("Video data =%s\n", pTmp);
		pTmp1 = strtok(cAngle, ",");
		if (pTmp1 == NULL)
		{
			LOG_ERR("get first data from camera data failure\n");
			return -1;
		}
		pTmp2 = strtok(NULL, ",");
		if (pTmp2 == NULL)
		{
			LOG_ERR("get second data from camera data failure\n");
			return -1;
		}
		pTmp3 = strtok(NULL, ",");
		if (pTmp3 == NULL)
		{
			pQRInfo->fAngle = atof(pTmp2);
			pQRInfo->iXOffset = 0;
			pQRInfo->iYOffset = 0;
			pQRInfo->iQR = iQR;
		}
		else
		{
			pQRInfo->fAngle = atof(pTmp1);
			pQRInfo->iXOffset = atoi(pTmp2);
			pQRInfo->iYOffset = atoi(pTmp3);
			pQRInfo->iQR = iQR;
				
		}
	}
	else if (g_stTopCameraDev.iUartVersion == CAMERA_VERSION_SUPDIFF)//add by jxu 20180920-the version to only support the angle,X,Y
	{
		//100110;180,x,y
		int   iXDiff = 0;
		int   iYDiff = 0;
		strcpy(cAngle, pTmp);//cAngle = "180,x,y"
		LOG_INF("Support diff=%s\n", pTmp);
		pTmp = strtok(cAngle, ",");
		if (pTmp == NULL)
		{
			LOG_ERR("get shelf'Angle(such as:180) from camera data failure\n");
			return -1;
		}
		fAngle = atof(pTmp);

		pTmp = strtok(NULL, ",");
		if (pTmp == NULL)
		{
			LOG_ERR("get shelf' XDiff from camera data failure\n");
			return -1;
		}
		iXDiff = atoi(pTmp);

		pTmp = strtok(NULL, ",");
		if (pTmp == NULL)
		{
			LOG_ERR("get shelf' YDiff from camera data failure\n");
			return -1;
		}
		iYDiff = atoi(pTmp);

		//pQRInfo->fAngle = fAngle*0.1;
		pQRInfo->fAngle = fAngle;
		pQRInfo->iXOffset = iXDiff;
		pQRInfo->iYOffset = iYDiff;
		pQRInfo->iQR = iQR;
	}
	else//the version to only support the angle add by jxu 20180920
	{
		strcpy(cAngle, pTmp);//"100891;3.1,180.0"
		LOG_INF("Support no diff=%s\n", pTmp);//add by jxu 20180920
		strtok(cAngle, ",");

		pTmp = strtok(NULL, ",");
		if (pTmp == NULL)
		{
			LOG_ERR("get shelf'Angle(such as:180) from camera data failure\n");
			return -1;
		}
		fAngle = atof(pTmp); //180��

		pQRInfo->fAngle = fAngle;
		pQRInfo->iXOffset = 0;
		pQRInfo->iYOffset = 0;
		pQRInfo->iQR = iQR;
	}

	return 0;
}
/*******************************************************************************
* Function Name      : uart_camera_init_check
* Description	     : get the version info from uart camera
* Input 		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int uart_camera_init_check()
{
	int iRet = 0;
	char cGetData[11] = { 0x16, 0x4d, 0x0d, 0x52, 0x45, 0x56, 0x5f, 0x53, 0x57, 0x3f, 0x2e };
	char cReset[3] = { 0x16, 0x55, 0x0D };

	char cDatabuf[UART_RET_SIZE] = { 0 };

	size_t uiSize = 0;
	fd_set stReadFds;
	//if (pQRInfo == NULL)
	//	return -1;

	struct timeval stTimeOut = { 8, 0 }; //5s  TO DO
	bzero(cDatabuf, sizeof(cDatabuf));

	FD_ZERO(&stReadFds);
	FD_SET(g_stAgvParm.iUartFd, &stReadFds);
	stTimeOut.tv_sec = 8;
	// send get data cmd to PGV
	uiSize = send_uart(g_stAgvParm.iUartFd, cGetData, sizeof(cGetData));

	LOG_INF("send getting pallet angle to camera\n");
	iRet = select(g_stAgvParm.iUartFd + 1, &stReadFds, NULL, NULL, &stTimeOut);
	if (iRet <= 0) //get pallet angle for 8s each time.
	{
		uiSize = send_uart(g_stAgvParm.iUartFd, cReset, sizeof(cReset));
		usleep(500000);
		LOG_INF("getting camera version failed\n");
		return -1;
	}
	uiSize = recv_uart(g_stAgvParm.iUartFd, cDatabuf, UART_RET_SIZE - 1);
	cDatabuf[uiSize] = '\0';
	if (uiSize <= 0)
	{
		LOG_INF("receive pallet info:failed\n");
		return -1;
	}
	LOG_INF("version is =%s\n", cDatabuf);
	return 0;
}
/*******************************************************************************
* Function Name      : get_camera_version_supportdiff
* Description	     : get the version info from uart camera
* Input 		     : NONE
* Return		     : error code on error, 0 on support the diff.
*******************************************************************************/
int get_camera_version_supportdiff()
{
	int iRet = 0;
	char cGetData[11] = { 0x16, 0x4d, 0x0d, 0x52, 0x45, 0x56, 0x5f, 0x57, 0x41, 0x3f, 0x2e };
	char cReset[3] = { 0x16, 0x55, 0x0D };

	char cDatabuf[UART_RET_SIZE] = { 0 };

	size_t uiSize = 0;
	fd_set stReadFds;

	struct timeval stTimeOut = { 8, 0 }; //5s  TO DO
	bzero(cDatabuf, sizeof(cDatabuf));

	FD_ZERO(&stReadFds);
	FD_SET(g_stAgvParm.iUartFd, &stReadFds);
	stTimeOut.tv_sec = 8;
	uiSize = send_uart(g_stAgvParm.iUartFd, cGetData, sizeof(cGetData));

	LOG_INF("send getting uart version to camera\n");
	iRet = select(g_stAgvParm.iUartFd + 1, &stReadFds, NULL, NULL, &stTimeOut);
	if (iRet <= 0) //get pallet angle for 8s each time.
	{
		uiSize = send_uart(g_stAgvParm.iUartFd, cReset, sizeof(cReset));
		usleep(500000);
		LOG_INF("getting camera version failed\n");
		return -1;
	}
	uiSize = recv_uart(g_stAgvParm.iUartFd, cDatabuf, UART_RET_SIZE - 1);
	cDatabuf[uiSize] = '\0';
	if (uiSize <= 0)
	{
		LOG_INF("receive uart version info:failed\n");
		return -1;
	}
	//WA version is =REV_WA: DD000038BBA^F
	char cVersion[12] = { "" };
	strncpy(cVersion, cDatabuf + 8, 11);
	cVersion[12] = '\0';
	LOG_INF("cDatabuf=%s cVersion is =%s\n", cDatabuf, cVersion);
	if (strcmp(cVersion, "DD000042BBA") >= 0)
	{
		LOG_INF("The uart camera suppport QR and DM\n");
		return 1;
	}
	else if (strcmp(cVersion, "DD000038BBA") >= 0)
	{
		LOG_INF("The uart camera suppport the XYdiff\n");
		return 0;
	}
	else
	{
		LOG_INF("The uart camera donnot support the diff in default\n");
		return -1;
	}
}
/*******************************************************************************
* Function Name      : uart_camera_get_qrinfo_check
* Description	     : get qr info from v4l2 camera
* Input 		     : NONE
* Output		     : pQRInfo: the qr info pointer
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int uart_camera_get_qrinfo_check(qr_info_t * pQRInfo, FILE *fp)
{
	int iRet = 0;
	char cGetData[3] = { 0x16, 0x54, 0x0D };
	char cReset[3] = { 0x16, 0x55, 0x0D };

	char cDatabuf[UART_RET_SIZE] = { 0 };
	char cAngle[UART_RET_SIZE] = { 0 };

	//char cCount = GET_PALLET_ANGLE_COUNT;
	char *pTmp = NULL;
	float fAngle = 0.0;
	size_t uiSize = 0;
	fd_set stReadFds;
	int iQR = 0;
	if (pQRInfo == NULL)
		return -1;

	struct timeval stTimeOut = { 8, 0 }; //5s  TO DO
	bzero(cDatabuf, sizeof(cDatabuf));

	//get pallet angle

	FD_ZERO(&stReadFds);
	FD_SET(g_stAgvParm.iUartFd, &stReadFds);
	stTimeOut.tv_sec = 8;
	// send get data cmd to PGV
	uiSize = send_uart(g_stAgvParm.iUartFd, cGetData, sizeof(cGetData));

	LOG_INF("send getting pallet angle to camera\n");
	iRet = select(g_stAgvParm.iUartFd + 1, &stReadFds, NULL, NULL, &stTimeOut);
	if (iRet <= 0) //get pallet angle for 8s each time.
	{
		uiSize = send_uart(g_stAgvParm.iUartFd, cReset, sizeof(cReset));
		usleep(500000);
		LOG_INF("getting pallet angle failed\n");
		return -1;

	}
	uiSize = recv_uart(g_stAgvParm.iUartFd, cDatabuf, UART_RET_SIZE - 1);// modified by jason
	if (uiSize <= 0)
	{
		LOG_ERR("receive pallet info failure\n");
		return -1;
	}
	cDatabuf[uiSize] = '\0';

	//cDatabuf = "100891;3.1,180.0"
	//get direction of pallet and pallet angle offset,in the initial����Direction A:g_stAgvAttr.iPalletDirect = g_stAgvAttr.iDirection = FORWARD 
	pTmp = strtok(cDatabuf, ";");
	if (pTmp == NULL)
	{
		LOG_ERR("get shelf'QR from camera data failure\n");
		return -1;
	}
	strcpy(g_stAgvAttr.cContainer, pTmp); //cContain = "100891"
	iQR = atoi(g_stAgvAttr.cContainer);

	pTmp = strtok(NULL, ";");
	if (pTmp == NULL)
	{
		LOG_ERR("get shelf'Angle(such as:3.1,180.0) from camera data failure\n");
		return -1;
	}

	strcpy(cAngle, pTmp);//cAngle = "3.1,180.0"
	strtok(cAngle, ",");

	pTmp = strtok(NULL, ",");
	if (pTmp == NULL)
	{
		LOG_ERR("get shelf'Angle(such as:180) from camera data failure\n");
		return -1;
	}
	fAngle = atof(pTmp); //180��

	pQRInfo->fAngle = fAngle;
	pQRInfo->iXOffset = 0;
	pQRInfo->iYOffset = 0;
	pQRInfo->iQR = iQR;
	LOG_INF("pQRInfo->fAngle=%f,pQRInfo->iQR=%d\n", pQRInfo->fAngle, pQRInfo->iQR);
	fprintf(fp, "pQRInfo->fAngle=%f,pQRInfo->iQR=%d\n", pQRInfo->fAngle, pQRInfo->iQR);
	return 0;
}
