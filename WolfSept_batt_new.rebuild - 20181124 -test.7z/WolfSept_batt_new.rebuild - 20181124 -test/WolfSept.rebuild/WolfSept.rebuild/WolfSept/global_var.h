/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* FileName:xxx.H
* Author: Menghu Wang   Version: V1.0   Data:2017-07-13
* Description:THE GLOBAL VARIATE OF AGV ,SUCH AS :STATE ,UART,UDP,CAN
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
#ifndef _GLOBAL_VAR_H__
#define _GLOBAL_VAR_H__
#include <time.h>
#include <errno.h>
#include <semaphore.h>  
#include <sys/time.h>
#include "uart.h"
#include "circle_queue.h"
#include "agv_pthread.h"
#include "can.h"
#include "udp.h"
#include "linkqueue.h"
#include "can_msg.h"
#include "dev_battery.h"
#include "udp_msg.h"
#include "debug.h"
#include "sem.h"
#include "ini_rw.h"
#include "atomic.h"
#include "dev_battery.h"

#define TRY_COUNT_LIMIT 100
#define DUMP_BATT_INFO_CYCLES	5
#define MAX_VOLT_DIFF	300	  // ��λ: mv
#define LOW_CHARGE_CUR_COUNT 30
#define RETRY_CHARGE_TIMES 1
#define BATTERY_CHARGE_SOC_100 100
#define BATTERY_CHARGE_SOC_60 60
#define CALIBRATION_SECONDS			60
#define CALIBRATION_FINISH_SOC        98 
#define CALIBRATION_FINISHED          1//by tiger.89
#define CALIBRATING						0//by tiger.89
#define NEED_NOT_CALIBRATION			(-1)//by tiger.89
#define CALIBRATION_TIMEOUT				(-2)//by tiger.89
#define HOURS_1_5     5400 // 1.5hours
#define CHARGE_HOURS_1_5_SOC 80//
#define CALIBRATE_VOLTAGE_V          510 //unit 0.1V,by tiger.89
//extern struct batt_info g_stBattInfoManage;   //yyf 20181124

#define TEST_POWER

extern pthread_mutex_t g_stChargeStatusMutexLock; //by tiger.41
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

typedef char i8;
typedef short i16;
typedef int i32;
typedef long long i64;

#define TRUE					1
#define FALSE					0

#define DEBUG_AGV				TRUE

#define MAX_TRY_TIMES			20
#define TIME_OUT_0S				0
#define TIME_OUT_100MS			100
#define TIME_OUT_1S				1000
#define TIME_OUT_2S				2000
#define TIME_OUT_4S				4000
#define TIME_OUT_8S				8000
#define TIME_OUT_10S			10000
#define TIME_OUT_20S			20000
#define TIME_OUT_30S			30000
#define TIME_OUT_60S			60000
#define TIME_OUT_180S			180000
#define TIME_OUT_10M			600000
#define TIME_OUT_30M			1800000

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
#define STR(s)      #s

#define DEFAULT_MC_MAC "000000000000" 

#define DEV_TC	0
#define DEV_MC	1

#define TASK_QUEUE_SIZE		100
#define UDP_MSG_SIZE		1024

#define SEQ_NUM						5
#define AGENENT_SEQ_ID				0
#define MC_SEQ_ID					1
#define TC_SEQ_ID					2
#define UDP_HEARTBEAT_SEQ_ID		3


#define CONTAINER_NUM_LENGTH	6  // container num of shelf length
#define INVALID_MSG_TYPE		-1
#define INVALID_SEQUENCE		-1
#define INVALID_TOKEN_ID		-1		//add  by tiger.34
#define RESERVE_TOKEN_ID		0		//add  by tiger.34

#define BATT_STATE_NOCHARGING	0
#define BATT_STATE_CHARGING		1

//add by jxu 20180820 beign
#define DISCHARGESHEET_SCALE 5 //discharging bms power increase 5 by voltage change
#define CHARGESHEET_SCALE 10 //charging bms power increase 10 by voltage change,the total power is 80*/
#define QUERY_FIRST_SECTION_SINGLEVOL	1
#define QUERY_SECOND_SECTION_SINGLEVOL	2
#define QUERY_THIRD_SECTION_SINGLEVOL	3
#define QUERY_FOURTH_SECTION_SINGLEVOL	4
#define ANSHANG_BMS_TYPE_BLUE           1
#define ANSHANG_BMS_TYPE_GREEN          2
#define ANSHANG_BMS_LOW_SINGLEVOL       3450
#define ANSHANG_BMS_MIN_SINGLEVOL       2500
#define ANSHANG_BMS_MAX_SINGLEVOL       4300
#define ANSHANG_BMS_LOW_SOC_30				30
#define ANSHANG_BMS_LOW_SOC_29				29
#define ANSHANG_BMS_LOW_SOC_15				15
extern float g_fChargeVoltage[7][9];
extern float g_fDischargeVoltage[7][21];
extern int g_iTemperature[7];
extern int g_iSingleBattery[13];
//add by jxu 20180820 end

//add by jxu 20180920-begin
#define CAMERA_VERSION_NOSUPDIFF	0
#define CAMERA_VERSION_SUPDIFF		1
#define CAMERA_VERSION_CHECK		2	//add by du for version 42bba
//add by jxu 20180920-end

#define PANSONIC_CURRENT_HIGHESTBIT (0x8000) //8th is 1 discharge 0:charge://add by jxu 20181017
//add by jxu 20180419 beigin
#define  BAT_TYPE_ANSHANG             1
#define  BAT_TYPE_SONGXIA             2
#define  BAT_TYPE_ERROR				 -1
//add by jxu 20180419 end

#define CONFIGURE_FILE_PATH   "/root/jdagvclientserver/jdagvserver/flow.conf"

// for network basic info
#define NETIF_NAME_SIZE			16
#define ESSID_MAX_LEN			32
#define IP_LEN					32
typedef struct net_info
{
	char pNetDevName[NETIF_NAME_SIZE + 1];
	char pProtocolName[NETIF_NAME_SIZE + 1];
	char pEssid[ESSID_MAX_LEN + 1];
	double iFreq;
	int iChannel;
	int iBitRate;
	int iSensitivity;
	int iLinkQuality;
	int iSignalLevel;
	int iNoiseLevel;
	unsigned int iRXPkts;
	unsigned int RXErrorPkts;
	unsigned int RXDropPkts;
	unsigned int RXOverRunsPkts;
	unsigned int TXPkts;
	unsigned int TXErrorPkts;
	unsigned int TXDropPkts;
	unsigned int TXOverRunsPkts;
	char	pApAddr[IP_LEN];
	char	pLocalIpAddr[IP_LEN];
	char	pGateWayIpAddr[IP_LEN];
	int iConnectConsoleOK;
} net_info_t;

extern net_info_t g_stNetInfo;
#define TEMPER_BASE 40 //add by tiger.31
// for battery basic info

#define BATT_CELL_NUM		16
typedef struct batt_info
{
	int32_t	iBattManufactor;				// ������Ϣ�� ���磺���£�����
	int32_t	iBattVersion;					// �汾��Ϣ�� ���磺���У����棬�̰棩�����£�11,15��

	uint16_t uVoltage;						// ��ѹ��Ϣ�� 0.1v
	uint16_t uCurrent;						// ������Ϣ�� 0.1A
	uint8_t uSoc;				     	// ������Ϣ�� 0-100
	uint8_t uTemp;							// �¶���Ϣ�� temp+40
	uint8_t uState;							// ���״̬�� 1 : charging 0: no charging
	uint8_t uCellNum;						// ��о������ battery set number

	uint32_t uInquiryCount;					//check battery info count,add by tiger.
	uint32_t uCalibrateTime;				//calibrate time ,by tiger.89
	uint8_t uNeedCheckSoc;					//record last reboot soc

	int16_t iVState;						// ���е�����еģ�VState
	int16_t iCState;						// ���е�����еģ�CState
	int16_t iTState;						// ���е�����еģ�TState
	uint8_t iFETState;						// ���е�����еģ�iFETState//add by jxu 20181017
	uint8_t iAlarm;							// ���е�����еģ�iAlarm//add by jxu 20181017
	uint16_t iPreVoltDiffProtectUser;       // ���е���쳣���ϴε�ѹ��ƽ��
 	
	int iMoidfySocFlag;
	uint8_t uSocOrg;				     	// ������Ϣ�� 0-100
	uint8_t uSocModified;                   //������Ϣ�� 0-100

	// ���ڵ�ص�ѹ��Ϣ��
	int16_t	iBattCellVolt[BATT_CELL_NUM];	// �����ѹ�б�
	int16_t iBattCellVoltMax;				// �����ѹ�����ֵ
	int16_t iBattCellVoltMin;				// �����ѹ����Сֵ
	int16_t iBattCellVoltDelt;              // �����ѹѹ��

	// ��ع�����Ϣ
	int16_t iVoltDiffProtectSys;		    //	��ѹ��ƽ��/ѹ���ϵͳ�ж�
	int16_t iVoltDiffProtectUser;		    //	��ѹ��ƽ��/ѹ��������ж�
	int16_t iDischargeUnderVolt;			//	�ŵ�Ƿѹ��־
	int16_t iChargeUnderVolt;				//	���Ƿѹ��־
	int16_t iBatteryFullFlag;				//	��س�����־
	int16_t iBatteryCapacityLowFlag;		//	�����ͱ�־

	int16_t iDischargeOverCurrFlag;			//	�ŵ������־
	int16_t iChargeFaultFlag;				//	�����ϱ�־
	int16_t iDischargeOverVoltProtection;	//	�ŵ��ѹ����
	int16_t iDischargeUnderVoltProtection;	//	�ŵ�Ƿѹ����
	int16_t iDischargeOverTemProtection;	//	�ŵ����
	int16_t iTempSensorFault;				//	�¶ȴ���������
	int16_t iDischargeOverCurrProtection;	//	�ŵ��������

	int16_t iSwitchAction;				//	��������
	int16_t iBattCellOverVolt;			//	�����ѹ
	int16_t iBattCellUnderVolt;			//	����Ƿѹ
	int16_t iBattGroupOverVolt;			//	������ѹ
	int16_t iBattGroupUnderVolt;		//	�����Ƿѹ
	int16_t iBattCellOverVoltWarn;		//	�����ѹ�澯ֵ
	int16_t iBattCellUnderVoltWarn;		//	����Ƿѹ�澯ֵ
	int16_t iBattGroupOverVoltWarn;		//	������ѹ�澯ֵ
	int16_t iBattGroupUnderVoltWarn;	//	�����Ƿѹ�澯ֵ

	int16_t iCommBreak;					//	����
	int16_t iLowVoltProhibitCharge;		//	��ѹ-��ֹ���
	
	int16_t iChargeStateFault;			//  ���״̬�쳣
	int16_t iDischargeStateFault;		//  �ŵ�״̬�쳣
	int16_t iChargeOverCurrProtection;	//  ����������
	int16_t iShortCircuitProtection;	//	��·����
	int16_t iDischargeOverCurrL1;		//	�ŵ����1��
	int16_t iDischargeOverCurrL2;		//	�ŵ����2��
	int16_t iChargeOverCurrWarn;		//	�������澯ֵ
	int16_t iDischargeOverCurrWarn;		//	�ŵ�����澯ֵ

	int16_t iDischargeSwitchState;		//	�ŵ翪��״̬
	int16_t iChargeSwitchState;			//	��翪��״̬
	int16_t iDischargeSwitch;			//	�ŵ翪��
	int16_t iChargeSwitch;				//	��翪��
	int16_t iDischargeMOSFlag;			//	�ŵ�mos��־
	int16_t iChargeMOSFlag;				//	���mos��־

	int16_t iChargeOverTempProtection;		//	�����±���
	int16_t iChargeUnderTempProtection;		//	���Ƿ�±���
	int16_t iDischargeOverTempProtection;	//	�ŵ���±���
	int16_t iDischargeUnderTempProtection;	//	�ŵ�Ƿ�±���
	int16_t iEnvOverTempProtection;			//	�������±���
	int16_t iEnvUnderTempProtection;		//	����Ƿ�±���
	int16_t iPowerOverTempProtection;		//	���ʹ��±���
	int16_t iPowerUnderTempProtection;		//	����Ƿ�±���
	int16_t iDischargeOverTempWarn;			//	�ŵ���±���
	int16_t iChargeOverTempWarn;			//	�����±���
	int16_t iBattCellOverTempWarn;			//	��о���¸澯
	int16_t iBattCellUnderTempWarn;			//	��оǷ�¸澯
	int16_t iEnvOverTempWarn;				//	�������¸澯
	int16_t iEnvUnderTempWarn;				//	����Ƿ�¸澯
	int16_t iPowerOverTempWarn;				//	���ʹ��¸澯
	int16_t iPowerUnderTempWarn;			//	����Ƿ�¸澯

	//add by jxu 20181017-begin blue bms exception
	int16_t iHighVolProtect;		        //	��ѹ����
	int16_t iLowVolProtect;			        //	��ѹ����
	int16_t iOffLineProtect;			    //	���߱���
	int16_t iChargeOverCurrent;			    //  ������
	int16_t iDischargeOverCurrent;			//	�ŵ����
	int16_t iShortCircuitPortect;		    //	��·����
	int16_t iHighTemPortect;				//	���±���
	int16_t iLowTemPortect;				    //	���±���
	//add by jxu 20181017-end blue bms exception

	//add by yyf 20181022-begin ,support can protocol(201800911) for songxia battery
	int16_t iChargeOverVolFlag;			//����ѹ��־
	int16_t iDischargeUnderVolFlag;		//�ŵ�Ƿѹ��־
	int16_t iChargeOverCurrentFlag;		//��������־
	int16_t iChargeUnderTempWarn;		//���Ƿ�±���
	int16_t iDischargeUnderTempWarn;	//�ŵ�Ƿ�±���

	int16_t iChargeErrFlag;				//��������ϱ�־
	int16_t iDishargeOverCurrentFlag;	// �ŵ������־

	int16_t iSoftVersion;               //�����汾

	int16_t iCycleTimes;				//ѭ������ 

	//add by yyf 20181022-end ,support can protocol(201800911) for songxia battery

	int(*batt_inquiry_bms_info)(struct batt_info *pBattInfo);
	int(*batt_recv_bms_info)(struct batt_info *pBattInfo);
	int(*batt_bms_info_exception_handle)(struct batt_info *pBattInfo);
	int(*batt_update_bms_info)(struct batt_info *pBattInfo);
	int(*batt_commit_bms_info)(struct batt_info *pBattInfo);
	int(*batt_dump_bms_info)(struct batt_info *pBattInfo);

} batt_info_t;

// for panasonic battery warning\error info
typedef struct bat_warn_error_info
{
	uint8_t		uTempFlags;		// Byte0:over temperature warn for charging/discharging
	uint8_t		uVoltFlags;		// Byte1:over voltage warn for charging/discharging
	uint8_t		uChargeFlags;	// Byte2:
	uint8_t		uResv1;			// Byte3:reserve
	uint8_t     uResv2;			// Byte4:reserve
	uint8_t     uResv3;			// Byte5:reserve
	uint8_t     uCycleTimesH;	// Byte7:cycle times hi bit
	uint8_t     uCycleTimesL;	// Byte8:cycle times lo bit
} bat_warn_error_info_t;

#define CONTAINER_SIZE	32

// 0 :not on limit switch 1: up 2: down
#define PALLET_STATUS_NULL		0
#define PALLET_STATUS_TOP		1
#define PALLET_STATUS_BOT		2
#define PALLET_STATUS_UNKONWN	3

typedef struct
{	
	u8 key;
	u32 value;
}key_value;  //add by tiger

typedef struct
{
	u8 key;
	float value;
}key_fvalue;  //add by tiger

#define AGV1_0   1
#define AGV2_0   2
typedef struct agv_attr
{
	int iProtoVer;
	int iAgvName;
	i64 iLocation;
	int iTokenNum;
	struct batt_info bms;
	int iBmsVersion;//add by jxu 20180910-begin
	int iBmsVID;
	int iBmsPID;//add by jxu 20180910--end
	int iBatType;//add by jxu 20180820-begin 1:anshang 2 songxia
	int iAnshangBmsType;//1:bule bms 2:green bms
	int iQueryFlag;
	int iMoidfySocFlag;
	int iOriginalSocVal;
	int iSingleMinVol;
	int iSingleMaxVol;//add by jxu 20181017
	int iStopChargeConflict;//add by jxu 20180820-end
	int iStopChargeFromMM;//add by jxu 20181017
	int iStatus;
	int iSpeed;
	//int iDirection;  
	int iGXOffset;
	int iGYOffset;
	int iGAngleOffset;
	int iTXOffset;
	int iTYOffset;
	int iPalletDirect;
	int iTaskPalletDirect;//add by jxu 20180322
	int iTAngleOffset;
	int iMoveStatus;//save agv status from arm
	int iMcHeartBeatStatus; //save mc status from its heartbeat,by tiger.61
	int iEvent;
	int iServoSubErr;//add by jxu 20180511

	int iSreamin;	// for debug tool
	int iGsDev;		// for debug tool
	int iGSDevFB;	// for debug tool
	int iGSAngle;	// for debug tool
	int iPath;		// for debug tool
	int iNewTag;	// for debug tool
	int iFinishTag;	// for debug tool

	int iGsDevOnline; // for online version,unit 0.1mm
	int iGSDevFBOnline;	// for online version,unit 0.1mm
	int iGSAngleOnline;	// for online version,unit 0.1degree

	int iPalletStatus; // 0 :not on limit switch 1: up 2: down
	atomic_t iException;//such as:1003,2009,3004
	atomic_t iAckException;//add by jxu 20180524
	int iBigVer;
	int iBigVerDate;
	int iMCStatus;  
	int iMCVerDate;
	int iTCVerDate;
	int iMCVehType;
	int iTCVehType;
	int iDSPStatus;
	int iDSPGeneration;
	int iAGVType;
	int iVehHeadDirect;// agv direction
	int iRaiseTAngle;
	char cContainer[CONTAINER_SIZE];

	// used for deal_mc_ack
	int iMcAction;
	int iMcStyle;
	int iMcVersion;
	int iMcState;//OK: the cmd will be excute; REFUSE:thc cmd will be drop,add annotation by tiger.17
	int iMcError;
	//used for deal_mc_fin,by tiger.91
	int iFinishPointId;
	
	// used for deal_tc_ack
	int iTcAction;
	int iTcStyle;
	int iTcVersion;
	int iTcState;//OK: the cmd will be excute; REFUSE:thc cmd will be drop ,add annotation by tiger.17
	int iTcError;
	//used for set and get flag key-value ,add by tiger
	key_value stMcProperty;
	key_value stTcProperty;
	//used for set and get pram key-value ,add by tiger
	key_fvalue stMcPropertyPram;
	key_fvalue stTcPropertyPram;
	//used for mc update cmd
	int iAppCrc;
	int iFileSize;
	int iCrcCheckRet;
	///used for updating from agent cmd
	char pVersion[100];
	bool bCheckGroundDir;

	char pSN[20];	//ARM MAC
	char pIP[16]; //ARM IP

	char pFtpServerIp[16];//ftp server ip,by tiger.64
	char pWarehouseBrainIp[16];//warehouse brain server ip,by tiger.65
	char pMcMAC[20];//mc MAC ,by tiger.66
	//PGV
	i8 i8PgvState;
	int iBootMethod;
} agv_attr_t;


typedef struct agv_conf
{
	char cSendPoint;
	char cCheckPoint;	// 1: will check the walk action with the real point of QR
	char cDebugEnable;	// 1: will not check groud and shelf QR, and print debug information
	char cChargeType;	// 1: ON_WALL, 0:ON_GROUND
	char cSendStatistical;//1:enable send statistical info to server;0: disable(default),add by tiger.51
	char cPgvPeriod;//add by jxu 20180709
} agv_conf_t;

typedef struct agv_parm
{
	int iCanSocketFd0;
	int iCanSocketFd1;
	int iMsgSocketFd;
	int iInfSocketFd;
	int iCfgSocketFd;
	int iUartFd;

	char cServerIp[IP_LEN];
	int  iMsgRecvServerPort;
	int  iMsgSendServerPort;
	int  iInfRecvServerPort;
	int  iInfSendServerPort;
	int  iCfgRecvServerPort;
	int  iCfgSendServerPort;

	struct stLinkQueue * pUdpTxQueue;
	struct stLinkQueue * pUdpRxQueue;
	
	struct stQueueType * pTaskQueue;  //the task circle queue 
	struct stQueueType * pSendQueue;  //the messege circle queue to send
	
	struct stLinkQueue * pPathQueue;
	struct stLinkQueue * pCanRxQueue;//add by tiger
	struct stLinkQueue * pErrorRxQueue;//add by tiger
	struct stLinkQueue * pBmsCanFrameQueue;//add by tiger
} agv_parm_t;

typedef enum
{
	TC_LOG_TYPE_INVALID = -1,
	TC_LOG_TYPE_TURN = 1
}enTcLogType;

typedef enum
{
	MC_LOG_TYPE_INVALID = -1,
	MC_LOG_TYPE_WALK = 1,
	MC_LOG_TYPE_TURN = 2,
	MC_LOG_TYPE_PGV = 3,

}enMcLogType;

typedef struct _agv_action
{
	u8 iType;
	enMcLogType eMcLogType; //log type need to be get
	enTcLogType eTcLogType; // log type need to be get
	int iResult; //the result of excuting action,be set in ACK or Finish
	sem_t stActSem;
	pthread_mutex_t stActLock;
} agv_action_t;

#define TIME_STR_LEN		32
typedef struct _agv_task
{
	bool bSliding; //the location is in the task queue ,add by tiger.28
	char pStartTime[TIME_STR_LEN];
	char pEndTime[TIME_STR_LEN];
	i64 iSrcPoint;
	i64 iDstPoint;
	int iQRDistance;//add by jxu 20180312
	int iWalkTimeout;
	bool iWalkContinue;
	int iDevType;
	int iTaskDir;
	task_type_t enTaskType;
	agv_action_t stAction;
	int i32TaskID;
} agv_task_t;

extern agv_task_t g_stAgvTask;   //the task attribution of agv,add by tiger
extern agv_attr_t g_stAgvAttr;	// agv global attribution
extern agv_conf_t g_stAgvConf;	// agv configure
extern agv_parm_t g_stAgvParm;	// agv parameter(s)

/* Private variables ---------------------------------------------------------*/

enum
{
	PowerOn = 0,
	StandBy = 1,
	Running,
	Suspend,
	Reset

} enAgvState;  // agv state

/***************udp para end ***********************/

/**********control can para end ********************/

#define BATT_CAN_DEV			CAN1
#define CANID_ANY               0
#define BATT_CAN_FIL_SIZE		14   //add by yyf 20181022 change from 9 to 14
#define BATT_REQ_CANID			0x16
#define BATT_ACK_CANID			0x10
#define BATT_ACK_CANID_0X11		0x11 //add by yyf 20181022 can protocol for songxia battery 
#define BATT_ACK_CANID_0X12		0x12 //add by yyf 20181022 can protocol for songxia battery
#define BATT_ACK_CANID_0X13		0x13 //add by yyf 20181022 can protocol for songxia battery
#define BATT_ACK_CANID_0X14		0x14 //add by yyf 20181022 can protocol for songxia battery
#define BATT_ACK_CANID_0X15		0x15
#define BATT_REQ_V2_CANID		0x20
#define BATT_CHARGE_FLAG		0x5A
#define BATT_STOP_CHARGE_FLAG	0xA5

//add by jxu 20180910-begin
#define BATT_REQ_CANID_0X18					0x18
#define BATT_ACK_CANID_0X19					0x19
#define BATT_ACK_CANID_0X1C					0x1C
#define BATT_ACK_CANID_0X1D                 0x1D  //add by yyf 20181022 can protocol for songxia battery
#define BMS_INQUIRY_CANID					0xF1
#define BMS_FLASH_ERASE_CANID				0xF3
#define BMS_PACKAGE_LEN_CANID				0xF5
#define BMS_BINFILE_TRAS_CANID				0xF6
#define BMS_JUMP_BOOT_CANID					0xF9
#define BMS_BINFILE_TRAS_ERR_CANID			0xF0
#define BMS_UPDATE_MIN_SOC                  20
#define BMS_PANSONIC_VID                    21584
//add by jxu 20180910-end

extern struct can_filter	g_stBatCanFilter[BATT_CAN_FIL_SIZE];

#define CTRL_CAN_DEV		CAN0 
#define BATT_CAN_DEV		CAN1 
#define CTRL_CAN_FIL_SIZE	21 //by tiger.08 //add by jxu 20180121: from 11 to 15//by tiger.43 18+2(0x504,0x508)
extern struct can_filter	g_stCtrlCanFilter[CTRL_CAN_FIL_SIZE];
//dsp update can id
#define ARM2MC_UPDATE_DATA_CANID    0x506
#define MC2ARM_UPDATE_DATA_CANID    0x508
#define ARM2MC_UPDATE_CANID         0x502
#define MC2ARM_UPDATE_CANID         0x504

/// top controller CAN ID 
#define ARM2TC_ANGLE_CANID		  (0x304)
#define ARM2TC_ANGLE_ACK		  (0x314)

#define TC_CANID_REQ			  (0x204)
#define TC_CANID_ACK	          (0x184)
#define TC_CANID_FINISH			  (0x284)
#define TC_CANID_ERR              (0x324)
#define TC_DATA_DLC				  (0x08)

#define TC_2MC_FINISH             (0x286)
#define TEST_CANID	              (0x7EE)

/// wheels controller CAN ID

#define MC_CANID_REQ			  (0x202)
#define MC_CANID_ACK			  (0x182)
#define MC_CANID_HEART			  (0x282)
#define MC_CANID_FINISH           (0x382)  
#define MC_DATA_DLC				  (0x08)

/// PGV CAN ID
#define PGV_CANID_START 			(0x000)
#define PGV_CANID_TxPDO1			(0x188)
#define PGV_CANID_TxPDO2			(0x288)
#define PGV_CANID_TxPDO3			(0x388)
#define PGV_CANID_TxPDO4			(0x488)
#define PGV_CANID_TxTEST			(0x608)
#define PGV_CAN_TESTACK				(0x708)
#define FTP_TC_UPLOAD_CANID			(0x714)
#define FTP_MC_UPLOAD_CANID			(0x715)

#define PGV_ON		0x01
#define PGV_OFF		0x02
#define CYCLE_TIME			100  //ms by tiger.19

// add by jxu 20180116:add the two generation canid begin
#define MC_CAN_REQ_V2_CANID                       (0x202)
#define MC_CAN_ACK_V2_CANID                       (0x204)
#define MC_CAN_HEARTBEAT_V2_CANID                 (0x184)
#define MC_CAN_FINISH_V2_CANID                    (0x284)
#define MC_CAN_ERR_V2_CANID                       (0x384)
#define MC_CAN_FLAG_PARAM_REQ_V2_CANID            (0x302)
#define MC_CAN_FLAG_PARAM_ACK_V2_CANID            (0x304)
#define TP_CAN_ANGLEREQ_V2_CANID                  (0x402)
#define TP_CAN_ANGLEACK_V2_CANID                  (0x404)
										          
#define MC_DATA_DLC_V2  				          (0x08)
#define MC_CAN_RESERVE_V2                         (0x0)

#define MC_TYPE_READ_V2_FLAG   		              (0x01)
#define MC_TYPE_SET_V2_FLAG                       (0x02)
#define MC_TYPE_READ_V2_PARAM  		              (0x03)
#define MC_TYPE_SET_V2_PARAM                      (0x04)
									              
#define MC_VERSION_KEY_V2_F			              (0x05)
#define MC_PLATE_STATUS_KEY_V2_F	              (0x0D)

#define MC_ACTION_ACK_OK_V2                       (0x0)
#define MC_ACTION_ACK_PARAM_ERR_V2                (0x1)
#define MC_ACTION_ACK_MC_ERR_V2                   (0x2)
#define MC_ACTION_ACK_PARK_PRECESION_ERR_V2       (0x3)
#define MC_ACTION_ACK_PLATE_UP_LEVEL_V2           (0x4)
#define MC_ACTION_ACK_PLATE_DOWN_LEVEL_V2         (0x5)
#define MC_ACTION_ACK_REFUSE_V2                   (0x6)
#define MC_ACTION_OTHER_ERR_V2                    (0xFF)

#define MC_STYLE_ERR_MCINTERNALERR                (0x01)
#define MC_STYLE_ERR_SERVERWARNING                (0x02)
#define MC_STYLE_ERR_SYSTEWARNING                 (0x03)
#define MC_STYLE_ERR_SYSTEMSTATUS                 (0x04)
#define MC_STYLE_ERR_SYSTEMERR                    (0x10)

#define MC_ERR_AGVSAFE						   (0x05)
#define MC_ERR_NOCONTACTIMPACT				   (0x06)

#define MC_ERR_LOSENAVIGATE      			   (0x01)
#define MC_ERR_DIFFOVAFTERTHREE  			   (0x02)
#define MC_ERR_WHEEL_ANGLEDIFFOV 			   (0x03)
#define MC_ERR_PLATE_ANGLEDIFFOV 			   (0x04)
#define MC_ERR_EMERSTOP          			   (0x05)
#define MC_ERR_EMERSTOPPRESS     			   (0x06)
#define MC_ERR_TURNING						   (0x08) //add by tiger.69


#define MC_ERR_TC_LIFT_TACK_1MIN        	   (0x10)
#define MC_ERR_DERAIL            			   (0x11)
#define MC_ERR_CHARGE_FEEDBACK_OVERTIME 	   (0x12)
#define MC_ERR_OB_DETECT_FAULT_EVENT    	   (0x13)
#define MC_ERR_RESET 						   (0x14) //add by tiger.70

#define MC_ERR_LEFTSERVOINVALID  			   (0x20)
#define MC_ERR_RIGHTSERVOINVALID 			   (0x21)
#define MC_ERR_ENCODERL						   (0x22)
#define MC_ERR_ENCODERR						   (0x23)
#define MC_ERR_MOTORL_NO_ACTION_EVENT   	   (0x24)
#define MC_ERR_MOTORR_NO_ACTION_EVENT   	   (0x25)
#define MC_ERR_PLATE_CYCLE_SERVO_ERR    	   (0x26)
#define MC_ERR_PLATE_CYCLE_ENCODER_ERR		   (0x27)
#define MC_ERR_PLATE_CYCLE_MOTOR_NO_ACTION	   (0x28)

#define MC_ERR_BASE1                           (1981)
#define MC_ERR_LIFT_SERVO_INVALID	           (0x29)
#define MC_ERR_LIFT_SERVO_ENCODER_ERR	       (0x2A)
#define MC_ERR_LIFT_SERVO_MOTOR_NO_ACTION	   (0x2B)
#define MC_ERR_LWHEEL_SERVO_OFFLINE	           (0x2C)
#define MC_ERR_RWHEEL_SERVO_OFFLINE			   (0x2D)
#define MC_ERR_PLATE_CYCLE_SERVO_OFFLINE	   (0x2E)
#define MC_ERR_LIFT_SERVO_OFFLINE			   (0x2F)
#define MC_ERR_SERVO_INITIAL_ERR        	   (0x30)
#define MC_ERR_LWHEEL_SERVO_DISCONNECT   	   (0x31)
#define MC_ERR_RWHEEL_SERVO_DISCONNECT	       (0x32)
#define MC_ERR_PLATE_CYCLE_SERVO_DISCONNECT	   (0x33)
#define MC_ERR_LIFT_SERVO_DISCONNECT	       (0x34)

#define MC_ERR_BASE2                           (1982)
#define MC_ERR_EMO_LWHEEL_SERVO_ERROR   	   (0x35)
#define MC_ERR_EMO_RWHEEL_SERVO_ERROR	       (0x36)
#define MC_ERR_EMO_PLATE_SERVO_ERROR	       (0x37)
#define MC_ERR_EMO_LIFT_SERVO_ERROR	           (0x38)
#define MC_ERR_MOTEC_LWHEEL_SERVO_ERROR	       (0x39)
#define MC_ERR_MOTEC_RWHEEL_SERVO_ERROR	       (0x3A)
#define MC_ERR_MOTEC_PLATE_SERVO_ERROR	       (0x3B)
#define MC_ERR_MOTEC_LIFT_SERVO_ERROR	       (0x3C)
#define MC_ERR_HSLS_LWHEEL_SERVO_ERROR	       (0x3D)
#define MC_ERR_HSLS_RWHEEL_SERVO_ERROR	       (0x3E)
#define MC_ERR_HSLS_PLATE_SERVO_ERROR	       (0x3F)
#define MC_ERR_HSLS_LIFT_SERVO_ERROR	       (0x40)
// add by jxu 20180116:add the two generation canid end

//add by jxu 20180205:statis the offset begin
#define MOVE_TYPE_GOING              (1)
#define MOVE_TYPE_GO_FINISH          (2)
#define MOVE_TYPE_TURN_FINISH        (5)
//add by jxu 20180205:statis the offset end

typedef enum
{
	agv_offline = 1,
	agv_stop = 2,
	agv_walk = 3,
	agv_sync_left = 4,
	agv_sync_right = 5,
	agv_tc_rise = 6,
	agv_tc_lay = 7,
	agv_charge = 8,
	agv_back = 9,
	agv_online = 10, //10
	agv_wheel_left = 11,
	agv_wheel_right = 12,
	agv_pallet_left = 13,
	agv_pallet_right = 14,
	agv_slow_go_back = 15,
	agv_slow_go_straight = 16,
	agv_left_arc = 17,
	agv_right_arc = 18,
	agv_stop_charge = 19,
	agv_reset = 20,
	agv_update = 21
} agv_move_status;

struct PGV_MSG_t
{
	uint16_t u16Status;
	uint16_t u16Warning;
	uint32_t u32Tag;
};
#define ONE_MB  (1024*1024)
typedef struct _dsp_log
{
	u8     u8RamData[ONE_MB];
	int    iSize;
	bool    bUploadFinish;
}DspLog;
extern DspLog g_stDspLog;
#define PGV_CC1_BIT  0x0800
/*********configue information*********************/
#define CONFIGURE_FILE "/root/jdagvclientserver/jdagvserver/flow.conf"
#define VERCRC_CONF "/root/jdagvclientserver/jdagvserver/dcu/version.txt"
#define UPDATE_PATH  "/root/jdagvclientserver/jdagvserver/"
#define MASTER_FILE_PATH "/root/jdagvclientserver/jdagvserver/dcu_update"
#define MC_TC_FILE_PATH "/root/jdagvclientserver/jdagvserver/dsp_update"
#define TRY_5_TIMES 5
#define AGV_OK		1
#define AGV_NOT_OK	0
/*********configuer information *********************/

/*********control can para end *********************/

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

extern void version(FILE *fp);
extern void usage(FILE *fp, int rc);
extern int get_current_time(char * pTimeBuff, int iLength);
extern int get_current_timestamp_ms(u64 * pTimeStamp);
extern int compute_angle_offset(int iAngle);
extern int convert_agv_offset();
extern int update_mcu_log();
extern int update_net_log();
extern int dump_exception_context();
extern int get_seq(int iSeqIndex);
extern char * get_msg_name(int iMsgType);
extern char * get_action_name(int iActionType);
extern char * get_can_desc(int iCanId);
extern int write_rtc(time_t liTime);
extern int sync_time_to_mc(void);
extern void init_seq(int iAgentSeq, int iMcSeq, int iTcSeq,int iHBSeq);//by tiger.79
extern int check_boot_method(agv_attr_t* stAgvAttr);/*BY YU 20181024*/
#endif /* __GLOBAL_VAR_H_ */



/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/
