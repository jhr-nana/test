#ifndef __FINDER_PATTERN_FINDER_H__
#define __FINDER_PATTERN_FINDER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include "globaldefine.h"

extern int IMG_WIDTH;   // 图像的宽
extern int IMG_HEIGHT;  // 图像的高
extern  uint8_t detectedRingsNum;   // 检测到的圆环数目
extern  snake_detectedRing detectedRings[MAX_RING_NUM]; // 记录检测到的圆环
extern int g_iPatternIdxArray[MAX_RING_NUM];

// 图像滤波
void FuncImageFilter(uint8_t *img, int width, int height);

// 特征模式检测入口函数
bool FuncFindPatternCenters(uint8_t *image_);

#ifdef __cplusplus
}
#endif

#endif // end of __FINDER_PATTERN_FINDER_H__
