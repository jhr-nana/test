#ifndef JDM_VERSION_H
#define JDM_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

const char* FuncVersionInfo(void);

#ifdef __cplusplus
}
#endif

#endif // JDM_VERSION_H
