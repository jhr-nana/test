/********************************************************************************
* Copyright (c) 2018, JD.COM, Inc .
* All rights reserved.
* FileName: v4l_camera.h
* Author: Xu Jing   Version: V2.0   Data:2018-02-22
* Description: V4L2 video capture program.
********************************************************************************/

#ifndef __V4L_CAMERA_H_
#define __V4L_CAMERA_H_

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <errno.h>

#include "debug.h"

#define USERP_BUFFER_COUNT      (4)
#define MMAP_BUFFER_COUNT       (1)
#define MMAP_BUFFER_LOWER_LIMIT (0)
#define TRY_TIMES               (5) /* When some errors occur, try RY_TIMES times. */ 
#define BYTE_ONE_PIXEL          (2) /* On average, a pixel is represented by 2 bytes in yuyv format. */
#define NUMERATOR               (1)
#define DENOMINATOR             (30) /* NUMERATOR/1DENOMINATOR second per frame */

#define CONTROL_PARAMETER
#define CAMERA_STATES	(3)		/// the number of camera parameters' states

#define CLEAR(x) memset(&(x), 0, sizeof(x))

#ifndef NDEBUG
    #define D_PRINT(out, format, ...) fprintf(out, format, ##__VA_ARGS__)
#else
    #define D_PRINT(out, msg)
#endif

typedef int BOOL ;

#ifndef TRUE
    #define TRUE  (1)
#endif
#ifndef FALSE
    #define FALSE (0)
#endif

extern int CAMERA_FALL;
extern int CAMERA_RISE;
extern int CAMERA_CONST;

typedef enum _enum_camera_resolution
{
    en1080PWidth = 1280,
    en1080PHeight = 1024
}Enum_camera_resolu;

typedef enum io_method
{
    IO_METHOD_MMAP    = 0,
    IO_METHOD_READ    = 1,
    IO_METHOD_USERPTR = 2,
} EnumIOMethod;

typedef struct buffer
{
    void   *start;
    size_t  length;
} buffer_t;
typedef struct camera_param
{
	int brightness;
	int contrast;
	int saturation;
	int hue;
	int sharpness;
	int	white_balance;
	int gamma;
	int	exposure;
	int	gain;
} camera_param_t;

typedef struct camera
{
    int iFd;
    const char* pchCameraName;
    uint32_t uiWidth;
    uint32_t uiHeight;
    enum io_method enIOMethod;
    buffer_t* pstBuffer;
    size_t ulBufferNum;
    int iBufferIndex;
    buffer_t stHead;
	camera_param_t cameraParam[CAMERA_STATES];
} camera_t;
extern camera_t* open_camera(const char * pchCameraName);
extern int init_camera(camera_t *pstCamera, EnumIOMethod enIOMethod, uint32_t uiWidth, uint32_t uiHeight);
extern int start_capturing(const camera_t *pstCamera);
extern int read_frame(camera_t *pstCamera, struct timeval *pTimeVal);
extern int push_frame(camera_t* pstCamera);
extern int stop_capturing(const camera_t *pstCamera);
extern int uninit_camera(const camera_t *pstCamera);
extern int close_camera(camera_t *pstCamera);
extern void query_capability(camera_t *pstCamera);
extern void list_supported_fmt(camera_t *pstCamera);
extern void get_current_fmt(camera_t *pstCamera);
extern void query_ctrl(camera_t *pstCamera);
extern void set_camera_param(camera_t *pstCamera, int state);

#endif
