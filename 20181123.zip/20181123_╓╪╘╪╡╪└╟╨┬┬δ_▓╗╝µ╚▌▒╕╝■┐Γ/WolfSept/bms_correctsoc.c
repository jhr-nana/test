/********************************************************************************
* Copyright (c) 2018, JD.COM, Inc .
* All rights reserved.
* FileName: bms_correctsoc.c
* Author: Xu Jing   Version: V2.0   Data:2018-08-20
* Description:
********************************************************************************/
#include "bms_correctsoc.h"

#define DUMP_BATT_INFO_CYCLES	5		// ��λ����
#define MAX_VOLT_DIFF	300				// ��λ: mv
/*******************************************************************************
* Function Name      : get_manufactor_desc
* Description	     : get_manufactor_desc.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
char* get_manufactor_desc(int iManufactorid)
{
	char *pManufactorDesc = NULL;
	switch (iManufactorid)
	{
	case BAT_TYPE_ANSHANG:
		pManufactorDesc = "ANSHANG";
		break;
	case BAT_TYPE_SONGXIA:
		pManufactorDesc = "PANSONIC";
		break;
	default:
		pManufactorDesc = "UNKNOWN_MANUFACTOR";
	};
	return pManufactorDesc;
}
/*******************************************************************************
* Function Name      : dump_batt_info
* Description	     : print all information from battery bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int dump_batt_info(bat_info_t *pBattInfo)
{
	int i = 0;
	if (pBattInfo == NULL)
		return -1;

	LOG_INF("battery base information\n");
	LOG_INF("iBattManufactor               : %s\n", get_manufactor_desc(pBattInfo->iBattManufactor));//add by jxu 20181017
	LOG_INF("iBattVersion                  : %d\n", pBattInfo->iBattVersion);//add by jxu 20181017
	LOG_INF("uVoltage                      : %.2f V\n", (float)pBattInfo->uVoltage / 10.0);
	LOG_INF("uCurrent                      : %.2f A\n", (float)pBattInfo->uCurrent / 10.0);
	LOG_INF("uSoc                          : %d\n", pBattInfo->uSoc);
	LOG_INF("uTemperature                  : %d\n", pBattInfo->uTemp - TEMPER_BASE);
	LOG_INF("uState                        : %d\n", pBattInfo->uState);
	LOG_INF("uCellNum                      : %d\n", pBattInfo->uCellNum);

	LOG_INF("battery cell information\n");
	for (i = 0; i < BATT_CELL_NUM; i++)
	{
		LOG_INF("iBattCellVolt[%02d]             : %5d mv\n", i, pBattInfo->iBattCellVolt[i]);
	}	
	LOG_INF("iBattCellVoltMax              : %5d mv\n", pBattInfo->iBattCellVoltMax);
	LOG_INF("iBattCellVoltMin              : %5d mv\n", pBattInfo->iBattCellVoltMin);
	LOG_INF("iBattCellVoltDelta            : %5d mv\n", pBattInfo->iBattCellVoltMax - pBattInfo->iBattCellVoltMin);


	if (pBattInfo->iBattVersion == ANSHANG_BMS_TYPE_GREEN)
	{
		LOG_INF("green BMS:battery fault information\n");

		LOG_INF("iVoltDiffProtectSys           : 0x%04x\n", pBattInfo->iVoltDiffProtectSys);
		LOG_INF("iVoltDiffProtectUser          : 0x%04x\n", pBattInfo->iVoltDiffProtectUser);
		LOG_INF("iDischargeUnderVolt           : 0x%04x\n", pBattInfo->iDischargeUnderVolt);
		LOG_INF("iChargeUnderVolt              : 0x%04x\n", pBattInfo->iChargeUnderVolt);
		LOG_INF("iBatteryFullFlag              : 0x%04x\n", pBattInfo->iBatteryFullFlag);
		LOG_INF("iBatteryCapacityLowFlag       : 0x%04x\n", pBattInfo->iBatteryCapacityLowFlag);

		LOG_INF("iDischargeOverCurrFlag        : 0x%04x\n", pBattInfo->iDischargeOverCurrFlag);
		LOG_INF("iChargeFaultFlag              : 0x%04x\n", pBattInfo->iChargeFaultFlag);
		LOG_INF("iDischargeOverVoltProtection  : 0x%04x\n", pBattInfo->iDischargeOverVoltProtection);
		LOG_INF("iDischargeUnderVoltProtection : 0x%04x\n", pBattInfo->iDischargeUnderVoltProtection);
		LOG_INF("iDischargeOverTemProtection   : 0x%04x\n", pBattInfo->iDischargeOverTemProtection);
		LOG_INF("iTempSensorFault              : 0x%04x\n", pBattInfo->iTempSensorFault);
		LOG_INF("iDischargeOverCurrProtection  : 0x%04x\n", pBattInfo->iDischargeOverCurrProtection);

		LOG_INF("iSwitchAction                 : 0x%04x\n", pBattInfo->iSwitchAction);
		LOG_INF("iBattCellOverVolt             : 0x%04x\n", pBattInfo->iBattCellOverVolt);
		LOG_INF("iBattCellUnderVolt            : 0x%04x\n", pBattInfo->iBattCellUnderVolt);
		LOG_INF("iBattGroupOverVolt            : 0x%04x\n", pBattInfo->iBattGroupOverVolt);
		LOG_INF("iBattGroupUnderVolt           : 0x%04x\n", pBattInfo->iBattGroupUnderVolt);
		LOG_INF("iBattCellOverVoltWarn         : 0x%04x\n", pBattInfo->iBattCellOverVoltWarn);
		LOG_INF("iBattCellUnderVoltWarn        : 0x%04x\n", pBattInfo->iBattCellUnderVoltWarn);
		LOG_INF("iBattGroupOverVoltWarn        : 0x%04x\n", pBattInfo->iBattGroupOverVoltWarn);
		LOG_INF("iBattGroupUnderVoltWarn       : 0x%04x\n", pBattInfo->iBattGroupUnderVoltWarn);

		LOG_INF("iCommBreak                    : 0x%04x\n", pBattInfo->iCommBreak);
		LOG_INF("iLowVoltProhibitCharge        : 0x%04x\n", pBattInfo->iLowVoltProhibitCharge);

		LOG_INF("iChargeStateFault             : 0x%04x\n", pBattInfo->iChargeStateFault);
		LOG_INF("iDischargeStateFault          : 0x%04x\n", pBattInfo->iDischargeStateFault);
		LOG_INF("iChargeOverCurrProtection     : 0x%04x\n", pBattInfo->iChargeOverCurrProtection);
		LOG_INF("iShortCircuitProtection       : 0x%04x\n", pBattInfo->iShortCircuitProtection);
		LOG_INF("iDischargeOverCurrL1          : 0x%04x\n", pBattInfo->iDischargeOverCurrL1);
		LOG_INF("iDischargeOverCurrL2          : 0x%04x\n", pBattInfo->iDischargeOverCurrL2);
		LOG_INF("iChargeOverCurrWarn           : 0x%04x\n", pBattInfo->iChargeOverCurrWarn);
		LOG_INF("iDischargeOverCurrWarn        : 0x%04x\n", pBattInfo->iDischargeOverCurrWarn);

		LOG_INF("iDischargeSwitchState         : 0x%04x\n", pBattInfo->iDischargeSwitchState);
		LOG_INF("iChargeSwitchState            : 0x%04x\n", pBattInfo->iChargeSwitchState);
		LOG_INF("iDischargeSwitch              : 0x%04x\n", pBattInfo->iDischargeSwitch);
		LOG_INF("iChargeSwitch                 : 0x%04x\n", pBattInfo->iChargeSwitch);
		LOG_INF("iDischargeMOSFlag             : 0x%04x\n", pBattInfo->iDischargeMOSFlag);
		LOG_INF("iChargeMOSFlag                : 0x%04x\n", pBattInfo->iChargeMOSFlag);

		LOG_INF("iChargeOverTempProtection     : 0x%04x\n", pBattInfo->iChargeOverTempProtection);
		LOG_INF("iChargeUnderTempProtection    : 0x%04x\n", pBattInfo->iChargeUnderTempProtection);
		LOG_INF("iDischargeOverTempProtection  : 0x%04x\n", pBattInfo->iDischargeOverTempProtection);
		LOG_INF("iDischargeUnderTempProtection : 0x%04x\n", pBattInfo->iDischargeUnderTempProtection);
		LOG_INF("iEnvOverTempProtection        : 0x%04x\n", pBattInfo->iEnvOverTempProtection);
		LOG_INF("iEnvUnderTempProtection       : 0x%04x\n", pBattInfo->iEnvUnderTempProtection);
		LOG_INF("iPowerOverTempProtection      : 0x%04x\n", pBattInfo->iPowerOverTempProtection);
		LOG_INF("iPowerUnderTempProtection     : 0x%04x\n", pBattInfo->iPowerUnderTempProtection);
		LOG_INF("iDischargeOverTempWarn        : 0x%04x\n", pBattInfo->iDischargeOverTempWarn);
		LOG_INF("iChargeOverTempWarn           : 0x%04x\n", pBattInfo->iChargeOverTempWarn);
		LOG_INF("iBattCellOverTempWarn         : 0x%04x\n", pBattInfo->iBattCellOverTempWarn);
		LOG_INF("iBattCellUnderTempWarn        : 0x%04x\n", pBattInfo->iBattCellUnderTempWarn);
		LOG_INF("iEnvOverTempWarn              : 0x%04x\n", pBattInfo->iEnvOverTempWarn);
		LOG_INF("iEnvUnderTempWarn             : 0x%04x\n", pBattInfo->iEnvUnderTempWarn);
		LOG_INF("iPowerOverTempWarn            : 0x%04x\n", pBattInfo->iPowerOverTempWarn);
		LOG_INF("iPowerUnderTempWarn           : 0x%04x\n", pBattInfo->iPowerUnderTempWarn);
	}
	else if (pBattInfo->iBattVersion == ANSHANG_BMS_TYPE_BLUE)
	{
		LOG_INF("blue BMS:battery fault information\n");

		LOG_INF("iHighVolProtect               : 0x%04x\n", pBattInfo->iHighVolProtect);
		LOG_INF("iLowVolProtect                : 0x%04x\n", pBattInfo->iLowVolProtect);
		LOG_INF("iOffLineProtect               : 0x%04x\n", pBattInfo->iOffLineProtect);
		LOG_INF("iChargeOverCurrent            : 0x%04x\n", pBattInfo->iChargeOverCurrent);
		LOG_INF("iDischargeOverCurrent         : 0x%04x\n", pBattInfo->iDischargeOverCurrent);
		LOG_INF("iShortCircuitPortect          : 0x%04x\n", pBattInfo->iShortCircuitPortect);
		LOG_INF("iHighTemPortect               : 0x%04x\n", pBattInfo->iHighTemPortect);
		LOG_INF("iLowTemPortect                : 0x%04x\n", pBattInfo->iLowTemPortect);
	}
	else
	{
		//add by yyf 20181022-begin��support can protocol(201800911) for songxia battery
		LOG_INF("Songxia BMS:battery fault information\n");

		LOG_INF("iVoltDiffProtectSys             : 0x%04x\n", pBattInfo->iVoltDiffProtectSys);
		LOG_INF("iChargeOverTempProtection       : 0x%04x\n", pBattInfo->iChargeOverTempProtection);
		LOG_INF("iDischargeOverTempProtection    : 0x%04x\n", pBattInfo->iDischargeOverTempProtection);
		LOG_INF("iChargeOverTempWarn             : 0x%04x\n", pBattInfo->iChargeOverTempWarn);
		LOG_INF("iDischargeOverTempWarn          : 0x%04x\n", pBattInfo->iDischargeOverTempWarn);
		LOG_INF("iChargeUnderTempProtection      : 0x%04x\n", pBattInfo->iChargeUnderTempProtection);
		LOG_INF("iDischargeUnderTempProtect      : 0x%04x\n", pBattInfo->iDischargeUnderTempProtection);

		LOG_INF("iChargeOverVolFlag              : 0x%04x\n", pBattInfo->iChargeOverVolFlag);
		LOG_INF("iDischargeUnderVolFlag          : 0x%04x\n", pBattInfo->iDischargeUnderVolFlag);
		LOG_INF("iChargeOverCurrentFlag          : 0x%04x\n", pBattInfo->iChargeOverCurrentFlag);
		LOG_INF("iChargeUnderTempWarn            : 0x%04x\n", pBattInfo->iChargeUnderTempWarn);
		LOG_INF("iDischargeUnderTempWarn         : 0x%04x\n", pBattInfo->iDischargeUnderTempWarn);

		LOG_INF("iChargeErrFlag                  : 0x%04x\n", pBattInfo->iChargeErrFlag);
		LOG_INF("iDishargeOverCurrentFlag        : 0x%04x\n", pBattInfo->iDishargeOverCurrentFlag);
		LOG_INF("iChargeSwitchState              : 0x%04x\n", pBattInfo->iChargeSwitchState);
		LOG_INF("iBatteryCapacityLowFlag         : 0x%04x\n", pBattInfo->iBatteryCapacityLowFlag);
		LOG_INF("iBatteryFullFlag                : 0x%04x\n", pBattInfo->iBatteryFullFlag);

		LOG_INF("iTState                         : 0x%04x\n", pBattInfo->iTState);
		LOG_INF("iCState                         : 0x%04x\n", pBattInfo->iCState);
		LOG_INF("iVState                         : 0x%04x\n", pBattInfo->iVState);
		LOG_INF("iSoftVersion                    : 0x%04x\n", pBattInfo->iSoftVersion);
		LOG_INF("iCycleTimes                     : 0x%04x\n", pBattInfo->iCycleTimes);
		//add by yyf 20181022-end��support can protocol(201800911) for songxia battery
	}

	return 0;
}

/*******************************************************************************
* Function Name      : update_batt_info
* Description	     : update battery info for anshang, such as: SOC, BattCellVoltMin/Max
* Input 		     : pBattInfo:the pointer of bat_info_t
* Output		     : NONE
* Return		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int update_batt_info(bat_info_t *pBattInfo)
{
	int i = 0;
	int16_t iBattCellVolt = 0;
	int16_t iTmpVoltMax	= 0;	// �����ѹ�����ֵ
	int16_t iTmpVoltMin = 0;	// �����ѹ����Сֵ
	int16_t iVoltDiff = 0;
	int16_t	*pBattCellVoltArray = NULL;

	if (pBattInfo == NULL)
	{
		return -1;
	}

	pBattCellVoltArray = pBattInfo->iBattCellVolt;
	// �����̰���ǰ��Ϊ0,�޷��жϵ����ѹ��Сֵ
	iTmpVoltMax = pBattCellVoltArray[8];
	iTmpVoltMin = pBattCellVoltArray[8];

	for (i = 1; i < BATT_CELL_NUM; i++)
	{
		iBattCellVolt = pBattCellVoltArray[i];

		if (iBattCellVolt == 0)
			continue;

		if (iBattCellVolt > iTmpVoltMax)
		{
			iTmpVoltMax = iBattCellVolt;
		}
		else if (iBattCellVolt < iTmpVoltMin)
		{
			iTmpVoltMin = iBattCellVolt;
		}
	}
	//add by jxu 20181017-begin check whether the single vol is valid
	if ((iTmpVoltMin <= ANSHANG_BMS_MIN_SINGLEVOL ) || (iTmpVoltMax >= ANSHANG_BMS_MAX_SINGLEVOL))
	{
		LOG_WRN("The single vol is invalid-iTmpVoltMin[%d] iTmpVoltMax[%d]\n", iTmpVoltMin, iTmpVoltMax);
		pBattInfo->iVoltDiffProtectUser = 0;
		pBattInfo->iPreVoltDiffProtectUser = 0;
		return -1;
	}
	//add by jxu 20181017-begin check whether the single vol is valid

	pBattInfo->iBattCellVoltMax = iTmpVoltMax;
	pBattInfo->iBattCellVoltMin = iTmpVoltMin;

	// ���ڰ��е�ص��쳣�ϱ���Ϣ��׼ȷ����Ҫ���¼����Ƿ���Ҫѹ���
	// �����ѹ�ģ����ֵ - ��Сֵ������300mv���������ѹ����쳣�ϱ�
	iVoltDiff = iTmpVoltMax - iTmpVoltMin;
	if (iVoltDiff >= MAX_VOLT_DIFF)
	{
		LOG_INF("battery cell voltage : max[%d]mv, min[%d]mv, diff[%d]mv > %dmv, set iVoltDiffProtect == TRUE\n",
			iTmpVoltMax, iTmpVoltMin, iVoltDiff, MAX_VOLT_DIFF);
		pBattInfo->iPreVoltDiffProtectUser = pBattInfo->iVoltDiffProtectUser;
		pBattInfo->iVoltDiffProtectUser = 0x0100;//add by jxu 20181017
	}
	else
	{
		pBattInfo->iPreVoltDiffProtectUser = pBattInfo->iVoltDiffProtectUser;
		pBattInfo->iVoltDiffProtectUser = 0;
	}

#if 0
	// add by yyf 20181027��code from tkd
	// ��������״̬�����ڷŵ�״̬�£���С�����ѹ����ANSHANG_BMS_LOW_SINGLEVOL��3450��mv���ҵ��BMS�ϱ�SOCֵ���ڵ���15%
	// ��:������ǿ������Ϊ15%,�Ա����̨��������ǿ�Ƴ��
	if ((pBattInfo->uState != BATT_STATE_CHARGING) &&
		(iTmpVoltMin < ANSHANG_BMS_LOW_SINGLEVOL) &&
		(pBattInfo->uSoc > ANSHANG_BMS_LOW_SOC_15))
	{
		// ���ڵ�һ�ν��е�������ʱ,���д�ӡ,�����������ͬ������־
		if (g_stAgvAttr.iMoidfySocFlag == FALSE)
		{
			LOG_INF("discharging:the min voltage[%d]mv of all battery cell < [%d]mv, then correct soc to %d\n",
				iTmpVoltMin, ANSHANG_BMS_LOW_SINGLEVOL, ANSHANG_BMS_LOW_SOC_15);
		}

		g_stAgvAttr.iMoidfySocFlag = TRUE;
		pBattInfo->uSoc = ANSHANG_BMS_LOW_SOC_15;
		g_stAgvAttr.iModifySocVal = pBattInfo->uSoc;
	}
	// ��������״̬�����ڳ��״̬�£���С�����ѹ����ANSHANG_BMS_LOW_SINGLEVOL+250��3700��mv���ҵ��BMS�ϱ�SOCֵС��30%
	// ��:������ǿ������Ϊ29%, �Ա����̨��������С����磬������ٵ�����Ϣ�����뿪
	else if ((pBattInfo->uState == BATT_STATE_CHARGING) &&
		(iTmpVoltMin < ANSHANG_BMS_LOW_SINGLEVOL + 250) &&
		(pBattInfo->uSoc > ANSHANG_BMS_LOW_SOC_30))
	{
		if ((pBattInfo->uInquireCount % DUMP_BATT_INFO_CYCLES) == 0)
		{
			LOG_INF("charging:the min voltage[%d]mv of all battery cell < [%d]mv, then correct soc to %d\n",
				iTmpVoltMin, ANSHANG_BMS_LOW_SINGLEVOL + 250, ANSHANG_BMS_LOW_SOC_29);
		}

		g_stAgvAttr.iMoidfySocFlag = TRUE;
		pBattInfo->uSoc = ANSHANG_BMS_LOW_SOC_29;
		g_stAgvAttr.iModifySocVal = pBattInfo->uSoc;
	}
	// ������״̬��������������״̬֮�⣬��������״̬���ָ����BMS�ϱ���SOCֵ
	else
	{
		g_stAgvAttr.iMoidfySocFlag = FALSE;
	}

#else
	// �����Ƿ����ڳ��״̬�£�
	// ֻҪ�����ѹ����ANSHANG_BMS_LOW_SINGLEVOL�ҵ�ǰSoc��ʾ������ANSHANG_BMS_LOW_SOC_30��
	// �������С�����ѹ����socֵ
	
	// modified by kedong, 20181031
	// ��(pBattInfo->uSoc >= ANSHANG_BMS_LOW_SOC_30)�ᵼ�½�������29�����������������iMoidfySocFlag=FALSE;
	// g_stAgvAttr.iMoidfySocFlag = FALSE, ���������ϱ�����(29->��ʵ����->29->��ʵ����)��ת�仯��
	// if ((iTmpVoltMin < ANSHANG_BMS_LOW_SINGLEVOL) && (pBattInfo->uSoc >= ANSHANG_BMS_LOW_SOC_30))
	if (iTmpVoltMin < ANSHANG_BMS_LOW_SINGLEVOL)
	{
		// ���ڵ�һ�ν��е�������ʱ,���д�ӡ,�����������ͬ������־
		if (g_stAgvAttr.iMoidfySocFlag == FALSE)
		{
			LOG_INF("the min voltage[%d]mv of all battery cell < [%d]mv, then correct soc to %d\n",
				iTmpVoltMin, ANSHANG_BMS_LOW_SINGLEVOL, ANSHANG_BMS_LOW_SOC_29);
		}

		g_stAgvAttr.iMoidfySocFlag = TRUE;
		pBattInfo->uSoc = ANSHANG_BMS_LOW_SOC_29;
		g_stAgvAttr.iModifySocVal = pBattInfo->uSoc;
	}
	else
	{
		g_stAgvAttr.iMoidfySocFlag = FALSE;
	}
#endif

	return 0;
}

/*******************************************************************************
* Function Name      : anshang_inquiry_batt_summary_info
* Description	     : inquiry battery summary information from battery bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
* Attention          : �ú����ӿ�ֻ�����ڵ�ǰ�����ϣ�������BATT_CAN_DEV������CAN�豸�ڵ㣬����ᵼ�¶�֡
*******************************************************************************/
int anshang_inquiry_batt_summary_info(bat_info_t *pBattInfo)
{
	int iTryCount = TRY_COUNT_LIMIT;
	int iRet = 0;
	struct can_frame stBatCanReq = { 0 };
	struct can_frame stBatCanAck = { 0 };
	int iCount = -1;
	float fVoltage = 0;
	float fCurrent = 0;

	if (pBattInfo == NULL)
		return -1;

	// ����CAN��ѯ����
	// DATA[8]= 16 BB XX XX XX XX XX 7E
	stBatCanReq.can_id = BATT_REQ_CANID;
	stBatCanReq.can_dlc = 8;
	stBatCanReq.data[0] = 0x16;
	stBatCanReq.data[1] = 0xBB;
	stBatCanReq.data[7] = 0x7E;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery error info can frame\n");
	print_can_frame(&stBatCanReq);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanReq);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}

	// ����CAN��ѯӦ��
	while (iTryCount--)
	{
		// add by kedong, 20180224
		// clear stBatCanAck before recv_can
		memset(&stBatCanAck, 0, sizeof(struct can_frame));
		iRet = recv_can(BATT_CAN_DEV, &stBatCanAck);
		if (iRet < 0)
		{
			usleep(500);
			continue;
		}

		if (stBatCanAck.can_id == BATT_ACK_CANID)
			break;

		usleep(500);
	}

	// add by kedong, 20180224
	// if timeout, return -1
	if (iTryCount <= 0)
	{
		return -1;
	}

#if(DEBUG_AGV == 333)
	LOG_INF("recv battery ack can frame\n");
	print_can_frame(&stBatCanAck);
#endif

	uint8_t uSoc = 0;
	// ����CAN��ѯӦ��
	pBattInfo->uVoltage = htons(*(int16_t *)(&stBatCanAck.data[0]));		// �ֽ�0,1
	pBattInfo->uCurrent = htons(*(int16_t *)(&stBatCanAck.data[2]));		// �ֽ�2,3
	// modified by kedong, 20181029
	// ���ڰ��е�س��ʱ�ϱ�SOC��׼�������Լ������¼���SOC����˲����õ��ʵ��
	// �ϱ���SOCȥ����g_stAgvAttr.bms.uSoc
	uSoc = stBatCanAck.data[4];				// �ֽ�4
	pBattInfo->uTemp = stBatCanAck.data[5];					// �ֽ�5
	pBattInfo->uState = stBatCanAck.data[6];				// �ֽ�6
	pBattInfo->uCellNum = stBatCanAck.data[7];				// �ֽ�7
	fVoltage = (float)pBattInfo->uVoltage / 10;
	fCurrent = (float)pBattInfo->uCurrent / 10;

	//modified by yyf 20181027 300���ΪDUMP_BATT_INFO_CYCLES����
	if ((pBattInfo->uInquireCount % DUMP_BATT_INFO_CYCLES) == 0)
	{
		LOG_BATTERY("battery temperature:[%dC],voltage:[%.2fV],current[%.2fA],battery:[act:%d%, mod:%d%],state:[%s]\n",
			pBattInfo->uTemp - TEMPER_BASE, fVoltage, fCurrent, uSoc, pBattInfo->uSoc,
			((pBattInfo->uState == 1) ? "charging" : "not charging"));
	}

	return 0;
}

/*******************************************************************************
* Function Name      : anshang_inquiry_batt_cell_info
* Description	     : inquiry battery cell information from battery bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
* Attention          : �ú����ӿ�ֻ�����ڵ�ǰ�����ϣ�������BATT_CAN_DEV������CAN�豸�ڵ㣬����ᵼ�¶�֡
*******************************************************************************/
int anshang_inquiry_batt_cell_info(bat_info_t *pBattInfo)
{
	int iTryCount = TRY_COUNT_LIMIT;
	int iRet = 0;
	int iCellGrpIdx = 0;
	uint8_t uData = 0;
	struct can_frame stBatCanReq = { 0 };
	struct can_frame stBatCanAck = { 0 };
	int iCount = -1;

	if (pBattInfo == NULL)
		return -1;

	// ����CAN��ѯ����
	// DATA[8]= 16 C1 XX XX XX XX XX 7E---Cell[01-04]
	// DATA[8]= 16 C2 XX XX XX XX XX 7E---Cell[05-08]
	// DATA[8]= 16 C3 XX XX XX XX XX 7E---Cell[09-12]
	// DATA[8]= 16 C4 XX XX XX XX XX 7E---Cell[13-16]
	// DATA[8]= 16 C5 XX XX XX XX XX 7E---Cell[17-20]
	// DATA[8]= 16 C6 XX XX XX XX XX 7E---Cell[21-24]
	// DATA[8]= 16 C7 XX XX XX XX XX 7E---Cell[25-28]
	// DATA[8]= 16 C8 XX XX XX XX XX 7E---Cell[29-32]

	for (iCellGrpIdx = 0; iCellGrpIdx < BATT_CELL_NUM / 4; iCellGrpIdx++)
	{
		uData = 0xC1 + iCellGrpIdx;

		stBatCanReq.can_id = BATT_REQ_CANID;
		stBatCanReq.can_dlc = 8;
		stBatCanReq.data[0] = 0x16;
		stBatCanReq.data[1] = uData;
		stBatCanReq.data[7] = 0x7E;

#if(DEBUG_AGV == 333)
		LOG_INF("send query battery error info can frame\n");
		print_can_frame(&stBatCanReq);
#endif

		iCount = send_can(BATT_CAN_DEV, &stBatCanReq);
		if (iCount != sizeof(struct can_frame))
		{
			return -1;
		}

		// ����CAN��ѯӦ��
		while (iTryCount--)
		{
			// add by kedong, 20180224
			// clear stBatCanAck before recv_can
			memset(&stBatCanAck, 0, sizeof(struct can_frame));
			iRet = recv_can(BATT_CAN_DEV, &stBatCanAck);
			if (iRet < 0)
			{
				usleep(500);
				continue;
			}

			if (stBatCanAck.can_id == BATT_ACK_CANID)
				break;

			usleep(500);
		}

		// add by kedong, 20180224
		// if timeout, return -1
		if (iTryCount <= 0)
		{
			return -1;
		}

#if(DEBUG_AGV == 333)
		LOG_INF("recv battery ack can frame\n");
		print_can_frame(&stBatCanAck);
#endif

		// ����CAN��ѯӦ��htons(*(int16_t *)(&pBatCanData->data[0]));
		pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 0] = htons(*(int16_t *)(&stBatCanAck.data[0]));		// �ֽ�0,1
		pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 1] = htons(*(int16_t *)(&stBatCanAck.data[2]));		// �ֽ�2,3
		pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 2] = htons(*(int16_t *)(&stBatCanAck.data[4]));		// �ֽ�4,5
		pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 3] = htons(*(int16_t *)(&stBatCanAck.data[6]));	// �ֽ�6,7
		
		//modified by yyf 20181027 300���ΪDUMP_BATT_INFO_CYCLES����
		if ((pBattInfo->uInquireCount % DUMP_BATT_INFO_CYCLES) == 0)
		{
			LOG_BATTERY("battery cell group[%d]'voltage:%4d, %4d, %4d, %4d mV\n",
				iCellGrpIdx,
				pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 0],
				pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 1],
				pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 2],
				pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 3]);
		}
	}

	// ��������Ϣδ����ʼ������ͨ����1��2��3�ڵ�صĵ�ѹ��Ϣ���������̰滹������
	// ��������Ϣ�ѱ���ʼ��������Ҫ����
	//add by jxu 20181017-begin init the anshang bms type
	if (pBattInfo->iBattVersion == 0)
	{
		if ((pBattInfo->iBattCellVolt[0] == 0) && (pBattInfo->iBattCellVolt[1] == 0) && (pBattInfo->iBattCellVolt[2] == 0) && (pBattInfo->iBattCellVolt[3] != 0))
		{
			pBattInfo->iBattVersion = ANSHANG_BMS_TYPE_GREEN;
		}
		else if (pBattInfo->iBattCellVolt[0] && pBattInfo->iBattCellVolt[1] && pBattInfo->iBattCellVolt[2] && pBattInfo->iBattCellVolt[3])
		{
			pBattInfo->iBattVersion = ANSHANG_BMS_TYPE_BLUE;
		}
		else
		{
			LOG_WRN("Init the anshang bms type is failed\n");
			return -1;
		}
	}
	//add by jxu 20181017-end

	return 0;
}

/*******************************************************************************
* Function Name      : anshang_inquiry_batt_fault_info
* Description	     : inquiry battery fault information from battery bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
* Attention          : �ú����ӿ�ֻ�����ڵ�ǰ�����ϣ�������BATT_CAN_DEV������CAN�豸�ڵ㣬����ᵼ�¶�֡
*******************************************************************************/
int anshang_inquiry_batt_fault_info(bat_info_t *pBattInfo)
{
	int iTryCount = TRY_COUNT_LIMIT;
	int iRet = 0;
	int iCellGrpIdx = 0;
	uint8_t uData = 0;
	struct can_frame stBatCanReq = { 0 };
	struct can_frame stBatCanAck = { 0 };
	int iCount = -1;

	if (pBattInfo == NULL)
		return -1;

	// ����CAN��ѯ����
	// DATA[8]= 16 BE XX XX XX XX XX 7E
	stBatCanReq.can_id = BATT_REQ_CANID;
	stBatCanReq.can_dlc = 8;
	stBatCanReq.data[0] = 0x16;
	stBatCanReq.data[1] = 0xBE;
	stBatCanReq.data[7] = 0x7E;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery error info can frame\n");
	print_can_frame(&stBatCanReq);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanReq);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}

	// ����CAN��ѯӦ��
	while (iTryCount--)
	{
		// add by kedong, 20180224
		// clear stBatCanAck before recv_can
		memset(&stBatCanAck, 0, sizeof(struct can_frame));
		iRet = recv_can(BATT_CAN_DEV, &stBatCanAck);
		if (iRet < 0)
		{
			usleep(500);
			continue;
		}

		if (stBatCanAck.can_id == BATT_ACK_CANID)
			break;

		usleep(500);
	}

	// add by kedong, 20180224
	// if timeout, return -1
	if (iTryCount <= 0)
	{
		return -1;
	}

#if(DEBUG_AGV == 333)
	LOG_INF("recv battery exception ack can frame\n");
	print_can_frame(&stBatCanAck);
#endif

	// ����CAN��ѯӦ��
	// �����»�ȡ�Ĺ���״̬����һ�εĹ���״̬�Ƚ�
	// �����ͬ, ��˵�����µ��쳣����
	// �����ͬ, ��˵�����µ��쳣����
	// TODO:���ݲ�ͬ�İ汾���̰棬���棩���й��Ͻ���
	//add by jxu 20181017-begin
	int16_t iVState = htons((int16_t)stBatCanAck.data[0]);	// �ֽ�0,1
	int16_t iCState = htons((int16_t)stBatCanAck.data[2]);	// �ֽ�2,3
	int16_t iTState = htons((int16_t)stBatCanAck.data[4]);	// �ֽ�4,5
	int8_t iFETState = stBatCanAck.data[6];					// �ֽ�6
	int8_t iAlarm = stBatCanAck.data[7];					// �ֽ�7

	if ((pBattInfo->uInquireCount % DUMP_BATT_INFO_CYCLES) == 0)
	{
		LOG_BATTERY("battery fault:iVState=0x%04x, iCState=0x%04x, iTState=0x%04x, iFETState=0x%02x, iAlarm=0x%02x\n",
			iVState, iCState, iTState, iFETState, iAlarm);
	}

	// modified by kedong, 20181029
	// ���е��FETState�ľ������䣬�����ǲ�û��ʹ�ø��ֶε��쳣�����ȥ��(pBattInfo->iFETState == iFETState)�߼�
	// ����ᵼ�����Ƕ��δ�ӡ����쳣
	if ((pBattInfo->iVState == iVState) && (pBattInfo->iCState == iCState) && (pBattInfo->iTState == iTState) 
		&& (pBattInfo->iAlarm == iAlarm) && (pBattInfo->iPreVoltDiffProtectUser == pBattInfo->iVoltDiffProtectUser))
	{
		return -1;
	}

	//add by yyf 20181024:begin
	LOG_WRN("battery fault info:iVState.............[0x%04x-->0x%04x]\n", pBattInfo->iVState, iVState);
	LOG_WRN("battery fault info:iCState.............[0x%04x-->0x%04x]\n", pBattInfo->iCState, iCState);
	LOG_WRN("battery fault info:iTState.............[0x%04x-->0x%04x]\n", pBattInfo->iTState, iTState);
	LOG_WRN("battery fault info:iFETState...........[0x%04x-->0x%04x]\n", pBattInfo->iFETState, iFETState);
	LOG_WRN("battery fault info:iAlarm..............[0x%04x-->0x%04x]\n", pBattInfo->iAlarm, iAlarm);
	LOG_WRN("battery fault info:VoltDiffProtectUser.[0x%04x-->0x%04x]\n", pBattInfo->iPreVoltDiffProtectUser, pBattInfo->iVoltDiffProtectUser);
	//add by yyf 20181024:end

	pBattInfo->iVState = iVState;
	pBattInfo->iCState = iCState;
	pBattInfo->iTState = iTState;
	pBattInfo->iFETState = iFETState;
	pBattInfo->iAlarm = iAlarm;

	if (pBattInfo->iBattVersion == ANSHANG_BMS_TYPE_GREEN)
	{
	    // iVState
		pBattInfo->iBattCellOverVolt = iVState & 0x0001;
		pBattInfo->iBattCellUnderVolt = iVState & 0x0002;
		pBattInfo->iBattGroupOverVolt = iVState & 0x0004;
		pBattInfo->iBattGroupUnderVolt = iVState & 0x0008;
		pBattInfo->iBattCellOverVoltWarn = iVState & 0x0010;
		pBattInfo->iBattCellUnderVoltWarn = iVState & 0x0020;
		pBattInfo->iBattGroupOverVoltWarn = iVState & 0x0040;
		pBattInfo->iBattGroupUnderVoltWarn = iVState & 0x0080;
		pBattInfo->iVoltDiffProtectSys = iVState & 0x0100;
		pBattInfo->iCommBreak = iVState & 0x0200;
		pBattInfo->iLowVoltProhibitCharge = iVState & 0x0400;
		// iCState
		pBattInfo->iChargeStateFault = iCState & 0x0001;
		pBattInfo->iDischargeStateFault = iCState & 0x0002;
		pBattInfo->iChargeOverCurrProtection = iCState & 0x0004;
		pBattInfo->iShortCircuitProtection = iCState & 0x0008;
		pBattInfo->iDischargeOverCurrL1 = iCState & 0x0010;
		pBattInfo->iDischargeOverCurrL2 = iCState & 0x0020;
		pBattInfo->iChargeOverCurrWarn = iCState & 0x0040;
		pBattInfo->iDischargeOverCurrWarn = iCState & 0x0080;
		// iTState//add by jxu 20181017-begin
		pBattInfo->iChargeOverTempProtection = iTState & 0x0001;
		pBattInfo->iChargeUnderTempProtection = iTState & 0x0002;
		pBattInfo->iDischargeOverTempProtection = iTState & 0x0004;
		pBattInfo->iDischargeUnderTempProtection = iTState & 0x0008;
		pBattInfo->iEnvOverTempProtection = iTState & 0x0010;
		pBattInfo->iEnvUnderTempProtection = iTState & 0x0020;
		pBattInfo->iPowerOverTempProtection = iTState & 0x0040;
		pBattInfo->iPowerUnderTempProtection = iTState & 0x0080;
		pBattInfo->iBattCellOverTempWarn = iTState & 0x0100;
		pBattInfo->iBattCellUnderTempWarn = iTState & 0x0200;
		pBattInfo->iEnvOverTempWarn = iTState & 0x0400;
		pBattInfo->iEnvUnderTempWarn = iTState & 0x0800;
		pBattInfo->iPowerOverTempWarn = iTState & 0x1000;
		pBattInfo->iPowerUnderTempWarn = iTState & 0x2000;
		//add by jxu 20181017-end
	}
	else if (pBattInfo->iBattVersion == ANSHANG_BMS_TYPE_BLUE)
	{
		pBattInfo->iHighVolProtect = stBatCanAck.data[0] & 0x0001;
		pBattInfo->iLowVolProtect = stBatCanAck.data[1] & 0x0001;
		pBattInfo->iOffLineProtect = stBatCanAck.data[2] & 0x0001;
		pBattInfo->iChargeOverCurrent = stBatCanAck.data[3] & 0x0001;
		pBattInfo->iDischargeOverCurrent = stBatCanAck.data[4] & 0x0001;
		pBattInfo->iShortCircuitPortect = stBatCanAck.data[5] & 0x0001;
		pBattInfo->iHighTemPortect = stBatCanAck.data[6] & 0x0001;
		pBattInfo->iLowTemPortect = stBatCanAck.data[7] & 0x0001;
	}
	else
	{
		return -1;
	}
	//add by jxu 20181017-end
	
	return 1;
}

/*******************************************************************************
* Function Name      : anshang_inquiry_bms_onetofourinfo
* Description	     : send inquiry information cmd to bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int anshang_inquiry_bms_onetofourinfo()
{
	struct can_frame stBatCanData = { 0 };
	int iCount = -1;

	stBatCanData.can_id = BATT_REQ_CANID;
	stBatCanData.can_dlc = 8;
	stBatCanData.data[0] = 0x16;
	stBatCanData.data[1] = 0xC1;//C1 1~4chuan BE:guzhang
	stBatCanData.data[7] = 0x7E;

#if(DEBUG_AGV == TRUE)
	LOG_INF("send query battery info can frame\n");
	print_can_frame(&stBatCanData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanData);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
/*******************************************************************************
* Function Name      : anshang_parse_bms_error_info
* Description	     : parse the information from bms.
* Input 		     : pBatCanData is the obtained data  .
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int anshang_parse_bmstype_info(struct can_frame *pBatCanData)
{
	int iRet = -1;
	int iTryCount = 0;

	if (pBatCanData == NULL) {
		return -1;
	}

	iTryCount = 1000;//ms
	while (iTryCount--)
	{
		usleep(1000);
		memset(pBatCanData, 0, sizeof(struct can_frame));
		iRet = recv_can(BATT_CAN_DEV, pBatCanData);
		if (iRet < 0)
			continue;
		if (pBatCanData->can_id == BATT_ACK_CANID)
		{
			int iBatVolArray[4] = { 0 };
			iBatVolArray[0] = htons(*(int16_t *)(&pBatCanData->data[0]));
			iBatVolArray[1] = htons(*(int16_t *)(&pBatCanData->data[2]));
			iBatVolArray[2] = htons(*(int16_t *)(&pBatCanData->data[4]));
			iBatVolArray[3] = htons(*(int16_t *)(&pBatCanData->data[6]));
			print_can_frame(pBatCanData);
			LOG_INF("iBatVolArray[0]=%d iBatVolArray[1]=%d iBatVolArray[2]=%d iBatVolArray[3]=%d\n",
				iBatVolArray[0], iBatVolArray[1], iBatVolArray[2], iBatVolArray[3]);
			if ((iBatVolArray[0] == FALSE) && (iBatVolArray[1] == FALSE) && (iBatVolArray[2] == FALSE))
			{
				if (iBatVolArray[3] != FALSE)
					g_stAgvAttr.iAnshangBmsType = ANSHANG_BMS_TYPE_GREEN;
				iRet = 0;
				break;
			}
			else if (iBatVolArray[0] && iBatVolArray[1] && iBatVolArray[2] && iBatVolArray[3])
			{
				g_stAgvAttr.iAnshangBmsType = ANSHANG_BMS_TYPE_BLUE;
				iRet = 0;
				break;
			}
		}
	}
	if (iTryCount <= 0)
	{
		iRet = -1;
	}
	return iRet;
}
/*******************************************************************************
* Function Name      : anshang_BmsType_init_check
* Description	     : The function recoginize the anshang bms type
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int anshang_bmstype_init_check()
{
	int iTimeOut = 4; // s
	struct can_frame stCanFrame = { 0 };
	u32 u32Count = 0;
	u32 u32FailCount = 0;
	int iRet = -1;
	struct can_frame stBattCanData = { 0 };

	while (iTimeOut--)
	{
		u32Count++;
		iRet = anshang_inquiry_bms_onetofourinfo();
		if (iRet < 0) {
			if (u32Count % 20 == 0)
				LOG_WRN("query battery one to four info failure\n");
			usleep(1000);
			continue;
		}
		iRet = anshang_parse_bmstype_info(&stBattCanData);
		if (iRet < 0)
		{
			u32FailCount++;
			LOG_INF("Do not get the 0x10 frame u32FailCount=%d\n", u32FailCount);
		}
		else
		{
			LOG_INF("The anshang bms type recoginize successfully\n");
			print_can_frame(&stBattCanData);
			break;
		}
	}
	if (iTimeOut <= 0)
	{
		LOG_WRN("get battery type timeout\n");
		return -1;
	}
	return 0;
}
/*******************************************************************************
* Function Name      : anshang_inquiry_bms_singleinfo
* Description	     : wait and get the information sent by bms.
* Input 		     : pBatCanData is the obtained data.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int anshang_inquiry_bms_singleinfo(uint8_t iData1)
{
	struct can_frame stBatCanData = { 0 };
	int iCount = -1;

	stBatCanData.can_id = BATT_REQ_CANID;
	stBatCanData.can_dlc = 8;
	stBatCanData.data[0] = 0x16;
	stBatCanData.data[1] = iData1;//C1 1~4
	stBatCanData.data[7] = 0x7E;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery info can frame\n");
	print_can_frame(&stBatCanData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanData);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
/*******************************************************************************
* Function Name      : anshang_init_single_info
* Description	     :init the anshang battery single info.
* Input 		     : pBatCanData is the obtained data  .
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
void anshang_init_single_info()
{
	int i = 0;
	for (i = 0; i < 13; i++)
	{
		g_iSingleBattery[i] = 0;
	}

}
/*******************************************************************************
* Function Name      : anshang_parse_bms_error_info
* Description	     : parse the information from bms.
* Input 		     : pBatCanData is the obtained data  .
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int anshang_parse_bms_single_info(struct can_frame *pBatCanData)
{
	int iRet = -1;
	int iTryCount = 0;

	if (pBatCanData == NULL) {
		return -1;
	}
#if(DEBUG_AGV == 333)
	LOG_INF("recv single battery info can frame\n");
	print_can_frame(pBatCanData);
#endif
	iTryCount = 1000;//ms
	while (iTryCount--)
	{
		usleep(1000);
		memset(pBatCanData, 0, sizeof(struct can_frame));
		iRet = recv_can(BATT_CAN_DEV, pBatCanData);
		if (iRet < 0)
			continue;
		if (g_stAgvAttr.iAnshangBmsType == ANSHANG_BMS_TYPE_BLUE) //1:bule bms
		{
			if (g_stAgvAttr.iQueryFlag == QUERY_FIRST_SECTION_SINGLEVOL)
			{
				g_iSingleBattery[0] = htons(*(int16_t *)(&pBatCanData->data[0]));
				g_iSingleBattery[1] = htons(*(int16_t *)(&pBatCanData->data[2]));
				g_iSingleBattery[2] = htons(*(int16_t *)(&pBatCanData->data[4]));
				g_iSingleBattery[3] = htons(*(int16_t *)(&pBatCanData->data[6]));
				g_stAgvAttr.iQueryFlag = QUERY_SECOND_SECTION_SINGLEVOL;
				iRet = 0;
				break;
			}
			else if (g_stAgvAttr.iQueryFlag == QUERY_SECOND_SECTION_SINGLEVOL)
			{
				g_iSingleBattery[4] = htons(*(int16_t *)(&pBatCanData->data[0]));
				g_iSingleBattery[5] = htons(*(int16_t *)(&pBatCanData->data[2]));
				g_iSingleBattery[6] = htons(*(int16_t *)(&pBatCanData->data[4]));
				g_iSingleBattery[7] = htons(*(int16_t *)(&pBatCanData->data[6]));
				g_stAgvAttr.iQueryFlag = QUERY_THIRD_SECTION_SINGLEVOL;
				iRet = 0;
				break;
			}
			else if (g_stAgvAttr.iQueryFlag == QUERY_THIRD_SECTION_SINGLEVOL)
			{
				g_iSingleBattery[8] = htons(*(int16_t *)(&pBatCanData->data[0]));
				g_iSingleBattery[9] = htons(*(int16_t *)(&pBatCanData->data[2]));
				g_iSingleBattery[10] = htons(*(int16_t *)(&pBatCanData->data[4]));
				g_iSingleBattery[11] = htons(*(int16_t *)(&pBatCanData->data[6]));
				g_stAgvAttr.iQueryFlag = QUERY_FOURTH_SECTION_SINGLEVOL;
				iRet = 0;
				break;
			}
			else if (g_stAgvAttr.iQueryFlag == QUERY_FOURTH_SECTION_SINGLEVOL)
			{
				g_iSingleBattery[12] = htons(*(int16_t *)(&pBatCanData->data[0]));
				g_stAgvAttr.iQueryFlag = QUERY_FIRST_SECTION_SINGLEVOL;
				iRet = 0;
				#if(DEBUG_AGV == 333)
					int i = 0;
					for (i; i < 13; i++)
					{
						LOG_INF("BLUE singlebattery[%d]=%d\n", i, g_iSingleBattery[i]);
	
					}
				#endif
				break;
			}
		}
		else if (g_stAgvAttr.iAnshangBmsType == ANSHANG_BMS_TYPE_GREEN) //2:green bms
		{
			if (g_stAgvAttr.iQueryFlag == QUERY_FIRST_SECTION_SINGLEVOL)
			{
				g_iSingleBattery[0] = htons(*(int16_t *)(&pBatCanData->data[6]));
				g_stAgvAttr.iQueryFlag = QUERY_SECOND_SECTION_SINGLEVOL;
				iRet = 0;
				break;
			}
			else if (g_stAgvAttr.iQueryFlag == QUERY_SECOND_SECTION_SINGLEVOL)
			{
				g_iSingleBattery[1] = htons(*(int16_t *)(&pBatCanData->data[0]));
				g_iSingleBattery[2] = htons(*(int16_t *)(&pBatCanData->data[2]));
				g_iSingleBattery[3] = htons(*(int16_t *)(&pBatCanData->data[4]));
				g_iSingleBattery[4] = htons(*(int16_t *)(&pBatCanData->data[6]));
				g_stAgvAttr.iQueryFlag = QUERY_THIRD_SECTION_SINGLEVOL;
				iRet = 0;
				break;
			}
			else if (g_stAgvAttr.iQueryFlag == QUERY_THIRD_SECTION_SINGLEVOL)
			{
				g_iSingleBattery[5] = htons(*(int16_t *)(&pBatCanData->data[0]));
				g_iSingleBattery[6] = htons(*(int16_t *)(&pBatCanData->data[2]));
				g_iSingleBattery[7] = htons(*(int16_t *)(&pBatCanData->data[4]));
				g_iSingleBattery[8] = htons(*(int16_t *)(&pBatCanData->data[6]));
				g_stAgvAttr.iQueryFlag = QUERY_FOURTH_SECTION_SINGLEVOL;
				iRet = 0;
				break;
			}
			else if (g_stAgvAttr.iQueryFlag == QUERY_FOURTH_SECTION_SINGLEVOL)
			{
				g_iSingleBattery[9] = htons(*(int16_t *)(&pBatCanData->data[0]));
				g_iSingleBattery[10] = htons(*(int16_t *)(&pBatCanData->data[2]));
				g_iSingleBattery[11] = htons(*(int16_t *)(&pBatCanData->data[4]));
				g_iSingleBattery[12] = htons(*(int16_t *)(&pBatCanData->data[6]));
				g_stAgvAttr.iQueryFlag = QUERY_FIRST_SECTION_SINGLEVOL;
				iRet = 0;
				#if(DEBUG_AGV == 333)
				int i = 0;
				for (i; i < 13; i++)
				{
					LOG_INF("GREE singlebattery[%d]=%d\n", i, g_iSingleBattery[i]);
				}
				#endif
				break;
			}
		}
		else
		{
			//LOG_WRN("iAnshangBmsType is error g_stAgvAttr.iAnshangBmsType=%d\n", g_stAgvAttr.iAnshangBmsType);
			iRet = -1;
			break;
		}
	}
	return iRet;
}
/*******************************************************************************
* Function Name      : bms_search_ocv
* Description	     : Seartch the ocv sheet
* Input 		     : capacity:voltage 's max value and min value;ocvsheet:ocv sheet;sheetlen:the len of ocvsheet
* Output		     : NONE
* Return		     : the index in the ocv sheet
*******************************************************************************/
char bms_search_ocv(int iCapacity, float* fOcvSheet, char cSheetlen)
{
	char sheetstart;
	char sheetend;
	float currentcapacity;
	sheetstart = 0;
	sheetend = cSheetlen - 1;
	currentcapacity = (float)iCapacity / 1000;
	while ((sheetend - sheetstart) > 1)
	{
		if (currentcapacity >= fOcvSheet[(sheetstart + sheetend) / 2])
		{
			sheetstart = (sheetstart + sheetend) / 2;
		}
		else
		{
			sheetend = (sheetstart + sheetend) / 2;
		}
	}
	return sheetstart;
}
/*******************************************************************************
* Function Name      : bms_capacityseq
* Description	     : get the single the voltage 's max value and min value.
* Input 		     : pCapacity:the all single battery capacity
* Output		     : max value and min value
* Return		     : NONE
*******************************************************************************/
void bms_capacityseq(int* pCapacity, int* pCapacity_max, int* pCapacity_min)
{
	char loop;
	int max_temp;
	int min_temp;

	max_temp = pCapacity[0];
	min_temp = pCapacity[0];
	for (loop = 1; loop < 13; loop++)
	{
		if (pCapacity[loop] == 0)
		{
			continue;
		}
		if (pCapacity[loop] > max_temp)
		{
			max_temp = pCapacity[loop];
		}
		else if (pCapacity[loop] < min_temp)
		{
			min_temp = pCapacity[loop];
		}
	}
	*pCapacity_max = max_temp;
	*pCapacity_min = min_temp;
	return;
}
/*******************************************************************************
* Function Name      : bms_acquirecapacity
* Description	     : get the average the soc from bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
char bms_acquirecapacity(void)
{
	float d_value;
	int max_temp;
	int min_temp;
	char sheet_index;
	char capacity = 0;
	bms_capacityseq(g_iSingleBattery, &max_temp, &min_temp);
	int iTemper = g_stAgvAttr.bms.uTemp - TEMPER_BASE;
	int iIndex = 4;
	int i = 0;
	for (i; i < 7; i++)
	{
		if (iTemper < g_iTemperature[i])
		{
			if (i>0)
			{
				int iDiff = g_iTemperature[i] - iTemper;
				if (iDiff <= 5)
				{
					iIndex = i;
				}
				else
				{
					iIndex = i - 1;
				}

				break;
			}
			else
			{
				iIndex = 0;
				break;
			}
		}
		else if (iTemper == g_iTemperature[i])
		{
			iIndex = i;
			break;
		}
	}
	if (g_stAgvAttr.bms.uState == BATT_STATE_CHARGING)
	{
		sheet_index = bms_search_ocv(max_temp, g_fChargeVoltage[iIndex], 9);
		d_value = (float)max_temp / 1000.0 - g_fChargeVoltage[iIndex][sheet_index];
		if (d_value < 0)
		{
			d_value = 0;
		}
		capacity = (sheet_index +
			(d_value) / (g_fChargeVoltage[iIndex][sheet_index + 1] - g_fChargeVoltage[iIndex][sheet_index]))*CHARGESHEET_SCALE; //����ط������Ѿ���SOC,100%
	}
	else
	{
		sheet_index = bms_search_ocv(min_temp, g_fDischargeVoltage[iIndex], 21);
		d_value = (float)min_temp / 1000.0 - g_fDischargeVoltage[iIndex][sheet_index];
		if (d_value < 0)
		{
			d_value = 0;
		}
		capacity = (sheet_index +
			(d_value) / (g_fDischargeVoltage[iIndex][sheet_index + 1] - g_fDischargeVoltage[iIndex][sheet_index]))*DISCHARGESHEET_SCALE;
	}
	return capacity;
}
/*******************************************************************************
* Function Name      : bms_get_agveragesoc
* Description	     : get the average the soc from bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
char bms_get_agveragesoc(void)
{
	char capacitycurrent;
	char capacitycal;
	static uint8_t totalnum = 0;
	static uint8_t start_index = 0;
	static int capacity_sum = 0;
	static char capacity[60] = { 0 };
	capacitycurrent = bms_acquirecapacity();
	capacity_sum += capacitycurrent;

	if (totalnum >= 60)
	{
		if (start_index >= 60)
		{
			start_index = 0;
		}
		capacity_sum -= capacity[start_index];
		capacity[start_index] = capacitycurrent;
		start_index++;
	}
	else
	{
		capacity[totalnum++] = capacitycurrent;
	}
	capacitycal = capacity_sum / totalnum;
	//s_battery_info.power = capacitycal;
	return capacitycal;
}
/*******************************************************************************
* Function Name      : bms_sigle_voltage_isvalid
* Description	     : whether the single voltage is valid .
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int bms_sigle_voltage_isvalid()
{
	int i = 0;
	int iRet = 0;
	for (i; i < 13; i++)
	{
		int iSingleVol = g_iSingleBattery[i];
		if ((iSingleVol > 2500) && (iSingleVol < 4300))
		{
		}
		else
		{
			iRet = -1;
			anshang_init_single_info();
			break;
		}
	}
	return iRet;
}
/*******************************************************************************
* Function Name      : bms_modify_low_voltage_soc
* Description	     : modify the soc when the single vol is low .
* Input 		     : NONE
* Output		     : NONE
* Return		     : soc
*******************************************************************************/
int bms_modify_low_voltage_soc()
{
	int iMaxVol;
	int iMinVol;
	if (g_stAgvAttr.bms.uState != BATT_STATE_CHARGING)
	{
		if (bms_sigle_voltage_isvalid() == 0)
		{
			bms_capacityseq(g_iSingleBattery, &iMaxVol, &iMinVol);
			if (iMinVol < ANSHANG_BMS_LOW_SINGLEVOL)
			{
				//LOG_INF("iMinVol =%d g_stAgvAttr.bms.uSoc=%d\n", iMinVol, g_stAgvAttr.bms.uSoc);
				g_stAgvAttr.iMoidfySocFlag = TRUE;
				g_stAgvAttr.bms.iBattCellVoltMin = iMinVol;
				g_stAgvAttr.bms.iBattCellVoltMax = iMaxVol;
				int iSoc = bms_get_agveragesoc();
				if (iSoc < ANSHANG_BMS_LOW_SOC_30)
				{
					g_stAgvAttr.bms.uSoc = iSoc;
				}
				else
				{
					g_stAgvAttr.bms.uSoc = ANSHANG_BMS_LOW_SOC_29;
				}
				g_stAgvAttr.iModifySocVal = g_stAgvAttr.bms.uSoc;
				
			}
		}
	}
	return g_stAgvAttr.bms.uSoc;
}
/*******************************************************************************
* Function Name      : songxia_inquiry_batt_summary_info
* Description	     : inquiry battery summary information from battery bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
* Attention          : �ú����ӿ�ֻ�����ڵ�ǰ�����ϣ�������BATT_CAN_DEV������CAN�豸�ڵ㣬����ᵼ�¶�֡
*******************************************************************************/
int songxia_inquiry_batt_summary_info(bat_info_t *pBattInfo)
{
	int iTryCount = TRY_COUNT_LIMIT;
	int iRet = 0;
	struct can_frame stBatCanReq = { 0 };
	struct can_frame stBatCanAck = { 0 };
	int iCount = -1;
	float fVoltage = 0;
	float fCurrent = 0;

	if (pBattInfo == NULL)
		return -1;
	stBatCanReq.can_id = BATT_REQ_CANID;
	stBatCanReq.can_dlc = 8;
	stBatCanReq.data[0] = 0x16;
	stBatCanReq.data[1] = 0xBB;
	stBatCanReq.data[7] = 0x7E;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery error info can frame\n");
	print_can_frame(&stBatCanReq);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanReq);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}

	int i = 0;
	// modified by kedong, 20181025
	// ���µ��,���Ͳ�ѯ֡0x16,Ӧ�÷���0x10~0x15��6֡
	// �����Ҫ��(i; i <= 1; i++)�ĳ�(i; i <= 5; i++)
	for (i = 0; i <= 5; i++)
	{
		memset(&stBatCanAck, 0, sizeof(struct can_frame));
		iRet = get_bms_info(&stBatCanAck);

		// modified by kedong, 20181025
		if (iRet < 0)
			continue;

		if (stBatCanAck.can_id == BATT_ACK_CANID)
		{
			pBattInfo->uVoltage = htons(*(int16_t *)(&stBatCanAck.data[0]));
			pBattInfo->uCurrent = htons(*(int16_t *)(&stBatCanAck.data[2]));
			if (pBattInfo->uCurrent >= PANSONIC_CURRENT_HIGHESTBIT)
			{
				pBattInfo->uCurrent = pBattInfo->uCurrent - PANSONIC_CURRENT_HIGHESTBIT;
			}
			pBattInfo->uSoc = stBatCanAck.data[4];
			pBattInfo->uTemp = stBatCanAck.data[5];
			pBattInfo->uState = stBatCanAck.data[6];
			pBattInfo->uCellNum = stBatCanAck.data[7];
			fVoltage = (float)pBattInfo->uVoltage / 10;
			fCurrent = (float)pBattInfo->uCurrent / 10;
			LOG_ERR("battery temperature:[%dC],voltage:[%.2fV],current[%.2fA],battery:[%d%],state:[%s]\n",
				pBattInfo->uTemp - TEMPER_BASE, fVoltage, fCurrent, pBattInfo->uSoc,
				((pBattInfo->uState == 1) ? "charging" : "not charging"));

			return 0;
		}
	}

	return -1;
}

//add by yyf 20181022:begin ,support can protocol(201800911) for songxia battery
/*******************************************************************************
* Function Name      : songxia_prase_batt_info
* Description	     : prase battery information from battery bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
* Attention          : �ú����ӿ�ֻ�����ڵ�ǰ�����ϣ�������BATT_CAN_DEV������CAN�豸�ڵ㣬����ᵼ�¶�֡
*******************************************************************************/
int songxia_prase_batt_info(struct can_frame *pBattCanData, bat_info_t *pBattInfo)
{
	uint8_t i = 0;
	int iRet = -1;

	if (pBattCanData == NULL || pBattInfo == NULL)
	{
		return -1;
	}

#if(DEBUG_AGV == 333)
	LOG_INF("recv battery info canid[0x%02x] can frame\n", pBattCanData->can_id);
	print_can_frame(pBattCanData);
#endif

	if (BATT_ACK_CANID_0X15 == pBattCanData->can_id)  //CANID����0x15,����BMS�ϱ�����ǰ����������״̬�Լ�ѭ������
	{
		iRet = songxia_prase_batt_fault_info(pBattCanData, pBattInfo); 
		if (iRet == 1) //BMS�ϱ���ǰ����������״̬�Լ�ѭ���������ϴβ����
		{
			LOG_ERR("songxia batt has a new fault info:>>>>>\n");
			dump_batt_info(pBattInfo);
			songxia_log_battery_fault_info(pBattInfo);
		}
	}
	else if (pBattCanData->can_id >= 0x11 && pBattCanData->can_id <= 0x14)
	{
		iRet = songxia_prase_batt_cell_info(pBattCanData, pBattInfo); //CANID��[0x11,0x14]֮�䣬����BMS�ϱ��ĵ����ص�ѹ
	}
	else
	{

	}

	return iRet;
}

/*******************************************************************************
* Function Name      : songxia_prase_batt_fault_info
* Description	     : prase battery fault information from battery bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 1:success; -1 on error
* Attention          : �ú����ӿ�ֻ�����ڵ�ǰ�����ϣ�������BATT_CAN_DEV������CAN�豸�ڵ㣬����ᵼ�¶�֡
*******************************************************************************/
int songxia_prase_batt_fault_info(struct can_frame *pBattCanData, bat_info_t *pBattInfo)
{
	int8_t iTState = 0;
	int8_t iCState = 0;
	int8_t iVState = 0;
	int8_t iSoftVersion = 0;
	int16_t iCycleTimes = 0;

	if (pBattCanData == NULL || pBattInfo == NULL)
	{
		return -1;
	}

	iTState = pBattCanData->data[0];		// �ֽ�0
	iCState = pBattCanData->data[1];		// �ֽ�1
	iVState = pBattCanData->data[2];		// �ֽ�2
	iSoftVersion = pBattCanData->data[4];		// �ֽ�6
	iCycleTimes = htons(*(int16_t *)(&pBattCanData->data[6]));		// �ֽ�7,8
	
	if ((pBattInfo->iTState == iTState) && (pBattInfo->iCState == iCState)
		&& (pBattInfo->iVState == iVState) && (pBattInfo->iPreVoltDiffProtectUser == pBattInfo->iVoltDiffProtectUser))
	{
		return -2;   //��������ϴ�һ����ֱ�ӷ���
	}

	//add by yyf 20181024:begin
	LOG_WRN("battery fault info:iVState.............[0x%04x-->0x%04x]\n", pBattInfo->iVState, iVState);
	LOG_WRN("battery fault info:iCState.............[0x%04x-->0x%04x]\n", pBattInfo->iCState, iCState);
	LOG_WRN("battery fault info:iTState.............[0x%04x-->0x%04x]\n", pBattInfo->iTState, iTState);
	LOG_WRN("battery fault info:VoltDiffProtectUser.[0x%04x-->0x%04x]\n", pBattInfo->iPreVoltDiffProtectUser, pBattInfo->iVoltDiffProtectUser);
	//add by yyf 20181024:end

	pBattInfo->iTState = iTState;
	pBattInfo->iCState = iCState;
	pBattInfo->iVState = iVState;
	pBattInfo->iSoftVersion = iSoftVersion;
	pBattInfo->iCycleTimes = iCycleTimes;

	pBattInfo->iVoltDiffProtectSys = iTState & 0x0001;						 //��ѹ��ƽ��
	pBattInfo->iChargeOverTempProtection = iTState & 0x0002;				 //�����±���
	pBattInfo->iDischargeOverTempProtection = iTState & 0x0004;				 //�ŵ���±���
	pBattInfo->iChargeOverTempWarn = iTState & 0x0008;					 //�����±���
	pBattInfo->iDischargeOverTempWarn = iTState & 0x0010;						 //�ŵ���±���
	pBattInfo->iChargeUnderTempProtection = iTState & 0x0020;				 //���Ƿ�±���
	pBattInfo->iDischargeUnderTempProtection = iTState & 0x0040;			 //�ŵ�Ƿ�±���

	// iCState
	pBattInfo->iChargeOverVolFlag = iCState & 0x0001;			//����ѹ��־
	pBattInfo->iDischargeUnderVolFlag = iCState & 0x0002;				//�ŵ�Ƿѹ��־
	pBattInfo->iChargeOverCurrentFlag = iCState & 0x0004;		//������
	pBattInfo->iChargeUnderTempWarn = iCState & 0x0020;             //���Ƿ�±���
	pBattInfo->iDischargeUnderTempWarn = iCState & 0x0040;				//�ŵ�Ƿ�±���

	// iTState
	pBattInfo->iChargeErrFlag = iVState & 0x0001;        //��������ϱ�־
	pBattInfo->iDishargeOverCurrentFlag = iVState & 0x0002;       //�ŵ������־
	pBattInfo->iChargeSwitchState = iVState & 0x0004;		//��翪��״̬
	pBattInfo->iBatteryCapacityLowFlag = iVState & 0x0008;	//�����ͱ�־λ
	pBattInfo->iBatteryFullFlag = iVState & 0x0010;			//��س�����־

	pBattInfo->iSoftVersion = iSoftVersion;                       //�����汾
	pBattInfo->iCycleTimes = iCycleTimes;							//ѭ������  

	return 1;
}

/*******************************************************************************
* Function Name      : songxia_prase_batt_cell_info
* Description	     : prase battery cell volt from battery bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
* Attention          : �ú����ӿ�ֻ�����ڵ�ǰ�����ϣ�������BATT_CAN_DEV������CAN�豸�ڵ㣬����ᵼ�¶�֡
*******************************************************************************/
int songxia_prase_batt_cell_info(struct can_frame *pBattCanData, bat_info_t *pBattInfo)
{
	int i = 0;
	uint16_t iCellGrpIdx = 0;

	if (pBattCanData == NULL || pBattInfo == NULL)
	{
		return -1;
	}

	if ((pBattCanData->can_id > BATT_ACK_CANID_0X15) || (pBattCanData->can_id < BATT_ACK_CANID))
	{
		return -2;
	}


	iCellGrpIdx = pBattCanData->can_id - 0x11;

	pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 0] = htons(*(int16_t *)(&pBattCanData->data[0]));		// �ֽ�0,1
	pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 1] = htons(*(int16_t *)(&pBattCanData->data[2]));		// �ֽ�2,3
	pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 2] = htons(*(int16_t *)(&pBattCanData->data[4]));		// �ֽ�4,5
	pBattInfo->iBattCellVolt[iCellGrpIdx * 4 + 3] = htons(*(int16_t *)(&pBattCanData->data[6]));	// �ֽ�6,7

	if (3 == iCellGrpIdx)
	{
		update_batt_info(pBattInfo);   //ѹ���
		if ((pBattInfo->uInquireCount % DUMP_BATT_INFO_CYCLES) == 0)
		{
			for (i = 0; i < BATT_CELL_NUM / 4; ++i)
			{
				LOG_BATTERY("battery cell group[%d]'voltage:%4d, %4d, %4d, %4d mV\n",
					i,
					pBattInfo->iBattCellVolt[i * 4 + 0],
					pBattInfo->iBattCellVolt[i * 4 + 1],
					pBattInfo->iBattCellVolt[i * 4 + 2],
					pBattInfo->iBattCellVolt[i * 4 + 3]);
			}
		}
	}

	return 0;
}

/*******************************************************************************
* Function Name      : songxia_log_battery_fault_info
* Description	     : inquiry battery summary information from battery bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
* Attention          : �ú����ӿ�ֻ�����ڵ�ǰ�����ϣ�������BATT_CAN_DEV������CAN�豸�ڵ㣬����ᵼ�¶�֡
*******************************************************************************/
int songxia_log_battery_fault_info(bat_info_t *pBattInfo)
{
	if (pBattInfo == NULL)
	{
		return -1;
	}
	// ��ع���:ѹ���/��ѹ��ƽ��
	if (pBattInfo->iVoltDiffProtectSys != 0)
	{
		LOG_ERR("BMS Exception Songxia:voltage diff protect in system\n");
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_VOLDISBALANCE);
	}

	if ((pBattInfo->iVoltDiffProtectUser != 0) && (pBattInfo->iPreVoltDiffProtectUser != pBattInfo->iVoltDiffProtectUser))
	{
		LOG_ERR("BMS Exception Songxia:voltage diff protect in user\n");
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_VOLDISBALANCE);
	}

	// ��ع���:�ŵ���¸澯�����±���
	if (pBattInfo->iDischargeOverTempProtection != 0)
	{
		LOG_ERR("BMS Exception Songxia:discharge over temperture protect\n");
		send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERTEMP);
	}
	// ��ع���:�����±��������¾���
	if (pBattInfo->iChargeOverTempProtection != 0)
	{
		LOG_ERR("BMS Exception Songxia:charge over temperture protect\n");
		send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEOVERTEMP);
	}
	// ��ع���:����ѹ��־���ŵ�Ƿѹ��־
	if (pBattInfo->iDischargeUnderVolFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:charge/discharge over/under voltage flag\n");
		send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERVOL);
	}
	// ��ع���:���������ŵ������־
	if (pBattInfo->iDishargeOverCurrentFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:discharge over current flag\n");
		send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERCUR);
	}
	// ��ع���:��������ϱ�־
	if (pBattInfo->iChargeErrFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia: charge err flag\n");
		send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEERR);
	}
	// ��ع���:����ѹ��־
	if (pBattInfo->iChargeOverVolFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:charge over voltage flag\n");
		//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEOVERVOL);
	}

	// ��ع���:���Ƿ�±�����Ƿ�±���
	if ((pBattInfo->iChargeUnderTempProtection != 0) ||
		(pBattInfo->iChargeUnderTempWarn != 0))
	{
		LOG_ERR("BMS Exception Songxia: charge under temperture warn/protect\n");
	}
	// ��ع���:�ŵ�Ƿ�±�����Ƿ�±���
	if ((pBattInfo->iDischargeUnderTempProtection != 0) ||
		(pBattInfo->iDischargeUnderTempWarn != 0))
	{
		LOG_ERR("BMS Exception Songxia: discharge under temperture warn/protect\n");
	}
	// ��ع���:��������־
	if (pBattInfo->iChargeOverCurrentFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:charge over current flag\n");
	}
	// ��ع���:�����ͱ�־λ
	if (pBattInfo->iBatteryCapacityLowFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:battery capacity low flag\n");
	}
	// ��ع���:��س�����־
	if (pBattInfo->iBatteryFullFlag != 0)
	{
		LOG_ERR("BMS Exception Songxia:battery full flag\n");
	}
	// ��ع���:��翪��״̬
	if ( pBattInfo->iChargeSwitchState != 0 )
	{
		LOG_ERR("BMS Exception Songxia:charge switch state\n");
	}
	return 0;
}
//add by yyf 20181022:end ,support can protocol(201800911) for songxia battery

/*******************************************************************************
* Function Name		 : songxia_start_charge
* Description	     : start charge power
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int songxia_start_charge()
{
	int iCount = 0;

	struct can_frame stFrameCharge =
	{
		.can_id = BATT_REQ_V2_CANID,
		.can_dlc = MC_DATA_DLC_V2,
		.data[0] = BATT_CHARGE_FLAG,
		.data[1] = MC_CAN_RESERVE_V2,
		.data[2] = MC_CAN_RESERVE_V2,
		.data[3] = MC_CAN_RESERVE_V2,
		.data[4] = MC_CAN_RESERVE_V2,
		.data[5] = MC_CAN_RESERVE_V2,
		.data[6] = MC_CAN_RESERVE_V2,
		.data[7] = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:panasonic start charge request\n");
	print_can_frame(&stFrameCharge);

	iCount = send_can(BATT_CAN_DEV, &stFrameCharge);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : songxia_stop_charge
* Description	     : stop charge power
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int songxia_stop_charge()
{
	int iCount = 0;

	struct can_frame sFrameStopCharge =
	{
		.can_id = BATT_REQ_V2_CANID,
		.can_dlc = MC_DATA_DLC_V2,
		.data[0] = BATT_STOP_CHARGE_FLAG,
		.data[1] = MC_CAN_RESERVE_V2,
		.data[2] = MC_CAN_RESERVE_V2,
		.data[3] = MC_CAN_RESERVE_V2,
		.data[4] = MC_CAN_RESERVE_V2,
		.data[5] = MC_CAN_RESERVE_V2,
		.data[6] = MC_CAN_RESERVE_V2,
		.data[7] = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:panasonic stop charge request\n");
	print_can_frame(&sFrameStopCharge);

	iCount = send_can(BATT_CAN_DEV, &sFrameStopCharge);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}

	return 0;
}

