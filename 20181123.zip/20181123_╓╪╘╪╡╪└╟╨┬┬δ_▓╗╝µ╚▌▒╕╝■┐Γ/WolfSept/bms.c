#include "bms.h"
#include "device.h"
#include "ftp.h"//add by jxu 20180917
#include <sys/time.h>//by tiger.102
 
/*******************************************************************************
* Function Name      : inquiry_bms_info
* Description	     : send inquiry information cmd to bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int inquiry_bms_info()
{
	struct can_frame stBatCanData = { 0 };
	int iCount = -1;

	stBatCanData.can_id = BATT_REQ_CANID;
	stBatCanData.can_dlc = 8;
	stBatCanData.data[0] = 0x16;
	stBatCanData.data[1] = 0xBB;
	stBatCanData.data[7] = 0x7E;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery info can frame\n");
	print_can_frame(&stBatCanData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanData);//change by tiger
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
/*******************************************************************************
* Function Name      : get_bms_info
* Description	     : wait and get the information sent by bms.
* Input 		     : pBatCanData is the obtained data.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int get_bms_info(struct can_frame * pBatCanData)
{
	int iRet = -1;
	int iTryCount = 0;

	if (pBatCanData == NULL) {
		return -1;
	}

	iTryCount = TRY_COUNT_LIMIT;
	while (iTryCount--)
	{
		usleep(500);//add by jxu 20180917 change 100000->500 5s time out

		// add by kedong, 20180224
		// clear pBatCanData before recv_can
		memset(pBatCanData, 0, sizeof(struct can_frame));
		iRet = recv_can(BATT_CAN_DEV, pBatCanData);
		if (iRet < 0)
			continue;

		//changed by yyf 20181022:begin ,support can protocol(201800911) for songxia battery
		if (pBatCanData->can_id >= BATT_ACK_CANID && pBatCanData->can_id <= BATT_ACK_CANID_0X15)
		{
			iRet = 0;
			break;
		}
		//changed by yyf 20181022:end ,support can protocol for songxia battery
	}

	// add by kedong, 20180224
	// if timeout, return -1
	if (iTryCount <= 0)
	{
		iRet = -1;
	}

	return iRet;
}

#define BATTERY_CHARGE_SOC_100		100 //by tiger.83
#define BATTERY_CHARGE_SOC_70		70 //by tiger.83
#define BATTERY_CHARGE_SOC_60		60 //by kedong, 20181030
// modified by kedong, 20181030
// ��������̫�����������̫��ᵼ�µȴ�ʱ�����������2��Сʱ��
// ��Ҫ��Ϊ��ػ��ڳ��ͷŵ�֮�������л�
#define RETRY_CHARGE_TIMES			1
#define CALIBRATION_SECONDS			60 //unit seconds,for too long soc will below by tiger.89
#define CALIBRATE_VOLTAGE_V          510 //unit 0.1V,by tiger.89
#define CALIBRATION_FINISH_SOC        98 //by tiger.89
#define CALIBRATION_FINISHED          1//by tiger.89
#define CALIBRATING						0//by tiger.89
#define NEED_NOT_CALIBRATION			(-1)//by tiger.89
#define CALIBRATION_TIMEOUT				(-2)//by tiger.89
/*******************************************************************************
*Function Name    :calibrate_battery
*Description      : by tiger.89 
*Input       	  :bat_info_t * pBattery  
*Output 		  :
*Return           :int:1:calibrate finish
					   0:on calibrating, 
					  -1: need not calibrate,
					  -2:calibrate timeout					   
*******************************************************************************/
int calibrate_battery(bat_info_t *pBattery, int iCalibrationPeriod)
{	
	if (NULL == pBattery ||iCalibrationPeriod <= 0)
	{
		return NEED_NOT_CALIBRATION;
	}

	int iCalibrationTime = (pBattery->uCalibrateTime)*iCalibrationPeriod;

	if (pBattery->uVoltage < CALIBRATE_VOLTAGE_V)
	{
		LOG_INF("need not wait calibrate battery,for battery voltage = %dV \n", pBattery->uVoltage/10);
		pBattery->uCalibrateTime = 0;
		return NEED_NOT_CALIBRATION;
	}
		
	if (pBattery->uSoc >= CALIBRATION_FINISH_SOC)
	{
		LOG_INF("calibrate battery finish,for battery voltage = %dV Soc = %d ,calibation_time = %d\n", 
			pBattery->uVoltage / 10, pBattery->uSoc, iCalibrationTime);
		pBattery->uCalibrateTime = 0;
		return CALIBRATION_FINISHED;
	}
		
	if (++pBattery->uCalibrateTime > CALIBRATION_SECONDS / iCalibrationPeriod)
	{
		LOG_INF("calibrate battery timeout,for %ds\n", iCalibrationTime);
		pBattery->uCalibrateTime = 0;
		return CALIBRATION_TIMEOUT;
	}

	LOG_INF("calibrating battery ,for %ds\n", iCalibrationTime);
	return CALIBRATING;
	
}
/*******************************************************************************
* Function Name      : parse_bms_info
* Description	     : parse the information from bms.
* Input 		     : pBatCanData is the obtained data  .
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
#define LOW_CHARGE_CUR_COUNT  30 //by tiger.89//add by jxu 20181008-change from 10->30 slove the dalian 3019
#define HOURS_1_5     5400 // 1.5hours
#define CHARGE_HOURS_1_5_SOC 80//after charging 1.5 hours,soc should bigger 80
//add by jxu 20180917-begin
static int iStaticDischargeOverTemProtect = 0;
static int iStaticChargeOverTemmProtect = 0;
static int iStaticVotageDisbalance = 0;
static int iStaticDischargeOverVolFlag = 0;
static int iStaticChargeOverVolFlag = 0;
static int iStaticDishargeOverCurrentFlag = 0;
static int iStaticChargeErrFlag = 0;
int g_iNotReport3019 = FALSE;
//add by jxu 20180917-end
int parse_bms_info(struct can_frame *pBatCanData)
{
	static int iLowChargeCurCount = 0;
	static int iRetryChargeCount = 0; //by tiger.84
	struct bat_info stBatInfo = {0};
	int iRet = 0, iResult = 0;
	float fVoltage = 0;
	float fCurrent = 0;
	static int iParseBmsInfoCount = 0;
	static bool s_bBatteryFull = false; //add by tiger.83
	int iCalibratePeriod = INQUIRE_PERIOD_SECONDS;
	static bool s_bCurSmallErr = false;
	//add by jxu 20180820-begin
	static int iParseChargeInfoCount = 0;
	static int iPreFiveMinuteSoc = 0;
	static float fPreFiveMinuteVol = 0;
	static float fPreFiveMinuteCur = 0;
	static time_t s_iStartCalTime = 0;
	time_t iCurCalTime = 0;
	char pStrSoc[10] = { 0 };
	//add by jxu 20180820-end

	if (pBatCanData == NULL)
		return -1;

	if (BATT_ACK_CANID == pBatCanData->can_id)
	{
#if(DEBUG_AGV == 333)
		LOG_INF("recv battery info can frame\n");
		print_can_frame(pBatCanData);
#endif

		stBatInfo.uVoltage = htons(*(int16_t *)(&pBatCanData->data[0]));	// �ֽ�0,1
		stBatInfo.uCurrent = htons(*(int16_t *)(&pBatCanData->data[2]));	// �ֽ�2,3
		stBatInfo.uSoc =pBatCanData->data[4];								// �ֽ�4
		stBatInfo.uTemp = pBatCanData->data[5];								// �ֽ�5
		stBatInfo.uState = pBatCanData->data[6];							// �ֽ�6
		stBatInfo.uCellNum = pBatCanData->data[7];							// �ֽ�7

		// add by jxu 20180820 end
		// ��������µ�أ������ֶ����λ��ʾ���״̬����Ҫ���⴦��
		// ͬʱ,��Ҫ�ȴ���,Ȼ���ٸ�ֵ��g_stAgvAttr.bms,����ᵼ�����µ�ص������㲻׼
		if (stBatInfo.uCurrent >= PANSONIC_CURRENT_HIGHESTBIT)
		{
			stBatInfo.uCurrent = stBatInfo.uCurrent - PANSONIC_CURRENT_HIGHESTBIT;
		}

		g_stAgvAttr.bms.uVoltage = stBatInfo.uVoltage;
		g_stAgvAttr.bms.uCurrent = stBatInfo.uCurrent;
		g_stAgvAttr.bms.uSoc = stBatInfo.uSoc;
		g_stAgvAttr.bms.uTemp = stBatInfo.uTemp;
		g_stAgvAttr.bms.uState = stBatInfo.uState;
		g_stAgvAttr.bms.uCellNum = stBatInfo.uCellNum;
		//end by tiger.83

		if (0 == (iParseBmsInfoCount++) % 5)//every 15 times, log battery info to battery_monitor.log
		{
			fVoltage = (float)stBatInfo.uVoltage / 10;
			fCurrent = (float)stBatInfo.uCurrent / 10;
			LOG_BATTERY("battery temperature:[%dC],voltage:[%.2fV],current[%.2fA],battery:[%d%],state:[%s]\n",
				stBatInfo.uTemp - TEMPER_BASE, fVoltage, fCurrent, stBatInfo.uSoc,
				((stBatInfo.uState == 1) ? "charging" : "not charging"));
			iParseBmsInfoCount = 1;
		}
		//add by jxu 201808020-beign�������У�С������ſ�ڳ��׮�ϣ�SOC�ޱ仯
		//add by jxu 20180917 find the status is charge when the veh is not charge postion 
		if ((g_stAgvAttr.iBatType == BAT_TYPE_ANSHANG) && (stBatInfo.uState == TRUE) && (agv_charge == g_stAgvAttr.iMoveStatus))
		{
			iParseChargeInfoCount = iParseChargeInfoCount + 1;
			if (iParseChargeInfoCount == 1)
			{
				iPreFiveMinuteSoc = stBatInfo.uSoc;
				fPreFiveMinuteVol = (float)stBatInfo.uVoltage / 10;
				fPreFiveMinuteCur = (float)stBatInfo.uCurrent / 10;
			}
			if (0 == (iParseChargeInfoCount % 300))//add by jxu 20181026 modify 150->300
			{
				iParseChargeInfoCount = 0;
				fVoltage = (float)stBatInfo.uVoltage / 10;
				fCurrent = (float)stBatInfo.uCurrent / 10;

				if (((stBatInfo.uSoc - iPreFiveMinuteSoc) < 1) && ((fVoltage - fPreFiveMinuteVol) < 0.1f) && (fCurrent < 0.2f))
				{
					LOG_WRN("EVENT_ERR_CHARGECURSAMLL[3010]-SOC:[%d-->%d], Volt:[%.2f-->%.2f]V, Current:[%.2f-->%.2f]A\n",
						iPreFiveMinuteSoc, stBatInfo.uSoc, fPreFiveMinuteVol, fVoltage, fPreFiveMinuteCur, fCurrent);
					iRet = -EVENT_ERR_CHARGECURSAMLL;
					return iRet;
				}
			}

		}
		//add by jxu 20181026-begin to make sure the 300 times in continuity
		else
		{
			iParseChargeInfoCount = 0;
			iPreFiveMinuteSoc = 0;
			fPreFiveMinuteVol = 0;
			fPreFiveMinuteCur = 0;
		}
		//add by jxu 20181026-end
		//add by jxu 201808020-end
		
		//start,add by tiger.83,by tiger.94
		//�������У���س����Զ��Ͽ����鱨���������ϱ�����100
// 		if ((true == bHadCharged) && (agv_charge == g_stAgvAttr.iMoveStatus)
// 			&& (BATT_STATE_CHARGING != stBatInfo.uState) && (BATTERY_CHARGE_SOC_60 <= stBatInfo.uSoc))
		
		if ((true == s_bBatteryFull) && (agv_stop == g_stAgvAttr.iMoveStatus)//by tiger.94
			&& (BATT_STATE_CHARGING != stBatInfo.uState) && (BATTERY_CHARGE_SOC_60 <= stBatInfo.uSoc))
		{
			LOG_INF("during charging, correct battery'soc:[%d->%d] when soc is incorrect\n", stBatInfo.uSoc, BATTERY_CHARGE_SOC_100);
			stBatInfo.uSoc = BATTERY_CHARGE_SOC_100;
			g_stAgvAttr.bms.uSoc = stBatInfo.uSoc;
		}
		else if (agv_stop != g_stAgvAttr.iMoveStatus)//recovery send real battery to agent,by tiger.94
		{
			s_bBatteryFull = false;
		}

		//end,add by tiger.83,by tiger.94

		//add by jxu 20180820 begin
		if (g_stAgvAttr.iMoidfySocFlag == TRUE)//add by jxu 20181017-to avoid the update the soc in charging
		{
			stBatInfo.uSoc = g_stAgvAttr.iModifySocVal;	
			g_stAgvAttr.bms.uSoc = stBatInfo.uSoc;
		}
		// start add by tiger.102
		// ��(TRUE == g_stAgvAttr.bms.uNeedCheckSoc)�����������
		// Ȩ�����һ:���ϴγ��1.5Сʱ������δ��80%ʱ, ������������ϱ�3057(��ǰʹ�õĲ���)�������ֵ��絽80%����
		// Ȩ����Զ�:���ϴγ��1.5Сʱ������δ��80%ʱ, ����ֻ���ڵ�һ������ʱ���ϱ�3057
		if (TRUE == g_stAgvAttr.bms.uNeedCheckSoc)
		{
			// g_stAgvAttr.bms.uNeedCheckSocֻ������������,ͨ�������ļ����ظ���
			g_stAgvAttr.bms.uNeedCheckSoc = FALSE;			
			if (stBatInfo.uSoc < CHARGE_HOURS_1_5_SOC)
			{
				LOG_ERR("batt'soc[%d] < expect[%d] when charge time > 1.5h at reboot\n", 
					stBatInfo.uSoc, CHARGE_HOURS_1_5_SOC);
				dump_batt_info(&g_stAgvAttr.bms);//dump bat info
				send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_NEED_OFFLINE);
			}
			else
			{
				set_check_soc_flag("0");
			}
		}

		if ((agv_charge == g_stAgvAttr.iMoveStatus) &&
			(BATT_STATE_CHARGING == stBatInfo.uState) 
			&& (stBatInfo.uSoc < CHARGE_HOURS_1_5_SOC))
		{
			time(&iCurCalTime);
			// ��¼��ʼ���ʱ�䣬�Ա��жϳ��ʱ���Ƿ񳬹�Ԥ��ֵ��Ĭ�ϣ�1.5Сʱ��
			// ���(0 == s_iStartCalTime) : ��ʾδ��¼����ʼ���ʱ��
			// ���(0 != s_iStartCalTime) : ���ֲ��伴��
			(0 == s_iStartCalTime) ? (s_iStartCalTime = iCurCalTime) : (s_iStartCalTime = s_iStartCalTime);//save charge start time
			if (iCurCalTime - s_iStartCalTime >= HOURS_1_5)
			{		

				set_check_soc_flag("1");
				g_iNotReport3019 = TRUE;
				iRet = stop_charge();
				if (iRet < 0)
				{
					g_iNotReport3019 = FALSE;
					return iRet;
				}	
				g_iNotReport3019 = FALSE;

				LOG_ERR("batt'soc[%d] < expect[%d] when charge time > 1.5h, then send error msg\n", 
					stBatInfo.uSoc, CHARGE_HOURS_1_5_SOC);
				dump_batt_info(&g_stAgvAttr.bms);//dump bat info
				send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHECK_FAILED);
			}
		}
		else
			s_iStartCalTime = 0;
		//end add by tiger.102
		//add by jxu 20180820 end
		stBatInfo.uCalibrateTime = g_stAgvAttr.bms.uCalibrateTime;//by tiger.89
		
		// iMoveStatus == agv_charge, but not in charging state
		//not excute the cmd if the agv is not in charging,and send finish to agent,start by tiger.41

		if ((g_stAgvAttr.iMoveStatus == agv_charge) 
			&& (stBatInfo.uState != BATT_STATE_CHARGING)
			&& (BATTERY_CHARGE_SOC_100 != stBatInfo.uSoc))//for not report 3010,add by tiger.83
		{
			LOG_WRN("battery charging failure[iMoveStatus=%d, stBatInfo.uState=%d, stBatInfo.uSoc=%d, retryTime=%d]\n",
				g_stAgvAttr.iMoveStatus, stBatInfo.uState, stBatInfo.uSoc, iLowChargeCurCount);

			// add by kedong, 20181111
			// ���µ�ؼ�⵽����״̬��ΪON��������ʱ������10s��û�м�⵽����ʱ���������رճ�翪��ֹͣ���
			// ���, �������������8�ζ�û�е��������£������ٴ������µ�ط��ͳ������, ���´򿪵�صĳ������.
			if ((g_stAgvAttr.iBatType == BAT_TYPE_SONGXIA) && (iLowChargeCurCount >= 8))
			{
				LOG_INF("retry to send charge request to panasonic battery, when iLowChargeCurCount=%d\n", iLowChargeCurCount);
				songxia_start_charge();
			}

			if (++iLowChargeCurCount >= LOW_CHARGE_CUR_COUNT) //by tiger.89
			{
				//add by jxu 20181008-begin add the battery info monitor
				fVoltage = (float)stBatInfo.uVoltage / 10;
				fCurrent = (float)stBatInfo.uCurrent / 10;
				LOG_WRN("battery temperature:[%dC],voltage:[%.2fV],current[%.2fA],battery:[%d%],state:[%s]\n",
					stBatInfo.uTemp - TEMPER_BASE, fVoltage, fCurrent, stBatInfo.uSoc,
					((stBatInfo.uState == 1) ? "charging" : "not charging"));
				//add by jxu 20181008-end
				iLowChargeCurCount = 0;
#if 0
				LOG_WRN("battery charging failure, send error msg[%d-%s] to console\n",
					EVENT_ERR_CHARGECURSAMLL, get_err_str(EVENT_ERR_CHARGECURSAMLL));
				return -EVENT_ERR_CHARGECURSAMLL;
#else
				g_stAgvAttr.iStopChargeFromMM = TRUE;//add by jxu 20181017 Need search bms info when the stop_charge from main-control
				iRet = stop_charge();
				if (iRet < 0)
				{
					return iRet;
				}
				///end by tiger.41
				//add by jxu 20180820-begin
				if (g_stAgvAttr.iStopChargeConflict == TRUE)
				{
					g_stAgvAttr.iStopChargeConflict = FALSE;
					LOG_WRN("Filter the EVENT_ERR_CHARGECURSAMLL and stop to retry when the stop charge conflict\n");
					return iRet;
				}
				//add by jxu 20180820-end

				//start by tiger.84
				//��һ��MM2.0ֹͣ�����ٳ��һ�Σ���2��MM2.0ֹͣ�����ϱ��쳣
				if (iRetryChargeCount < RETRY_CHARGE_TIMES )
				{
					LOG_INF("detect 3010-EVENT_ERR_CHARGECURSAMLL,start change again\n");
					iRet = start_charge();
					if (iRet != OK)
					{
						if (BERROR == iRet) //iRet = 0x4f56
							iRet = -EVENT_ERR_PARKPRECISION;
						return iRet;
					}
					iRetryChargeCount++;
					LOG_INF("%dth start change by MM2.0 success\n",iRetryChargeCount);					
				}
				else
				{
					iRetryChargeCount = 0;
					// modify by kedong, 20180228
					// correct the wrong error num and error string
					s_bCurSmallErr = true;

				}
#endif
				//end ,by tiger.84
				
			}
		}
		//start add by tiger.83
		//�������У���س������鱨���������ϱ�����100
// 		else if ((agv_charge == g_stAgvAttr.iMoveStatus)
// 			&& (BATT_STATE_CHARGING == stBatInfo.uState))
// 		{
// 			iLowChargeCurCount = 0;
// 			//bHadCharging = true; //by tiger.89			
// 		}
		//end add by tiger.83

		// add by kedong, 20180211
		// when (g_stAgvAttr.iMoveStatus != agv_charge) or (stBatInfo.uState == BATT_STATE_CHARGING)
		// we should set iLowChargeCurCount = 0
		else
		{
			iLowChargeCurCount = 0;
		}

		//report 3010 error ,by tiger.89
		if (true == s_bCurSmallErr)
		{
			iResult = calibrate_battery(&(g_stAgvAttr.bms), iCalibratePeriod);
			//add by tiger.94
			switch (iResult)
			{
			case CALIBRATION_FINISHED:
				s_bCurSmallErr = false;
				break;
			case CALIBRATION_TIMEOUT:
				s_bCurSmallErr = false;
				s_bBatteryFull = true;//send soc=100 to agent,for battery is full now
				//add by yyf 20181029��begin����ֹ���ʱ��ѹ����52V������soc�ϱ��쳣���޷�ֹͣ������
				if (stBatInfo.uVoltage > CALIBRATE_VOLTAGE_V && stBatInfo.uSoc < BATTERY_CHARGE_SOC_60)
				{
					fVoltage = (float)stBatInfo.uVoltage / 10.0;
					LOG_WRN("3010-EVENT_ERR_CHARGECURSAMLL: fVoltage[act:%.2fV, exp:%.2fV, Soc[act:%3d%, exp:%3d%\n",
						fVoltage, CALIBRATE_VOLTAGE_V/10.0f, stBatInfo.uSoc, BATTERY_CHARGE_SOC_60);
					
					// ���ܼ򵥱��쳣3058-EVENT_ERR_BMS_SOC_DISTORTION��
					// ��Ϊ��ʱ�ڳ��׮��,��û��ֹͣ����Ƚ�Σ��, ��3010�ÿ���̨�����뿪.
					// return -EVENT_ERR_BMS_SOC_DISTORTION;
					return -EVENT_ERR_CHARGECURSAMLL;
				}
				//add by yyf 20181029��end����ֹ���ʱ��ѹ����52V������soc�ϱ��쳣���޷�ֹͣ������
				break;
			case NEED_NOT_CALIBRATION:
				LOG_WRN("battery charging failure, send error msg[%d-%s] to console\n",
					EVENT_ERR_CHARGECURSAMLL, get_err_str(EVENT_ERR_CHARGECURSAMLL));
				s_bCurSmallErr = false;
				return -EVENT_ERR_CHARGECURSAMLL;
			case CALIBRATING://keep calibrating
				break; 
			default:
				LOG_INF("not valid result:[%d]\n",iResult);
				break;
			}
			//add by tiger.94
		}
	}
	
	// add by kedong, 20180211
	// just for panasonic battery
	//add by jxu 20180917:begin hanle the pansonic exception
	if (-1 == pBatCanData->can_id)   //modified by yyf 20181022 
	{
#if(DEBUG_AGV == 333)
		LOG_INF("recv battery warn/error info can frame\n");
		print_can_frame(pBatCanData);
#endif
		int iDischargeOverTemWarning = pBatCanData->data[0] & 0x10;
		int iChargeOverTemWarning = pBatCanData->data[0] & 0x08;
		int iDischargeOverTemProtect = pBatCanData->data[0] & 0x04;
		int iChargeOverTemmProtect = pBatCanData->data[0] & 0x02;
		int iVotageDisbalance = pBatCanData->data[0] & 0x01;

		int iDischargeOverVolFlag = pBatCanData->data[1] & 0x02;
		int iChargeOverVolFlag = pBatCanData->data[1] & 0x01;

		int iChargeFullFlag = pBatCanData->data[2] & 0x10;
		int iCapacityLowFlag = pBatCanData->data[2] & 0x08;
		int iChargeStatus = pBatCanData->data[2] & 0x04;
		int iDishargeOverCurrentFlag = pBatCanData->data[2] & 0x02;
		int iChargeErrFlag = pBatCanData->data[2] & 0x01;

		int iCycleCount = htons(*(int16_t *)(&pBatCanData->data[6]));
		//LOG_INF("data0=%d data1=%d data2=%d iCycleCount1=%d\n", 
		//	pBatCanData->data[0], pBatCanData->data[1], pBatCanData->data[2],  iCycleCount);

		//the battery warning beign
		/*if (iDischargeOverTemWarning)
		{
		LOG_WRN("Discharge over temperture warning\n");
		}
		if (iChargeOverTemWarning)
		{
		LOG_WRN("Charge over temperture warning\n");
		}
		if (iChargeFullFlag)
		{
		LOG_WRN("Battery charge fully\n");
		}
		if (iCapacityLowFlag)
		{
		LOG_WRN("Battery capacity low\n");
		}*/
		//the battery warning end

		if ((iDischargeOverTemProtect > 0) && (iDischargeOverTemProtect != iStaticDischargeOverTemProtect))
		{
			LOG_ERR("BMS Exception Pansonic:Discharge over temperture protect-iDischargeOverTemProtect[%d] and iStaticDischargeOverTemProtect[%d]\n",
				iDischargeOverTemProtect, iStaticDischargeOverTemProtect);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_DISCHARGEOVERTEMP, get_err_str(EVENT_ERR_BAT_DISCHARGEOVERTEMP), BMS_VID_PANSONIC);//add by jxu 20180925
			iStaticDischargeOverTemProtect = iDischargeOverTemProtect;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERTEMP);//by tiger.102
		}
		if ((iChargeOverTemmProtect>0) && (iChargeOverTemmProtect != iStaticChargeOverTemmProtect))
		{
			LOG_ERR("BMS Exception Pansonic:Charge over temperture protect-iChargeOverTemmProtect[%d] and iStaticChargeOverTemmProtect[%d]\n",
				iChargeOverTemmProtect, iStaticChargeOverTemmProtect);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_CHARGEOVERTEMP, get_err_str(EVENT_ERR_BAT_CHARGEOVERTEMP), BMS_VID_PANSONIC);
			iStaticChargeOverTemmProtect = iChargeOverTemmProtect;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEOVERTEMP);//by tiger.102
		}
		if ((iVotageDisbalance > 0) && (iVotageDisbalance != iStaticVotageDisbalance))
		{
			LOG_ERR("BMS Exception Pansonic:Voltage is disbalance-iVotageDisbalance[%d] and iStaticVotageDisbalance[%d]\n",
				iVotageDisbalance, iStaticVotageDisbalance);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_VOLDISBALANCE, get_err_str(EVENT_ERR_BAT_VOLDISBALANCE), BMS_VID_PANSONIC);
			iStaticVotageDisbalance = iVotageDisbalance;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_VOLDISBALANCE);//by tiger.102
		}

		if ((iDischargeOverVolFlag >0) && (iDischargeOverVolFlag != iStaticDischargeOverVolFlag))
		{
			LOG_ERR("BMS Exception Pansonic:Discharge over voltage flag-iDischargeOverVolFlag[%d] and iStaticDischargeOverVolFlag[%d]\n",
				iDischargeOverVolFlag, iStaticDischargeOverVolFlag);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_DISCHARGEOVERVOL, get_err_str(EVENT_ERR_BAT_DISCHARGEOVERVOL), BMS_VID_PANSONIC);
			iStaticDischargeOverVolFlag = iDischargeOverVolFlag;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERVOL);//by tiger.102
		}
		if ((iChargeOverVolFlag >0) && (iChargeOverVolFlag != iStaticChargeOverVolFlag))
		{
			LOG_ERR("BMS Exception Pansonic:Charge over voltage flag-iChargeOverVolFlag[%d] and iStaticChargeOverVolFlag[%d]\n",
				iChargeOverVolFlag, iStaticChargeOverVolFlag);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_CHARGEOVERVOL, get_err_str(EVENT_ERR_BAT_CHARGEOVERVOL), BMS_VID_PANSONIC);
			iStaticChargeOverVolFlag = iChargeOverVolFlag;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEOVERVOL);//by tiger.102
		}

		if ((iDishargeOverCurrentFlag >0) && (iDishargeOverCurrentFlag != iStaticDishargeOverCurrentFlag))
		{
			LOG_ERR("BMS Exception Pansonic:Discharge over current flag-iDishargeOverCurrentFlag[%d] and iStaticDishargeOverCurrentFlag[%d]\n",
				iDishargeOverCurrentFlag, iStaticDishargeOverCurrentFlag);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_DISCHARGEOVERCUR, get_err_str(EVENT_ERR_BAT_DISCHARGEOVERCUR), BMS_VID_PANSONIC);
			iStaticDishargeOverCurrentFlag = iDishargeOverCurrentFlag;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERCUR);//by tiger.102
		}

		if ((iChargeErrFlag >0) && (iChargeErrFlag != iStaticChargeErrFlag))
		{
			LOG_ERR("BMS Exception Pansonic:Charge error flag-iChargeErrFlag[%d] iStaticChargeErrFlag[%d]\n", iChargeErrFlag, iStaticChargeErrFlag);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_CHARGEERR, get_err_str(EVENT_ERR_BAT_CHARGEERR), BMS_VID_PANSONIC);
			iStaticChargeErrFlag = iChargeErrFlag;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEERR);//by tiger.102
		}
		iStaticDischargeOverTemProtect = iDischargeOverTemProtect;
		iStaticChargeOverTemmProtect = iChargeOverTemmProtect;
		iStaticVotageDisbalance = iVotageDisbalance;
		iStaticDischargeOverVolFlag = iDischargeOverVolFlag;
		iStaticChargeOverVolFlag = iChargeOverVolFlag;
		iStaticDishargeOverCurrentFlag = iDishargeOverCurrentFlag;
		iStaticChargeErrFlag = iChargeErrFlag;
	}
	//add by jxu 20180917:end
	return iRet;
}
/*******************************************************************************
* Function Name      : anshang_inquiry_bms_errinfo
* Description	     : send inquiry information cmd to bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int anshang_inquiry_bms_errinfo()
{
	struct can_frame stBatCanData = { 0 };
	int iCount = -1;

	stBatCanData.can_id = BATT_REQ_CANID;
	stBatCanData.can_dlc = 8;
	stBatCanData.data[0] = 0x16;
	stBatCanData.data[1] = 0xBE;
	stBatCanData.data[7] = 0x7E;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery error info can frame\n");
	print_can_frame(&stBatCanData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanData);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
/*******************************************************************************
* Function Name      : anshang_parse_bms_error_info
* Description	     : parse the information from bms.
* Input 		     : pBatCanData is the obtained data  .
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int anshang_parse_bms_error_info(struct can_frame *pBatCanData)
{
	int iRet = 0;

	if (pBatCanData == NULL)
		return -1;
	if (BATT_ACK_CANID == pBatCanData->can_id)
	{
#if(DEBUG_AGV == 333)
		LOG_INF("recv battery warn/error info can frame\n");
		print_can_frame(pBatCanData);
#endif
		int iVstate = htons(*(int16_t *)(&pBatCanData->data[0]));
		int iCstate = htons(*(int16_t *)(&pBatCanData->data[2]));
		int iTstate = htons(*(int16_t *)(&pBatCanData->data[4]));

		int iVotageDisbalance = iVstate & 0x0100;
		int iDischargeOverVolFlag = iVstate & 0x0008;
		int iChargeOverVolFlag = iVstate & 0x0004;

		int iDishargeOverCurrentFlag = iCstate & 0x0010 || iCstate & 0x0020;
		int iChargeErrFlag = iCstate & 0x0004;


		int iDischargeOverTemWarning = iTstate & 0x0200;
		int iChargeOverTemWarning = iTstate & 0x0100;
		int iDischargeOverTemProtect = iTstate & 0x0004 || iTstate & 0x0008;
		int iChargeOverTemmProtect = iTstate & 0x0001 || iTstate & 0x0002;

		//int iChargeFullFlag = pBatCanData->data[2] & 0x10;
		//int iCapacityLowFlag = pBatCanData->data[2] & 0x08;
		//int iChargeStatus = pBatCanData->data[2] & 0x04;
		//int iCycleCount = htons(*(int16_t *)(&pBatCanData->data[6]));

		//the battery warning beign
		/*if (iDischargeOverTemWarning)
		{
		LOG_WRN("Discharge over temperture warning\n");
		}
		if (iChargeOverTemWarning)
		{
		LOG_WRN("Charge over temperture warning\n");
		}
		if (iChargeFullFlag)
		{
		LOG_WRN("Battery charge fully\n");
		}
		if (iCapacityLowFlag)
		{
		LOG_WRN("Battery capacity low\n");
		}*/
		//the battery warning end

		if ((iDischargeOverTemProtect > 0) && (iDischargeOverTemProtect != iStaticDischargeOverTemProtect))
		{
			LOG_ERR("BMS Exception Anshang:Discharge over temperture protect-iDischargeOverTemProtect[%d] and iStaticDischargeOverTemProtect[%d]\n",
				iDischargeOverTemProtect, iStaticDischargeOverTemProtect);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_DISCHARGEOVERTEMP, get_err_str(EVENT_ERR_BAT_DISCHARGEOVERTEMP), BMS_VID_ANSHANG);
			iStaticDischargeOverTemProtect = iDischargeOverTemProtect;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERTEMP);//by tiger.102
		}
		if ((iChargeOverTemmProtect>0) && (iChargeOverTemmProtect != iStaticChargeOverTemmProtect))
		{
			LOG_ERR("BMS Exception Anshang:Charge over temperture protect-iChargeOverTemmProtect[%d] and iStaticChargeOverTemmProtect[%d]\n",
				iChargeOverTemmProtect, iStaticChargeOverTemmProtect);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_CHARGEOVERTEMP, get_err_str(EVENT_ERR_BAT_CHARGEOVERTEMP), BMS_VID_ANSHANG);
			iStaticChargeOverTemmProtect = iChargeOverTemmProtect;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEOVERTEMP);//by tiger.102
		}
		if ((iVotageDisbalance > 0) && (iVotageDisbalance != iStaticVotageDisbalance))
		{
			LOG_ERR("BMS Exception Anshang:Voltage is disbalance-iVotageDisbalance[%d] and iStaticVotageDisbalance[%d]\n",
				iVotageDisbalance, iStaticVotageDisbalance);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_VOLDISBALANCE, get_err_str(EVENT_ERR_BAT_VOLDISBALANCE), BMS_VID_ANSHANG);
			iStaticVotageDisbalance = iVotageDisbalance;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_VOLDISBALANCE);//by tiger.102
		}

		if ((iDischargeOverVolFlag >0) && (iDischargeOverVolFlag != iStaticDischargeOverVolFlag))
		{
			LOG_ERR("BMS Exception Anshang:Discharge over voltage flag-iDischargeOverVolFlag[%d] and iStaticDischargeOverVolFlag[%d]\n",
				iDischargeOverVolFlag, iStaticDischargeOverVolFlag);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_DISCHARGEOVERVOL, get_err_str(EVENT_ERR_BAT_DISCHARGEOVERVOL), BMS_VID_ANSHANG);
			iStaticDischargeOverVolFlag = iDischargeOverVolFlag;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERVOL);//by tiger.102
		}
		if ((iChargeOverVolFlag >0) && (iChargeOverVolFlag != iStaticChargeOverVolFlag))
		{
			LOG_ERR("BMS Exception Anshang:Charge over voltage flag-iChargeOverVolFlag[%d] and iStaticChargeOverVolFlag[%d]\n",
				iChargeOverVolFlag, iStaticChargeOverVolFlag);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_CHARGEOVERVOL, get_err_str(EVENT_ERR_BAT_CHARGEOVERVOL), BMS_VID_ANSHANG);
			iStaticChargeOverVolFlag = iChargeOverVolFlag;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEOVERVOL);//by tiger.102
		}

		if ((iDishargeOverCurrentFlag >0) && (iDishargeOverCurrentFlag != iStaticDishargeOverCurrentFlag))
		{
			LOG_ERR("BMS Exception Anshang:Discharge over current flag-iDishargeOverCurrentFlag[%d] and iStaticDishargeOverCurrentFlag[%d]\n",
				iDishargeOverCurrentFlag, iStaticDishargeOverCurrentFlag);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_DISCHARGEOVERCUR, get_err_str(EVENT_ERR_BAT_DISCHARGEOVERCUR), BMS_VID_ANSHANG);
			iStaticDishargeOverCurrentFlag = iDishargeOverCurrentFlag;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_DISCHARGEOVERCUR);//by tiger.102
		}

		if ((iChargeErrFlag >0) && (iChargeErrFlag != iStaticChargeErrFlag))
		{
			LOG_ERR("BMS Exception Anshang:Charge error flag-iChargeErrFlag[%d] iStaticChargeErrFlag[%d]\n", iChargeErrFlag, iStaticChargeErrFlag);
			EVENT_LOG("%d\t%s\t%s\n", EVENT_ERR_BAT_CHARGEERR, get_err_str(EVENT_ERR_BAT_CHARGEERR), BMS_VID_ANSHANG);
			iStaticChargeErrFlag = iChargeErrFlag;
			print_can_frame(pBatCanData);
			//send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_BAT_CHARGEERR);//by tiger.102
		}
		iStaticDischargeOverTemProtect = iDischargeOverTemProtect;
		iStaticChargeOverTemmProtect = iChargeOverTemmProtect;
		iStaticVotageDisbalance = iVotageDisbalance;
		iStaticDischargeOverVolFlag = iDischargeOverVolFlag;
		iStaticChargeOverVolFlag = iChargeOverVolFlag;
		iStaticDishargeOverCurrentFlag = iDishargeOverCurrentFlag;
		iStaticChargeErrFlag = iChargeErrFlag;
	}
	return iRet;
}
/*******************************************************************************
* Function Name      : check_bms_monitor
* Description	     : check the information from bms.
* Input 		     : fp: file handle will be writen  .
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int check_bms_monitor(FILE *fp)
{
	struct can_frame stBattCanData = { 0 };
	bool bIfReport = TRUE;
	int iRet = -1;
	u32 u32Count = 0;
	u32 u32FailCount = 0;

	while (1)
	{
		u32Count++;
		sleep(2);//change by tiger.38,attention packet loss

		iRet = inquiry_bms_info();
		if (iRet < 0) {
			if (u32Count % 20 == 0)
				LOG_WRN("query battery info failure\n");

			continue;
		}

		iRet = get_bms_info(&stBattCanData);
		if (iRet < 0)
		{
			u32FailCount++;

			// modified by kedong, 20180206
			// we no need to report get bms info failed every time
			// report 30*2 second = 1 report/minute
			if ((TRUE == bIfReport) && (u32FailCount > 20))
			{
				bIfReport = FALSE;
				u32FailCount = 0;
				break;
			}
		}
		else
		{
			bIfReport = TRUE;
			iRet = parse_bms_info(&stBattCanData);
			if (iRet < 0)
				LOG_INF("parse_bms_info is failed iRet=%d\n", iRet);
			else
			{
				iRet = 0;
				fprintf(fp, "uVoltage=%f uCurrent=%f temperature=%d SOC=%d uState=%d\n", g_stAgvAttr.bms.uVoltage*0.1, g_stAgvAttr.bms.uCurrent*0.1, g_stAgvAttr.bms.uTemp - TEMPER_BASE, g_stAgvAttr.bms.uSoc, g_stAgvAttr.bms.uState);
				break;
			}
		}
	}

	return iRet;
}
/*******************************************************************************
* Function Name      : get_bms_info
* Description	     : wait and get the information sent by bms.
* Input 		     : pBatCanData is the obtained data.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int songxia_get_bms_info(struct can_frame * pBatCanData)
{
	int iRet = -1;
	int iTryCount = 0;

	if (pBatCanData == NULL) {
		return -1;
	}

	iTryCount = 1000;//ms
	while (iTryCount--)
	{
		usleep(1000);
		memset(pBatCanData, 0, sizeof(struct can_frame));
		iRet = recv_can(BATT_CAN_DEV, pBatCanData);
		if (iRet < 0)
			continue;
		//add by jxu 20180910-begin
		if (pBatCanData->can_id == BATT_ACK_CANID)
		{
			g_stAgvAttr.bms.uSoc = pBatCanData->data[4];
		}
		//add by jxu 20180910-end
		if (pBatCanData->can_id == BATT_ACK_CANID_0X15)
		{
			g_stAgvAttr.iBmsVersion = pBatCanData->data[5];//add by jxu 20180910
			g_stAgvAttr.bms.iBattVersion = g_stAgvAttr.iBmsVersion;//add by jxu 20181017
			iRet = 0;
			break;
		}
	}
	if (iTryCount <= 0)
	{
		iRet = -1;
	}

	return iRet;
}
/*******************************************************************************
* Function Name      : songxia_battery_init_check
* Description	     : The function recoginize the songxia battery
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int songxia_battery_init_check()
{
	int iTimeOut = 3; // s
	struct can_frame stCanFrame = { 0 };
	u32 u32Count = 0;
	u32 u32FailCount = 0;
	int iRet = -1;
	struct can_frame stBattCanData = { 0 };

	while (iTimeOut--)
	{
		u32Count++;
		iRet = inquiry_bms_info();
		if (iRet < 0) {
			if (u32Count % 20 == 0)
				LOG_WRN("query battery info failure\n");
			usleep(1000);
			continue;
		}
		iRet = songxia_get_bms_info(&stBattCanData);
		if (iRet < 0)
		{
			u32FailCount++;
			LOG_INF("Do not get the 0x15 frame u32FailCount=%d\n", u32FailCount);
		}
		else
		{
			LOG_INF("The battery type is songxia\n");
			print_can_frame(&stBattCanData);
			break;
		}
	}
	if (iTimeOut <= 0)
	{
		LOG_WRN("get battery type timeout\n");
		return -1;
	}
	return 0;

}
/*******************************************************************************
* Function Name      : songxia_get_bms_info
* Description	     : wait and get the information sent by bms.
* Input 		     : pBatCanData is the obtained data.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int songxia_get_bmsvid_info(struct can_frame * pBatCanData)
{
	int iRet = -1;
	int iTryCount = 0;

	if (pBatCanData == NULL) {
		return -1;
	}

	iTryCount = 1000;//ms
	while (iTryCount--)
	{
		usleep(1000);
		memset(pBatCanData, 0, sizeof(struct can_frame));
		iRet = recv_can(BATT_CAN_DEV, pBatCanData);
		if (iRet < 0)
			continue;
		if (pBatCanData->can_id == BATT_ACK_CANID_0X1C)
		{
			g_stAgvAttr.iBmsVID = htons(*(int16_t *)(&pBatCanData->data[0]));
			iRet = 0;
			break;
		}
	}
	if (iTryCount <= 0)
	{
		iRet = -1;
	}

	return iRet;
}
/*******************************************************************************
* Function Name      : inquiry_bms_vid
* Description	     : send inquiry information cmd to bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int inquiry_bms_vid()
{
	struct can_frame stBatCanData = { 0 };
	int iCount = -1;

	stBatCanData.can_id = BATT_REQ_CANID_0X18;
	stBatCanData.can_dlc = 8;
	stBatCanData.data[0] = 0xBB;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery VID can frame\n");
	print_can_frame(&stBatCanData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanData);//change by tiger
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
/*******************************************************************************
* Function Name      : songxia_battery_init_check
* Description	     : The function recoginize the songxia battery
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int songxia_battery_vid_pid()
{
	int iTimeOut = 3; // s
	struct can_frame stCanFrame = { 0 };
	u32 u32Count = 0;
	u32 u32FailCount = 0;
	int iRet = -1;
	struct can_frame stBattCanData = { 0 };

	while (iTimeOut--)
	{
		u32Count++;
		iRet = inquiry_bms_vid();
		if (iRet < 0) {
			if (u32Count % 20 == 0)
				LOG_WRN("query battery info failure\n");
			usleep(1000);
			continue;
		}
		iRet = songxia_get_bmsvid_info(&stBattCanData);
		if (iRet < 0)
		{
			u32FailCount++;
			LOG_INF("Do not get the 0x1C frame u32FailCount=%d\n", u32FailCount);
		}
		else
		{
			LOG_INF("The songxia battery vid is following\n");
			print_can_frame(&stBattCanData);
			break;
		}
	}
	if (iTimeOut <= 0)
	{
		LOG_WRN("get battery type timeout\n");
		return -1;
	}
	return 0;

}
/*******************************************************************************
* Function Name      : inquiry_bms_lasterfive_poweroff_info
* Description	     : send inquiry information cmd to bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int inquiry_bms_lasterfive_poweroff_info()
{
	struct can_frame stBatCanData = { 0 };
	int iCount = -1;

	stBatCanData.can_id = BATT_REQ_CANID_0X18;
	stBatCanData.can_dlc = 8;
	stBatCanData.data[0] = 0x5B;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery info can frame\n");
	print_can_frame(&stBatCanData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanData);//change by tiger
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
/*******************************************************************************
* Function Name      : songxia_get_lasterfive_poweroff_info
* Description	     : wait and get the information sent by bms.
* Input 		     : pBatCanData is the obtained data.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int songxia_get_lasterfive_poweroff_info(struct can_frame * pBatCanData)
{
	int iRet = -1;
	int iTryCount = 0;

	if (pBatCanData == NULL) {
		return -1;
	}

	iTryCount = 1000;//ms
	while (iTryCount--)
	{
		usleep(1000);
		memset(pBatCanData, 0, sizeof(struct can_frame));
		iRet = recv_can(BATT_CAN_DEV, pBatCanData);
		if (iRet < 0)
			continue;
		if (pBatCanData->can_id == BATT_ACK_CANID_0X19)
		{
			print_can_frame(pBatCanData);
			int ilatestOne = pBatCanData->data[0];
			int ilatestTwo = pBatCanData->data[1];
			int ilatestThree = pBatCanData->data[2];
			int ilatestFour = pBatCanData->data[3];
			int ilatestFive = pBatCanData->data[4];
			LOG_INF("BMS Exception Pansonic:ilatestOne =%d ilatestTwo=%d ilatestThree=%d ilatestFour=%d ilatestFive=%d\n",
				ilatestOne, ilatestTwo, ilatestThree, ilatestFour, ilatestFive);
			iRet = 0;
			break;
		}
	}
	if (iTryCount <= 0)
	{
		iRet = -1;
	}

	return iRet;
}
/*******************************************************************************
* Function Name      : songxia_battery_lasterfive_poweroff
* Description	     : The function recoginize the songxia battery
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int songxia_battery_lasterfive_poweroff()
{
	int iTimeOut = 3; // s
	struct can_frame stCanFrame = { 0 };
	u32 u32Count = 0;
	u32 u32FailCount = 0;
	int iRet = -1;
	struct can_frame stBattCanData = { 0 };

	while (iTimeOut--)
	{
		u32Count++;
		iRet = inquiry_bms_lasterfive_poweroff_info();
		if (iRet < 0) {
			if (u32Count % 20 == 0)
				LOG_WRN("query lasterfive_poweroff info failure\n");
			usleep(1000);
			continue;
		}
		iRet = songxia_get_lasterfive_poweroff_info(&stBattCanData);
		if (iRet < 0)
		{
			u32FailCount++;
			LOG_INF("Do not get the 0x19 frame u32FailCount=%d\n", u32FailCount);
		}
		else
		{
			LOG_INF("The songxia battery lasterfive_poweroff is following\n");
			print_can_frame(&stBattCanData);
			break;
		}
	}
	if (iTimeOut <= 0)
	{
		LOG_WRN("get lasterfive_poweroff timeout\n");
		return -1;
	}
	return 0;

}

//add by yyf 20181022:begin
/*******************************************************************************
* Function Name      : songxia_battery_get_pack_model
* Description	     : The function get pack model about the songxia battery
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int songxia_battery_get_pack_model()
{
	int iTimeOut = 3; // s
	struct can_frame stCanFrame = { 0 };
	u32 u32Count = 0;
	u32 u32FailCount = 0;
	int iRet = -1;
	struct can_frame stBattCanData = { 0 };

	while (iTimeOut--)
	{
		u32Count++;
		iRet = inquiry_bms_pack_model_info();
		if (iRet < 0) {
			if (u32Count % 20 == 0)
				LOG_WRN("inquiry bms pack model info failure\n");
			usleep(1000);
			continue;
		}
		iRet = songxia_get_bms_model_info(&stBattCanData);
		if (iRet < 0)
		{
			u32FailCount++;
			LOG_INF("Do not get the 0x19 frame u32FailCount=%d\n", u32FailCount);
		}
		else
		{
			LOG_INF("The songxia battery get pack model is following\n");
			print_can_frame(&stBattCanData);
			break;
		}
	}
	if (iTimeOut <= 0)
	{
		LOG_WRN("get pack model timeout\n");
		return -1;
	}
	return 0;

}

/*******************************************************************************
* Function Name      : inquiry_bms_pack_model_info
* Description	     : send inquiry pcak model cmd to bms.
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1 on error
*******************************************************************************/
int inquiry_bms_pack_model_info()
{
	struct can_frame stBatCanData = { 0 };
	int iCount = -1;

	stBatCanData.can_id = BATT_REQ_CANID_0X18;
	stBatCanData.can_dlc = 8;
	stBatCanData.data[0] = 0xBA;

#if(DEBUG_AGV == 333)
	LOG_INF("send query battery pack model info can frame\n");
	print_can_frame(&stBatCanData);
#endif

	iCount = send_can(BATT_CAN_DEV, &stBatCanData);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}


/*******************************************************************************
* Function Name      : songxia_get_bms_model_info
* Description	     : wait and get the information sent by bms.
* Input 		     : pBatCanData is the obtained data.
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int songxia_get_bms_model_info(struct can_frame * pBatCanData)
{
	int iRet = -1;
	int iTryCount = 0;

	if (pBatCanData == NULL) {
		return -1;
	}

	iTryCount = 1000;//ms
	while (iTryCount--)
	{
		usleep(1000);
		memset(pBatCanData, 0, sizeof(struct can_frame));
		iRet = recv_can(BATT_CAN_DEV, pBatCanData);
		if (iRet < 0)
			continue;
		if (pBatCanData->can_id == BATT_ACK_CANID_0X1D)
		{
			print_can_frame(pBatCanData);
			LOG_INF("BMS Pack Model:%s\n",pBatCanData->data);
			iRet = 0;
			break;
		}
	}
	if (iTryCount <= 0)
	{
		iRet = -1;
	}

	return iRet;
}
//add by yyf 20181022:edn