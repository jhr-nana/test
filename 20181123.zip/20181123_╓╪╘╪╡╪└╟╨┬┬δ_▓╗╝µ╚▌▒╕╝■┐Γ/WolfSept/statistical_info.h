/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* FileName:xxx.H
* Author: Menghu Wang   Version: V1.0   Data:2018-03-19
* Description:THE INTERFACE OF AGV STATISTICAL INFO
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
#ifndef __STATISTICAL_H_
#define __STATISTICAL_H_
/* Define to prevent recursive inclusion -------------------------------------*/
/* Includes ------------------------------------------------------------------*/
#include "global_var.h"
/* Exported constants --------------------------------------------------------*/
#define PACKAGE_MAX_SIZE  1464
/* Exported types ------------------------------------------------------------*/
typedef struct _package_header
{
	i16 i16DateType;
	i16 i16ProtoVer;
	i16 i16DataNum;
	i16 i16ColumnNum;
}package_header_st;
typedef struct _statical_info_package
{
	package_header_st st_header;
	char pDateBuf[PACKAGE_MAX_SIZE];
}statical_info_package_st;
typedef struct _event_info
{
	i16 i16ThemeID;
	float fThemeVersion;
	char pDateID[24];
	char pDateTime[24];
	i32 i32AGVNo;
	char pSN[13];
	i32 i32Location;
	i32 i32VehHeadDirect;
	i32 i32PalletDirect;
	i32 i32MoveStatus;
	i32 i32Speed;
	i32 i32GXOffset;
	i32 i32GYOffset;
	i32 i32GAngleOffset;
	i32 i32TXOffset;
	i32 i32TYOffset;
	i32 i32TAngleOffset;
	i32 i32Battery;
	i32 i32ErrorCode;
	i32 i32PalletStatus;
	char pShelfQR[32];
	char cLinkQuality;
	char cSignalLevel;
	char cNoiseLevel;
}event_info_st;
typedef struct _battery_info
{
	i16 i16ThemeID;
	float fThemeVersion;
	char pDateID[24];
	char pDateTime[24];
	i32 i32AGVNo;
	char pSN[13];
	float fTemperature;
	float fVoltage;
	float fCurrent;
	i32 i32Battery;
	i8 i8State;

}battery_info_st;
typedef struct udp_rx_info
{
	i32 i32Bytes;
	i32 i32Packets;
	i32 i32Errs;
	i32 i32Drop;
	i32 i32Fifo;
	i32 i32Frame;
	i32 i32Compressed;
	i32 i32Multicast;
}udp_rx_info_st;
typedef struct udp_tx_info
{
	i32 i32Bytes;
	i32 i32Packets;
	i32 i32Errs;
	i32 i32Drop;
	i32 i32Fifo;
	i32 i32Colls;
	i32 i32Carrier;
	i32 i32Compressed;
}udp_tx_info_st;
typedef struct _network_info
{
	i16 i16ThemeID;
	float fThemeVersion;
	char pDateID[24];
	char pDateTime[24];
	i32 i32AGVNo;
	char pSN[13];
	char pSensitivity[8];
	char pLinkQuality[8];
	char pSignalLevel[8];
	char pNoiseLevel[8];
	i32 i32RXPkts;
	i32 i32RXErrorPkts;
	i32 i32RXDropPkts;
	i32 i32RXOverRunsPkts;
	i32 i32TXPkts;
	i32 i32TXErrorPkts;
	i32 i32TXDropPkts;
	i32 i32TXOverRunsPkts;

}network_info_st;
typedef struct _action_info
{
	i16 i16ThemeID;
	float fThemeVersion;
	char pDateID[24];
	i32 i32AGVNo;
	char pSN[13];
	char pStartDateTime[24];
	char pEndDateTime[24];
	i32 i32Action;
	char pActionName[32];
}action_info_st;
typedef struct _pgv_heartbeat
{
	i16 i16ThemeID;
	float fThemeVersion;
	char pDateID[24];
	char pDateTime[24];
	i32 i32AGVNo;
	char pSN[13];
	i8 i8State;
}pgv_heartbeat_st;

/* Exported macro ------------------------------------------------------------*/
#define SATISTICAL_SEND_NOW   0
#define SATISTICAL_SEND_PERIOD_30S		30		//unit:second
#define SATISTICAL_SEND_PERIOD_60S		60		//unit:second
#define SATISTICAL_SEND_PERIOD_300S		300		//unit:second
#define SATISTICAL_SEND_PERIOD_1H		(60*60)	 //one hour(unit:second)
/* Exported functions --------------------------------------------------------*/
extern int sta_send_event_info(int iSendPeriod);
extern int sta_send_battery_info(int iSendPeriod);
extern int sta_send_network_info(int iSendPeriod);
extern int sta_send_action_info(int iSendPeriod, char *pActionName);
extern int sta_send_pgv_heartbeat_info(int iSendPeriod);
extern int get_ip_sn(int iSockfd);
#endif /* __STATISTICAL_H_ */
/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/