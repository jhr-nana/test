/********************************************************************************
* Copyright (c) 2017, JD.COM, Inc .
* All rights reserved.
* FileName: uart_camera.h
* Author: tongkedong   Version: V1.0   Data:2017-12-18
* Description:
* uart_camera low-level support api code
********************************************************************************/
#ifndef _UART_CAMERA_H_
#define _UART_CAMERA_H_
#include "global_var.h"
#include "device.h"
#include "debug.h"


extern int uart_camera_start();
extern int uart_camera_stop();
extern int uart_camera_get_qrinfo(qr_info_t * pQRInfo);
extern int uart_camera_init_check();//add by jxu 20180305
extern int get_camera_version_supportdiff();//add by jxu 20180920
extern int uart_camera_get_qrinfo_check(qr_info_t * pQRInfo, FILE *fp);//add by jxu 20180719

#endif //_UART_CAMERA_H_
