﻿/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* All rights reserved.
* FileName:UART.C
* Author: Menghu Wang   Version: V1.0   Data:2017-06-26
* Description:REALIZE THE UART FUNCTION LIB
*Version: V1.0
*History:
	<author>    <time>    <version>     <desc>
********************************************************************************/
#include "uart.h"
/* Includes ------------------------------------------------------------------*/
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name		 : open_uart
* Description	     : open the uart device
* Input 		     : pathname:the name of the uart
* Output		     : NONE
* Return		     : file descriptor if OK, -1 on error 
*******************************************************************************/
int open_uart(const char *pPathName)
{
	int iFd = 0;
	int iRet = 0;
	
	if (pPathName == NULL) {
		return -1;
	}

	iFd = open(pPathName, O_RDWR | O_NOCTTY | O_NDELAY);
	if (iFd < 0) {
		LOG_ERR("open %s is failed\n", pPathName);
		return -1;
	}
	
	iRet = fcntl(iFd, F_SETFL, 0);
	if (iRet < 0)	//set block
	{
		LOG_ERR("fcntl failed!\n");
		close(iFd);
		return -1;
	}
	
	//if input parameter(file descriptor) is terminal device, return 1; else return 0
	//if (0 == isatty(STDIN_FILENO))
	//{
	//	LOG_ERR("standard input is not a terminal device\n");
	//	close(iFd);
	//	return -1;
	//}

	return iFd;
}

/*******************************************************************************
* Function Name      : set_uart_opt
* Description	     : set the option of the uart
* Input 		     : iFd:the fd of opened uart; iBaudrate:the baudrate of the uart
					   cBits:bit of byte,such as DATA_BIT_7;cCheck:the style of check ,such asPARITY_ODD
					   cStop:the bit of stop,such as STOP_BIT_1
* Output		     : NONE
* Return		     : 0 if OK, -1 on error
*******************************************************************************/
int set_uart_opt(int iFd, int iBaudrate, char cBits, char cCheck, char cStop)
{
	struct termios stNewTio, stOldTio;

	if (0 != tcgetattr(iFd, &stOldTio))
	{
		LOG_ERR("set the state of fd into *TERMIOS_P failure. error:[%s]\n", strerror(errno));
		return -1;
	}

	bzero(&stNewTio, sizeof(stNewTio));

	///ensure the uart port cannot be disturb by other port
	stNewTio.c_cflag |= CLOCAL | CREAD;
	stNewTio.c_cflag &= ~CSIZE;

	if (DATA_BIT_7 == cBits)
	{
		stNewTio.c_cflag |= CS7;
	}
	else
	{
		stNewTio.c_cflag |= CS8;
	}

	switch (cCheck)
	{
		case PARITY_ODD:
			stNewTio.c_cflag |= PARENB;
			stNewTio.c_cflag |= PARODD;
			stNewTio.c_iflag |= (INPCK | ISTRIP);
			break;
		case PARITY_EVEN:
			stNewTio.c_iflag |= (INPCK | ISTRIP);
			stNewTio.c_cflag |= PARENB;
			stNewTio.c_cflag &= ~PARODD;
			break;
		case PARITY_NONE:
			stNewTio.c_cflag &= ~PARENB;
			break;
		default:
			stNewTio.c_cflag &= ~PARENB;
			break;
	}

	switch (iBaudrate)
	{
		case  BAUD_1200:
			cfsetispeed(&stNewTio, B1200);
			cfsetospeed(&stNewTio, B1200);
			break;
		case  BAUD_2400:
			cfsetispeed(&stNewTio, B2400);
			cfsetospeed(&stNewTio, B2400);
			break;
		case  BAUD_4800:
			cfsetispeed(&stNewTio, B4800);
			cfsetospeed(&stNewTio, B4800);
			break;
		case  BAUD_9600:
			cfsetispeed(&stNewTio, B9600);
			cfsetospeed(&stNewTio, B9600);
			break;
		case  BAUD_19200:
			cfsetispeed(&stNewTio, B19200);
			cfsetospeed(&stNewTio, B19200);
			break;
		case  BAUD_38400:
			cfsetispeed(&stNewTio, B38400);
			cfsetospeed(&stNewTio, B38400);
			break;
		case  BAUD_57600:
			cfsetispeed(&stNewTio, B57600);
			cfsetospeed(&stNewTio, B57600);
			break;
		case  BAUD_115200:
			cfsetispeed(&stNewTio, B115200);
			cfsetospeed(&stNewTio, B115200);
			break;
		case BAUD_460800:
			cfsetispeed(&stNewTio, B460800);
			cfsetospeed(&stNewTio, B460800);
			break;
		default:
			cfsetispeed(&stNewTio, B9600);
			cfsetospeed(&stNewTio, B9600);
			break;
	}

	if (STOP_BIT_1 == cStop)
	{
		stNewTio.c_cflag &= ~CSTOPB;
	}		
	else
	{
		stNewTio.c_cflag |= CSTOPB;
	}

	stNewTio.c_cc[VTIME] = 1; //read immediately with block
	stNewTio.c_cc[VMIN] = 50;
	tcflush(iFd,TCIFLUSH);

	if ( 0 != (tcsetattr(iFd, TCSANOW, &stNewTio))) //with immediate effect
	{
		LOG_ERR("set attr of uart failure, error:[%s]", strerror(errno));
		return -1;
	}

	LOG_INF("uart'parameter:[Baudrate=%d, DataBit=%d, ParityBit=%c, StopBit=%d]\n", iBaudrate, cBits, cCheck, cStop);

	return 0;
}

/*******************************************************************************
* Function Name      : init_uart
* Description	     : init the uart
* Input 		     : NONE
* Output		     : NONE
* Return		     : fd if OK, -1 on error
*******************************************************************************/
int init_uart(uart_attr_t *pUartAttar)
{
	int iFd = 0;
	int iRet = 0;

	if (pUartAttar == NULL) {
		return -1;
	}

	iFd = open_uart(pUartAttar->pUartName);
	if (iFd < 0)
	{
		LOG_ERR("open_uart failed\n");
		return -1;
	}

	iRet = set_uart_opt(iFd, pUartAttar->iBaud, pUartAttar->cDateBit, pUartAttar->cParity, pUartAttar->cStopBit);
	if (iRet < 0)
	{
		LOG_ERR("set uart opt failure\n");
		close_uart(iFd);
		return -1;
	}

	return iFd;
}

/*******************************************************************************
* Function Name      : send_uart
* Description	     : send the data by uart
* Input 		     : iFd:the fd of opened uart; pBuf:the data to be send
					   iLen:the length of the pBuf
* Output		     : NONE
* Return		     : number of bytes written if OK , -1 on error
*******************************************************************************/
ssize_t send_uart(int iFd, char *pBuf, ssize_t iLen)
{
	ssize_t iRet = {0};

	iRet = write(iFd, pBuf, iLen);
	if (-1 == iRet)
	{
		LOG_ERR("write device failure, error:[%s]\n", strerror(errno));
		return -1;
	}

	return iRet;
}

/*******************************************************************************
* Function Name      : read_uart
* Description	     : send the data by uart,the uart is block
* Input 		     : fd:the fd of opened uart; pBuf:the data to be send
iLen:the length of the pBuf
* Output		     : NONE
* Return		     : number of bytes written if OK , -1 on error
*******************************************************************************/
size_t recv_uart(int iFd, char *pRcvBuf, ssize_t iLen)
{
	int iByte = 0;

	iByte = read(iFd, pRcvBuf, iLen);
	if(0 >= iByte)
		return -1;
	
	return iByte;
}

/*******************************************************************************
* Function Name      : close_uart
* Description	     : close uart
* Input 		     : iFd:the fd of opened uart;
* Output		     : NONE
* Return		     :0 if OK , -1 on error
*******************************************************************************/
int close_uart(int iFd)
{
	if (0 != close(iFd))
	{
		LOG_ERR("close uart fd failure, error:[%s]\n", strerror(errno));
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name      : test_uart
* Description	     : just for test uart;send the reiceve buf
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0 on ok;-1 on error
*******************************************************************************/
int test_uart(void)
{
	char pTmpBuf[1024];
	int iUartFd = -1;
	ssize_t iRecLength = 0;
	uart_attr_t stUartAttr =
	{
		 .cDateBit = DATA_BIT_8,
		 .cParity = PARITY_NONE,
		 .cStopBit = STOP_BIT_1,
		 .iBaud = BAUD_19200,
		 .pUartName = UART_NAME
		
	};
	strcpy(pTmpBuf, "Tiger is handsome boy!!!\n");
	if (0 > (iUartFd = init_uart(&stUartAttr)))
	{
		return -1;
	}
	if ( send_uart(iUartFd, pTmpBuf, strlen(pTmpBuf)))
	{
		return -1;
	}
	while (1)
	{
		bzero(pTmpBuf, sizeof(pTmpBuf));
		iRecLength = recv_uart(iUartFd, pTmpBuf, 30);
		if (0 > iRecLength )
		{
			if (-1 == send_uart(iUartFd, pTmpBuf, strlen(pTmpBuf)))
			{
				return -1;
			}
		}

	}
	return 0;
}
/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/