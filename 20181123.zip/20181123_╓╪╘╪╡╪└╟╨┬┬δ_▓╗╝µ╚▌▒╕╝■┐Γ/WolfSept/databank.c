#include "databank.h"

int CAMERA_ANGLE = CAMERA_0;

int IMG_WIDTH;               //   宽度
int IMG_HEIGHT;              //   高度

float CAMERA_POS_X = 0.0;
float CAMERA_POS_Y = 0.0;
float CAMERA_POS_THETA = 0.0;

uint8_t *grayImageData=NULL;
uint8_t *binaryImageData=NULL;

// 存放临时数据的池子，用于临时存储每次提取的特征数据，切记每次使用完后要清理数据
snake_point *tempDataPool=NULL;


uint8_t  detectedRingsNum=0;

snake_detectedRing detectedRings[MAX_RING_NUM];

int g_iPatternIdxArray[MAX_RING_NUM];

snake_mapPose mapPose;                   // 码图位姿

snake_rigidTransModel rigidTransModel;   // 刚体变换模型



snake_pointf infoZeroPoint;


snake_infoMatrix infoMatrix[INFO_MATRIX_ROW][INFO_MATRIX_COLUMN];
snake_infoMatrix codeIdxMatrix[CODE_IDX_BITS];

// 输出的接口信息
snake_infoOutput infoOutput;

// 多码的解码结果
uint64_t g_decodeRet[STANDARD_RING_MAX_NUM] = {};

// 多个解码结果中，次数最多的结果所对应的码图的索引
int g_realMapIdx[STANDARD_RING_MAX_NUM] = {};

// monitor
snake_monitor monitor;

// 记录解码的错误信息
snake_decode_error decode_error[NUM_OF_DATAWORDS];

/////////////////////// end //////////////////////////
