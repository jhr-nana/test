/********************************************************************************
* Copyright (c) 2018, JD.COM, Inc .
* All rights reserved.
* FileName: mc_v2.h
* Author: Xu Jing   Version: V2.0   Data:2018-01-09
* Description:
********************************************************************************/
#ifndef _MC_V2_H_
#define _MC_V2_H_
#include "global_var.h"
#include "device.h"
#include "debug.h"


#define MC_CAN_CMD_GOFORWARD_V2		        (0x01)
#define MC_CAN_CMD_GOBACKWARD_V2		    (0x02)
#define MC_CAN_CMD_TURNLEFT_V2			    (0x03)
#define MC_CAN_CMD_TURNRIGHT_V2		        (0x04)
#define MC_CMD_LEFT_ARC_V2      			(0x05)
#define MC_CMD_RIGHT_ARC_V2				    (0x06)
#define MC_CMD_BACK_TO_CHARGE_V2 			(0x07)
#define MC_CMD_FORWARD_LEAVE_CHARGE_V2   	(0x08)
#define MC_CMD_FORWARD_TO_CHARGE_V2		    (0x09)//0x08 instead
#define MC_CMD_BACK_LEAVE_CHARGE_V2		    (0x0A)//0x07 instead
#define TC_CAN_CMD_CYCLELEFT_V2			    (0x11)
#define TC_CAN_CMD_CYCLERIGHT_V2			(0x12)
#define TC_CAN_CMD_JACK_V2					(0x21)
#define TC_CAN_CMD_PUT_V2				    (0x22)
#define MC_CAN_CMD_STOP_V2					(0x31)
#define MC_CAN_CMD_PARK_V2					(0x41)
#define MC_CAN_CMD_STOPPARK_V2				(0x42)
#define MC_CAN_CMD_RESTART_V2				(0x51)


typedef struct mc_can_action_req
{
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned short iVel;
	unsigned short iDist;
	unsigned char  iWeitLev;
	unsigned char  iRsvd;
	unsigned char  iAction;
	unsigned char  iSeq;
} mc_can_action_req_st;

typedef struct mc_can_action_ack
{
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned short iRetInfo;
	unsigned char  iRsvd1;
	unsigned char  iRsvd2;
	unsigned char  iRsvd3;
	unsigned char  iRsvd4;
	unsigned char  iAction;
	unsigned char  iSeq;
}mc_can_action_ack_st;

typedef struct plate_can_angle_req
{

	unsigned int	iCanId;
	unsigned int	iCanDlc;
	unsigned short	iAngle;
	short	iDiffY;
	short	iDiffX;
	//add by jxu 20180920-begin
	unsigned char	iCameraVer : 1;
	unsigned char	iSuppDiff : 1;
	unsigned char	iRsvd : 6;
	//add by jxu 20180920-end
	unsigned char	iSeq;
}plate_can_angle_req_st;

typedef struct plate_can_angle_ack
{
	unsigned int	iCanId;
	unsigned int	iCanDlc;
	unsigned short  iRetVal;
	short	iDiffY;
	short	iDiffX;
	unsigned char   iRsvd;
	unsigned char   iSeq;
}plate_can_angle_ack_st;


typedef struct mc_can_status_heartbeat
{
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned short iData2;
	unsigned short iData1;
	unsigned char  iPath : 7;
	unsigned char  iNewTag : 1;
	unsigned char  iEvent:6;
	unsigned char  iMode : 2;
	unsigned char  iHeaddirect : 3;
	unsigned char  iMoveState : 5;
	unsigned char  iSeq;
}mc_can_status_heartbeat_st;


typedef struct mc_can_status_finish
{
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned int   iPointId;
	unsigned char  iRsvd1;
	unsigned char  iRsvd2;
	unsigned char  iAction;
	unsigned char  iSeq;
}mc_can_status_finish_st;


typedef struct mc_can_exception_notify
{
	unsigned int   iCanId;
	unsigned int   iCanDlc;
	unsigned int   iData;
	unsigned short iErrId;
	unsigned char  iStyle;
	unsigned char  iSeq;
}mc_can_exception_notify_st;


typedef struct mc_can_rw_flag_param_req
{
	unsigned int	iCanId;
	unsigned int	iCanDlc;
	unsigned int	iParamVal;
	unsigned short  iParamId;
	unsigned char   iCmd;
	unsigned char   iSeq;
}mc_can_rw_flag_param_req_st;

typedef struct mc_can_rw_param_req
{
	unsigned int	iCanId;
	unsigned int	iCanDlc;
	float	iParamVal;
	unsigned short  iParamId;
	unsigned char   iCmd;
	unsigned char   iSeq;
}mc_can_rw_param_req_st; //add by tiger.42

typedef struct mc_can_rw_flag_param_ack
{
	unsigned int	iCanId;
	unsigned int	iCanDlc;
	unsigned int	iParamVal;
	unsigned short  iParamId;
	unsigned char   iCmd;
	unsigned char   iSeq;
}mc_can_rw_flag_param_ack_st;

typedef struct mc_can_rflag_version_ack
{
	unsigned int	iCanId;
	unsigned int	iCanDlc;
	unsigned char	iRsvd;
	unsigned char	iModifyVerId;
	unsigned char	iMinorVerId;
	unsigned char	iMajorVerId;
	unsigned short  iParamId;
	unsigned char   iCmd;
	unsigned char   iSeq;
}mc_can_rflag_version_ack_st;

typedef struct _mc_update_req
{
	canid_t can_id;  /* 32 bit CAN_ID + EFF/RTR/ERR flags */
	__u8    can_dlc; /* data length code: 0 .. 8 */
	u32     u32Data;//data[0~3]
	u8    u8data4;//data[4]
	u8    u8data5;//data[5]
	u8   u8Style;//data[6]
	u8	  u8Sequence;//data[7]
}mc_update_req;
typedef struct _mc_update_ack
{
	canid_t can_id;  /* 32 bit CAN_ID + EFF/RTR/ERR flags */
	__u8    can_dlc; /* data length code: 0 .. 8 */
	u32     u32Data;//data[0~3]
	u8    u8data4;//data[4]
	u8    u8data5;//data[5]
	u8   u8Style;//data[6]
	u8	  u8Seq;//data[7]
}mc_update_ack;

typedef enum _mc_update_cmd
{
	MC_UPDATE_CRC_CMD = 0x01,
	MC_UPDATE_LENGTH_CMD = 0x02,
	MC_UPDATE_ABORT_CMD = 0x03,
	MC_UPDATE_DATA_ACK = 0x04,
	MC_UPDATE_CHECK_RESULT = 0x05,
}mc_update_cmd;
//extern void mc_v2_deal_ack(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);//donot need
extern void mc_v2_deal_fin(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
extern int mc_v2_deal_heartbeat(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
extern int mc_v2_deal_exception(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);

extern int mc_v2_check_version();

extern int mc_v2_get_flag(u8 u8FlagVar);
extern int mc_v2_set_flag(u8 u8FlagVar, u32 u32Value);
extern int mc_v2_get_param(u8 u8ParamVar);
extern int mc_v2_set_param(u8 u8ParamVar, float fValue);

extern int mc_v2_go_forward(u8 u8Weight, u16 u16Distance, u16 u16Speed);
extern int mc_v2_go_backward(u8 u8Weight, u16 u16Distance, u16 u16Speed);
extern int mc_v2_turn_left(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed);
extern int mc_v2_turn_right(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed);
extern int mc_v2_leftarc(u16 u16Weight);
extern int mc_v2_rightarc(unsigned short u16Weight);
extern int mc_v2_slow_go_back(u16 u16SRemain, u16 u16QRDistance);
extern int mc_v2_slow_go_straight(u16 u16SRemain, u16 u16QRDistance);
extern int mc_v2_cntl_lift_motor(u8 u8Operate, u8 u8Weight);
extern int mc_v2_cntl_cycle_motor(u8 u8Operate, u8 u8Weight, u16 u16Angle, u16 u16Speed);
extern int mc_v2_stop();
extern int mc_panasonic_charge();
extern int mc_panasonic_stopcharge();
extern int mc_v2_start_charge();
extern int mc_v2_stop_charge();
extern int mc_v2_restart();
extern int mc_v2_send_angle_offset(u16 u16Angle);
extern int mc_v2_clear_derail(void);
extern int mc_v2_clear_navigation(void);
extern int mc_v2_clear_lcoder_error(void);
extern int mc_v2_clear_rcoder_error(void);
extern int mc_v2_enter_debug_mode(void);
extern int mc_v2_quit_debug_mode(void);
extern int mc_v2_clasp_pallet(void);
extern int mc_v2_unclasp_pallet(void);
extern int mc_v2_clasp_wheel(void);
extern int mc_v2_unclasp_wheel(void);
extern int mc_v2_update_crc_cmd(u32 u32Crc32);
extern int mc_v2_update_length_cmd(u32 u32Length);
extern int mc_v2_update_abort_cmd();
#endif //_MC_V2_H_
/******************* (C) COPYRIGHT 2018  Jd.Com, Inc . *****END OF FILE****/
