#include "processing.h"
#include "multipatternfinder.h"
#include "databank.h"
#include "binarize.h"
#include "scanner.h"
#include "rigidmodel.h"
#include "decoder.h"

static void FuncInfoOutput(bool bIsSuccess);

/********************************************
函数功能:FuncMemoryAlloc函数实现，分配内存
函数输入:
函数输出:
*********************************************/
void FuncMemoryAlloc(void)
{
    grayImageData =(uint8_t *)malloc(IMG_WIDTH*IMG_HEIGHT*sizeof(uint8_t));
    binaryImageData =(uint8_t *)malloc(IMG_WIDTH*IMG_HEIGHT*sizeof(uint8_t));
    tempDataPool =(snake_point *)malloc(IMG_WIDTH*IMG_HEIGHT*sizeof(snake_point));
}


/********************************************
函数功能:FuncDataInit函数实现，初始化函数
函数输入:
函数输出:
*********************************************/
void FuncDataInit(void)
{

    memset(grayImageData,0x00,sizeof(uint8_t)*IMG_WIDTH*IMG_HEIGHT);
    memset(binaryImageData,0x00,sizeof(uint8_t)*IMG_WIDTH*IMG_HEIGHT);
    memset(tempDataPool,0x00,sizeof(snake_point)*IMG_WIDTH*IMG_HEIGHT);

    detectedRingsNum=0;
    memset(detectedRings, 0x00, sizeof(detectedRings));

    memset(g_iPatternIdxArray, 0x00, sizeof(g_iPatternIdxArray));

    memset(&mapPose,0x00,sizeof(snake_mapPose));

    memset(&rigidTransModel,0x00,sizeof(rigidTransModel));


    memset(&infoZeroPoint,0x00,sizeof(infoZeroPoint));

    memset(infoMatrix,0x00,sizeof(infoMatrix));

    memset(&infoOutput,0x00,sizeof(infoOutput));

    memset(decode_error,0x00,sizeof(decode_error));

    memset(g_decodeRet,0,sizeof(g_decodeRet));
    memset(g_realMapIdx,0,sizeof(g_realMapIdx));
    memset(codeIdxMatrix,0,sizeof(codeIdxMatrix));
}


/********************************************
函数功能:FuncDataDestroy函数实现，内存释放
函数输入:
函数输出:
*********************************************/
void FuncMemoryDestroy()
{
    free(grayImageData);
    grayImageData=NULL;

    free(binaryImageData);
    binaryImageData=NULL;

    free(tempDataPool);
    tempDataPool=NULL;

}

/********************************************
函数功能: 计算AGV正向与二维码之间的角度
函数输入: codeIdx : 多码码图的编号
         angle : 摄像头的正向与AGV正向的夹角(按逆时针)
函数输出: AGV正向与二维码的夹角的单位向量的笛卡尔坐标表示
*********************************************/
static bool FuncCalcuRigidTransModelAngle(int angle, int codeIdx, snake_pointf *pVec)
{
    float theta = 0.0f;
    if (NULL==pVec)
        return false;
#ifdef CAMERA_UP   // 上方摄像头
    switch (angle) {
    case CAMERA_0:
        if (0==codeIdx)
            theta = rigidTransModel.updatedTheta;
        else if (1==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI_2;
        else if (2==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI;
        else if (3==codeIdx)
            theta = rigidTransModel.updatedTheta + M_PI_2;
        break;

    case CAMERA_90:
        if (1==codeIdx)
            theta = rigidTransModel.updatedTheta;
        else if (2==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI_2;
        else if (3==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI;
        else if (0==codeIdx)
            theta = rigidTransModel.updatedTheta + M_PI_2;
        break;

    case CAMERA_180:
        if (2==codeIdx)
            theta = rigidTransModel.updatedTheta;
        else if (3==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI_2;
        else if (0==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI;
        else if (1==codeIdx)
            theta = rigidTransModel.updatedTheta + M_PI_2;
        break;


    case CAMERA_270:
        if (3==codeIdx)
            theta = rigidTransModel.updatedTheta;
        else if (0==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI_2;
        else if (1==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI;
        else if (2==codeIdx)
            theta = rigidTransModel.updatedTheta + M_PI_2;
        break;

    default:
        break;
    }
#else   // 下方摄像头
    switch (angle) {
    case CAMERA_0:
        if (0==codeIdx)
            theta = rigidTransModel.updatedTheta;
        else if (1==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI_2;
        else if (2==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI;
        else if (3==codeIdx)
            theta = rigidTransModel.updatedTheta + M_PI_2;
        break;

    case CAMERA_90:
        if (3==codeIdx)
            theta = rigidTransModel.updatedTheta;
        else if (0==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI_2;
        else if (1==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI;
        else if (2==codeIdx)
            theta = rigidTransModel.updatedTheta + M_PI_2;
        break;

    case CAMERA_180:
        if (2==codeIdx)
            theta = rigidTransModel.updatedTheta;
        else if (3==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI_2;
        else if (0==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI;
        else if (1==codeIdx)
            theta = rigidTransModel.updatedTheta + M_PI_2;
        break;


    case CAMERA_270:
        if (1==codeIdx)
            theta = rigidTransModel.updatedTheta;
        else if (2==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI_2;
        else if (3==codeIdx)
            theta = rigidTransModel.updatedTheta - M_PI;
        else if (0==codeIdx)
            theta = rigidTransModel.updatedTheta + M_PI_2;
        break;

    default:
        break;
    }
#endif
    rigidTransModel.updatedTheta = theta;
    pVec->Pix = cos(theta);
    pVec->Lin = sin(theta);
    return true;
}

/********************************************
函数功能: 计算AGV正向与二维码之间的角度
函数输入: codeIdx : 多码码图的编号
         angle : 摄像头的正向与AGV正向的夹角(按逆时针)
函数输出: AGV正向与二维码的夹角的单位向量的笛卡尔坐标表示
*********************************************/
void FuncCalcuRigidTransModelOffset(snake_camera_angle angle, float deltaX, float deltaY)
{
    /// 以车头方向为X正方向，建立右手系
    switch (angle) {
    case CAMERA_0:
        infoOutput.deltaX= -deltaY;
        infoOutput.deltaY= deltaX;
        break;

    case CAMERA_90:
        infoOutput.deltaX= -deltaX;
        infoOutput.deltaY= -deltaY;
        break;

    case CAMERA_180:
        infoOutput.deltaX= deltaY;
        infoOutput.deltaY= -deltaX;
        break;

    case CAMERA_270:
        infoOutput.deltaX= deltaX;
        infoOutput.deltaY= deltaY;
        break;
    default:
        break;
    }
}

// 找到数组中出现次数最多的元素
static int FuncSelectMessg(uint64_t *messg)
{
    int i = 0, j = 0, k = 0;
    int kMax = 0;
    uint64_t m = 0; //这个数用来作判断是否检查过，同时作为最终结果输出
    int tagValueX = 0, tagValueY = 0;

    for (i=0; i<STANDARD_RING_MAX_NUM; i++) {
        if (g_decodeRet[i] != m) { //已经检查过的数不再检查
            // 计算出现次数
            k = 0;
            for (j=i; j<STANDARD_RING_MAX_NUM; j++) {
                if (g_decodeRet[i] == g_decodeRet[j] && g_decodeRet[i] > 0) {
                    k++;
                }
            }
            if (k > kMax) {
                kMax = k;
                m = g_decodeRet[i]; //1. 次数更多，优先选取
            } else if (k == kMax) {
                m = g_decodeRet[i] > m ? g_decodeRet[i] : m; //2. 次数相同，取更大的数
            }
        }
    }

    k = 0;
    for (i=0; i<STANDARD_RING_MAX_NUM; i++)
    {
        if (m == g_decodeRet[i])
            g_realMapIdx[k++] = i;
    }

    *messg = m;
    return kMax;
}


/********************************************
函数功能:FuncProcessing函数实现
函数输入:
函数输出:
*********************************************/
bool FuncProcessing(void)
{
    int i = 0;

    // 多码图的二维码，需要对识别出来的多个码图的中心以及角度进行平均
    snake_pointf mapCenterTmp[STANDARD_RING_MAX_NUM];   // 对码图中心进行平均
    snake_pointf updateMapCenterTmp[STANDARD_RING_MAX_NUM];  // 对码图中心进行平均
    snake_pointf vectmp[STANDARD_RING_MAX_NUM];
    snake_pointf thetaVecSum = {0.0f, 0.0f};
    float widthPerPix = 0;
    float heightPerLin = 0;
    snake_transType mapType = TRANS_ERROR;
    snake_pointf ptTmp;
    int nMapNum = 0; // 码图个数
    int8_t codeIdx[4] = {-1,-1,-1,-1};
    uint8_t codeIdxNum = 0;
    snake_WarnType warn;

#ifdef DISPLAY
    snake_point pointATmp[STANDARD_RING_MAX_NUM];
    snake_point pointBTmp[STANDARD_RING_MAX_NUM];
    snake_point pointCTmp[STANDARD_RING_MAX_NUM];
    snake_point recCornerBATmp[STANDARD_RING_MAX_NUM][4];
    snake_point recCornerBCTmp[STANDARD_RING_MAX_NUM][4];
    ELLIPSE_PARA recBAEllipseParaTmp[STANDARD_RING_MAX_NUM];
    ELLIPSE_PARA recBCEllipseParaTmp[STANDARD_RING_MAX_NUM];
    snake_infoMatrix InforMatrix3[STANDARD_RING_MAX_NUM][INFO_MATRIX_ROW][INFO_MATRIX_COLUMN];
#endif

    bool isDetected = false;
    bool isRigidTrans = false;
    bool isPoseCalculated = false;
    bool isExtracted = false;

    memset(g_decodeRet,0,sizeof(g_decodeRet));
    memset(&monitor,0x00,sizeof(monitor));
    memset(mapCenterTmp,0,sizeof(mapCenterTmp));
    memset(updateMapCenterTmp,0,sizeof(updateMapCenterTmp));
    memset(vectmp,0,sizeof(vectmp));

    // 0. 滤波操作
    FuncImageFilter(grayImageData,IMG_WIDTH,IMG_HEIGHT);

    // 1. 二值化操作
    FuncImgBinarize(IMG_WIDTH,IMG_HEIGHT);

    // 2. 图像3个特征圆检测
    isDetected=FuncRingsDetect(binaryImageData,3,IMG_WIDTH-3,3,IMG_HEIGHT-3);

    if(isDetected && STANDARD_RING_NUM<=detectedRingsNum
            /*&& STANDARD_RING_MAX_NUM>=detectedRingsNum*/)
    { // 如果获得有效数目的特征圆

        for (i=0; i<detectedRingsNum; i+=3)
        {
            // 如果后续不足三个特征圆则退出循环
            if (i+3>detectedRingsNum)
                break;

            // 3. 特征圆匹配及码图位姿估计
            isRigidTrans=FuncCodeMapPoseEstimate(i, i+1, i+2);

            if(isRigidTrans && mapPose.transType==RIGID)
            {
                // 4. 利用直线的几何矩计算精确的码图Pose数据
                isPoseCalculated=FuncMapPosePreciseCalculate();

                if(isPoseCalculated)
                {
                    // 5. 对信息矩阵的读取
                    isExtracted=FuncInfoMatrixExtract(); // to be added.......

                    if(isExtracted)
                    {
                        // 6. 解码及验证
                        warn = FuncSingleDecoder(codeIdx, &codeIdxNum); // to be added.......
                        if(codeIdx[0]!=-1 && WARN_NONE==warn)
                        {
                            mapType = RIGID;
                            // 计算码图中心
                            mapCenterTmp[nMapNum].Pix = mapPose.mapCenter.Pix;
                            mapCenterTmp[nMapNum].Lin = mapPose.mapCenter.Lin;
                            widthPerPix += mapPose.widthPerPix;
                            heightPerLin += mapPose.heightPerLin;
                            updateMapCenterTmp[nMapNum].Pix = rigidTransModel.updatedMapCenter.Pix;
                            updateMapCenterTmp[nMapNum].Lin = rigidTransModel.updatedMapCenter.Lin;
//                            g_decodeRet[nMapNum] = infoOutput.messg;
                            FuncCalcuRigidTransModelAngle(CAMERA_ANGLE, codeIdx[0], &vectmp[nMapNum]);
#ifdef DISPLAY
                            memcpy(&pointATmp[nMapNum], &mapPose.PointA, sizeof(snake_point));
                            memcpy(&pointBTmp[nMapNum], &mapPose.PointB, sizeof(snake_point));
                            memcpy(&pointCTmp[nMapNum], &mapPose.PointC, sizeof(snake_point));
                            memcpy(recCornerBATmp[nMapNum],rigidTransModel.recCornerBA, 4*sizeof(snake_point));
                            memcpy(recCornerBCTmp[nMapNum],rigidTransModel.recCornerBC, 4*sizeof(snake_point));
                            memcpy(&recBAEllipseParaTmp[nMapNum], &rigidTransModel.recBAEllipsePara, sizeof(ELLIPSE_PARA));
                            memcpy(&recBCEllipseParaTmp[nMapNum], &rigidTransModel.recBCEllipsePara, sizeof(ELLIPSE_PARA));
                            memcpy(InforMatrix3[nMapNum], infoMatrix, sizeof(infoMatrix));
#endif
                            nMapNum++;

                            //return true;
                        }
                        else
                        {
                            //printf("--------RIGID-ERR: Info decode wrong ...\n");
                            monitor.decodeUNRELIABLE++;
                            //return false;
                        }
                    }
                    else
                    {

                        //printf("------RIGID-ERR: Info extracted wrong ...\n");
                        monitor.infoExtractERR++;

                        //return false;
                    }

                }
                else
                {

                    //printf("----RIGID-ERR: detected wrong line...\n");
                    monitor.lineDetectERR++;

                    //return false;

                }

            }
            else
            {

                //printf("----ERR: not rigid transform rings...\n");
                monitor.transTypeERR++;

                //return false;
            }
        }

        if (nMapNum<1)
		{
			FuncInfoOutput(false);
            return false;
		}

//        nMapNum = FuncSelectMessg(&infoOutput.messg);
        FuncFusionDecoder(&infoOutput.messg);

        if (0 == infoOutput.messg)
		{
			FuncInfoOutput(false);
            return false;
		}

        mapPose.transType = mapType;
        detectedRingsNum = nMapNum * 3;

        ptTmp.Pix = ptTmp.Lin = 0.0f;
        for (i=0; i<nMapNum; i++)
        {
            ptTmp.Pix += mapCenterTmp[i].Pix;
            ptTmp.Lin += mapCenterTmp[i].Lin;
//            ptTmp.Pix += mapCenterTmp[g_realMapIdx[i]].Pix;
//            ptTmp.Lin += mapCenterTmp[g_realMapIdx[i]].Lin;
        }
        mapPose.mapCenter.Pix = ptTmp.Pix/nMapNum;
        mapPose.mapCenter.Lin = ptTmp.Lin/nMapNum;
        mapPose.widthPerPix = widthPerPix/nMapNum;
        mapPose.heightPerLin = heightPerLin/nMapNum;

        ptTmp.Pix = ptTmp.Lin = 0.0f;
        for (i=0; i<nMapNum; i++)
        {
            ptTmp.Pix += updateMapCenterTmp[i].Pix;
            ptTmp.Lin += updateMapCenterTmp[i].Lin;
//            ptTmp.Pix += updateMapCenterTmp[g_realMapIdx[i]].Pix;
//            ptTmp.Lin += updateMapCenterTmp[g_realMapIdx[i]].Lin;
        }
        rigidTransModel.updatedMapCenter.Pix = ptTmp.Pix/nMapNum;
        rigidTransModel.updatedMapCenter.Lin = ptTmp.Lin/nMapNum;

        // 使用向量平均，然后再转化为角度的
        thetaVecSum.Pix = thetaVecSum.Lin = 0.0f;
        for (i=0; i<nMapNum; i++)
        {
            thetaVecSum.Pix += vectmp[i].Pix;
            thetaVecSum.Lin += vectmp[i].Lin;
//            thetaVecSum.Pix += vectmp[g_realMapIdx[i]].Pix;
//            thetaVecSum.Lin += vectmp[g_realMapIdx[i]].Lin;
        }
        thetaVecSum.Pix /= nMapNum;
        thetaVecSum.Lin /= nMapNum;
        rigidTransModel.updatedTheta = atan2(thetaVecSum.Lin, thetaVecSum.Pix);
#ifdef DISPLAY
        memcpy(&mapPose.PointA, &pointATmp[0], sizeof(snake_point));
        memcpy(&mapPose.PointB, &pointBTmp[0], sizeof(snake_point));
        memcpy(&mapPose.PointC, &pointCTmp[0], sizeof(snake_point));
        memcpy(rigidTransModel.recCornerBA,recCornerBATmp[0], 4*sizeof(snake_point));
        memcpy(rigidTransModel.recCornerBC,recCornerBCTmp[0], 4*sizeof(snake_point));
        memcpy(&rigidTransModel.recBAEllipsePara, &recBAEllipseParaTmp[0], sizeof(ELLIPSE_PARA));
        memcpy(&rigidTransModel.recBCEllipsePara, &recBCEllipseParaTmp[0], sizeof(ELLIPSE_PARA));
        memcpy(infoMatrix, InforMatrix3[0], sizeof(infoMatrix));
#endif
    }
    else
    {
        //printf("--ERR: Ring detect failed...\n");
        monitor.ringDetectERR++;
		FuncInfoOutput(false);
        return false;
    }
	FuncInfoOutput(true);

    return true;
}



void FuncInfoOutput(bool bIsSuccess){

    int i = 0;
    float deltaXImage = 0.0f;
    float deltaYImage = 0.0f;
    float deltaXMap = 0.0f;
    float deltaYMap = 0.0f;

    if(bIsSuccess){
        infoOutput.error = ERR_NO_ERROR;
        infoOutput.angle=rigidTransModel.updatedTheta*180/M_PI;

        if (infoOutput.angle < -180.0 || infoOutput.angle > 180.0)
        {
            memset(&infoOutput,0x00,sizeof(infoOutput));
            infoOutput.error = ERR_UNRELIABLE;
            return;
        }
        // 在图像坐标系下坐标偏差
        deltaXImage=(rigidTransModel.updatedMapCenter.Pix-(IMG_WIDTH-1)/2.0)*mapPose.widthPerPix;
        deltaYImage=(rigidTransModel.updatedMapCenter.Lin-(IMG_HEIGHT-1)/2.0)*mapPose.heightPerLin;
#ifndef CAMERA_UP   // 下方摄像头
        // 转换为在码图坐标系下坐标偏差
        deltaXMap= -(deltaXImage*cos(rigidTransModel.updatedTheta)+deltaYImage*sin(rigidTransModel.updatedTheta));
        deltaYMap= -(-deltaXImage*sin(rigidTransModel.updatedTheta)+deltaYImage*cos(rigidTransModel.updatedTheta));

        // 码图坐标系转换为地面标准坐标系
        infoOutput.deltaX= -deltaYMap;
        infoOutput.deltaY= -deltaXMap;
//        FILE *fp = fopen("D:\\CPlusPlusCode\\MultiCodeRecognition\\demo\\Camera\\zxing.txt","a+");
//        fprintf(fp,"%f %f %f\n",infoOutput.deltaX, infoOutput.deltaY, infoOutput.angle);
//        fclose(fp);
#else   // 上方摄像头
        /// 以车头方向为X正方向，建立右手系
        FuncCalcuRigidTransModelOffset(CAMERA_ANGLE,deltaXImage,deltaYImage);

        /// consider camera position error
        infoOutput.deltaX -= CAMERA_POS_X;
        infoOutput.deltaY -= CAMERA_POS_Y;
        infoOutput.angle  -= CAMERA_POS_THETA;
        if (infoOutput.angle > 180.0)
            infoOutput.angle -= 360.0;
        else if (infoOutput.angle < -180.0)
            infoOutput.angle += 360.0;
#endif
//        printf("deltaX: %f  deltaY: %f\n",infoOutput.deltaX,infoOutput.deltaY);
    }
    else if (detectedRingsNum < 1)
    {
        infoOutput.error = ERR_NO_CODE;
    }
    else if (detectedRingsNum < STANDARD_RING_NUM || monitor.ringDetectERR > 0)
    {
        infoOutput.error = ERR_CODE_BROKEN;
    }
    else if (monitor.decodeUNRELIABLE > 0)
    {
        infoOutput.error = ERR_UNRELIABLE;
    }
    else if (monitor.infoExtractERR > 0)
    {
        infoOutput.error = ERR_DATA_BROKEN;
    }
    else if (monitor.lineDetectERR > 0)
    {
        infoOutput.error = ERR_LINE_BROKEN;
    }
    else if (monitor.transTypeERR > 0)
    {
        infoOutput.error = ERR_CODE_SLOPE;
    }
}

int FuncGetResult(float *deltaX, float *deltaY, float *angle, uint64_t *tag, uint8_t* ringsNum)
{
	*deltaX = infoOutput.deltaX;
	*deltaY = infoOutput.deltaY;
	*angle = infoOutput.angle;
	*tag = infoOutput.messg;
    *ringsNum = detectedRingsNum;
	return infoOutput.error;
}

/////////////////////// end //////////////////////////
