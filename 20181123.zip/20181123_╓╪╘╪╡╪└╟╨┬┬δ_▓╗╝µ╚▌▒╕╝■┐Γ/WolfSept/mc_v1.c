/********************************************************************************
* Copyright (c) 2017, JD.COM, Inc .
* All rights reserved.
* FileName: mc_v1.c
* Author: tongkedong   Version: V1.0   Data:2017-12-18
* Description:
* move control low-level support api code
********************************************************************************/
#include "mc_v1.h"
#define VAR_OUT_TRACK				0x02 
#define CLEAN_FLAG					0
#define VAR_OUT_NAVIGATE			0x03 
#define VAR_WHEEL_CLASP				0x07
#define VAR_PALLET_CLASP			0x02

/*******************************************************************************
* Function Name      : mc_v1_check_version
* Description	     : check mc software'version
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0 if OK, -1 on error.
*******************************************************************************/
int mc_v1_check_version()
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;
	stCanFrame.can_id = MC_CANID_REQ;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[4] = MC_VERSION_F;
	stCanFrame.data[6] = MC_TYPE_READ_F;
	stCanFrame.data[7] = get_seq(MC_SEQ_ID);

	LOG_INF("send to can:check version\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount !=  sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name      : mc_v1_update_version
* Description	     : update mc software'version
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int mc_v1_update_version(bool bUpdate)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	if (bUpdate == TRUE)
	{
		//TODO
		//update mc version
		return 0;
	}
	else if (bUpdate == FALSE){
		stCanFrame.can_id = MC_CANID_REQ;
		stCanFrame.can_dlc = MC_DATA_DLC;
		stCanFrame.data[4] = 0;
		stCanFrame.data[6] = 7;
		return 0;
	}

	LOG_INF("send to can:update version\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v1_get_flag
* Description	     : get flag of MC
* input			     : u8FlagVar : series number of flag var
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v1_get_flag(u8 u8FlagVar)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(MC_SEQ_ID));
	stCanFrame.data[6] = MC_GET_FLAG; //cmd 
	stCanFrame.data[4] = u8FlagVar; //var

	LOG_INF("send to can:get flag\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v1_set_flag
* Description	     : set flag of MC
* input			     : u8FlagVar : series number of flag var
* input			     : fValue : value will be set
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v1_set_flag(u8 u8FlagVar, u32 u32Value)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(MC_SEQ_ID));
	stCanFrame.data[6] = MC_SET_FLAG; //cmd 
	stCanFrame.data[4] = u8FlagVar; //flag var
	*((u32 *)(&stCanFrame.data[0])) = u32Value;
	
	LOG_INF("send to can:set flag\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v1_get_param
* Description	     : get param from MC
* input			     : u8FlagVar : series number of flag var
* input			     : fValue : the value of param var
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v1_get_param(u8 u8ParamVar)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(MC_SEQ_ID));
	stCanFrame.data[6] = MC_GET_PARAM; //cmd 
	stCanFrame.data[4] = u8ParamVar; //param

	LOG_INF("send to can:get param\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v1_set_param
* Description	     : set param for MC
* input			     : u8FlagVar : series number of flag var
* input			     : fValue : the value of param var
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v1_set_param(u8 u8ParamVar, float fValue)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(MC_SEQ_ID));
	stCanFrame.data[6] = MC_SET_PARAM; //cmd 
	stCanFrame.data[4] = u8ParamVar; //flag var
	*((float *)(&stCanFrame.data[0])) = fValue;

	LOG_INF("send to can:set param\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v1_enable_wdg
* Description	     : enable watchdog for MC
* Input              : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v1_enable_wdg()
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(MC_SEQ_ID));
	stCanFrame.data[6] = MC_OPERATE; //cmd 
	stCanFrame.data[5] = MC_ENABLE_WDG; //wdg

	LOG_INF("send to can:enable mc watchdog\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v1_start
* Description	     : start mc
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v1_start()
{
	int iRet = 0;

	// nothing to do

	return iRet;
}

/*******************************************************************************
* Function Name		 : mc_v1_reset
* Description	     : reset mc
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v1_reset()
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(TC_SEQ_ID));
	stCanFrame.data[6] = MC_OPERATE;  //cmd
	stCanFrame.data[5] = MC_RESET;  //stop charging agv

	LOG_INF("send to can:reset agv mc\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}


/*******************************************************************************
* Function Name		 : mc_v1_stop
* Description	     : stop MC
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v1_stop()
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(MC_SEQ_ID));
	stCanFrame.data[6] = MC_OPERATE; //cmd 
	stCanFrame.data[5] = MC_STOP; //param

	LOG_INF("send to can:stop agv mc\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v1_start_charge
* Description	     : start charge power
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v1_start_charge()
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(MC_SEQ_ID));
	stCanFrame.data[6] = MC_OPERATE;  //cmd
	stCanFrame.data[5] = MC_BEGIN_CHARGE;  //charge agv

	LOG_INF("send to can:start charge\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v1_stop_charge
* Description	     : stop charge power
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v1_stop_charge()
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(MC_SEQ_ID));
	stCanFrame.data[6] = MC_OPERATE;  //cmd
	stCanFrame.data[5] = MC_STOP_CHARGE;  //stop charging agv

	LOG_INF("send to can:stop charge\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}	
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v1_deal_ack
* Description	     : deal with MC ACK msg, and send finish msg to console
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
///start by tiger.17
void mc_v1_deal_ack(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	mc_can_cmd_ack_t * pMcCanCmdAck = NULL;

	u16 u16Status = 0;
	u16 u32Data = 0;
	float fData = 0.0;

	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return;

	pMcCanCmdAck = (mc_can_cmd_ack_t *)pCanFrame;

	LOG_DBG("recv mc ack[seq=%d style=%d cmd=%d var=%d data1=0x%04x data2=0x%04x]\n",
		pMcCanCmdAck->iSeq, pMcCanCmdAck->iStyle, pMcCanCmdAck->iCmd,
		pMcCanCmdAck->iVar, pMcCanCmdAck->iData1, pMcCanCmdAck->iData2);
	print_can_frame(pCanFrame);

	u16Status = *((u16*)&pMcCanCmdAck->iData1);
	u32Data = *((u32*)&pMcCanCmdAck->iData1);
	fData = *((float*)&pMcCanCmdAck->iData1);
	pAgvAttr->iMcAction = (u8)pMcCanCmdAck->iCmd;
	pAgvAttr->iMcStyle = (u8)pMcCanCmdAck->iStyle;
	switch (pAgvAttr->iMcStyle)
	{
	case MC_GET_FLAG:
		pAgvAttr->stMcProperty.key = pMcCanCmdAck->iVar;
		pAgvAttr->stMcProperty.value = u32Data;
		break;
	case MC_SET_FLAG:
		pAgvAttr->stMcProperty.key = pMcCanCmdAck->iVar;
		pAgvAttr->stMcProperty.value = u32Data;
		break;
	case MC_GET_PARAM:
		pAgvAttr->stMcPropertyPram.key = pMcCanCmdAck->iVar;
		pAgvAttr->stMcPropertyPram.value = fData;
		break;
	case MC_SET_PARAM:
		pAgvAttr->stMcPropertyPram.key = pMcCanCmdAck->iVar;
		pAgvAttr->stMcPropertyPram.value = fData;
		break;
	case MC_OPERATE:
		pAgvAttr->iMcState = u16Status;
		break;
	default:
		LOG_INF("received MC'ACK :nothing to do\n");
		break;
	}
}
///end by tiger.17

/*******************************************************************************
* Function Name		 : mc_v1_deal_fin
* Description	     : deal with MC finish and send msg to console
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void mc_v1_deal_fin(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	mc_can_cmd_fin_t * pMcCanCmdFin = NULL;

	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return;

	pMcCanCmdFin = (mc_can_cmd_fin_t *)pCanFrame;

	// when canid=0x382, filter CAN_MDH(Byte[4~7])=0xA55A0101\0xA55A0102\0xA55A0103
	if ((pCanFrame->data[7] == 0xA5) && (pCanFrame->data[6] == 0x5A))
	{
		pAgvAttr->iMcAction = -1;		//Byte[5]
		pAgvAttr->iMcStyle = -1;		//Byte[6]
	}
	else
	{
		pAgvAttr->iMcAction = pMcCanCmdFin->iCmd;		//Byte[5]
		pAgvAttr->iMcStyle  = pMcCanCmdFin->iStyle;		//Byte[6]
	}

	LOG_INF("recv action[%d-%s] finish can frame\n", 
		pAgvAttr->iMcAction, get_mc_cmd_name(pAgvAttr->iMcAction));
	print_can_frame(pCanFrame);
}

/*******************************************************************************
* Function Name		 : mc_v1_deal_heartbeat
* Description	     : deal with the MC heartbeat frame
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : int:the check sum of data[0~6]
*******************************************************************************/
int mc_v1_deal_heartbeat(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	int iCheckSum = 0;
	mc_can_heartbeat_t * pMcHeartBeat = (mc_can_heartbeat_t *)pCanFrame;
	int iSpeed = abs(pMcHeartBeat->iSpeed);	//data[0]
	int iResDistance = pMcHeartBeat->iResDistance;	//data[1]
	int iPath = pMcHeartBeat->iPath;		//data[2].bit[7:1]
	int iNewTag = pMcHeartBeat->iNewTag;	//data[2].bit[0]
	int iEvent = pMcHeartBeat->iEvent;		//data[3].bit[7:2]
	//int iMode = pMcHeartBeat->iMode;		//data[3].bit[1:0]
	//int iHeadDirect = pMcHeartBeat->iHeadDirect;	//data[4].bit[7:4]
	//int iStyle = pMcHeartBeat->iStyle;				//data[4].bit[3:0]
	//int iSeq = pMcHeartBeat->iSeq;					//data[5]
	int iMoveStatus = pMcHeartBeat->iMoveState;
	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return -1;

	//LOG_INF("deal mc heartbeat can frame\n");
	//print_can_frame(pCanFrame);

	iCheckSum = (pCanFrame->data[0] + pCanFrame->data[1] + pCanFrame->data[2] + pCanFrame->data[3] + \
		pCanFrame->data[4] + pCanFrame->data[5] + pCanFrame->data[6]) &0xffffffff;
	pAgvAttr->iMCStatus = 0;
	pAgvAttr->iStatus = 0;
	pAgvAttr->iSpeed = iSpeed / 10;
	pAgvAttr->iEvent = iEvent;
	pAgvAttr->iSreamin = iResDistance;//add by jxu 20180312
	pAgvAttr->iMcHeartBeatStatus = iMoveStatus;//add by tiger.61

	if (g_stAgvConf.cDebugEnable == TRUE)
	{
		pAgvAttr->iPath = iPath;
		pAgvAttr->iNewTag = iNewTag;
	}
	//pAgvAttr->iVehHeadDirect = iHeadDirect;

	return iCheckSum;
}

/*******************************************************************************
* Function Name		 : mc_v1_deal_exception
* Description	     : deal with the exceptions of MC
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int mc_v1_deal_exception(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return 0;

	LOG_INF("deal mc exception can frame\n");
	print_can_frame(pCanFrame);

	// nothing to do
}

/*******************************************************************************
* Function Name		 : mc_v1_go_forward
* Description	     : set go forward command to mc
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Distance : distance(unit:0.1 degree)
* input			     : u16Speed : speed(unit:millimeter/second)
* Output		     : NONE
* Return		     : 0:if OK ; -1 on error
*******************************************************************************/
int mc_v1_go_forward(u8 u8Weight, u16 u16Distance, u16 u16Speed)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(MC_SEQ_ID));
	stCanFrame.data[6] = MC_OPERATE;  //cmd
	stCanFrame.data[5] = MC_GO_FORWARD;
	stCanFrame.data[4] = u8Weight;
	*((u16 *)(&stCanFrame.data[2])) = u16Distance;
	*((u16 *)(&stCanFrame.data[0])) = u16Speed;

	LOG_INF("send to can:go forward:distance=%dmm, speed=%dmm/s, weight=%d\n", u16Distance, u16Speed / 10, u8Weight);
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v1_go_backward
* Description	     : set go backward command to mc
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Distance : distance(unit:0.1 degree)
* input			     : u16Speed : speed(unit:millimeter/second)
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int mc_v1_go_backward(u8 u8Weight, u16 u16Distance, u16 u16Speed)
{
	int iRet = 0;

	//nothing to do

	return iRet;
}

/*******************************************************************************
* Function Name		 : mc_v1_turn_left
* Description	     : set turn left command to mc
* input			     : u8Sync : 1 if u8Sync,0 on async
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Distance : distance(unit:0.1 degree)
* input			     : u16Speed : speed(unit:millimeter/second)
* Output		     : NONE
* Return		     : 0 if OK ,-1 on error
*******************************************************************************/
int mc_v1_turn_left(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	struct can_frame stCanFrame = {0};
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(MC_SEQ_ID));
	stCanFrame.data[6] = MC_OPERATE; //cmd
	stCanFrame.data[5] = MC_TURN_LEFT;
	stCanFrame.data[4] = u8Weight | (u8Sync << 4);
	*((u16 *)(&stCanFrame.data[2])) = u16Angle;
	*((u16 *)(&stCanFrame.data[0])) = u16Speed;

	LOG_INF("send to can:turn left:%s, angle=%d, weight=%d\n",
		(u8Sync == 1 ? "sync" : "async"), u16Angle, u8Weight);
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v1_turn_right
* Description	     : set turn right command to mc
* input			     : u8Sync : 1 if u8Sync,0 on async
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Distance : distance(unit:0.1 degree)
* input			     : u16Speed : speed(unit:millimeter/second)
* Output		     : NONE
* Return		     : 0 if OK ,-1 on error
*******************************************************************************/
int mc_v1_turn_right(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2MC_CMD_CANID;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(MC_SEQ_ID));
	stCanFrame.data[6] = MC_OPERATE;  //cmd
	stCanFrame.data[5] = MC_TURN_RIGHT;
	stCanFrame.data[4] = u8Weight | (u8Sync << 4);
	*((u16 *)(&stCanFrame.data[2])) = u16Angle;
	*((u16 *)(&stCanFrame.data[0])) = u16Speed;

	LOG_INF("send to can:turn right:%s, angle=%d, weight=%d\n",
		(u8Sync == 1 ? "sync" : "async"), u16Angle, u8Weight);
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
///add ,by tiger.10

/*******************************************************************************
*Function Name    :mc_v1_slow_go_back
*Description      :  
*Input       	  :u16 u16SRemain  
*Input       	  :u16 u16QRDistance  
*Output 		  :
*Return           :int: 0 if OK, -1 on error  
*******************************************************************************/
int mc_v1_slow_go_back(u16 u16SRemain, u16 u16QRDistance)
{
	int iCount = 0;
	struct can_frame stCanFrame = {
		.can_id = ARM2MC_CMD_CANID,
		.can_dlc = MC_DATA_DLC,
		.data[7] = (u8)(get_seq(MC_SEQ_ID)),
		.data[6] = MC_OPERATE,
		.data[5] = MC_SLOW_GO_BACK,
		.data[4] = REVERSE_VALUE,
	};

	*((u16 *)&stCanFrame.data[0]) = u16QRDistance;
	*((u16 *)&stCanFrame.data[2]) = u16SRemain;

	LOG_INF("send to can:slow go back:distance=%d mm, qr'distance=%d mm\n", u16SRemain, u16QRDistance);
	print_can_frame(&stCanFrame);	

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :mc_v1_slow_go_straight
*Description      :  
*Input       	  :u16 u16SRemain  
*Input       	  :u16 u16QRDistance  
*Output 		  :
*Return           :int : 0 if OK, -1 on error   
*******************************************************************************/
int mc_v1_slow_go_straight(u16 u16SRemain, u16 u16QRDistance)
{
	int iCount = 0;
	struct can_frame stCanFrame = {
		.can_id = ARM2MC_CMD_CANID,
		.can_dlc = MC_DATA_DLC,
		.data[7] = (u8)(get_seq(MC_SEQ_ID)),
		.data[6] = MC_OPERATE,
		.data[5] = MC_SLOW_GO_STRAIGHT,
		.data[4] = REVERSE_VALUE
	};

	*((u16 *)&stCanFrame.data[0]) = u16QRDistance;
	*((u16 *)&stCanFrame.data[2]) = u16SRemain;

	LOG_INF("send to can:slow go straight:distance=%dmm, qr'distance=%dmm\n", u16SRemain, u16QRDistance);
	print_can_frame(&stCanFrame);	

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :mc_v1_leftarc
*Description      :  
*Input       	  :u16 u16Weight  
*Output 		  :
*Return           :int: 0 if OK, -1 on error    
*******************************************************************************/
int mc_v1_leftarc(u16 u16Weight)
{
	int iCount = 0;
	int iSync = (g_stAgvAttr.iPalletStatus == PALLET_STATUS_BOT) ? 0 : 1;  //1:sync turn  0:async turn
	struct can_frame stCanFrame = {
		.can_id = ARM2MC_CMD_CANID,
		.can_dlc = MC_DATA_DLC,
		.data[7] = (u8)(get_seq(MC_SEQ_ID)),
		.data[6] = MC_OPERATE,
		.data[5] = MC_LEFT_ARC,
		.data[4] = ((iSync << 4) | u16Weight),
		.data[3] = REVERSE_VALUE,
		.data[2] = REVERSE_VALUE,
		.data[1] = REVERSE_VALUE,
		.data[0] = REVERSE_VALUE,
	};

	LOG_INF("sent to can:mc %s turn left  arc, weight=%d\n", (iSync == 1) ? "sync" : "async", u16Weight);
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :mc_v1_rightarc
*Description      :  
*Input       	  :unsigned short u16Weight  
*Output 		  :
*Return           :int: 0 if OK, -1 on error    
*******************************************************************************/
int mc_v1_rightarc(unsigned short u16Weight)
{
	int iCount = 0;
	int iSync = (g_stAgvAttr.iPalletStatus == PALLET_STATUS_BOT) ? 0 : 1;  //1:sync turn  0:async turn
	struct can_frame stCanFrame = {
		.can_id = ARM2MC_CMD_CANID,
		.can_dlc = MC_DATA_DLC,
		.data[7] = (u8)(get_seq(MC_SEQ_ID)),
		.data[6] = MC_OPERATE,
		.data[5] = MC_RIGHT_ARC,
		.data[4] = ((iSync << 4) | u16Weight),
		.data[3] = REVERSE_VALUE,
		.data[2] = REVERSE_VALUE,
		.data[1] = REVERSE_VALUE,
		.data[0] = REVERSE_VALUE,
	};

	LOG_INF("sent to can:mc %s turn right arc, weight=%d\n", (iSync == 1) ? "sync" : "async", u16Weight);
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :mc_v1_clear_derail
*Description      :  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v1_clear_derail()
{
	int iRet = 0;
	iRet = set_flag(DEV_MC, VAR_OUT_TRACK, CLEAN_FLAG);
	return iRet;
}

/*******************************************************************************
*Function Name    :mc_v1_clear_navigation
*Description      :  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v1_clear_navigation()
{
	int iRet = 0;
	iRet = set_flag(DEV_MC, VAR_OUT_NAVIGATE, CLEAN_FLAG);
	return iRet;
}

/*******************************************************************************
*Function Name    :mc_v1_clear_lcoder_error
*Description      :  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v1_clear_lcoder_error()
{
	int iRet = 0;

	return 0;
}

/*******************************************************************************
*Function Name    :mc_v1_clear_rcoder_error
*Description      :  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v1_clear_rcoder_error()
{
	int iRet = 0;

	return 0;
}

/*******************************************************************************
*Function Name    :mc_v1_enter_debug_mode
*Description      :  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v1_enter_debug_mode()
{
	int iRet = 0;

	return 0;
}

/*******************************************************************************
*Function Name    :mc_v1_quit_debug_mode
*Description      :  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v1_quit_debug_mode()
{
	int iRet = 0;

	return 0;
}

/*******************************************************************************
*Function Name    :mc_v1_clasp_pallet
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :void  
*******************************************************************************/
int mc_v1_clasp_pallet(void)
{
	return set_flag(DEV_TC, VAR_PALLET_CLASP, 1);
}

/*******************************************************************************
*Function Name    :mc_v1_unclasp_pallet
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :void  
*******************************************************************************/
int mc_v1_unclasp_pallet(void)
{
	return set_flag(DEV_TC, VAR_PALLET_CLASP, 0);
}

/*******************************************************************************
*Function Name    :mc_v1_clasp_wheel
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :void  
*******************************************************************************/
int mc_v1_clasp_wheel(void)
{
	return set_flag(DEV_MC, VAR_WHEEL_CLASP, 1);//modify  by jxu 20180507 from DEV_TC->DEV_MC
}

/*******************************************************************************
*Function Name    :mc_v1_unclasp_wheel
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :void  
*******************************************************************************/
int mc_v1_unclasp_wheel(void)
{
	return set_flag(DEV_MC, VAR_WHEEL_CLASP, 0);//modify  by jxu 20180507 from DEV_TC->DEV_MC
}

/*******************************************************************************
*Function Name    :mc_v1_cntl_update_cmd
*Description      :send D500-10��D500-15 update cmd,by tiger.63
*Input       	  :bool bIsMC:1:operate with MC  0:operate with TC
*Input       	  :int iCmd: 0: not update ;1:need update  2:finished sending data
*Input       	  :size_t ulFrameCount: the number of data frames on iCmd = 1; 0 if iCmd != 1;
*Output 		  :NONE
*Return           :int: 0 if OK; -1 on error
*******************************************************************************/
int mc_v1_cntl_update_cmd(bool bIsMC, int iCmd, size_t ulFrameCount)
{
	const char *pDesc[] = { "not update", "need update", "finished sending data" };
	int iCount = 0;
	if (iCmd < 0 || ulFrameCount < 0)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}
	mc_update stCanFrame = {
		.can_dlc = 8,
		.can_id = FTP_TC_UPDATE_CAN_ID,
		.u8Sequence = (u8)(get_seq(TC_SEQ_ID)),
		.u8Style = 7,
		.u8Var = iCmd,
	};

	if (bIsMC)
	{
		stCanFrame.can_id = FTP_MC_UPDATE_CAN_ID;
		stCanFrame.u8Sequence = (u8)(get_seq(MC_SEQ_ID));
	}
	if (iCmd == DSP_UPDATE_CMD)
	{
		stCanFrame.u32Data = ulFrameCount;
	}
	else
	{
		stCanFrame.u32Data = 0;
	}
	LOG_INF("send %s frame to %s\n", pDesc[iCmd], (bIsMC == 1) ? "MC" : "TC");
	print_can_frame((struct can_frame*)&stCanFrame);
	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}

	return 0;
}
///end,by tiger.10
