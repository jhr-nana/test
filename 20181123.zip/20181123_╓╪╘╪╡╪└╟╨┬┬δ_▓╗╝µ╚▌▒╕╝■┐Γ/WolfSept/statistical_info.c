/********************************************************************************
* Copyright (c) 2018, Jd.Com, Inc .
* FileName: STATISTICAL.C
* Author: Menghu Wang   Version: V1.0   Data:2018-03-19
* Description:REALIZE THE INTERFACE OF STATISTICAL INFO
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include <net/if.h>
#include "statistical_info.h"
#include "device.h"
#include "netstat.h"
#include "debug.h"
/* Private typedef -----------------------------------------------------------*/
typedef enum 
{
	EVENT_INFO = 1001,
	BATTERY_INFO = 1002,
	NETWORK_INFO = 1003,
	ACTION_INFO = 1004,
	PGV_HEARTBEAT_INFO = 1005,
}enDataType;
typedef enum
{
	EVENT_INFO_COLUMN = 24,
	BATTERY_INFO_COLUMN = 10,
	NETWORK_INFO_COLUMN = 18,
	ACTION_INFO_COLUMN = 9,
	PGV_HEARTBEAT_INFO_COLUMN = 7,
}enColumnNum;
typedef enum
{
	EVENT_SEQ = 0,
	BATTERY_SEQ = 1,
	NETWORK_SEQ = 2,
	ACTION_SEQ = 3,
	PGV_HEARTBEAT_SEQ = 4,
}enSeqNum;
typedef enum
{
	EVENT_MAX_LINE_BYTES = 180,
	BATTERY_MAX_LINE_BYTES = 140,
	NETWORK_MAX_LINE_BYTES = 140,
	ACTION_MAX_LINE_BYTES = 140,
	PGV_HEARTBEAT_MAX_LINE_BYTES = 140,
}enMaxLineBytes;  //unit:bytes
#define PROTOCOL_VERSION	1
#define THEME_VERSION_1_0	1.0
#define PACKAGE_HEADER_SIZE 8
#define STAICAL_MAX_SEQ		999999
#define STATICAL_SEQ_NUM	5


/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
static pthread_mutex_t statical_seq_mutex = PTHREAD_MUTEX_INITIALIZER;

/*******************************************************************************
*Function Name    :get_seq
*Description      :get the  seq of each statistical info 
*Input       	  :enSeqNum enSeqIndex :the type of statistical info ,such as :EVENT_SEQ
*Return           :int:the value of seq  
*******************************************************************************/
static int get_statical_seq(enSeqNum enSeqIndex)
{
	static int32_t i32Seq[STATICAL_SEQ_NUM] = { 0 };
	int32_t i32Ret;

	if (enSeqIndex >= STATICAL_SEQ_NUM)
	{
		LOG_ERR("get wrong sequence id\n");
		return -1;
	}

	pthread_mutex_lock(&statical_seq_mutex);
	i32Ret = i32Seq[enSeqIndex];
	i32Seq[enSeqIndex] = (i32Seq[enSeqIndex] + 1) % STAICAL_MAX_SEQ;
	pthread_mutex_unlock(&statical_seq_mutex);
	return i32Ret;
}

/*******************************************************************************
*Function Name    :get_dataID
*Description      :get the value of DateID key   
*Input       	  :enSeqNum enSeq:seq type ,such as:EVENT_SEQ   
*Output       	  :char * pBuf:the buf to save the result ,such as:20180302100030000000  
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
static int get_dataID(enSeqNum enSeq,char *pDataID)
{
	time_t iTimer = 0;
	int iRet = 0;
	struct tm *pTime = NULL;
	char pStrTime[100];
	
	if (NULL == pDataID)
	{
		return -1;
	}
	if (enSeq >= STATICAL_SEQ_NUM)
	{
		LOG_ERR("get wrong sequence id\n");
		return -1;
	}
	int iSeq = get_statical_seq(enSeq);
	time(&iTimer);
	pTime = localtime(&iTimer);
	iRet = strftime(pStrTime, 100, "%Y%m%d%H%M%S", pTime);
	if (iRet < 0 )
	{
		LOG_ERR("get system time failed:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	iRet = sprintf(pDataID, "%s%06d", pStrTime, iSeq);
	if (iRet < 0)
	{
		LOG_ERR("get dataID failed:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :get_ip_sn
*Description      :get the agv sn and ip  
*Input       	  :int iSockfd  
*Output 		  :
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int get_ip_sn(int iSockfd) 
{
	int iRet = 0;
	struct ifreq stIfReq;
	stIfReq.ifr_addr.sa_family = AF_INET;
	char *pIP = NULL;
	strncpy(stIfReq.ifr_name, "wlan0", IFNAMSIZ - 1);
	iRet = ioctl(iSockfd, SIOCGIFHWADDR, &stIfReq);
	if (iRet <0)
	{
		LOG_ERR("get hardware address failed:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	sprintf(g_stAgvAttr.pSN,"%.2x%.2x%.2x%.2x%.2x%.2x",
		(unsigned char)stIfReq.ifr_hwaddr.sa_data[0],
		(unsigned char)stIfReq.ifr_hwaddr.sa_data[1],
		(unsigned char)stIfReq.ifr_hwaddr.sa_data[2],
		(unsigned char)stIfReq.ifr_hwaddr.sa_data[3],
		(unsigned char)stIfReq.ifr_hwaddr.sa_data[4],
		(unsigned char)stIfReq.ifr_hwaddr.sa_data[5]);
	iRet = ioctl(iSockfd, SIOCGIFADDR, &stIfReq);
	if (iRet < 0)
	{
		LOG_ERR("get PA address failed:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	pIP = inet_ntoa(((struct sockaddr_in*)&(stIfReq.ifr_addr))->sin_addr);
	strcpy(g_stAgvAttr.pIP, pIP);
	LOG_INF("the %d agv ip :%s\n", g_stAgvAttr.iAgvName, g_stAgvAttr.pIP);
	
	return 0;
}
/*******************************************************************************
*Function Name    :get_dataTime
*Description      : get the value of DateTime key 
*Output       	  :char * pBuf:the result of time ,such as:2018/3/5  17:40:49  
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
static int  get_dataTime(char *pDateTime)
{
	time_t iTimer = 0;
	struct tm *pTime = NULL;
	char pStrTime[100];
	int iRet = 0;
	time(&iTimer);
	pTime = localtime(&iTimer);
	iRet = strftime(pStrTime, 100, "%Y-%m-%d %H:%M:%S", pTime);
	if (iRet < 0)
	{
		LOG_ERR("get system time failed:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	strcpy(pDateTime, pStrTime);
	return 0;
}

/*******************************************************************************
*Function Name    :time_to_send
*Description      :  
*Input       	  :int i32TotalSize:the number of  byte int buffer   
*Input       	  :int iMaxLineSize:the max byte size of row  
*Input       	  :time_t iPreCalTimer:the previous time 
*Input       	  :int iTimeout:0 without timeout,>0 the timeout seconds  
*Output 		  :
*Return           :int:0 if need send ;-1 not send  
*******************************************************************************/
static int time_to_send(int i32TotalSize, int iMaxLineSize, time_t iPreCalTimer, int iTimeout)
{
	int iRet = 0;
	time_t iCurCaltimer = 0;

	iRet = (PACKAGE_MAX_SIZE - i32TotalSize) / iMaxLineSize;
	if (0 == iRet)
		return 0;

	time(&iCurCaltimer);
	if (SATISTICAL_SEND_NOW == iTimeout)
		return 0;
	else if (iCurCaltimer - iPreCalTimer >= iTimeout)
		return 0;

	return -1;
}

pthread_mutex_t sta_send_event_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t sta_send_action_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t sta_send_network_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t sta_send_battery_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t sta_send_pgv_heartbeat_lock = PTHREAD_MUTEX_INITIALIZER;
/*******************************************************************************
*Function Name    :send_event_info
*Description      :  
*Output 		  :
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int sta_send_event_info(int iSendPeriod)
{
	pthread_mutex_lock(&sta_send_event_lock);
	static statical_info_package_st s_stPackage = { 0 };
	int iRet = 0, iSize = 0;
	char pDateRecord[1000] = { 0 };
	static time_t s_iLastSendTimer = 0;
	static int s_iTotalSize = 0;
	static int s_iTotalRow = 0;

	event_info_st stEventInfo = { 
		.i16ThemeID = EVENT_INFO,
		.fThemeVersion = THEME_VERSION_1_0,
		.i32AGVNo = g_stAgvAttr.iAgvName,
	};

	if (false == g_stAgvConf.cSendStatistical)
	{
		pthread_mutex_unlock(&sta_send_event_lock);
		return 0;
	}

	update_net_stat();		
	if (0 == s_iLastSendTimer)
	{
		time(&s_iLastSendTimer); //refresh the value
	}

	iRet = get_dataID(EVENT_SEQ, stEventInfo.pDateID);
	if (iRet < 0)
	{
		LOG_ERR("get data id failed\n");
		pthread_mutex_unlock(&sta_send_event_lock);
		return -1;
	}

	iRet = get_current_time(stEventInfo.pDateTime, sizeof(stEventInfo.pDateTime));
	if (iRet < 0)
	{
		LOG_ERR("get data time failed\n");
		pthread_mutex_unlock(&sta_send_event_lock);
		return -1;
	}
	memcpy(stEventInfo.pSN, g_stAgvAttr.pSN, sizeof(stEventInfo.pSN));
	memcpy(stEventInfo.pShelfQR, g_stAgvAttr.cContainer, sizeof(stEventInfo.pShelfQR));
	stEventInfo.i32Location = g_stAgvAttr.iLocation;
	stEventInfo.i32VehHeadDirect = g_stAgvAttr.iVehHeadDirect;
	stEventInfo.i32PalletDirect = g_stAgvAttr.iPalletDirect;
	stEventInfo.i32MoveStatus = g_stAgvAttr.iMoveStatus;
	stEventInfo.i32Speed = g_stAgvAttr.iSpeed;
	stEventInfo.i32GXOffset = g_stAgvAttr.iGsDevOnline;
	stEventInfo.i32GYOffset = g_stAgvAttr.iGSDevFBOnline;
	stEventInfo.i32GAngleOffset = g_stAgvAttr.iGSAngleOnline;
	stEventInfo.i32TXOffset = g_stAgvAttr.iTXOffset;
	stEventInfo.i32TYOffset = g_stAgvAttr.iTYOffset;
	stEventInfo.i32TAngleOffset = g_stAgvAttr.iTAngleOffset;
	stEventInfo.i32Battery = g_stAgvAttr.bms.uSoc;
	stEventInfo.i32ErrorCode = atomic_read(&g_stAgvAttr.iException);//by tiger.67
	stEventInfo.i32PalletStatus = g_stAgvAttr.iPalletStatus;
	stEventInfo.cLinkQuality = (char)g_stNetInfo.iLinkQuality;
	stEventInfo.cSignalLevel = (char)g_stNetInfo.iSignalLevel;
	stEventInfo.cNoiseLevel = (char)g_stNetInfo.iNoiseLevel;
	iSize = sprintf(pDateRecord, "%d\t%01.1f\t%s\t%s\t%d\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%d\t%d\t%d\n",
		stEventInfo.i16ThemeID, stEventInfo.fThemeVersion, stEventInfo.pDateID, stEventInfo.pDateTime,stEventInfo.i32AGVNo, stEventInfo.pSN, stEventInfo.i32Location,
		stEventInfo.i32VehHeadDirect, stEventInfo.i32PalletDirect, stEventInfo.i32MoveStatus,stEventInfo.i32Speed, stEventInfo.i32GXOffset, stEventInfo.i32GYOffset,
		stEventInfo.i32GAngleOffset, stEventInfo.i32TXOffset, stEventInfo.i32TYOffset,stEventInfo.i32TAngleOffset, stEventInfo.i32Battery, stEventInfo.i32ErrorCode,
		stEventInfo.i32PalletStatus, stEventInfo.pShelfQR, stEventInfo.cLinkQuality,stEventInfo.cSignalLevel, stEventInfo.cNoiseLevel);

	if ((s_iTotalSize + iSize) >= PACKAGE_MAX_SIZE)
	{		
		goto out;
	}
	memcpy(s_stPackage.pDateBuf + s_iTotalSize, pDateRecord, iSize);
	s_iTotalRow++;
	s_iTotalSize += iSize;

	iRet = time_to_send(s_iTotalSize, EVENT_MAX_LINE_BYTES, s_iLastSendTimer, iSendPeriod);
	if (iRet < 0)
	{
		LOG_INF("have store the event statistical information,but not need to send to collector\n");
		pthread_mutex_unlock(&sta_send_event_lock);
		return 0;
	}

out:
	s_stPackage.st_header.i16DateType = htons(EVENT_INFO);
	s_stPackage.st_header.i16ColumnNum = htons(EVENT_INFO_COLUMN);
	s_stPackage.st_header.i16ProtoVer = htons(PROTOCOL_VERSION);
	s_stPackage.st_header.i16DataNum = htons(s_iTotalRow);

	LOG_DBG("DataType:%d ProtoVer:%d DataNum:%d ColumnNum:%2d Bytes:%4d\n",
		EVENT_INFO, PROTOCOL_VERSION, s_iTotalRow, EVENT_INFO_COLUMN,sizeof(package_header_st)+s_iTotalSize);
#if(DEBUG_AGV == 333)
	LOG_DBG("\n-----------------------------------\n%s\n", s_stPackage.pDateBuf);
#endif

	iRet = send_inf2collector(&s_stPackage, s_iTotalSize + PACKAGE_HEADER_SIZE);

	//reset the static value
	time(&s_iLastSendTimer); //refresh the value
	bzero(&s_stPackage, sizeof(statical_info_package_st));
	s_iTotalSize = 0;
	s_iTotalRow = 0;
	pthread_mutex_unlock(&sta_send_event_lock);

	return iRet;
}

int sta_send_battery_info(int iSendPeriod)
{
	pthread_mutex_lock(&sta_send_battery_lock);
	static statical_info_package_st s_stPackage = { 0 };
	int iRet = 0, iSize = 0;
	char pDateRecord[1000] = { 0 };
	static time_t s_iLastSendTimer = 0;
	static int s_iTotalSize = 0;
	static int s_iTotalRow = 0;

	battery_info_st stBatteryInfo = {
		.i16ThemeID = BATTERY_INFO,
		.fThemeVersion = THEME_VERSION_1_0,
		.i32AGVNo = g_stAgvAttr.iAgvName,
	};
	if (false == g_stAgvConf.cSendStatistical)
	{
		pthread_mutex_unlock(&sta_send_battery_lock);
		return 0;
	}
		
	if (0 == s_iLastSendTimer)
	{
		time(&s_iLastSendTimer); //refresh the value
	}

	iRet = get_dataID(BATTERY_SEQ, stBatteryInfo.pDateID);
	if (iRet < 0)
	{
		LOG_ERR("get data id failed\n");
		pthread_mutex_unlock(&sta_send_battery_lock);
		return -1;
	}
	iRet = get_current_time(stBatteryInfo.pDateTime, sizeof(stBatteryInfo.pDateTime));
	if (iRet < 0)
	{
		LOG_ERR("get data time failed\n");
		pthread_mutex_unlock(&sta_send_battery_lock);
		return -1;
	}
	memcpy(stBatteryInfo.pSN, g_stAgvAttr.pSN, sizeof(stBatteryInfo.pSN));
	stBatteryInfo.fTemperature = (float)g_stAgvAttr.bms.uTemp - TEMPER_BASE;
	stBatteryInfo.fVoltage = (float) g_stAgvAttr.bms.uVoltage;
	stBatteryInfo.fVoltage = stBatteryInfo.fVoltage / 10;
	stBatteryInfo.fCurrent = (float)g_stAgvAttr.bms.uCurrent;
	stBatteryInfo.fCurrent = stBatteryInfo.fCurrent / 10;
	stBatteryInfo.i32Battery = g_stAgvAttr.bms.uSoc;
	stBatteryInfo.i8State = g_stAgvAttr.bms.uState;
	iSize = sprintf(pDateRecord, "%d\t%01.1f\t%s\t%s\t%d\t%s\t%f\t%f\t%f\t%d\t%d\n",
		stBatteryInfo.i16ThemeID, stBatteryInfo.fThemeVersion, stBatteryInfo.pDateID,
		stBatteryInfo.pDateTime, stBatteryInfo.i32AGVNo, stBatteryInfo.pSN,stBatteryInfo.fTemperature,
		stBatteryInfo.fVoltage, stBatteryInfo.fCurrent, stBatteryInfo.i32Battery,
		stBatteryInfo.i8State);

	if ((s_iTotalSize + iSize) >= PACKAGE_MAX_SIZE)
	{
		goto out;
	}
	memcpy(s_stPackage.pDateBuf +s_iTotalSize, pDateRecord, iSize);
	s_iTotalRow++;
	s_iTotalSize += iSize;

	iRet = time_to_send(s_iTotalSize, BATTERY_MAX_LINE_BYTES, s_iLastSendTimer, iSendPeriod);
	if (iRet < 0)
	{
		LOG_INF("have store the battery statistical information,but not need to send to collector\n");
		pthread_mutex_unlock(&sta_send_battery_lock);
		return 0;
	}

out:
	s_stPackage.st_header.i16DateType = htons(BATTERY_INFO);
	s_stPackage.st_header.i16ColumnNum = htons(BATTERY_INFO_COLUMN);
	s_stPackage.st_header.i16ProtoVer = htons(PROTOCOL_VERSION);
	s_stPackage.st_header.i16DataNum = htons(s_iTotalRow);

	LOG_DBG("DataType:%d ProtoVer:%d DataNum:%d ColumnNum:%2d Bytes:%4d\n",
		BATTERY_INFO, PROTOCOL_VERSION, s_iTotalRow, BATTERY_INFO_COLUMN,sizeof(package_header_st)+s_iTotalSize);
#if(DEBUG_AGV == 333)
	LOG_DBG("\n-----------------------------------\n%s\n", s_stPackage.pDateBuf);
#endif

	iRet = send_inf2collector(&s_stPackage, s_iTotalSize + PACKAGE_HEADER_SIZE);

	//reset the static value
	time(&s_iLastSendTimer); //refresh the value
	bzero(&s_stPackage, sizeof(statical_info_package_st));
	s_iTotalSize = 0;
	s_iTotalRow = 0;
	pthread_mutex_unlock(&sta_send_battery_lock);
	return iRet;
}

/*******************************************************************************
*Function Name    :get_wlan0_info
*Description      :  
*Input       	  :network_info_st * pNetworkInfo  
*Output 		  :
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
static int get_wlan0_info(network_info_st *pNetworkInfo)
{
	char pBuf[1024] = { 0 };
	udp_rx_info_st stCurRx = { 0 };
	udp_tx_info_st stCurTx = { 0 };
	FILE *pFp = NULL;

	if ((pFp = popen("cat /proc/net/dev | grep 'wlan0'", "r")) == NULL)
	{
		LOG_ERR("execute cat /proc/net/dev failed:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	if (fgets(pBuf, sizeof(pBuf), pFp) == NULL)
	{
		LOG_ERR("get cmd output failed:[%d-%s]\n", errno, strerror(errno));
		pclose(pFp);
		return -1;
	}
	pclose(pFp);

	sscanf(pBuf, "%*s%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t\n",
		&stCurRx.i32Bytes, &stCurRx.i32Packets, &stCurRx.i32Errs, &stCurRx.i32Drop,
		&stCurRx.i32Fifo, &stCurRx.i32Frame, &stCurRx.i32Compressed, &stCurRx.i32Multicast,
		&stCurTx.i32Bytes, &stCurTx.i32Packets, &stCurTx.i32Errs, &stCurTx.i32Drop,
		&stCurTx.i32Fifo, &stCurTx.i32Colls, &stCurTx.i32Carrier, &stCurTx.i32Compressed);

	pNetworkInfo->i32RXDropPkts = stCurRx.i32Drop;
	pNetworkInfo->i32RXErrorPkts = stCurRx.i32Errs ;
	pNetworkInfo->i32RXOverRunsPkts = stCurRx.i32Fifo;
	pNetworkInfo->i32RXPkts = stCurRx.i32Packets;
	pNetworkInfo->i32TXDropPkts = stCurTx.i32Drop;
	pNetworkInfo->i32TXErrorPkts = stCurTx.i32Errs;
	pNetworkInfo->i32TXOverRunsPkts = stCurTx.i32Fifo;
	pNetworkInfo->i32TXPkts = stCurTx.i32Packets;



	return 0;
}


/*******************************************************************************
*Function Name    :sta_send_network_info
*Description      :  
*Output 		  :
*Return           :int  
*******************************************************************************/
int sta_send_network_info(int iSendPeriod)
{
	pthread_mutex_lock(&sta_send_network_lock);
	static statical_info_package_st s_stPackage = { 0 };
	int iRet = 0, iSize = 0;
	char pDateRecord[1024] = { 0 };
	static time_t s_iLastSendTimer = 0;
	static int s_iTotalSize = 0;
	static int s_iTotalRow = 0;

	network_info_st stNetworkInfo = {
		.i16ThemeID = NETWORK_INFO,
		.fThemeVersion = THEME_VERSION_1_0,
		.i32AGVNo = g_stAgvAttr.iAgvName,
	};
	if (false == g_stAgvConf.cSendStatistical)
	{
		pthread_mutex_unlock(&sta_send_network_lock);
		return 0;
	}
		
	update_net_stat();
	if (0 == s_iLastSendTimer)
	{
		time(&s_iLastSendTimer); //refresh the value
	}

	iRet = get_dataID(NETWORK_SEQ, stNetworkInfo.pDateID);
	if (iRet < 0)
	{
		LOG_ERR("get data id failed\n");
		pthread_mutex_unlock(&sta_send_network_lock);
		return -1;
	}
	iRet = get_current_time(stNetworkInfo.pDateTime, sizeof(stNetworkInfo.pDateTime));
	if (iRet < 0)
	{
		LOG_ERR("get data time failed\n");
		pthread_mutex_unlock(&sta_send_network_lock);
		return -1;
	}
	memcpy(stNetworkInfo.pSN, g_stAgvAttr.pSN, sizeof(stNetworkInfo.pSN));
	sprintf(stNetworkInfo.pSensitivity, "%d", g_stNetInfo.iSensitivity);
	sprintf(stNetworkInfo.pLinkQuality, "%d", g_stNetInfo.iLinkQuality);
	sprintf(stNetworkInfo.pSignalLevel, "%d", g_stNetInfo.iSignalLevel);
	sprintf(stNetworkInfo.pNoiseLevel, "%d", g_stNetInfo.iNoiseLevel);
	iRet = get_wlan0_info(&stNetworkInfo);
	if (iRet < 0)
	{
		pthread_mutex_unlock(&sta_send_network_lock);
		return -1;
	}

	iSize = sprintf(pDateRecord, "%d\t%01.1f\t%s\t%s\t%d\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
		stNetworkInfo.i16ThemeID, stNetworkInfo.fThemeVersion, stNetworkInfo.pDateID,
		stNetworkInfo.pDateTime, stNetworkInfo.i32AGVNo, stNetworkInfo.pSN,
		stNetworkInfo.pSensitivity, stNetworkInfo.pLinkQuality, stNetworkInfo.pSignalLevel,
		stNetworkInfo.pNoiseLevel, stNetworkInfo.i32RXPkts, stNetworkInfo.i32RXErrorPkts,
		stNetworkInfo.i32RXDropPkts, stNetworkInfo.i32RXOverRunsPkts, stNetworkInfo.i32TXPkts,
		stNetworkInfo.i32TXErrorPkts, stNetworkInfo.i32TXDropPkts, stNetworkInfo.i32TXOverRunsPkts);

	if ((s_iTotalSize + iSize) >= PACKAGE_MAX_SIZE)
	{
		goto out;
	}
	memcpy(s_stPackage.pDateBuf + s_iTotalSize, pDateRecord, iSize);
	s_iTotalRow++;
	s_iTotalSize += iSize;

	iRet = time_to_send(s_iTotalSize, NETWORK_MAX_LINE_BYTES, s_iLastSendTimer,iSendPeriod);
	if (iRet < 0)
	{
		LOG_INF("have store the network statistical information,but not need to send to collector\n");
		pthread_mutex_unlock(&sta_send_network_lock);
		return 0;
	}
out:
	s_stPackage.st_header.i16DateType = htons(NETWORK_INFO);
	s_stPackage.st_header.i16ColumnNum = htons(NETWORK_INFO_COLUMN);
	s_stPackage.st_header.i16ProtoVer = htons(PROTOCOL_VERSION);
	s_stPackage.st_header.i16DataNum = htons(s_iTotalRow);

	LOG_DBG("DataType:%d ProtoVer:%d DataNum:%d ColumnNum:%2d Bytes:%4d\n",
		NETWORK_INFO, PROTOCOL_VERSION,	s_iTotalRow, NETWORK_INFO_COLUMN,sizeof(package_header_st)+s_iTotalSize);
#if(DEBUG_AGV == 333)
	LOG_DBG("\n-----------------------------------\n%s\n", s_stPackage.pDateBuf);
#endif

	iRet = send_inf2collector(&s_stPackage, s_iTotalSize + PACKAGE_HEADER_SIZE);

	//reset the static value
	time(&s_iLastSendTimer); //refresh the value
	bzero(&s_stPackage, sizeof(statical_info_package_st));
	s_iTotalSize = 0;
	s_iTotalRow = 0;
	pthread_mutex_unlock(&sta_send_network_lock);
	return iRet;
}


/*******************************************************************************
*Function Name    :sta_send_action_info
*Description      :  
*Output 		  :
*Return           :int  
*******************************************************************************/
int sta_send_action_info(int iSendPeriod, char *pActionName)
{
	pthread_mutex_lock(&sta_send_action_lock);
	static statical_info_package_st s_stPackage = { 0 };
	int iRet = 0, iSize = 0;
	char pDateRecord[1024] = { 0 };
	static time_t s_iLastSendTimer = 0;
	static int s_iTotalSize = 0;
	static int s_iTotalRow = 0;

	action_info_st stActionInfo = {
		.i16ThemeID = ACTION_INFO,
		.fThemeVersion = THEME_VERSION_1_0,
		.i32AGVNo = g_stAgvAttr.iAgvName,
	};
	if (false == g_stAgvConf.cSendStatistical)
	{
		pthread_mutex_unlock(&sta_send_action_lock);
		return 0;
	}
		
	if (0 == s_iLastSendTimer)
	{
		time(&s_iLastSendTimer); //refresh the value
	}

	iRet = get_dataID(NETWORK_SEQ, stActionInfo.pDateID);
	if (iRet < 0)
	{
		LOG_ERR("get data id failed\n");
		pthread_mutex_unlock(&sta_send_action_lock);
		return -1;
	}
	memcpy(stActionInfo.pSN, g_stAgvAttr.pSN, sizeof(stActionInfo.pSN));
	strncpy(stActionInfo.pStartDateTime, g_stAgvTask.pStartTime, sizeof(stActionInfo.pStartDateTime) - 1);
	strncpy(stActionInfo.pEndDateTime, g_stAgvTask.pEndTime, sizeof(stActionInfo.pEndDateTime) - 1);
	stActionInfo.i32Action = g_stAgvTask.stAction.iType;
	sprintf(stActionInfo.pActionName, "%s", pActionName);
	
	iSize = sprintf(pDateRecord, "%d\t%01f\t%s\t%d\t%s\t%s\t%s\t%d\t%s\n",
		stActionInfo.i16ThemeID, stActionInfo.fThemeVersion, stActionInfo.pDateID,
		stActionInfo.i32AGVNo, stActionInfo.pSN, stActionInfo.pStartDateTime, 
		stActionInfo.pEndDateTime, stActionInfo.i32Action,stActionInfo.pActionName);

	if ((s_iTotalSize + iSize) >= PACKAGE_MAX_SIZE)
	{
		goto out;
	}
	memcpy(s_stPackage.pDateBuf + s_iTotalSize, pDateRecord, iSize);
	s_iTotalRow++;
	s_iTotalSize += iSize;

	iRet = time_to_send(s_iTotalSize, ACTION_MAX_LINE_BYTES, s_iLastSendTimer, iSendPeriod);
	if (iRet < 0)
	{
		LOG_INF("have store the action statistical information,but not need to send to collector\n");
		pthread_mutex_unlock(&sta_send_action_lock);
		return 0;
	}
out:
	s_stPackage.st_header.i16DateType = htons(ACTION_INFO);
	s_stPackage.st_header.i16ColumnNum = htons(ACTION_INFO_COLUMN);
	s_stPackage.st_header.i16ProtoVer = htons(PROTOCOL_VERSION);
	s_stPackage.st_header.i16DataNum = htons(s_iTotalRow);

	LOG_DBG("DataType:%d ProtoVer:%d DataNum:%d ColumnNum:%2d Bytes:%4d\n",
		ACTION_INFO, PROTOCOL_VERSION, s_iTotalRow, ACTION_INFO_COLUMN,sizeof(package_header_st)+s_iTotalSize);
#if(DEBUG_AGV == 333)
	LOG_DBG("\n-----------------------------------\n%s\n", s_stPackage.pDateBuf);
#endif

	iRet = send_inf2collector(&s_stPackage, s_iTotalSize + PACKAGE_HEADER_SIZE);

	//reset the static value
	time(&s_iLastSendTimer); //refresh the value
	bzero(&s_stPackage, sizeof(statical_info_package_st));
	s_iTotalSize = 0;
	s_iTotalRow = 0;
	pthread_mutex_unlock(&sta_send_action_lock);
	return iRet;
}

int sta_send_pgv_heartbeat_info(int iSendPeriod)
{
	pthread_mutex_lock(&sta_send_pgv_heartbeat_lock);
	static statical_info_package_st s_stPackage = { 0 };
	int iRet = 0, iSize = 0;
	char pDateRecord[1024] = { 0 };
	static time_t s_iLastSendTimer = 0;
	static int s_iTotalSize = 0;
	static int s_iTotalRow = 0;

	pgv_heartbeat_st stPgvHeartbeatInfo = {
		.i16ThemeID = PGV_HEARTBEAT_INFO,
		.fThemeVersion = THEME_VERSION_1_0,
		.i32AGVNo = g_stAgvAttr.iAgvName,
	};

	if (false == g_stAgvConf.cSendStatistical)
	{
		pthread_mutex_unlock(&sta_send_pgv_heartbeat_lock);
		return 0;
	}
		
	if (0 == s_iLastSendTimer)
	{
		time(&s_iLastSendTimer); //refresh the value
	}

	iRet = get_dataID(PGV_HEARTBEAT_SEQ, stPgvHeartbeatInfo.pDateID);
	if (iRet < 0)
	{
		LOG_ERR("get data id failed\n");
		pthread_mutex_unlock(&sta_send_pgv_heartbeat_lock);
		return -1;
	}
	
	iRet = get_current_time(stPgvHeartbeatInfo.pDateTime, sizeof(stPgvHeartbeatInfo.pDateTime));
	if (iRet < 0)
	{
		LOG_ERR("get data time failed\n");
		pthread_mutex_unlock(&sta_send_pgv_heartbeat_lock);
		return -1;
	}
	memcpy(stPgvHeartbeatInfo.pSN, g_stAgvAttr.pSN, sizeof(stPgvHeartbeatInfo.pSN));
	stPgvHeartbeatInfo.i8State = g_stAgvAttr.i8PgvState;

	iSize = sprintf(pDateRecord, "%d\t%01.1f\t%s\t%s\t%d\t%s\t0x%02x\n",
		stPgvHeartbeatInfo.i16ThemeID, stPgvHeartbeatInfo.fThemeVersion, stPgvHeartbeatInfo.pDateID,
		stPgvHeartbeatInfo.pDateTime, stPgvHeartbeatInfo.i32AGVNo, stPgvHeartbeatInfo.pSN, stPgvHeartbeatInfo.i8State);

	if ((s_iTotalSize + iSize) >= PACKAGE_MAX_SIZE)
	{
		goto out;
	}
	memcpy(s_stPackage.pDateBuf + s_iTotalSize, pDateRecord, iSize);
	s_iTotalRow++;
	s_iTotalSize += iSize;

	iRet = time_to_send(s_iTotalSize, PGV_HEARTBEAT_MAX_LINE_BYTES, s_iLastSendTimer,iSendPeriod);
	if (iRet < 0)
	{
		LOG_INF("have store the action statistical information,but not need to send to collector\n");
		pthread_mutex_unlock(&sta_send_pgv_heartbeat_lock);
		return 0;
	}
out:
	s_stPackage.st_header.i16DateType = htons(PGV_HEARTBEAT_INFO);
	s_stPackage.st_header.i16ColumnNum = htons(PGV_HEARTBEAT_INFO_COLUMN);
	s_stPackage.st_header.i16ProtoVer = htons(PROTOCOL_VERSION);
	s_stPackage.st_header.i16DataNum = htons(s_iTotalRow);

	LOG_DBG("DataType:%d ProtoVer:%d DataNum:%d ColumnNum:%2d Bytes:%4d\n",
		PGV_HEARTBEAT_INFO, PROTOCOL_VERSION, s_iTotalRow, PGV_HEARTBEAT_INFO_COLUMN,sizeof(package_header_st)+s_iTotalSize);
#if(DEBUG_AGV == 333)
	LOG_DBG("\n-----------------------------------\n%s\n", s_stPackage.pDateBuf);
#endif

	iRet = send_inf2collector(&s_stPackage, s_iTotalSize + PACKAGE_HEADER_SIZE);

	//reset the static value
	time(&s_iLastSendTimer); //refresh the value
	bzero(&s_stPackage, sizeof(statical_info_package_st));
	s_iTotalSize = 0;
	s_iTotalRow = 0;
	pthread_mutex_unlock(&sta_send_pgv_heartbeat_lock);
	return iRet;
}
/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/

