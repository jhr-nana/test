#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <pthread.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#include "debug.h"


#define LOG_FILE			"/var/log/jdagv.log"
#define MCU_LOG_FILE		"/var/log/McuLog.log"
#define CMD_LOG_FILE		"/var/log/CMDLog.log"
#define LRFINISH_LOG_FILE	"/var/log/LRfinishLog.log"
#define MCHEARBEAT_LOG_FILE	"/var/log/MCheartbeat.log"
#define PGV_LOG_FILE	    "/var/log/PGVheartbeat.log"
#define EVNET_LOG_FILE	    "/var/log/jdagv_event.log"
#define ACTION_LOG_FILE     "/var/log/jdagv_action.log"
#define SHELFDIFF_LOG_FILE	"/var/log/Shelfdiff.log"
#define PGVJITTER_LOG_FILE	"/var/log/PGVJitter.log"
#define NET_LOG_FILE		"/var/log/wifi_monitor.log"
#define BATTERY_LOG_FILE		"/var/log/battery_monitor.log" //by tiger.86

#define LOG_BUFF_SIZE		512

const char cLogFileName[][MAX_LOG_FILE_NAME_SIZE] =
{
	LOG_FILE,			     // 0
	MCU_LOG_FILE,			 // 1
	CMD_LOG_FILE,			 // 2
	LRFINISH_LOG_FILE,		 // 3
	MCHEARBEAT_LOG_FILE,	 // 4
	PGV_LOG_FILE,			 // 5
	EVNET_LOG_FILE,			 // 6
	ACTION_LOG_FILE,		 // 7
	SHELFDIFF_LOG_FILE,		 // 8  //add by jxu 20180222
	PGVJITTER_LOG_FILE,		 // 9  //add by jxu 20180313
	NET_LOG_FILE,			 // 10 wifi_monitor
	BATTERY_LOG_FILE,			 // 11 battery_monitor.log
};

const char *log_level[] = {
	"INF", "DGB", "WRN", "ERR"
};

int swrite(int fd, char *logstr, int length)
{
	int off, writelen, n;

	off = 0;
	while (length > 0)
	{
		if (length >= 1024)
			writelen = 1024;
		else
			writelen = length;
		n = write(fd, logstr + off, writelen);
		if (n < 0)
		{
			printf("\n\rwrite error(%d)(%s)!", errno, strerror(errno));
			break;
		}
		off += n;
		length -= n;
	}
	return off;
}

int write_log(int type, char *msg)
{
	int fd = 0;
	int offset = 0;
	int off = -1;
	int flags = O_WRONLY | O_CREAT;
	
	if (type > (sizeof(cLogFileName) / MAX_LOG_FILE_NAME_SIZE) - 1) // beyond the max log file num 
	{
		return -1;
	}
	else
	{
		fd = open(cLogFileName[type], flags, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
	}

	if (fd < 0)
	{
		return -1;
	}

	offset = lseek(fd, 0, SEEK_END);
	if (offset < 0)
	{
		goto out;
	}

	if (offset > (MAX_LOG_FILE_SIZE * 1024 * 1024))
	{
		char newLogFileName[MAX_LOG_FILE_NAME_SIZE] = { 0 };

		printf("log file[%s]'size is larger than %d MB, will be closed and writen into a new log\n", 
			cLogFileName[type], MAX_LOG_FILE_SIZE);
		
		close(fd);
		sprintf(newLogFileName, "%s.old", cLogFileName[type]);
		rename(cLogFileName[type], newLogFileName);

		fd = open(cLogFileName[type], flags | O_TRUNC, 0777);

		if (fd < 0)
		{
			return -1;
		}
	}

	off = swrite(fd, msg, strlen(msg));

out:
	close(fd);
	return off;

}

#define FILE_MAX_LEN	10
#define FUNC_MAX_LEN	16

pthread_mutex_t logMutex = PTHREAD_MUTEX_INITIALIZER;

/*******************************************************************************
* Function Name		 : __log
* Description	     : basic log function
* Input 		     : level:log level, such as:PRINT_LEVEL_INF��PRINT_LEVEL_MCU��...
* Input 		     : format:
* Input 		     : ...
* Output		     : NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int __basic_0_log(int type, char *format, ...)
{
	char buffer[LOG_BUFF_SIZE] = { 0 };
	va_list parguments;
	int length = 0;

	pthread_mutex_lock(&logMutex);
	memset(buffer, 0, sizeof(buffer));

	va_start(parguments, format);
	length = vsnprintf(buffer, sizeof(buffer)-1, format, parguments);
	va_end(parguments);

	write_log(type, buffer);
	pthread_mutex_unlock(&logMutex);

	fflush(stdout);

	return length;
}

/*******************************************************************************
* Function Name		 : __basic_1_log
* Description	     : mcu log function
* Input 		     : level:log level, such as:PRINT_LEVEL_INF��PRINT_LEVEL_MCU��...
* Input 		     : file: file name
* Input 		     : line: line number
* Input 		     : func: fuction name
* Input 		     : format:
* Input 		     : ...
* Output		     : NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int __basic_1_log(int type, char *format, ...)
{
	char buffer[LOG_BUFF_SIZE] = {0};
	char msg[LOG_BUFF_SIZE] = {0};
	va_list parguments;
	int length = 0;
	int year = 0, month = 0, day = 0;
	int hour = 0, min = 0, sec = 0, ms = 0;
	struct timeval  tv;
	struct timezone tz;
	struct tm *tm1, tm2;

	pthread_mutex_lock(&logMutex);
	gettimeofday(&tv, &tz);
	tm1 = localtime_r((time_t*)&tv.tv_sec, &tm2);

	ms = tv.tv_usec / 1000;
	sec = tm1->tm_sec;
	min = tm1->tm_min;
	hour = tm1->tm_hour;
	day = tm1->tm_mday;
	month = tm1->tm_mon + 1;
	year = tm1->tm_year + 1900;

	memset(buffer, 0, sizeof(buffer));
	memset(msg, 0, sizeof(msg));

	va_start(parguments, format);
	length = vsnprintf(buffer, sizeof(buffer)-1, format, parguments);
	va_end(parguments);

	// %-10s must be same with define[FILE_MAX_LEN	10]
	// %-16s must be same with define[FUNC_MAX_LEN	16]
	snprintf(msg, sizeof(msg)-1, "%04d-%02d-%02d %02d:%02d:%02d.%03d\t%s",
		year, month, day, hour, min, sec, ms, buffer);

	write_log(type, msg);
	pthread_mutex_unlock(&logMutex);

	fflush(stdout);

	return length;
}

/*******************************************************************************
* Function Name		 : __basic_log
* Description	     : basic log function
* Input 		     : level:log level, such as:PRINT_LEVEL_INF��PRINT_LEVEL_MCU��...
* Input 		     : file: file name
* Input 		     : line: line number
* Input 		     : func: fuction name
* Input 		     : format:
* Input 		     : ...
* Output		     : NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int __basic_log(int type, int level, char *file, int line, char *func, char *format, ...)
{
	char fileTmpBuff[FILE_MAX_LEN + 1] = { 0 };
	char funcTmpBuff[FUNC_MAX_LEN + 1] = { 0 };
	char buffer[LOG_BUFF_SIZE] = {0};
	char msg[LOG_BUFF_SIZE] = {0};
	va_list parguments;
	int length = 0;
	int year = 0, month = 0, day = 0;
	int hour = 0, min = 0, sec = 0, ms = 0;
	struct timeval  tv;
	struct timezone tz;
	struct tm *tm1, tm2;

	if ((level < INF) || (level > ERR)) {
		return -1;
	}

	pthread_mutex_lock(&logMutex);
	gettimeofday(&tv, &tz);
	tm1 = localtime_r((time_t*)&tv.tv_sec, &tm2);

	ms = tv.tv_usec / 1000;
	sec = tm1->tm_sec;
	min = tm1->tm_min;
	hour = tm1->tm_hour;
	day = tm1->tm_mday;
	month = tm1->tm_mon + 1;
	year = tm1->tm_year + 1900;

	memset(buffer, 0, sizeof(buffer));
	memset(msg, 0, sizeof(msg));

	va_start(parguments, format);
	length = vsnprintf(buffer, sizeof(buffer)-1, format, parguments);
	va_end(parguments);

	// trunc filename, such as:circle_queue.c-->circle_qu.
	int file_name_len = strlen(file);
	if (file_name_len > FILE_MAX_LEN) {
		memset(fileTmpBuff, '.', sizeof(fileTmpBuff));
		strncpy(fileTmpBuff, file, FILE_MAX_LEN-1);
	} else {
		memset(fileTmpBuff, '\0', sizeof(fileTmpBuff));
		strncpy(fileTmpBuff, file, file_name_len);
	}
	fileTmpBuff[FILE_MAX_LEN] = '\0';

	// trunc funcname, such as:thread_bms_monitor-->thread_bms_moni.
	int func_name_len = strlen(func);
	if (func_name_len > FUNC_MAX_LEN) {
		memset(funcTmpBuff, '.', sizeof(funcTmpBuff));
		strncpy(funcTmpBuff, func, FUNC_MAX_LEN - 1);
	}
	else {
		memset(funcTmpBuff, '\0', sizeof(funcTmpBuff));
		strncpy(funcTmpBuff, func, func_name_len);
	}
	funcTmpBuff[FUNC_MAX_LEN] = '\0';

	// %-10s must be same with define[FILE_MAX_LEN	10]
	// %-16s must be same with define[FUNC_MAX_LEN	16]
	snprintf(msg, sizeof(msg)-1, "[%04d-%02d-%02d %02d:%02d:%02d.%03d %3s %-10s %-4d %-16s] %s",
		year, month, day, hour, min, sec, ms, log_level[level], fileTmpBuff, line, funcTmpBuff, buffer);

	write_log(type, msg);
	pthread_mutex_unlock(&logMutex);

	fflush(stdout);

	return length;
}

/*******************************************************************************
* Function Name		 : __my_printf
* Description	     : basic printf function
* Input 		     : level:log level, such as:PRINT_LEVEL_INF��PRINT_LEVEL_MCU��...
* Input 		     : file: file name
* Input 		     : line: line number
* Input 		     : func: function name
* Input 		     : format:
* Input 		     : ...
* Output		     : NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int __my_printf(int level, char *file, int line, char *func, char *format, ...)
{

	pthread_mutex_lock(&logMutex);
	char buffer[512];
	char msg[512];
	va_list parguments;
	int length;
	int year, month, day, hour, min, sec, ms;
	struct timeval  tv;
	struct timezone tz;
	struct tm *tm1, tm2;

	gettimeofday(&tv, &tz);
	tm1 = localtime_r((time_t*)&tv.tv_sec, &tm2);

	ms = tv.tv_usec / 1000;
	sec = tm1->tm_sec;
	min = tm1->tm_min;
	hour = tm1->tm_hour;
	day = tm1->tm_mday;
	month = tm1->tm_mon + 1;
	year = tm1->tm_year + 1900;

	memset(buffer, 0, sizeof(buffer));
	memset(msg, 0, sizeof(msg));

	va_start(parguments, format);
	length = vsnprintf(buffer, sizeof(buffer)-1, format, parguments);
	va_end(parguments);

	snprintf(msg, sizeof(msg)-1, "[%04d-%02d-%02d %02d:%02d:%02d.%03d %s %d %s] %s",
		year, month, day, hour, min, sec, ms, file, line, func, buffer);

	write_log(level, msg);
	pthread_mutex_unlock(&logMutex);

	fflush(stdout);

	return length;
}
