#ifndef PROCESSING_H
#define PROCESSING_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

extern int IMG_WIDTH;  // image width
extern int IMG_HEIGHT; // image height

/// 车头方向为X正向，建立右手系
extern float CAMERA_POS_X;
extern float CAMERA_POS_Y;
/// 安装偏差角度，范围[-pi,pi]
extern float CAMERA_POS_THETA;

/// =0, 0 degree
/// =1, 90 degree
/// =2, 180 degree
/// =3, 270 degree
extern int CAMERA_ANGLE; // 镜头的安装方向

extern uint8_t *grayImageData;     // gray image got from camera

extern const char* FuncVersionInfo(void);
extern void FuncMemoryAlloc(void);
extern void FuncDataInit(void);
extern bool FuncProcessing(void);
extern int  FuncGetResult(float* deltaX, float* deltaY, float* angle, uint64_t* tag, uint8_t* ringsNum);
extern void FuncMemoryDestroy(void);

#ifdef __cplusplus
}
#endif

#endif // PROCESSING_H
