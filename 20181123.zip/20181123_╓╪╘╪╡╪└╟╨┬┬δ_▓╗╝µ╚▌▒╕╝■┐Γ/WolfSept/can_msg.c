#include "can_msg.h"
#include "device.h"
#include "mc_v2.h"
#include "statistical_info.h"
#define PGV_CAN_TxTEST_CANID       (0x608)// by tiger.39

///start add by tiger.39

/*******************************************************************************
* Function Name      : start_pgv_heartbeart_req
* Description	     : send pgv heartbeart req
* Input 		     : iMS ：iMS(unit ms) 
* Output		     : NONE
* Return		     : 0 if OK; -1 on error 
*******************************************************************************/
static int start_pgv_heartbeart_req(int iMS)
{
	int iRet = -1;
	if (iMS <= 0)
	{
		LOG_ERR("input parameter value %d < 0 ",iMS);
		return -1;
	}
	struct can_frame stCanFrame =
	{
		.can_id = PGV_CAN_TxTEST_CANID,
		.can_dlc = 8,
		.data[0] = 0x2B,
		.data[1] = 0x17,
		.data[2] = 0x10,
		.data[3] = 0x00,
		.data[4] = iMS,  // T = 100ms
		.data[5] = 0x00,
		.data[6] = 0x00,
		.data[7] = 0x00,
	};

	LOG_INF("set the pgv start heartbeat and the cycle time: %dms\n",iMS);
	iRet = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iRet != sizeof(struct can_frame))
	{
		LOG_ERR("send start pgv heartbeart request\n");
	}

	return iRet;
}

/*******************************************************************************
* Function Name      : send_pgv_req
* Description	     : send pgv req
* Input 		     : u8Data: PGV_OFF or PGV_ON
* Output		     : NONE
* Return		     : 0 if OK; -1 on error 
*******************************************************************************/
int send_pgv_req(uint8_t u8Data)
{
	int iCount = -1;
	struct can_frame stCanFrame =
	{
		.can_id = PGV_CANID_START,
		.can_dlc = 2,
		.data[0] = u8Data,
		.data[1] = 0x08,
	};

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		LOG_ERR("send %s pgv req error\n", u8Data == PGV_OFF ? "close" : "start");
		return -1;
	}

	LOG_INF("send %s pgv req ok\n", u8Data == PGV_OFF ? "close" : "start");
	return 0;
}
/*******************************************************************************
*Function Name    :pgv_set_periodic_mode
*Description      :pgv_set_periodic_mode ,by tiger.95
*Input       	  :int iMS: should be more than 20 ms
*Output 		  :NONE
*Return           :int: 0 if OK, -1 on error
*******************************************************************************/
static int pgv_set_periodic_mode(int iMS)
{
	int iRet = -1;
	if (iMS < 20)
	{
		LOG_ERR("input parameter value %d < 20 ", iMS);
		return -1;
	}
	struct can_frame stSetModeCanFrame =
	{
		.can_id = PGV_CAN_TxTEST_CANID,
		.can_dlc = 8,
		.data[7] = 0,
		.data[6] = 0,
		.data[5] = 0,
		.data[4] = 0xff, //periodic mode
		.data[3] = 0x02,
		.data[2] = 0x18,
		.data[1] = 0x02,
		.data[0] = 0x2f,
	};
	struct can_frame stSetPeriodCanFrame =
	{
		.can_id = PGV_CAN_TxTEST_CANID,
		.can_dlc = 8,
		.data[7] = 0,
		.data[6] = 0,
		.data[5] = iMS >> 8,
		.data[4] = iMS % 256,
		.data[3] = 0x05,
		.data[2] = 0x18,
		.data[1] = 0x02,
		.data[0] = 0x2b,
	};

	iRet = send_can(CTRL_CAN_DEV, &stSetModeCanFrame);
	if (iRet != sizeof(struct can_frame))
	{
		LOG_ERR("set the pgv periodic mode failed\n");
		return -1;
	}
	LOG_INF("set the pgv periodic mode success\n");
	usleep(100000);
	iRet = send_can(CTRL_CAN_DEV, &stSetPeriodCanFrame);
	if (iRet != sizeof(struct can_frame))
	{
		LOG_ERR("failed,set the pgv period :%dms\n", iMS);
		return -1;
	}
	LOG_INF("set the pgv period:%dms success\n", iMS);
	usleep(100000);
	return 0;

}
/*******************************************************************************
* Function Name      : pgv_restart
* Description	     : pgv_off, pgv_on, start_pgv_heartbeart_req
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0 if OK; -1 on error
*******************************************************************************/
void pgv_restart()
{
	//set pgv periodic mode,start by tiger.95
	if (g_stAgvConf.cPgvPeriod == TRUE)
	{
		int iRet = 0;
		iRet = pgv_set_periodic_mode(20);
		if (iRet < 0)
			LOG_ERR("set pgv periodic mode failed\n");
		else
			LOG_INF("set pgv periodic mode success\n");
	}
	//end by tiger.95
	send_pgv_req(PGV_OFF);	//close PGV heart beart	
	usleep(100000);
	send_pgv_req(PGV_ON);	//start PGV heart beart	
	usleep(100000);
	start_pgv_heartbeart_req(100);  // start AGV heart beart
	usleep(100000);
}

/*******************************************************************************
* Function Name      : init_agv_location_head_direct
* Description	     : get the current location and head direct of agv
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0 if OK; -1 on error
*******************************************************************************/
#define PGV_RETRY_TIME_MAX	60000
int init_agv_location_head_direct()
{
	struct can_frame stCtrlCanData = { 0 };
	int iCurLocation = 0;
	int iVehHeadDirect = INVALID_DIRECTION;
	int iGXOffset = 0;
	int iGYOffset = 0; //by tiger.92
	int iGAngleOffset = 0;
	int iTryTime = PGV_RETRY_TIME_MAX;
	int iRet = 0;
	bool bHadGetY = false;//by tiger.92

	LOG_INF("init agv location head direct now\n");
	while (iTryTime)
	{
		if ((iTryTime--) % 10000 == 0)
			pgv_restart();

		iRet = recv_can(CTRL_CAN_DEV, &stCtrlCanData);
		if (iRet < 0) {
			//LOG_WRN("control can recv error[%s]\n", strerror(errno));
			usleep(10);
			continue;
		}

		// get iGXOffset, iGAngleOffset, iVehHeadDirect from PGV_CANID_TxPDO2
		if ((iVehHeadDirect == INVALID_DIRECTION) && (PGV_CANID_TxPDO2 == stCtrlCanData.can_id))
		{
			LOG_INF("get VehHeadDirect try time %d\n", (PGV_RETRY_TIME_MAX - iTryTime) / 10000);
			iGXOffset = ntohl(*(int32_t *)(&stCtrlCanData.data[0]));		 // TODO unit 0.1 mm
			iGAngleOffset = htons(*(int16_t *)(&stCtrlCanData.data[4]));	 // unit 0.1 degree

			//compute iVehHeadDirect instead of deal_mc_heart_beat
			if (((iGAngleOffset >= 0) && (iGAngleOffset <= 450)))
				iVehHeadDirect = DIRECTION_X_P;
			else if ((iGAngleOffset > 450) && (iGAngleOffset <= 1350))
				iVehHeadDirect = DIRECTION_Y_N;
			else if (((iGAngleOffset > 1350) && (iGAngleOffset <= 2250)))
				iVehHeadDirect = DIRECTION_X_N;
			else if ((iGAngleOffset > 2250) && (iGAngleOffset <= 3150))
				iVehHeadDirect = DIRECTION_Y_P;
			else if (iGAngleOffset > 3150)
				iVehHeadDirect = DIRECTION_X_P;
			else
				LOG_WRN("unsupported angle offset: iGAngleOffset = %d\n", iGAngleOffset);
		}

		//get iCurLocation
		if ((iCurLocation == INVALID_POINT) && (PGV_CANID_TxPDO3 == stCtrlCanData.can_id))
		{
			struct PGV_MSG_t *stPgvMsg = (struct PGV_MSG_t *)stCtrlCanData.data;
			LOG_INF("get CurLocation try time %d\n", (PGV_RETRY_TIME_MAX - iTryTime) / 10000);
			//pgv must use ntohs or ntohl convert can frame
			//u8 u16Status = ntohs(stPgvMsg->u16Status);
			iCurLocation = ntohl(stPgvMsg->u32Tag);

			//judge tag(location) is valid?
			//if ((u16Status & PGV_CC1_BIT) == 0)
			//{
			//	LOG_WRN("invalid groud QR[%d]\n", iCurLocation);
			//	iCurLocation = 0;
			//	continue;
			//}
		}
		if ((false == bHadGetY) && ((PGV_CANID_TxPDO1 == stCtrlCanData.can_id)))//by tiger.92,check offset Y
		{
			iGYOffset = ntohl(*(int32_t *)(&stCtrlCanData.data[0]));// TODO unit 0.1 mm	 
			bHadGetY = true;
		}
		if ((iVehHeadDirect != INVALID_DIRECTION) && (iCurLocation != INVALID_POINT) && (true == bHadGetY))//by tiger.92,check offset Y
		{
			bHadGetY = false;
			break;
		}
			
	}

	if (iTryTime <= 0)
	{
		LOG_WRN("init agv location head direct time out, use default\n");
	}

	LOG_INF("agv at location[%d], head direction[%d-%s] success\n", 
		iCurLocation, iVehHeadDirect, get_direct_desc(iVehHeadDirect));

	g_stAgvAttr.iVehHeadDirect = iVehHeadDirect;
	g_stAgvAttr.iLocation = iCurLocation;
	g_stAgvAttr.iGXOffset = iGXOffset;
	g_stAgvAttr.iGYOffset = iGYOffset; //by tiger.92
	g_stAgvAttr.iGAngleOffset = iGAngleOffset;

	return 0;
}

/*******************************************************************************
* Function Name      : parse_groudqr
* Description	     : parse ground QR.
* Input 		     : pframe :can frame pointer.
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
static int iPreHead = INVALID_DIRECTION;
static int iPreOffsetAngle = -1;
static int iPreLocation = 0;
int parse_groudqr(struct can_frame *pframe)
{
	uint16_t u16Status = 0;
	int iCurLocation = 0;
	int iTaskLocation = 0;
	bool bPathLocationError = FALSE;
	int iRet = 0;
	static int s_iCount = 0;//by tiger.95

	if (pframe == NULL)
		return -1;

	struct PGV_MSG_t *stPgvMsg = (struct PGV_MSG_t *)pframe->data;

	//pgv must use ntohs or ntohl convert can frame
	u16Status = ntohs(stPgvMsg->u16Status);
	iCurLocation = ntohl(stPgvMsg->u32Tag);

	//judge tag(location) is valid?
	if ((u16Status & PGV_CC1_BIT) == 0)
	{
		//LOG_WRN("invalid groud QR[%d]\n", iCurLocation);
		return -1;
	}
	// tag is valid, then judge iCurLocation is equal g_stAgvAttr.iLocation?
	if (iCurLocation == g_stAgvAttr.iLocation)
	{
		//LOG_WRN("the current groud QR[%d] is same as last\n", iCurLocation);
		s_iCount++;//by tiger.95		
		return -1;
	}
	LOG_INF("get %d Tag(0x388) can frame,when pass the [%lld] \n", s_iCount + 1, g_stAgvAttr.iLocation);//by tiger.95
	s_iCount = 0;//by tiger.95
	g_stAgvTask.bSliding = false;	//the location is not in the task queue ,add by tiger.28,tiger.96
			
	// not same with last point
	g_stAgvAttr.iLocation = iCurLocation;
	LOG_INF("AGV at location[%d] now\n", iCurLocation);

	
	
	//start ,add by tiger.51
	//iRet = sta_send_event_info(SATISTICAL_SEND_PERIOD_30S);
	iRet = sta_send_event_info(SATISTICAL_SEND_NOW);
	if (iRet < 0)
	{
		LOG_WRN("send statistical event info failed:[%d-%s]\n", errno, strerror(errno));
	}
	//end ,add by tiger.51

	// modified by kedong, 20180305
	// update the navgate data into mcu log, use function update_mcu_log.	
	update_mcu_log();

	
	if (FALSE == g_stAgvConf.cCheckPoint)
	{
		goto common_process;
	}

	//if need do path location check
	iRet = linkqueue_retrieve(g_stAgvParm.pPathQueue, &(iTaskLocation));
	if (iRet < 0)
	{
		g_stAgvTask.bSliding = true;//the agv sliding ,add by tiger.28
		LOG_WRN("task path linkqueue is empty\n"); //add  by tiger.27
		goto common_process;
	}

	//start by tiger.22
	if (iCurLocation == iTaskLocation)
	{
		LOG_INF("task'location[%d] is same with current'location[%d]\n", iTaskLocation, iCurLocation);
		
		//add by jxu 20180313:begin
		if ((iPreHead == INVALID_DIRECTION) && (iPreOffsetAngle == -1))
		{
			iPreHead = g_stAgvAttr.iVehHeadDirect;
			iPreOffsetAngle = g_stAgvAttr.iGAngleOffset;
			iPreLocation = g_stAgvAttr.iLocation;
		}
		else
		{
			int iCurHead = g_stAgvAttr.iVehHeadDirect;
			int iCurAngle = g_stAgvAttr.iGAngleOffset;
			if (iCurHead != iPreHead)
			{
				pgvjitter_printf("CurLocaction[%d] CurVHead[%d] CurGAngle[%4d] != PreLocaction[%d] PreVHead[%d] PreGAngle[%4d]， WARN!!!\n", 
					iCurLocation, iCurHead, iCurAngle, iPreLocation, iPreHead, iPreOffsetAngle);
			}
			else
			{
				pgvjitter_printf("CurLocaction[%d] CurVHead[%d] CurGAngle[%4d]  = PreLocaction[%d] PreVHead[%d] PreGAngle[%4d]\n",
					iCurLocation, iCurHead, iCurAngle, iPreLocation, iPreHead, iPreOffsetAngle);
			}
			iPreLocation = iCurLocation;
		}
		//add by jxu 20180313:end
		goto common_process;
	}

	LOG_INF("task'location[%d] is different with current'location[%d]\n", iTaskLocation, iCurLocation);
	int iAbs = abs(iTaskLocation - iCurLocation);
	if ((1 == iAbs) || (10000 == iAbs)) //the ground point is next to the pointid in task
	{
		LOG_INF("task'location[%d] is next to current'location[%d], report task'location[%d] first\n", 
			iTaskLocation, iCurLocation, iTaskLocation);
		send_point_msg(iTaskLocation, DRIVER_MODE_AUTO);

		if (linkqueue_retrieve(g_stAgvParm.pPathQueue, &(iTaskLocation)) < 0)
		{
			g_stAgvTask.bSliding = true;//the agv sliding ,add by tiger.28
			LOG_WRN("task path linkqueue is empty\n");
			goto common_process;
		}

		if (iTaskLocation != iCurLocation)
		{
			bPathLocationError = TRUE;
		}
	}
	else  //the ground point is not next to the pointid in task
	{
		bPathLocationError = TRUE;
	}

	if (bPathLocationError == TRUE)
	{
		LOG_WRN("task'location[%d] is different with current'location[%d], error\n",
			iTaskLocation, iCurLocation);
		//add by jxu 20180312:begin
		int iMainCtrlRemainPath = g_stAgvParm.pPathQueue->iLength;
		int iMainCtrlRemainDist = g_stAgvTask.iQRDistance * iMainCtrlRemainPath + 100;
		if (g_stAgvAttr.iSreamin > iMainCtrlRemainDist)
		{
			LOG_WRN("Move the vehicle in manual Mcu.g_stAgvAttr.iSreamin[%d]> iMainCtrlRemainDist[%d]=g_stAgvTask.iQRDistance[%d]*iMainCtrlRemainPath[%d]\n", 
				g_stAgvAttr.iSreamin, iMainCtrlRemainDist, g_stAgvTask.iQRDistance, iMainCtrlRemainPath);//add by jxu 20180719
			send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_MANUAL_MOVE_AGV);
		}
		else //add by tiger.62
		{
			send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_PROCESTOPINVALID);
		}
		//add by jxu 20180312:end
		
		
		iRet = agv_sem_post(SEM_MSG_TYPE, MSG_TYPE_STOP, STOP_AGV_SEM_SEQ);//stop agv
		if (iRet < -1)
		{
			LOG_ERR("post agent update cmd  signal error:[%s]\n", strerror(errno));
			return -1;
		}
				
		linkqueue_clear(g_stAgvParm.pPathQueue);
	}
	//check the direction of AGV and QR,start by tiger.
	if (true == g_stAgvAttr.bCheckGroundDir && g_stAgvTask.iTaskDir !=g_stAgvAttr.iVehHeadDirect) 
	{
		LOG_ERR("Error:the ground direction[%s] diffrent with task direction [%s]\n",
			get_direct_desc(g_stAgvAttr.iVehHeadDirect),get_direct_desc(g_stAgvTask.iTaskDir));
		iRet = agv_sem_post(SEM_MSG_TYPE, MSG_TYPE_STOP, STOP_AGV_SEM_SEQ);//stop agv
		if (iRet < -1)
		{
			LOG_ERR("post agent update cmd  signal error:[%s]\n", strerror(errno));
			return -1;
		}
		send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_GROUNDDIRECTERR);

		linkqueue_clear(g_stAgvParm.pPathQueue);
	}
common_process:
	//must do it after send_point_msg(iTaskLocation);
	if (g_stAgvParm.pPathQueue->iLength == 0)
	{
		iPreHead = INVALID_DIRECTION;
		iPreOffsetAngle = -1;
		iPreLocation = 0;
	}
	send_point_msg(iCurLocation, DRIVER_MODE_AUTO);	//by tiger

	return 0;
}


/*******************************************************************************
* Function Name      : parse_pgv_heartbeart
* Description	     : parse pgv heartbeart information
* Input 		     : u8Data: obtained data.
* Output		     : NONE
* Return		     : 0: success; -1:failure
*******************************************************************************/
int parse_pgv_heartbeart(uint8_t u8Data)
{
	static uint8_t u8PreData = 0xFF;
	static uint32_t u32StateCount = 0;
	int iRet = 0;

	g_stAgvAttr.i8PgvState = u8Data;

	if (u8PreData != u8Data)
	{
		//start ,add by tiger.51
		//iRet = sta_send_pgv_heartbeat_info(SATISTICAL_SEND_PERIOD_60S);
		iRet = sta_send_pgv_heartbeat_info(SATISTICAL_SEND_NOW);
		if (iRet < 0)
		{
			LOG_WRN("send statistical pgv heartbeat info failed:[%d-%s]\n", errno, strerror(errno));
		}
		//end ,add by tiger.51

		switch (u8Data)
		{
		case 0x7F: // Pre-Operational 
			pgv_printf("PGV State is Pre-Operational, data is 0x%x.\n", u8Data);
			//pgv_printf("PGV State is Pre-Operational, data is 0x%x.\n", u8Data);
			break;
		case 0x05: // Operational
			pgv_printf("PGV State is Operational, data is 0x%x.\n", u8Data);
			//pgv_printf("PGV State is Operational, data is 0x%x.\n", u8Data);
			break;
		case 0x04: //Stopped
			pgv_printf("PGV State is Stopped, data is 0x%x.\n", u8Data);
			//pgv_printf("PGV State is Stopped, data is 0x%x.\n", u8Data);
			break;
		case 0x00: //Initialising
			pgv_printf("PGV State is Initialising, data is 0x%x.\n", u8Data);
			//pgv_printf("PGV State is Initialising, data is 0x%x.\n", u8Data);
			break;
		default:
			pgv_printf("PGV State is unknown , data is 0x%x.\n", u8Data);
			//pgv_printf("PGV State is unknown, data is 0x%x.\n", u8Data);
			break;
		}
		u32StateCount = 0;
	}
	else
	{
		u32StateCount++;
		if (u32StateCount > 600) //60s to print
		{
			pgv_printf("PGV State is same, data is 0x%x.\n", u8Data);
			//start ,add by tiger.51
			iRet = sta_send_pgv_heartbeat_info(SATISTICAL_SEND_PERIOD_60S);
			if (iRet < 0)
			{
				LOG_WRN("send statistical pgv heartbeat info failed:[%d-%s]\n", errno, strerror(errno));
			}
			//end ,add by tiger.51
			u32StateCount = 0;
		}
	}

	u8PreData = u8Data;

	return 0;

}

/*******************************************************************************
* Function Name      : parse_Y_offset
* Description	     : parse y offset
* Input 		     : pframe :can frame pointer.
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void parse_Y_offset(struct can_frame *pframe)
{
	g_stAgvAttr.iGYOffset = ntohl(*(int32_t *)(&pframe->data[0]));// TODO unit 0.1 mm	 
}

/*******************************************************************************
* Function Name      : parse_X_offset
* Description	     : parse x offset
* Input 		     : pframe :can frame pointer.
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void parse_X_offset(struct can_frame *pframe)
{
	g_stAgvAttr.iGXOffset = ntohl(*(int32_t *)(&pframe->data[0]));		 // TODO unit 0.1 mm
	g_stAgvAttr.iGAngleOffset = ntohs( *(int16_t *)(&pframe->data[4]));	 // unit 0.1 degre,//by tiger
	//compute iVehHeadDirect instead of deal_mc_heart_beat
	int iGAngleOffset = g_stAgvAttr.iGAngleOffset;
	if (((iGAngleOffset > 0) && (iGAngleOffset <= 450)))
		g_stAgvAttr.iVehHeadDirect = DIRECTION_X_P;
	else if ((iGAngleOffset > 450) && (iGAngleOffset <= 1350))
		g_stAgvAttr.iVehHeadDirect = DIRECTION_Y_N;
	else if (((iGAngleOffset > 1350) && (iGAngleOffset <= 2250)))
		g_stAgvAttr.iVehHeadDirect = DIRECTION_X_N;
	else if ((iGAngleOffset > 2250) && (iGAngleOffset <= 3150))
		g_stAgvAttr.iVehHeadDirect = DIRECTION_Y_P;
	else if (iGAngleOffset > 3150)
		g_stAgvAttr.iVehHeadDirect = DIRECTION_X_P;

	//LOG_INF("get  xoffset:%d angle offset :%d - %d, head direct[%d-%s]\n", 
	//	(g_stAgvAttr.iGXOffset), g_stAgvAttr.iGAngleOffset, g_stAgvAttr.iGYOffset,
	//	g_stAgvAttr.iVehHeadDirect, get_direct_desc(g_stAgvAttr.iVehHeadDirect));
}

/*******************************************************************************
* Function Name      : init_agv_pallet_status
* Description	     : init agv pallet position status.
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int init_agv_pallet_status()
{
	struct can_frame stCtrlCanData = { 0 };
	int iRet = 0;
	int iPalletStatus = PALLET_STATUS_NULL;
	int iTryTime = 20000;
	int iTcStyle = 0;
	u8 iKey = 0;
	u32 iValue = 0;

	LOG_INF("init pallet status\n");
	// add by jxu 20180121:get the plate status begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		get_flag(DEV_TC, PALLET_STATUS_F);
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		get_flag(DEV_MC, MC_PLATE_STATUS_KEY_V2_F);
	}
	// add by jxu 20180121:get the plate status end

	while (iTryTime--)
	{
		iRet = recv_can(CTRL_CAN_DEV, &stCtrlCanData);
		if (iRet < 0) {
			//LOG_WRN("control can recv error[%s]\n", strerror(errno));
			usleep(1000);
			continue;
		}

		// get iGXOffset, iGAngleOffset, iVehHeadDirect from PGV_CANID_TxPDO2
		if (TC_CANID_ACK == stCtrlCanData.can_id)
		{
			iTcStyle = stCtrlCanData.data[6];	//style
			iKey     = stCtrlCanData.data[4];	// key
			iValue   = (u32)stCtrlCanData.data[0];	//data1
			
			if ((TC_GET_FLAG == iTcStyle) && (PALLET_STATUS_F == iKey)) {
				iPalletStatus = iValue;
				break;
			}
		}
		// add by jxu 20180121:get the plate status begin
		if (MC_CAN_FLAG_PARAM_ACK_V2_CANID == stCtrlCanData.can_id)
		{
			mc_can_rw_flag_param_ack_st *pAck = (mc_can_rw_flag_param_ack_st *)(&stCtrlCanData);
			int iPramId = pAck->iParamId;
			int iPramVaule = pAck->iParamVal;
			if (MC_PLATE_STATUS_KEY_V2_F == iPramId)
			{
				iPalletStatus = iPramVaule;
				break;
			}
		}
		// add by jxu 20180121:get the plate status end
	}

	if (iTryTime <= 0)
	{
		iPalletStatus = EVENT_ERR_TCCOMMUNISTOP;
		LOG_WRN("init pallet status time out\n");
	}
	// add by jxu 20180302:begin
	if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		if (iPalletStatus == PALLET_STATUS_UNKONWN)
		{
			iPalletStatus = PALLET_STATUS_NULL;
			LOG_ERR("init agv pallet status[%d-%s] success\n",
				iPalletStatus, get_pallet_status_desc(iPalletStatus));
		}
	}
	//add by jxu 20180302:end
	LOG_INF("init agv pallet status[%d-%s] success\n",
		iPalletStatus, get_pallet_status_desc(iPalletStatus));

	g_stAgvAttr.iPalletStatus = iPalletStatus;

	return 0;
}

/*******************************************************************************
* Function Name      : check_pallet
* Description	     : check pallet position status.
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int check_pallet()
{
	int iRet = 0;
	int iPalletStatus = 0;
	LOG_INF("check pallet status\n");
	//g_stAgvAttr.iPalletStatus be updated by deal_tc_completion()
	iPalletStatus = g_stAgvAttr.iPalletStatus;	
	if (PALLET_STATUS_NULL == iPalletStatus)
	{
		iRet = EVENT_ERR_TPERR;
		g_stAgvAttr.iPalletStatus = PALLET_STATUS_TOP;
	}
	else if (EVENT_ERR_TCCOMMUNISTOP == iPalletStatus)
	{
		LOG_WRN("get pallet status time out\n");
		return EVENT_ERR_TCCOMMUNISTOP;
	}

	LOG_INF("check pallet status[%d-%s] success\n",
		iPalletStatus, get_pallet_status_desc(iPalletStatus));

	return iRet;
}
/*******************************************************************************
* Function Name      : check_pallet_QR
* Description	     : check pallet QR,by tiger.105
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int check_pallet_QR()
{
	int iRet = 0;
	int iPalletStatus = 0;
	LOG_INF("check pallet QR\n");
	//g_stAgvAttr.iPalletStatus be updated by deal_tc_completion()
	if (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus && INVALID_DIRECTION == g_stAgvAttr.iPalletDirect)
	{
		LOG_WRN("get pallet direction failed \n");
		iRet = EVENT_ERR_SCANTPIDERROR;
	}
	else if (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus && INVALID_DIRECTION != g_stAgvAttr.iPalletDirect)
	{
		LOG_WRN("pallet init direction[%d-%s]\n", g_stAgvAttr.iPalletDirect, get_direct_desc(g_stAgvAttr.iPalletDirect));
	}
	return iRet;
}