/********************************************************************************
* Copyright (c) 2017, JD.COM, Inc .
* All rights reserved.
* FileName: v4l2_camera.c
* Author: tongkedong   Version: V1.0   Data:2017-12-18
* Description:
* v4l2_camera low-level support api code
********************************************************************************/
#include "v4l2_camera.h"
#include "globaldefine.h"
#include "databank.h"

//add by jxu 20180226:begin
#include "v4l_camera.h"//for camera driver
#include "processing.h"//for camera driver
#define   DEFAULT_CAMERA_NAME  "/dev/video0"
#define   VEDEO1_CAMERA_NAME  "/dev/video1"
#define   WIDTH2                 (1280)
#define   HEIGHT2                (720)//ZhongZai 2 need set const param
#define   WIDTH1                 (1280)
#define   HEIGHT1                (800) //ZhongZai 1 donot need set param
#define   TIMEOUT_S				 (10)
#define   TIMEOUT_US             (0)
int nScanSucCount = 0;
int nScanFailedCount = 0;
int nScanErrCount = 0;
static int iWidth = 0;
static int iHeight = 0;
static int nScanErrFlag = 0;
pthread_mutex_t start_scanner_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t scanner_statistic_lock = PTHREAD_MUTEX_INITIALIZER;
camera_t *pstCamera = NULL;
//add by jxu 20180226:end

/*******************************************************************************
* Function Name      : v4l2_camera_start
* Description	     : start v4l2 camera
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int v4l2_camera_start()
{
	int iRet = 0;

	return iRet;
}

/*******************************************************************************
* Function Name      : v4l2_camera_stop
* Description	     : stop v4l2 camera
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int v4l2_camera_stop()
{
	int iRet = 0;

	return iRet;
}
int camera_default_get_qrinfo()
{
	return 0;
}
/*******************************************************************************
* Function Name		 : get_camera_version
* Description	     : get the camera version.
* input			     : pstCamera is a camera handle returned by open_camera(...)
* Output		     : 0:success -1:failed
*******************************************************************************/
int get_camera_version(camera_t *pstCamera)
{
	int iRet = -1;
	struct v4l2_fmtdesc fmt;
	struct v4l2_frmsizeenum frmsize;

	fmt.index = 0;
	fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	LOG_INF("Get camera version begin\n");
	while (ioctl(pstCamera->iFd, VIDIOC_ENUM_FMT, &fmt) >= 0)
	{
		frmsize.pixel_format = fmt.pixelformat;
		frmsize.index = 0;
		LOG_INF("description=%s\n", fmt.description);
		if ('Y' == fmt.description[0])
		{
			while (ioctl(pstCamera->iFd, VIDIOC_ENUM_FRAMESIZES, &frmsize) >= 0)
			{
				LOG_INF("frmsize.type=%d frmsize.discrete.width=%d frmsize.discrete.height=%d\n", frmsize.type, frmsize.discrete.width
					, frmsize.discrete.height);
				frmsize.index++;
			}
			if (frmsize.index == 8)
			{
				iWidth = WIDTH2;
				iHeight = HEIGHT2;
				iRet = 0;
			}
			else if (frmsize.index == 3)
			{
				iWidth = WIDTH1;
				iHeight = HEIGHT1;
				iRet = 0;
			}
			else
			{
				LOG_ERR("Get the camera version is failed\n");
			}
		}
		fmt.index++;
	}
	LOG_INF("Get camera version end iWidth=%d iHeight=%d\n", iWidth, iHeight);
	return iRet;
}
/*******************************************************************************
* Function Name      : restart_v4camera
* Description	     : This function open the camera and allocate the algorithm's memory
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int restart_v4camera()
{
	pstCamera = open_camera(DEFAULT_CAMERA_NAME);
	if (!pstCamera)
	{
		LOG_ERR("pstCamera-DEFAULT_CAMERA_NAME is NULL and please make sure the carmera connection\n");
		pstCamera = open_camera(VEDEO1_CAMERA_NAME);
		if (!pstCamera)
		{
			LOG_ERR("pstCamera-VEDEO1_CAMERA_NAME is NULL and please make sure the carmera connection\n");
			if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CARMEROPENFAIL) < 0)
			{
				LOG_ERR("append to udp Tx queue failed\n");
			}
			return -1;
		}
	}
	if (-1 == get_camera_version(pstCamera))
	{
		LOG_ERR("Get self-researching camera version failed\n");
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_GET_SELFCAMERAVERERR) < 0)
		{
			LOG_ERR("append to udp Tx queue failed\n");
		}
		return -1;
	}
	if (-1 == init_camera(pstCamera, IO_METHOD_MMAP, iWidth, iHeight))
	{
		LOG_ERR("Init camera failed\n");
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CARMERINITFAIL) < 0)
		{
			LOG_ERR("append to udp Tx queue failed\n");
		}
		return -1;
	}
	LOG_INF("Real width: %d Real height: %d\n", pstCamera->uiWidth, pstCamera->uiHeight);
	IMG_WIDTH = pstCamera->uiWidth;
	IMG_HEIGHT = pstCamera->uiHeight;
	CAMERA_ANGLE = CAMERA_0;
	if (-1 == start_capturing(pstCamera))
	{
		LOG_ERR("Start capturing failed\n");
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CARMERCAPTUREFAIL) < 0)
		{
			LOG_ERR("append to udp Tx queue failed\n");
		}
		return -1;
	}
	FuncMemoryAlloc();
	return 0;
}
/*******************************************************************************
* Function Name      : v4l2_camera_get_qrinfo
* Description	     :  This function regonize the Qr code and get the offset and qrcode infomation
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int v4l2_camera_get_qrinfo(qr_info_t * pQRInfo)
{
	int iRet = 0;
	if (pQRInfo == NULL)
		return -1;

	LOG_INF("start the scanner\n");
	pthread_mutex_lock(&start_scanner_lock);
	if (!pstCamera)
	{
		pthread_mutex_unlock(&start_scanner_lock);
		LOG_ERR("uart_start_cmd:NULL pointer: pstCamera\n");
		return -1;
	}
	push_frame(pstCamera);//add by jxu 20180925-commet the line
	struct timeval tv;
	tv.tv_sec = TIMEOUT_S;
	tv.tv_usec = TIMEOUT_US;
	int iReadRet = 0;
#if 1
	int k = 0;
	int iFailedCount = 0;
	for (k; k < 1; k++)
	{
		iReadRet = read_frame(pstCamera, &tv);
		if (1 == iReadRet)
		{
			push_frame(pstCamera);
		}
		else
		{
			iFailedCount++;
			LOG_WRN("Read_frame is falied k=%d iFailedCount=%d\n", k, iFailedCount);
			push_frame(pstCamera);
		}
	}
#endif
	//add by jxu 20180925-begin:try to reconnection in 30s if disconnect
	int iV4lRet = v4l2_camera_init_check_id();
	if (iV4lRet < 0)
	{
		free_camera();
		LOG_WRN("Check the v4l2 connection is failed and try to reconnect in 30s\n");
		k = 0;
		for (k; k < 30; k++)
		{
			sleep(1);
			iV4lRet = v4l2_camera_init_check_id();
			if (iV4lRet == 0)
			{
				LOG_INF("Check the v4l2 connection is success and k is %d\n",k);
				//RE_OPEN_CAMRA
				iRet = restart_v4camera();
				if (iRet < 0)
				{
					pthread_mutex_unlock(&start_scanner_lock);
					LOG_INF("retry start_v4camera is failed\n");
					return -1;
				}
				else
				{
					LOG_INF("retry start_v4camera is success\n");
					break;
				}
			}
		}
		if ((k == 30) && (iV4lRet < 0))
		{
			pthread_mutex_unlock(&start_scanner_lock);
			LOG_ERR("Check the v4l2 connection is failed after try to reconnect in 30s\n");
			if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CARMERREADFAILE) < 0)
			{
				LOG_ERR("append to udp Tx queue failed\n");
			}
			return -1;
		}
	}
	//add by jxu 20180925-end

	iReadRet = read_frame(pstCamera, &tv);
	if (1 == iReadRet)
	{
		uint8_t *data = pstCamera->stHead.start;
		clock_t iBegin;
		iBegin = clock();
		FuncDataInit();//Initialize the variable
		int i = 0;
		for (i; i < IMG_HEIGHT; i++)
		{
			int j = 0;
			for (j; j < IMG_WIDTH; j++)
			{
				grayImageData[i*IMG_WIDTH + j] = data[i*IMG_WIDTH * 2 + j * 2];// gray the camera data
			}
		}
		bool isSuccess = FuncProcessing(); // begin to location the qr and decoding operation
		LOG_INF("Detected Ring Number: %d\n", (int)detectedRingsNum);
		clock_t iEnd;
		iEnd = clock();
		int iRunTime = iEnd - iBegin;
		LOG_INF("recgonize's runtime is %d and isSuccess=%d\n", iRunTime, isSuccess);
		if (isSuccess)
		{
//			FuncInfoOutput(isSuccess);  //calculate the output
			LOG_INF("The 2-D code recognition successed angle=%f deltaX=%f deltaY=%f message=%d\n",
				infoOutput.angle, infoOutput.deltaX, infoOutput.deltaY, infoOutput.messg);
			pQRInfo->fAngle = infoOutput.angle;
			pQRInfo->iQR = infoOutput.messg;
			snprintf(g_stAgvAttr.cContainer, 7, "%06d", pQRInfo->iQR);
			short int iDeltaX = 0;
			short int iDeltaY = 0;
			if (infoOutput.deltaX < 0)
			{
				iDeltaX = infoOutput.deltaX * 10 - 0.5;
			}
			else
			{
				iDeltaX = infoOutput.deltaX * 10 + 0.5;
			}
			if (infoOutput.deltaY < 0)
			{
				iDeltaY = infoOutput.deltaY * 10 - 0.5;
			}
			else
			{
				iDeltaY = infoOutput.deltaY * 10 + 0.5;
			}
			pQRInfo->iXOffset = iDeltaX;
			pQRInfo->iYOffset = iDeltaY;
			iRet = 0;
			pthread_mutex_lock(&scanner_statistic_lock);
			nScanSucCount++;
			pthread_mutex_unlock(&scanner_statistic_lock);
			//LOG_INF("The scanner's output before:code=%s angle=%d tpdirection=%d iDeltaX=%d iDeltaY=%d deltaX=%f deltaY=%f\n",
			//	pQRInfo->iQR, pQRInfo->fAngle, get_tpdirection(), get_XDiff(), get_YDiff(), infoOutput.deltaX, infoOutput.deltaY);
			LOG_INF("The scanner's output before:code=%d angle=%.2f  iDeltaX=%d iDeltaY=%d deltaX=%f deltaY=%f\n",
				pQRInfo->iQR, pQRInfo->fAngle, pQRInfo->iXOffset, pQRInfo->iYOffset, infoOutput.deltaX, infoOutput.deltaY);
			shelfdiff_printf("QRCode=%d angle=%.2f iDeltaX=%d iDeltaY=%d detectedRingsNum=%d deltaX=%f deltaY=%f\n",
				pQRInfo->iQR, pQRInfo->fAngle, pQRInfo->iXOffset, pQRInfo->iYOffset, (int)detectedRingsNum, infoOutput.deltaX, infoOutput.deltaY);
		}
		else
		{
			//save the failed imageraw file begin
			if (nScanErrFlag == 10)
			{
				LOG_INF("nScanErrFlag is 10 and will be 0\n");
				nScanErrFlag = 0;
			}
			time_t t;
			struct tm *tmp = NULL;
			char strErrTime[48] = { 0 };
			time(&t);
			tmp = localtime(&t);
			strftime(strErrTime, sizeof(strErrTime), "%F-%H.%M.%S_", tmp);
			char sScanErrFlag[4];
			sprintf(sScanErrFlag, "%d", nScanErrFlag);

			char imageraw[256] = "/var/log/imagrawfail";
			strcat(imageraw, strErrTime);
			strcat(imageraw, sScanErrFlag);
			strcat(imageraw, ".raw");
			LOG_INF("imageraw=%s\n", imageraw);
			FILE* fd = fopen(imageraw, "w");
			fwrite(grayImageData, IMG_WIDTH*IMG_HEIGHT, 1, fd);
			fsync(fileno(fd));
			fclose(fd);
			nScanErrFlag = nScanErrFlag + 1;
			LOG_INF("The 2-D code recognition failed\n");
			save_log_img(EVENT_ERR_SCANTPIDERROR);
			iRet = -1;
			pthread_mutex_lock(&scanner_statistic_lock);
			nScanFailedCount++;
			pthread_mutex_unlock(&scanner_statistic_lock);
		}
		LOG_INF("Scantest:nSucCount=%d nFailedCount=%d nScanErrCount=%d angle=%f deltaX=%f deltaY=%f message=%d detectedRingsNum=%d\n",
			nScanSucCount, nScanFailedCount, nScanErrCount, infoOutput.angle, infoOutput.deltaX, infoOutput.deltaY, infoOutput.messg, (int)detectedRingsNum);
	}
	else
	{
		pthread_mutex_unlock(&start_scanner_lock);
		LOG_ERR("Read frame failed and please make sure the carmera's connection\n");
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CARMERREADFAILE) < 0)
		{
			LOG_ERR("append to udp Tx queue failed\n");
		}
		return -1;
	}

	pthread_mutex_unlock(&start_scanner_lock);
	return iRet;
}

/*******************************************************************************
* Function Name      : start_camera
* Description	     : This function open the camera and allocate the algorithm's memory
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int start_v4camera()
{
	pstCamera = open_camera(DEFAULT_CAMERA_NAME);
	if (!pstCamera)
	{
		LOG_ERR("pstCamera is NULL and please make sure the carmera connection\n");
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CARMEROPENFAIL) < 0)
		{
			LOG_ERR("append to udp Tx queue failed\n");
		}
		return -1;
	}
	if (-1 == get_camera_version(pstCamera))
	{
		LOG_ERR("Get self-researching camera version failed\n");
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_GET_SELFCAMERAVERERR) < 0)
		{
			LOG_ERR("append to udp Tx queue failed\n");
		}
		return -1;
	}
	if (-1 == init_camera(pstCamera, IO_METHOD_MMAP, iWidth, iHeight))
	{
		LOG_ERR("Init camera failed\n");
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CARMERINITFAIL) < 0)
		{
			LOG_ERR("append to udp Tx queue failed\n");
		}
		return -1;
	}
	LOG_INF("Real width: %d Real height: %d\n", pstCamera->uiWidth, pstCamera->uiHeight);
	IMG_WIDTH = pstCamera->uiWidth;
	IMG_HEIGHT = pstCamera->uiHeight;
	CAMERA_ANGLE = CAMERA_0;
	if (-1 == start_capturing(pstCamera))
	{
		LOG_ERR("Start capturing failed\n");
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CARMERCAPTUREFAIL) < 0)
		{
			LOG_ERR("append to udp Tx queue failed\n");
		}
		return -1;
	}
	FuncMemoryAlloc();
	return 0;
}
/*******************************************************************************
* Function Name      : free_camera
* Description	     : This function close the camera and free the algorithm's memory
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
void free_camera()
{
	LOG_INF("free_camera resource\n");
	// close camera begin
	stop_capturing(pstCamera);
	uninit_camera(pstCamera);
	close_camera(pstCamera);
	//free the algorthim 's memory
	FuncMemoryDestroy();
}
/*******************************************************************************
* Function Name      : v4l2_camera_init_check
* Description	     : This function close the camera and free the algorithm's memory
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int v4l2_camera_init_check()
{
	char sStatisCmd[64] = { "lsusb | grep ID -c" };
	FILE *stream;
	char buf[32];
	memset(buf, '\0', sizeof(buf));
	stream = popen(sStatisCmd, "r");
	fread(buf, sizeof(char), sizeof(buf), stream);
	pclose(stream);

	int iUsbNum = atoi(buf);
	LOG_INF("iUsbNum=%d \n",iUsbNum);
	if (iUsbNum < 5)
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name      : v4l2_camera_init_check_id
* Description	     : The function recoginize the usb camera
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int v4l2_camera_init_check_id()
{
	char sStatisCmd[64] = { "lsusb | grep -E '05a3|2e5a' -c" };//for Ruier or Maizhe
	FILE *stream;
	char buf[32];
	memset(buf, '\0', sizeof(buf));
	stream = popen(sStatisCmd, "r");
	fread(buf, sizeof(char), sizeof(buf), stream);
	pclose(stream);

	int iUsbNum = atoi(buf);
	LOG_INF("iUsbNum=%d \n", iUsbNum);
	if (iUsbNum <= 0)
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name      : v4l2_camera_get_qrinfo_check
* Description	     :  This function regonize the Qr code and get the offset and qrcode infomation
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int v4l2_camera_get_qrinfo_check(qr_info_t * pQRInfo, FILE *fp)
{
	int iRet = 0;
	if (pQRInfo == NULL)
		return -1;

	LOG_INF("start the scanner\n");
	pthread_mutex_lock(&start_scanner_lock);
	if (!pstCamera)
	{
		pthread_mutex_unlock(&start_scanner_lock);
		LOG_ERR("uart_start_cmd:NULL pointer: pstCamera\n");
		return -1;
	}
	push_frame(pstCamera);//add by jxu 20180925 comment the line
	struct timeval tv;
	tv.tv_sec = TIMEOUT_S;
	tv.tv_usec = TIMEOUT_US;
	int iReadRet = 0;
#if 1
	int k = 0;
	int iFailedCount = 0;
	for (k; k < 1; k++)
	{
		iReadRet = read_frame(pstCamera, &tv);
		if (1 == iReadRet)
		{
			push_frame(pstCamera);
		}
		else
		{
			iFailedCount++;
			LOG_WRN("Read_frame is falied k=%d iFailedCount=%d\n", k, iFailedCount);
			push_frame(pstCamera);
		}
	}
#endif

	iReadRet = read_frame(pstCamera, &tv);
	if (1 == iReadRet)
	{
		uint8_t *data = pstCamera->stHead.start;
		clock_t iBegin;
		iBegin = clock();
		FuncDataInit();//Initialize the variable
		int i = 0;
		for (i; i < IMG_HEIGHT; i++)
		{
			int j = 0;
			for (j; j < IMG_WIDTH; j++)
			{
				grayImageData[i*IMG_WIDTH + j] = data[i*IMG_WIDTH * 2 + j * 2];// gray the camera data
			}
		}
		bool isSuccess = FuncProcessing(); // begin to location the qr and decoding operation
		LOG_INF("Detected Ring Number: %d\n", (int)detectedRingsNum);
		clock_t iEnd;
		iEnd = clock();
		int iRunTime = iEnd - iBegin;
		LOG_INF("recgonize's runtime is %d and isSuccess=%d\n", iRunTime, isSuccess);
		if (isSuccess)
		{
//			FuncInfoOutput(isSuccess);  //calculate the output
			LOG_INF("The 2-D code recognition successed angle=%f deltaX=%f deltaY=%f message=%d\n",
				infoOutput.angle, infoOutput.deltaX, infoOutput.deltaY, infoOutput.messg);
			pQRInfo->fAngle = infoOutput.angle;
			pQRInfo->iQR = infoOutput.messg;
			snprintf(g_stAgvAttr.cContainer, 7, "%06d", pQRInfo->iQR);
			short int iDeltaX = 0;
			short int iDeltaY = 0;
			if (infoOutput.deltaX < 0)
			{
				iDeltaX = infoOutput.deltaX * 10 - 0.5;
			}
			else
			{
				iDeltaX = infoOutput.deltaX * 10 + 0.5;
			}
			if (infoOutput.deltaY < 0)
			{
				iDeltaY = infoOutput.deltaY * 10 - 0.5;
			}
			else
			{
				iDeltaY = infoOutput.deltaY * 10 + 0.5;
			}
			pQRInfo->iXOffset = iDeltaX;
			pQRInfo->iYOffset = iDeltaY;
			iRet = 0;
			pthread_mutex_lock(&scanner_statistic_lock);
			nScanSucCount++;
			pthread_mutex_unlock(&scanner_statistic_lock);
			//LOG_INF("The scanner's output before:code=%s angle=%d tpdirection=%d iDeltaX=%d iDeltaY=%d deltaX=%f deltaY=%f\n",
			//	pQRInfo->iQR, pQRInfo->fAngle, get_tpdirection(), get_XDiff(), get_YDiff(), infoOutput.deltaX, infoOutput.deltaY);
			LOG_INF("The scanner's output before:code=%d angle=%.2f  iDeltaX=%d iDeltaY=%d deltaX=%f deltaY=%f\n",
				pQRInfo->iQR, pQRInfo->fAngle, pQRInfo->iXOffset, pQRInfo->iYOffset, infoOutput.deltaX, infoOutput.deltaY);
			shelfdiff_printf("QRCode=%d angle=%.2f iDeltaX=%d iDeltaY=%d detectedRingsNum=%d deltaX=%f deltaY=%f\n",
				pQRInfo->iQR, pQRInfo->fAngle, pQRInfo->iXOffset, pQRInfo->iYOffset, (int)detectedRingsNum, infoOutput.deltaX, infoOutput.deltaY);
			fprintf(fp, "The 2-D code recognition successed QRCode=%d angle=%.2f iDeltaX=%d iDeltaY=%d detectedRingsNum=%d deltaX=%f deltaY=%f\n",
				pQRInfo->iQR, pQRInfo->fAngle, pQRInfo->iXOffset, pQRInfo->iYOffset, (int)detectedRingsNum, infoOutput.deltaX, infoOutput.deltaY);
		}
		else
		{
			//save the failed imageraw file begin
			if (nScanErrFlag == 10)
			{
				LOG_INF("nScanErrFlag is 10 and will be 0\n");
				nScanErrFlag = 0;
			}
			time_t t;
			struct tm *tmp = NULL;
			char strErrTime[48] = { 0 };
			time(&t);
			tmp = localtime(&t);
			strftime(strErrTime, sizeof(strErrTime), "%F-%H.%M.%S_", tmp);
			char sScanErrFlag[4];
			sprintf(sScanErrFlag, "%d", nScanErrFlag);

			char imageraw[256] = "/var/log/imagrawfail";
			strcat(imageraw, strErrTime);
			strcat(imageraw, sScanErrFlag);
			strcat(imageraw, ".raw");
			LOG_INF("imageraw=%s\n", imageraw);
			FILE* fd = fopen(imageraw, "w");
			fwrite(grayImageData, IMG_WIDTH*IMG_HEIGHT, 1, fd);
			fsync(fileno(fd));
			fclose(fd);
			nScanErrFlag = nScanErrFlag + 1;
			LOG_INF("The 2-D code recognition failed\n");
			fprintf(fp,"The 2-D code recognition failed\n");
			save_log_img(EVENT_ERR_SCANTPIDERROR);
			iRet = -1;
			pthread_mutex_lock(&scanner_statistic_lock);
			nScanFailedCount++;
			pthread_mutex_unlock(&scanner_statistic_lock);
		}
		LOG_INF("Scantest:nSucCount=%d nFailedCount=%d nScanErrCount=%d angle=%f deltaX=%f deltaY=%f message=%d detectedRingsNum=%d\n",
			nScanSucCount, nScanFailedCount, nScanErrCount, infoOutput.angle, infoOutput.deltaX, infoOutput.deltaY, infoOutput.messg, (int)detectedRingsNum);
	}
	else
	{
		pthread_mutex_unlock(&start_scanner_lock);
		LOG_ERR("Read frame failed and please make sure the carmera's connection\n");
		if (send_error_msg(EVENT_TYPE_ERROR, EVENT_ERR_CARMERREADFAILE) < 0)
		{
			LOG_ERR("append to udp Tx queue failed\n");
		}
		return -1;
	}

	pthread_mutex_unlock(&start_scanner_lock);
	return iRet;
}