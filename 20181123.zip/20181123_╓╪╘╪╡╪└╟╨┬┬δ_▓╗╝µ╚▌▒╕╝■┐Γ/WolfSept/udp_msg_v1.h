#ifndef _UDP_MSG_V1_H__
#define _UDP_MSG_V1_H__

#include "global_var.h"
#include "udp_msg.h"


#ifdef MSG_TYPE_V1P0

typedef struct msgv1_head
{
	int iMsgtype;
	int iSequence;
	int iAgvName;
} msgv1_head_t;

typedef struct msgv1_ack
{
	int iMsgtype;
	int iSequence;
	int iTokenNum;//add by tiger.34
	int iServerTime;//add by tiger.72
} msgv1_ack_t;

typedef struct msgv1_register
{
	int iMsgType;
	int iSequence;
	int iAgvName;
	int iLocation;
	int iStatus;
	int iBigVer;
	int iBigVerDate;
	int iMCVerDate;
	int iTCVerDate;
	int iDSPStatus;
	int iVehHeadDirect; //add head direction when register ,by tiger.13
	int iChargeType; //0:charge interface is on ground;1:charge interface is on wall,add by tiger.40
	int iPalletStatus;
	int iBootMethod;
	int iPalletDirection;//���̷���,by tiger.105
} msgv1_register_t;

typedef struct msgv1_heartbeat
{
	int iMsgType;
	int iSequence;
	int iAgvName;
	int iBattery;
	int iSpeed;
	int iVehHeadDirect;
	int iLocation;
	int iStatus;
	int iGXOffset;
	int iGYOffset;
	int iGAngleOffset;
	int iTXOffset;
	int iTYOffset;
	int iTAngleOffset;
	int iMoveStatus;
	int iBatTemper;//add by jxu 20180709
	//int iBatUnitMaxVoltage;//add by tiger.98
	int iTokenNum;// by tiger.34
} msgv1_heartbeat_t;

typedef struct msgv1_heartbeat_debug
{
	int iMsgType;
	int iSequence;
	int iAgvName;
	int iBattery;
	int iSpeed;
	int iVehHeadDirect;
	int iLocation;
	int iStatus;
	int iGXOffset;
	int iGYOffset;
	int iGAngleOffset;
	int iGsdev;
	int iGSdevFB;
	int iGSangle;
	int iTAngleOffset;
	int iSreamin;
	int iEvent;
	int iPath;
	int iNewTag;
	int iFinishTag;
	int iMoveStatus;
	int iBatTemper;//add by jxu 20180709
	int iTokenNum;// by tiger.34
} msgv1_heartbeat_debug_t;

typedef struct msgv1_error
{
	int iMsgType;
	int iSequence;
	int iAgvName;
	int iLocation;
	int iError;
	int iXoffset;
	int iYoffset;
	int iAngle;
	int iTokenNum;// by tiger.34
	int iSubErrorCode;//add by jxu 20180510
} msgv1_error_t;

typedef struct msgv1_error_point
{
	int iMsgType;
	int iSequence;
	int iAgvName;
	int iLocation;
	int iVehHeadDirect;
	int iTokenNum;// by tiger.34
	int iErrorCode;	// add by kedong. 20180321
} msgv1_error_point_t;

#define MAX_WALK_POINT	6
typedef struct msgv1_operate
{
	int iMsgtype;
	int iSequence;
	int iAgvName;
	int iLength;
	int iPara;
	int iAction;
	int iSpeed;
	int iWeight;
	int iPoint[MAX_WALK_POINT];
	int iTokenNum;// by tiger.34
	char cContainer[32];
} msgv1_operate_t;

typedef struct msgv1_operate_ack
{
	int iMsgtype;
	int iSequence;
	int iAgvName;
	int iTokenNum;// by tiger.34
} msgv1_operate_ack_t;

typedef struct msgv1_finish
{
	int iMsgType;
	int iSequence;
	int iAgvName;
	int iAction;
	int iPalletDirect;//pallet direction
	int iVehHeadDirect;
	int iLocation;
	int iTokenNum;// by tiger.34
} msgv1_finish_t;

typedef struct msgv1_point
{
	int iMsgType;
	int iSequence;
	int iAgvName;
	int iLocation;
	int iVehHeadDirect;
	int iTokenNum;// by tiger.34
} msgv1_point_t;

typedef struct msgv1_confirm
{
	int iMsgType;
	int iSequence;
	int iAgvName;
	int iConType;
	int iConSeq;
	int iTokenNum;// by tiger.34
} msgv1_confirm_t;

typedef struct msgv1_debug
{
	int iMsgtype;
	int iSequence;
	int iAgvName;
	int iCmd;
	int iAgvValue;
	int iTokenNum;//add by tiger.34
} msgv1_debug_t;

typedef struct msgv1_get_param_req
{
	int iMsgtype;
	int iSequence;
	int iAgvName;
	int iParamID;
	int iTokenNum;
} msgv1_param_get_req_t;

typedef struct msgv1_param_ack
{
	int iMsgtype;
	int iSequence;
	int iAgvName;
	int iParamID;
	int iParamValue;
//	int iTokenNum;
} msgv1_param_ack_t;

typedef struct msgv1_set_param_req
{
	int iMsgtype;
	int iSequence;
	int iAgvName;
	int iParamID;
	int iParamValue;
	int iTokenNum;
} msgv1_param_set_req_t;

///start by tiger.31
typedef struct msgv1_batt_info {
	int iMsgtype;
	int iSequence;
	int iAgvName;
	int iTemp; //temperature by tiger.31
	int iTokenNum;// by tiger.34
} msgv1_batt_info_t;
///end by tiger.31

typedef struct msgv1_state
{
	int iMsgtype;
	int iState;
} msgv1_state_t;

enum enChargeType{ //add by tiger.40
	ON_GROUND = 0,
	ON_WALL = 1
};
//add by jxu 20180205:begin
typedef struct msgv1_ground_offset
{
	int iMsgtype;
	int iSeq;
	int iAgvName;
	int iPointId;
	int iGXOffset;
	int iGYOffset;
	int iGAngleOffset;
	int iGsDev;
	int iGSDevFB;
	int iGSAngle;
	int iHeadDirect;
	int iAction;
}msgv1_ground_offset_st;
//add by jxu 20180205:end

extern char * get_debug_cmd_name(int iCmd);
extern int msgv1_head_dump(const char * pMsgBuff);
extern int msgv1_tokennum_is_valid(int iTokenNum);
extern int msgv1_is_valid(const char * pMsgBuff, int iMsgSize);
extern int msgv1_agv_register();
extern int msgv1_deal_ack(const char * pMsgBuff, int iMsgSize);
extern int msgv1_send_heartbeat();
extern int msgv1_send_event(int iEventType, int iErrorCode);
extern int msgv1_send_event_suberror(int iEventType, int iErrorCode, int iSubError);//add by jxu 20180510
extern int msgv1_send_error_point(int iErrorCode);
extern int msgv1_send_event_release(int iEventType, int iErrorCode);
extern int msgv1_send_finish(int iAction);
extern int msgv1_send_point(int iLocation, int iDriverMode);
extern int msgv1_send_confirm(int iMsgType, int iSeq);
extern int msgv1_send_ack(const char * pMsgBuff);
extern int msgv1_send_batt_info();
extern int msgv1_send_scan_info();
extern int msgv1_send_offset_info();
extern int msgv1_dump_walk_path(const char * pMsgBuff);
extern int msgv1_check_walk_path(const char * pMsgBuff);
extern int msgv1_deal_action_result(int iRet, bool bNeedSendFinish, int iAction);
extern int msgv1_deal_operate(const char * pMsgBuff);
extern int msgv1_parse_operate(const char * pMsgBuff, int iMsgSize);
extern int msgv1_parse_debug(const char * pMsgBuff, int iMsgSize);

extern int msgv1_get_msgtype(const char * pMsgBuff, int iMsgSize);
extern int msgv1_get_sequence(const char * pMsgBuff, int iMsgSize);
extern int msgv1_get_tokennum(const char * pMsgBuff, int iMsgSize);

extern int msgv1_recv(const char * pMsgBuff, int iMsgSize);
extern int msgv1_deal(const char * pMsgBuff, int iMsgSize);
extern int msgv1_send_offset_statistic(int iAction);//add by jxu 20180205

#endif	//MSG_TYPE_V1P0

#endif/*_UDP_MSG_V1_H__*/
