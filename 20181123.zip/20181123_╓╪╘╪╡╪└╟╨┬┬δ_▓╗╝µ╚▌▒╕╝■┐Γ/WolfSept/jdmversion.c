#include "jdmversion.h"

#define MAJOR_VER     1
#define SUB_VER       1
#define PHASE_VER     0

#define JDX_MAJOR_VER 1
#define JDX_SUB_VER 5

static const char jdmVersion[8] = {MAJOR_VER,SUB_VER, PHASE_VER,'J','D','M',JDX_MAJOR_VER,JDX_SUB_VER};

const char* FuncVersionInfo(void)
{
	return jdmVersion;
}