/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* All rights reserved.
* FileName: FTP.C
* Author: Menghu Wang   Version: V1.0   Data:2017-05-13
* Description:REALIZE THE FTP FUNCTION LIB
*Version: V1.0
*History:
	<author>    <time>    <version>     <desc>
********************************************************************************/
#include "ftp.h"
#include "debug.h"
#include "device.h"
#include "mc_v2.h"//add by tiger.63
#include "mc_v1.h"//add by tiger.63
#include "device.h"
#include "wget_update.h"
#include <assert.h>
#include <time.h>
#include <stdbool.h>
//star by tiger.101

bool g_bMmAppWgetOK = false;
bool g_bMcAppWgetOK = false;
bool g_bTcAppWgetOK = false;
bool g_bBmsAppWgetOK = false;
//end by tiger.101
#define USERNAMEOK 331
#define LOGGEDINOK 230
#define CMDSIZE 4
#define DIR_EXIST 550
#define DIR_CREAT_SUCCESS 257
#define CHANGE_DIR_SUCCESS 250
#define ENABLE       125 //enable store or transport data
#define ALREADY       150 //already to  store or transport data

static bool bPreTimeOut = false; //quit ftp function because connect server timeout last time,by tiger.05
static bool iSigPipeFlag = false;//happened SIGPIPE,by tiger.05
struct sockaddr_in stFtpServer;    //ftp server address
struct hostent * pServerHostent;
int iSockControl;
char pLcd[MAXLINE];    //save download path
char pVersionPath[MAXLINE+10];    //save version.txt path
bool g_stop_update = false;

static uint32_t pCrc[256];    //crc
///start,tiger.11
///the interface of different gennerate AGV update
#define DSP_TOTAL_TYPE 10  //the number of dsp type  //by tiger.33
char *pTcAppName[DSP_TOTAL_TYPE] = { "tc.hex", "tc1.hex", "tc2.hex", "tc3.hex", "tc4.hex", "tc5.hex", "tc6.hex", "tc7.hex", "tc8.hex", "tc9.hex" }; //by tiger.33
char *pMcAppName[DSP_TOTAL_TYPE] = { "mc.hex", "mc1.hex", "mc2.hex", "mc3.hex", "mc4.hex", "mc5.hex", "mc6.hex", "mc7.hex", "mc8.hex", "mc9.hex" }; //by tiger.33
char *pDspSegName[DSP_TOTAL_TYPE] = { "generation_1", "generation_2", "generation_3", "generation_4", "generation_5", "generation_6", "generation_7", "generation_8", "generation_9","generation_10" };
int s_iDspType[2] = { 0, 0 };//g_iDspType[0]:TC ;g_iDspType[1]:MC
///end.tiger.11

///start by tiger.12
#define ARM_LOG_NUM 10//9->10 ,by tiger.86
char *pARMLogPath[ARM_LOG_NUM] = { "/var/log/jdagv.log", "/var/log/McuLog.log", "/var/log/LRfinishLog.log", //0~2
"/var/log/MCheartbeat.log", "/var/log/PGVheartbeat.log","/var/log/PGVJitter.log","/var/log/jdagv_action.log",
"/var/log/jdagv_event.log","/var/log/wifi_monitor.log","/var/log/battery_monitor.log" };//by tiger.59 ,add /var/log/battery_monitor.log tiger.86
char *pARMLogOldPath[ARM_LOG_NUM] = { "/var/log/jdagv.log.old", "/var/log/McuLog.log.old", "/var/log/LRfinishLog.log.old", //0~2
"/var/log/MCheartbeat.log.old", "/var/log/PGVheartbeat.log.old", "/var/log/PGVJitter.log.old", "/var/log/jdagv_action.log.old",
"/var/log/jdagv_event.log.old", "/var/log/wifi_monitor.log.old", "/var/log/battery_monitor.log.old" };
#define DSP_LOG_NUM 2
char *pDSPLogPath[DSP_LOG_NUM] = { "/var/log/TcRam.log", "/var/log/McRam.log" };
//"/var/log/TcRam.log",//3~6
//"/var/log/McRam.log" //7

DspLog g_stDspLog = { 0 };

#define  DSP_UPDATE_DCU  "/root/jdagvclientserver/jdagvserver/dsp_update"
extern int sock_can0;
#define CAN_LENGTH 10


/*******************************************************************************
* Function Name  : init_crc32_tab
* Description    : get the init crc table
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void init_crc32_tab( void ) 
{
	int i, j;
	uint32_t u32Crc;

	bzero(pCrc, sizeof(pCrc));
	
	for (i=0; i<256; i++)
	{
		u32Crc = (unsigned long)i;
		for (j=0; j<8; j++) 
		{
			if (u32Crc & 0x00000001L)
				u32Crc = (u32Crc >> 1) ^ POLY;
			else      
				u32Crc = u32Crc >> 1;
		}
		pCrc[i] = u32Crc;
	}
}

/*******************************************************************************
* Function Name  : get_crc32
* Description    : get the 32-bit crc of a buf
* Input          : u32_crcinit:a 32-bit init crc ;p_buf:the buf to calc ,
					u32_buf_size:the size fo the buf
* Output         : None
* Return         : a 32-bit crc
*******************************************************************************/
uint32_t get_crc32(uint32_t u32Crcinit, uint8_t * pBuf ,uint32_t u32BufSize)
{
	uint32_t u32Crc = u32Crcinit ^ 0xffffffff;
 
	init_crc32_tab();
	while (u32BufSize--)
		u32Crc = (u32Crc >> 8) ^ pCrc[(u32Crc & 0xff) ^ *pBuf++];
 
	return u32Crc ^ 0xffffffff;
}
/*******************************************************************************
* Function Name  : get_crc
* Description    : get the 32-bit crc of the file
* Input          : filename:the name of file ;
* Output         : None
* Return         : a 32-bit crc
*******************************************************************************/
 unsigned int get_crc(const char *pFilename)
{
	unsigned int iSize = 1024;
	unsigned char pCrcBuf[iSize];
	unsigned int iLen = 0;
	unsigned int iCrc = 0;	//CRC��ʼֵΪ0
	FILE *fd;
	if ((fd = fopen(pFilename, "r")) == NULL)
	{
		LOG_ERR("open %s failed:%s\n",pFilename,strerror(errno));
		return -1;
	}
 	fseek(fd,0,SEEK_SET);
	while ((iLen = fread(pCrcBuf, sizeof(uint8_t), iSize, fd)) > 0)
		iCrc = get_crc32(iCrc, pCrcBuf, iLen);
	LOG_INF("CRC: %X\n", iCrc);
 	fclose(fd);
	return iCrc;
}
 /*******************************************************************************
 * Function Name  : cmd_err_exit
 * Description    : cmd fault and return
 * Input          : err_msg:error msg ;err_code:error number
 * Output         : NONE
 * Return         : the error value
 *******************************************************************************/
 int cmd_err_exit(char * pErrMsg, int iErrCode)
 {
	 LOG_ERR("%s\n", pErrMsg);
	 return(iErrCode);
 }
 /*******************************************************************************
 * Function Name  : read_conf
 * Description        : read the configue file
 * Input         	       : filename:the name of the configue file ;name: the content ;				
 * Output               : des:save the value of the name in configue
 * Return        	       : 0:  success  -1: failed
 *******************************************************************************/
 int read_conf(const char *pFilename, const char *pName, char *pDes)
 {
	 char pBuf[MAXLINE];
	 char *pDelim = "=";
	 char *pTmpBuf = NULL;
	 int iResult = -1;
	 size_t iLen = 0;
	 
	 bzero(pBuf, sizeof(pBuf));
	 
	 FILE *pFp = fopen(pFilename, "r");
	 if (pFp == NULL)
	 {
		 LOG_INF("open %s failed \n!", pFilename);
		 return -1;
		
	 }
	 while (fgets(pBuf, MAXLINE, pFp) != NULL)
	 {
		 if (strstr(pBuf, pName) != NULL)
		 {
			 strtok(pBuf, pDelim);
			 pTmpBuf = strtok(NULL, pDelim);
			 iLen = strlen(pTmpBuf);
			 strncpy(pDes, pTmpBuf, iLen - 1); //delete '\n'
			 *(pDes + iLen - 1) = '\0';
		
			 iResult = 0;
			 break;
		 }
		 iResult = -1;

	 }
	 fclose(pFp);
	 return iResult;
 }

 /*******************************************************************************
 * Function Name  : fill_host_addr
 * Description    : send command to server with sock_fd
 * Input          : p_host_ip_addr,p_host,i_port
 * Output         : NONE
 * Return         : 0:  success  n: failed
 *******************************************************************************/
int fill_host_addr(char * pHostIpAddr, struct sockaddr_in * pHost, int iPort)
{
	if (iPort <= 0 || iPort > 65535)
	{
		return 254;
	}
	
	bzero(pHost, sizeof(struct sockaddr_in));
	pHost->sin_family = AF_INET;
	if (inet_addr(pHostIpAddr) != -1)
	{
		pHost->sin_addr.s_addr = inet_addr(pHostIpAddr);
	}
	else 
	{
		if ((pServerHostent = gethostbyname(pHostIpAddr)) != 0)
		{
			memcpy(&pHost->sin_addr, pServerHostent->h_addr, \
				sizeof(pHost->sin_addr));
		}
		return 253;
	}
	pHost->sin_port = htons(iPort);
	return 0;
}
/*******************************************************************************
* Function Name  : connect_sock
* Description    : send command to server with sock_fd
* Input          : sock_fd: socket id  p_cmd:cmd  p_param: the param of the cmd
* Output         : NONE
* Return         : num:socket value; -1: failed
*******************************************************************************/
int connect_sock(struct sockaddr_in *stAddr, int iType)//
{
	struct timeval stOutTime;
	int iSet = 0;
	char pTimeOut[MAXLINE];
	int iTimeout = 15;    //max time out in seconds when connect to the ftp server
	int iSock = 0; 
	int iNumSec = 0;
	int iFlags = 0;    //save socket  flag
	int iConnectSuc = 0;    //socket connect success flag
	time_t stTimeNow = 0;   //save the time while connect the ftp server
	bzero(pTimeOut, sizeof(pTimeOut));
	if ((iSock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		LOG_ERR("failed to open the socket %d ,%s \n", iSock, strerror(errno));
		cmd_err_exit("creat socket error! \n", 249);
	}
	//set st_outtime for the control socket
	if (iType == 1)
	{
		stOutTime.tv_sec = 5;
		stOutTime.tv_usec = 300000;
	}
	else
	{
		stOutTime.tv_sec = 5;
		stOutTime.tv_usec = 0;
	}

	iSet = setsockopt(iSock, SOL_SOCKET, SO_RCVTIMEO, &stOutTime, sizeof(stOutTime));
	if (iSet != 0)
	{
		LOG_ERR("set socket %s errno:%d\n", strerror(errno), errno);
		cmd_err_exit("set socket", 1);
	}
	iFlags = fcntl(iSock, F_GETFL, 0);
	fcntl(iSock, F_SETFL, iFlags | O_NONBLOCK);
	
	//connect to the server
	if (ini_read(UPDATA_CONF,FTP_SECTION, "time_out", pTimeOut,sizeof(pTimeOut)) != 0)
	{
		LOG_ERR("ini_read time_out error \n");
		iSock = -1;
	}
	else
	{
		iTimeout = atoi(pTimeOut);
		LOG_INF("The max connect time is %d\n", iTimeout);
	}	
	stTimeNow = time(NULL);
	for (iNumSec = 1; iNumSec <= iTimeout; iNumSec++)
	{
		if (connect(iSock, (struct sockaddr *)stAddr, sizeof(struct sockaddr_in)) == 0)
		{
			LOG_INF("Connect to server %s, port %d\n",
				inet_ntoa(stAddr->sin_addr), ntohs(stFtpServer.sin_port));
			LOG_INF("Connect time = %d\n", time(NULL) - stTimeNow);
			iConnectSuc = 1;
			fcntl(iSock, F_SETFL, iFlags &(~O_NONBLOCK));
			break;
		}
		LOG_INF("Can't connect to server %s, port %d,with the soocket id %d,%s\n",
			inet_ntoa(stAddr->sin_addr), ntohs(stFtpServer.sin_port), iSock, strerror(errno));
		sleep(1);
		iConnectSuc = 0;
	}
	if (iConnectSuc == 0)
	{
		close(iSock);
		bPreTimeOut = true;
		iSock = -1;
	}
	return iSock;
}
/*******************************************************************************
* Function Name  : send_cmd
* Description    : send command to server with sock_fd
* Input          : sock_fd: socket id  p_cmd:cmd  p_param: the param of the cmd
* Output         : NONE
* Return         : 0:  success  -1: failed
*******************************************************************************/
int send_cmd(const char *pCmd, const char *pParam, int iSockFd)
{
	char pSendBuf[256];
	int iSendErr = 0;
	int iLen = 0;
	char *pTmp;

	if (NULL == pCmd || iSockFd < 0)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}

	bzero(pSendBuf, sizeof(pSendBuf));
	
	if (pCmd)
	{
		strcpy(pSendBuf, pCmd);
		if (pParam)
		{	
			strcat(pSendBuf, pParam);
			strcat(pSendBuf, "\r\n");
			iLen = strlen(pSendBuf);
			pTmp = pSendBuf;
			while (iLen > 0)
			{
				iSendErr = send(iSockFd, pTmp, iLen, 0);
				//LOG_INF("has writen %d bytes,not written %d bytes\n", iSendErr, iLen - iSendErr);
				if (iSendErr < 0)
				{
					LOG_INF("send_cmd error,%s!\n", strerror(errno));
					return -1;
				}	
				iLen = iLen - iSendErr;
				pTmp = pTmp + iSendErr;
				usleep(5000); // sleep 5ms
			}
			//LOG_INF("send_cmd %s,OK!\n", pCmd);
		}
		else 
		{
			strcat(pSendBuf, "\r\n");
			iLen = strlen(pSendBuf);
			pTmp = pSendBuf;
			while (iLen > 0)
			{
				iSendErr = send(iSockFd, pTmp, iLen, 0);
				//LOG_INF("has writen %d bytes,not written %d bytes\n", iSendErr, iLen - iSendErr);
				if (iSendErr < 0)
				{
					LOG_ERR("send_cmd error,%s!\n", strerror(errno));
					return -1;
				}
				iLen = iLen - iSendErr;
				pTmp = pTmp + iSendErr;
				usleep(5000); // sleep 5ms
			}
			//LOG_INF("send_cmd %s,OK!\n", pCmd);
		}
	}
	
	return 0;
}
/*******************************************************************************
* Function Name  : get_reply
* Description    : get the server's reply message 
* Input          : sock_fd: socket id
* Output         : NONE
* Return         : -1:on error  n: the reply number
*******************************************************************************/
int get_reply(int iSockFd)
{
	static int iReplyCode = 0,iCount=0;
	char pRcvBuf[512];
	if (iSockFd<0)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}
	bzero(pRcvBuf, sizeof(pRcvBuf));
	iCount = read(iSockFd, pRcvBuf, 510);
	pRcvBuf[iCount] = '\0';
	//LOG_INF("get_reply:%s", pRcvBuf);
	if (iCount > 0)
		iReplyCode = atoi(pRcvBuf);
	else
	{
		LOG_INF("the i_count = %d,i_sock_fd=%d,%s\n", iCount, iSockFd, strerror(errno));
		return -1;
	}
	
	return iReplyCode;
}
/*******************************************************************************
* Function Name  : get_port
* Description    : get the port of the server in PASV mode
* Input          : NONE
* Output         : NONE
* Return         : the port number
*******************************************************************************/
int get_port(void)
{
	char pPortRespond[512];
	char *pBuf = NULL;
	int iCount = 0;
	int iPortNum = 0;

	bzero(pPortRespond, sizeof(pPortRespond));
	
	send_cmd("PASV", NULL, iSockControl);
	iCount = read(iSockControl, pPortRespond, 510);
	if (iCount <= 0)
		return 0;
	pPortRespond[iCount] = '\0';
	if (atoi(pPortRespond) == 227)
	{
		
		pBuf = strrchr(pPortRespond, ',');    //get low byte of the port
		iPortNum = atoi(pBuf + 1);
		*pBuf = '\0';
		
		pBuf = strrchr(pPortRespond, ',');    //get high byte of the port
		iPortNum += atoi(pBuf + 1) * 256;
		return iPortNum;
	}
	return 0;
}


/*******************************************************************************
* Function Name  : connect_ftpdata
* Description    : connect data stream
* Input          : NONE
* Output         : NONE
* Return         : 0:  success  -1: failed
*******************************************************************************/
int connect_ftpdata(void)
{
	int iDataPort = 0;
	iDataPort = get_port();
	if (iDataPort != 0)
	{
		stFtpServer.sin_port = htons(iDataPort);
	}
	return(connect_sock(&stFtpServer, 0));

}
/*******************************************************************************
* Function Name  : get_filename
* Description    : get the source file name and des file name of the cmd
* Input          : p_usr_cmd :the string of the get cmd of ftp
* Output         : p_src_file:the source file name ;p_dst_file: the des file name
* Return         : NONE
*******************************************************************************/
void get_filename(char * pUsrCmd, char * pSrcFile, char * pDstFile)
{
	int iLength = 0;
	int iFlag = 0;
	int i = 0, j = 0;
	char * pCmdSrc = NULL;
	pCmdSrc = strchr(pUsrCmd, ' ');
	if (pCmdSrc == NULL)
	{
		LOG_ERR("command error!\n");
		return;
	}
	else
	{
		while (*pCmdSrc == ' ')
			pCmdSrc++;
	}
	if (pCmdSrc == NULL || pCmdSrc == '\0')
	{
		LOG_ERR("command error!\n");
		return;
	}
	else
	{
		iLength = strlen(pCmdSrc);
		while (i <= iLength)//be careful with space in the filename
		{
			if ((*(pCmdSrc + i)) != ' ' && (*(pCmdSrc + i)) != '\\')
			{
				if (iFlag == 0)
					pSrcFile[j] = *(pCmdSrc + i);
				else
					pDstFile[j] = *(pCmdSrc + i);
				j++;
			}
			if ((*(pCmdSrc + i)) == '\\' && (*(pCmdSrc + i + 1)) != ' ')
			{
				if (iFlag == 0)
					pSrcFile[j] = *(pCmdSrc + i);
				else
					pDstFile[j] = *(pCmdSrc + i);
				j++;
			}
			if ((*(pCmdSrc + i)) == ' ' && (*(pCmdSrc + i - 1)) != '\\')
			{
				pSrcFile[j] = '\0';
				iFlag = 1;
				j = 0;
			}
			if ((*(pCmdSrc + i)) == '\\' && (*(pCmdSrc + i + 1)) == ' ')
			{
				if (iFlag == 0)
					pSrcFile[j] = ' ';
				else
					pDstFile[j] = ' ';
				j++;
			}
			i++;
		};
	}
	if (iFlag == 0)
		strcpy(pDstFile, pSrcFile);
	else
		pDstFile[j] = '\0';
}
/*******************************************************************************
* Function Name  : get_file
* Description    : download the file from the server
* Input          : p_usr_cmd :the string of the get cmd of ftp
* Output         : NONE
* Return         : 0 :success -1:error
*******************************************************************************/
int get_file(char * pUsrCmd)
{
	int iGetSock = 0;
	char pSrcFile[512];
	char pDstFile[512];
	char pRcvBuf[512];
	int iLocalFile = 0;
	int iCount = 0;
	char *pTmp;
	int iWriteCount = 0;
	int iReplyCode = 0;
	bzero(pSrcFile, sizeof(pSrcFile));
	bzero(pDstFile, sizeof(pDstFile));
	bzero(pRcvBuf, sizeof(pRcvBuf));
	
	get_filename(pUsrCmd, pSrcFile, pDstFile);
	send_cmd("SIZE ", pSrcFile, iSockControl);
	if (get_reply(iSockControl) != 213)
	{
		LOG_ERR("SIZE COMMAND error,%s!\n",strerror(errno));
		return -1;
	}

	iLocalFile = open(pDstFile, O_CREAT | O_TRUNC | O_WRONLY, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
	if (iLocalFile < 0)
	{
		LOG_ERR("creat local file %s error,%s!\n", pDstFile, strerror(errno));
		return -1;
	}
	iGetSock = connect_ftpdata();
	if (iGetSock < 0)
	{
		LOG_ERR("socket error,the i_get_sock is %d!\n", iGetSock);
		return -1;
	}
	send_cmd("TYPE I", NULL, iSockControl);
	if (get_reply(iSockControl) != 200)
	{
		LOG_ERR("TYPE I COMMAND error,%s!\n", strerror(errno));
		return -1;
	}
	send_cmd("RETR ", pSrcFile, iSockControl);
	iReplyCode = get_reply(iSockControl);
	if ((iReplyCode != ENABLE) && (iReplyCode != ALREADY))
	{
		LOG_ERR("RETR COMMAND error,%s!\n", strerror(errno));
		return -1;
	}
	while(1)
	{
		iCount = read(iGetSock, pRcvBuf, sizeof(pRcvBuf));
		if (iCount <= 0)
			break;
		else
		{
			pTmp = pRcvBuf;
			while (iCount > 0)
			{
				iWriteCount = write(iLocalFile, pTmp, iCount);
				if (iWriteCount < 0)
				{
					LOG_ERR("ERROR:write data to %s failed\n", iLocalFile);
					fsync(iLocalFile);
					close(iLocalFile);
					close(iGetSock);
					return -1;
				}
				iCount = iCount - iWriteCount;
				pTmp = pTmp + iWriteCount;
				//usleep(5000); //sleep 5ms
			}
			
		}
	}
	fsync(iLocalFile);
	close(iLocalFile);
	close(iGetSock);
	if (get_reply(iSockControl) != 226)
	{
		LOG_WRN("warning:get ftp data reply \n");
		//return -1;
	}
	
	if (!chmod(pSrcFile, 0644))
	{
		LOG_INF("chmod %s to 0644\n", pDstFile);
		return 0;
	}
	else
	{
		LOG_ERR("chmod %s to 0644 error,%s!\n", pDstFile, strerror(errno));
		return -1;
	}

	
}

/*******************************************************************************
* Function Name  : quit_server
* Description    : disconnect to server
* Input          : NONE
* Output         : NONE
* Return         : NONE
*******************************************************************************/
void quit_server(void)
{
	if (send_cmd("QUIT", NULL, iSockControl) < 0)
	{
		close(iSockControl);
		return ;
	}	
	if (get_reply(iSockControl) != 221)
	{
		LOG_WRN("Not normal quit the FTP connect\n");
	}
	else
		LOG_INF("Normal quit the FTP connect\n");
	close(iSockControl);
	
}
/*******************************************************************************
* Function Name  : login_server
* Description    : login the ftp server
* Input          : NONE
* Output         : NONE
* Return         : 0:  success  -1: failed
*******************************************************************************/
int login_server(void)
{
	int iReplyCode = 0;
	char pUser[MAXLINE];
	char pPassword[MAXLINE];
	bzero(pUser, sizeof(pUser));
	bzero(pPassword, sizeof(pPassword));
	
	if (ini_read(UPDATA_CONF,FTP_SECTION, "user", pUser,sizeof(pUser)) != 0)
	{
		LOG_ERR("ini_read user error\n");
		return -1;
	}
	if (send_cmd("USER ", pUser, iSockControl) < 0)
	{
		LOG_ERR("Can not send message:%s\n",strerror(errno));
		return -1;
	}
	iReplyCode = get_reply(iSockControl);
	if (iReplyCode != USERNAMEOK)
	{
		LOG_ERR("User error!\n");
		return -1;
	}
	if (ini_read(UPDATA_CONF,FTP_SECTION, "password", pPassword,sizeof(pPassword)) != 0)
	{
		LOG_ERR("ini_read user error\n");
		return -1;
	} 
	if (send_cmd("PASS ", pPassword, iSockControl) < 0)
	{
		LOG_ERR("Can not send message,%s\n",strerror(errno));
		return -1;
	}	
	iReplyCode = get_reply(iSockControl);
	if (iReplyCode != LOGGEDINOK)
	{
		LOG_ERR("Password error!,i_err is %d\n", iReplyCode);
		return -1;
	}
	return 0;	
}

/*******************************************************************************
* Function Name  : download_app
* Description    : download_app the app  from the server
* Input          : p_crc32: the crc of the app
* Output         : NONE
* Return         : 0:  success  -1: failed
*******************************************************************************/
int download_app(const char *pCrc32,const char *pAppName,bool bWgetResult)
{
	unsigned int iCrc32 = 0;
	int iDownloadCount = DOWNLOAD_MAX_COUNT;
	
	char pGetCmd[MAXLINE + CMDSIZE] = {0};
	
	sprintf(pGetCmd, "%s %s", "get", pAppName);
	if (false == g_bMmAppWgetOK)//by tiger.101
		LOG_INF("begin download the %s\n", pAppName);
	while ((iCrc32 != strtoul(pCrc32, NULL, 0)) && (--iDownloadCount>=0))
	{
		if (false == bWgetResult)//by tiger.101
		{
			if (get_file(pGetCmd) < 0) return -1;
		}		
		iCrc32 = get_crc(pAppName);
	}
	if (iDownloadCount >= 0)
	{
		LOG_INF("[%dth] download %s success\n", (DOWNLOAD_MAX_COUNT-iDownloadCount), pAppName);
	}
	else
	{
		unlink(pAppName);
		LOG_WRN("%d count download  failed,the crc is wrong!\n", (DOWNLOAD_MAX_COUNT - iDownloadCount));
		return  -1;
		
	}
	return 0;	
}

/*******************************************************************************
* Function Name  : exec_app
* Description    : exec the app that download from the server
* Input          : NONE
* Output         : NONE
* Return         : NONE
*******************************************************************************/
void exec_app(void)
{
	char cPwd[MAXLINE];
	struct stat stFileInfo;
	char pUpdateScript[MAXLINE];
	char pUpdateCmd[MAXLINE+12];
	char pAppName[MAXLINE];
	
	bzero(cPwd, sizeof(cPwd));
	bzero(pUpdateScript, sizeof(pUpdateScript));
	bzero(pUpdateCmd, sizeof(pUpdateCmd));
	bzero(pAppName, sizeof(pAppName));
	bzero(&stFileInfo, sizeof(struct stat));
	
	if (ini_read(UPDATA_CONF, FTP_SECTION,"app_name", pAppName,sizeof(pAppName)) != 0)
	{
		LOG_ERR("ini_read cwd error\n");
		return;
	}
	if (!(stat(pAppName, &stFileInfo)))
	{
		if (!chmod(pAppName, 0777))
		{
			LOG_INF("chmod %s to 0777\n", pAppName);

			if (ini_read(UPDATA_CONF,FTP_SECTION, "pwd", cPwd,sizeof(pAppName)) != 0)
			{
				LOG_ERR("ini_read pwd error\n");
				return;

			}
			if (chdir(cPwd) < 0)/*change current work director*/
			{
				LOG_ERR("change the current dir to %s\n", cPwd);
				return;
			}

			if (ini_read(UPDATA_CONF, FTP_SECTION,"update_script", pUpdateScript,sizeof(pUpdateScript)) != 0)
			{
				LOG_ERR("ini_read updata_script error\n");
				return;
			}
			quit_server();    //disconnect ftp server
			sprintf(pUpdateCmd, "sudo /bin/sh %s", pUpdateScript);
			LOG_INF("Start the new master app\n");
			if (system(pUpdateCmd) < 0)
			{
				LOG_WRN("function system error:\n");
			}

			exit(0);
		}
		else
		{
			LOG_ERR("chmod  error!\n");
			
		}
	}
	return ;
}

/*******************************************************************************
* Function Name  : connect_server
* Description    : connect the server and login
* Input          : i_port: the port of the network
* Output         :NONE
* Return         : 0:  success  -1: failed
*******************************************************************************/
int connect_server(int iPort)
{
	int iErr = 0;
	char pServerIp[MAXLINE];
	int iRet = 0;

	bzero(pServerIp, sizeof(pServerIp));

	if (ini_read(UPDATA_CONF, FTP_SECTION, "ftp_serverip", pServerIp, sizeof(pServerIp)) != 0)
	{
		LOG_ERR("ini_read ftp_serverip error\n");
		return -1;
	}
	LOG_INF("the ftp server ip is :%s\n", pServerIp);

	iErr = fill_host_addr(pServerIp, &stFtpServer, iPort);
	if (iErr == 254)
	{
		LOG_ERR("Invalid port! %d\n", 254);
		return -1;
	}

	if (iErr == 253)
	{
		LOG_ERR("Invalid server address! %d\n", 253);
		return -1;
	}
	if (bPreTimeOut == false) //by tiger.05
	{
		iSockControl = connect_sock(&stFtpServer, 1);
		if ((iErr = get_reply(iSockControl)) != 220)
		{
			LOG_ERR("Connect error! %d\n", 220);
			return -1;
		}
	}
	else
	{
		LOG_ERR("not connect ftp server,becase connect server timeout last time\n"); // by tiger.05
		return -1;
	}

	iRet = login_server();
	return iRet;
}

/*******************************************************************************
* Function Name  : lcd_cmd
* Description    : change local directory
* Input          : usr_cmd : lcd cmd
* Output         : NONE
* Return         : NONE
*******************************************************************************/
void lcd_cmd(char * pUsrCmd)
{
	char *pCmd = strchr(pUsrCmd, ' ');
	char pPath[MAXLINE];

	bzero(pPath, sizeof(pPath));
	
	if (pCmd == NULL)
	{
		LOG_ERR("command error!\n");
		return;
	}
	else
	{
		while (*pCmd == ' ')
			pCmd++;
	}
	if (pCmd == NULL || pCmd == '\0')
	{
		LOG_ERR("command error!\n");
		return;
	}
	else
	{
		strncpy(pPath, pCmd, strlen(pCmd));
		pPath[strlen(pCmd)] = '\0';
		if (chdir(pPath) < 0)
			LOG_ERR("Local: chdir to %s error!\n", pPath);
		//else
		//	LOG_INF("Local: chdir to %s\n", pPath);
	}
}


/*******************************************************************************
* Function Name  : get_version_crc
* Description    : get the version and crc from the server
* Input          : NONE
* Output         : p_version;app's version;   p_crc32:the crc value of the app
* Return         : 0:success -1:failed
*******************************************************************************/
int get_version_crc(char *pVersion, char *pCrc32)
{
	char pLcdCmd[MAXLINE + CMDSIZE];
	bzero(pLcdCmd, sizeof(pLcdCmd));
	bzero(pLcd, sizeof(pLcd));
	bzero(pVersionPath, sizeof(pVersionPath));

	if (ini_read(UPDATA_CONF, FTP_SECTION, "lcd", pLcd, sizeof(pLcd)) != 0)
	{
		LOG_ERR("ini_read lcd error\n");
		return -1;
	}
	if (opendir(pLcd) == NULL)
	{
		if (mkdir(pLcd, S_IRWXU | S_IROTH | S_IWOTH | S_IRWXG) != 0)
		{
			LOG_ERR("mkdir error\n");
			return -1;
		}
	}
	sprintf(pLcdCmd, "%s %s", "lcd", pLcd);
	lcd_cmd(pLcdCmd);    //set download path
	if (false == g_bMmAppWgetOK)//by tiger.101 
	{
		if (get_file("get version.txt") < 0) return -1;
	}
	
	sprintf(pVersionPath, "%s%s", pLcd, "/version.txt");
	///read the server's version
	if (ini_read(pVersionPath, NULL, "version", pVersion, MAXLINE) != 0)
	{
		LOG_ERR("ini_read cwd error\n");
		return -1;
	}
	if (ini_read(pVersionPath, NULL, "CRC", pCrc32, MAXLINE) != 0)
	{
		LOG_ERR("ini_read CRC error\n");
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name  : start_ftp_cmd
* Description    : report update_success
* Input          : port: server's network port
* Output         : null
* Return         : 0: the app is latest version; -1:error
*******************************************************************************/
int start_ftp_cmd(unsigned int iPort)
{
	int iRet = 0;
	char pPwd[MAXLINE];
	char pVersionNew[MAXLINE];
	char pVersionCurent[MAXLINE];
	char pCrc32String[MAXLINE];
	char pTmp[MAXLINE];
	char pAppName[MAXLINE];
	struct stat stFileInfo;
	bzero(pAppName, sizeof(pAppName));
	bzero(pVersionNew, sizeof(pVersionNew));
	bzero(pCrc32String, sizeof(pCrc32String));
	bzero(pVersionCurent, sizeof(pVersionCurent));
	bzero(pPwd, sizeof(pPwd));
	bzero(pTmp, sizeof(pTmp));
	bzero(&stFileInfo, sizeof(struct stat));
	///add wget update,start by tiger.101 
	g_bMmAppWgetOK = false;
	iRet = wget_download_file(MM_APP_URL, MM_TGZ, TRY_5_TIMES);
	LOG_INF("wget %s %s\n", MM_TGZ, (0 == iRet)?"Success":"Failed");
	if (0 == iRet)
	{
		iRet = wget_untar_file(MM_TGZ, MASTER_FILE_PATH);
		if (iRet < 0) 
			g_bMmAppWgetOK = false;
		LOG_INF("untar %s %s\n", MM_TGZ, (g_bMmAppWgetOK == true) ? ("Success") : ("Failed"));
	}	
	///add wget update,end by tiger.101 
	if ((false == g_bMmAppWgetOK) && (connect_server(iPort)) != 0)//by tiger.101 
	{		
		return -1;
	}	
	///save the current work director
	if (getcwd(pPwd, sizeof(pPwd)) == NULL)
	{
		LOG_ERR("getcwd error!\n");
		return -1;
	}
	else
	{
		LOG_INF("pwd = %s\n", pPwd);
	}
	///get the version and crc
	if (get_version_crc(pVersionNew, pCrc32String) != 0)
	{
		iRet = -1;
		LOG_ERR("download version from ftp server failed \n");
		goto out_no_update;
	}	
	///read the current version
	
	if (ini_read(UPDATA_CONF, FTP_SECTION, "cwd", pTmp, sizeof(pTmp)) != 0)
	{
		LOG_ERR("ini_read cwd error \n");
		return -1;
	}
	if (!(stat(pTmp, &stFileInfo)))
	{
		strcat(pTmp, "/version.txt");
		if (ini_read(pTmp, NULL, "version", pVersionCurent, sizeof(pVersionCurent)) != 0)
		{
			LOG_ERR("ini_read c_version_new_tab error \n");
			return -1;
		}
	}
	else
	{
		strcpy(pVersionCurent, INITIAL_VERSION);
	}
	LOG_INF("the curren version is:%s \n", pVersionCurent);
	///update the app 
	if (strcmp(pVersionNew, pVersionCurent) > 0)
	{
		LOG_INF("the server version is:%s,the curren version is:%s\n", pVersionNew, pVersionCurent);
	
		if (ini_read(UPDATA_CONF,FTP_SECTION, "app_name", pAppName,sizeof(pAppName)) != 0)
		{
			LOG_ERR("ini_read cwd error\n");
			return -1;
		}
		if ((download_app(pCrc32String,pAppName,g_bMmAppWgetOK)) == -1)
		{
			iRet = -1;
			goto out_no_update;
		}
		else
		{
			exec_app();
		}
	}	

	
out_no_update:
	/// no need to update ,remove the version.txt 
	if (chdir(pLcd) < 0)
	{
		LOG_ERR("chdir error \n");
		return -1;
	}
	unlink(pVersionPath);
	if (ini_read(UPDATA_CONF, FTP_SECTION, "app_name", pAppName, sizeof(pAppName)) != 0) //add by tiger.06
	{
		LOG_ERR("ini_read cwd error\n");
		return -1;
	}
	else
	{
		unlink(pAppName);
	}
	if (rmdir(pLcd) < 0)
	{
		LOG_ERR("rmdir error:\n");
		return -1;
	}
			
	
	if (chdir(pPwd) < 0)    //reset the work director
	{
		LOG_ERR("chdir error\n");
		return -1;
	}
	return 0; //by tiger.106
}
/*******************************************************************************
* Function Name  : copy_file
* Description    : copy source file to the des file
* Input          : source : file name of the source file
* Output         : des;file name of the destination file
* Return         : 0: copy success -1:failed
*******************************************************************************/
int copy_file(const char *pSource,const char*pDes)
{
	char pTmp = 0;
	FILE *pSourceFp = NULL, *pDesFp = NULL;
	int iFd = 0;
	if ((pSourceFp = fopen(pSource, "rb")) == NULL)		return -1;

	if ((pDesFp = fopen(pDes, "wb")) == NULL) return -1;
	
	while (!feof(pSourceFp))
	{
		pTmp = fgetc(pSourceFp);
		fputc(pTmp, pDesFp);
	}		
	iFd = fileno(pDesFp);
	fsync(iFd);
	fclose(pSourceFp);
	fclose(pDesFp);

	return 0;
}
/*******************************************************************************
* Function Name  : report_update
* Description    : report update_success
* Input          : None
* Output         : None
* Return         : 0:need report to server; 1: need check version; -1:error 
*******************************************************************************/
int report_update(void)
{
	struct stat stFileInfo;
	char pPwd[MAXLINE];

	bzero(&stFileInfo, sizeof(struct stat));
	bzero(pPwd, sizeof(pPwd));
	sleep(2);    //wait the older app exit
	if (ini_read(UPDATA_CONF,FTP_SECTION, "pwd", pPwd,sizeof(pPwd)) != 0)
	{
		LOG_ERR("ini_read pwd error\n");
		return -1;
	}
	 
	strcat(pPwd, "/update_success");
	if (!(stat(pPwd, &stFileInfo)))
	{
		LOG_INF("update success \n");
		if (unlink(pPwd) != 0)
		{
			LOG_WRN("unlink update_success failed\n");
			return -1;
		}
		return 0;
	} 
	return  1;
}

/*******************************************************************************
* Function Name  : update_app
* Description    : ftp update_app
* Input          : None
* Output         : None
* Return         : int:0: app is the latest version ;1:update success -1:error  
*******************************************************************************/
int update_app(void)
{
 
	char pPwd[MAXLINE];
	char pCwd[MAXLINE];
	char pAppName[MAXLINE];
	int iFd = -1;
	struct stat stInfo = { 0 };

	if (stat(UPDATA_MASTER_DIR, &stInfo) == 0)//by tiger.44
		exec_app();

	if (report_update() == 0)
	{
		if (ini_read(UPDATA_CONF,FTP_SECTION, "pwd", pPwd,sizeof(pPwd)) != 0)
		{
			LOG_ERR("ini_read pwd error \n");
			return;

		}
		if (ini_read(UPDATA_CONF,FTP_SECTION, "cwd", pCwd,sizeof(pCwd)) != 0)
		{
			LOG_ERR("ini_read cwd error\n");
			return;
		}

		if (ini_read(UPDATA_CONF,FTP_SECTION, "app_name", pAppName,sizeof(pAppName)) != 0)
		{
			LOG_ERR("ini_read app_name error\n");
			return;

		}
		strcat(pPwd, "/");
		strcat(pCwd, "/");
		strcat(pPwd, pAppName);
		strcat(pCwd, pAppName);
		unlink(pPwd);
		LOG_INF("********begin copy app *****\n");
		while (copy_file(pCwd, pPwd) != 0)     //copy the app to the install dir
		{
			LOG_WRN("copy_file error \n");
			sleep(1);
		}
		LOG_INF("********end copy app *****\n");
		if (!chmod(pPwd, S_IRWXU | S_IRWXG | S_IRWXO))
		{
			LOG_INF("chmod %s to 0777\n", pPwd);
			iFd = open(pPwd, O_RDWR);
			fsync(iFd);
			close(iFd);
			LOG_INF("update %s success!\n", pAppName);
			return 1;
		}
		else
		{
			LOG_WRN("error:chmod %s to 0777 error!!!\n", pPwd);
		}

	}
	else
	{
		if (start_ftp_cmd(DEFAULT_FTP_PORT) == 0)
		{
			LOG_INF("The app is the latest version\n");
			quit_server();
			return 0;
		}
		else
		{
			LOG_WRN("update failed\n");
			return -1;
			//quit_server(); //modified by tiger.06,if network disconnect,then not quit_server(),becasue maybe the connect has been reset 
		}
	}

}

/*******************************************************************************
*Function Name    :ftp_get_mc_log
*Description      :  
*Input       	  :enMcLogType eRamType:1,2,3,....  
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error,-2:need not get log ,else error code value  
*******************************************************************************/
int ftp_get_mc_log(enMcLogType eRamType)
{
	
	int iRet = -1, iPreSize = 0,i = 0;
	int iFdMcLog = -1;  //fd of /var/log/McFlash.log
	int iRecvFrameCount = 0;
	char *pLogName[MC_LOG_TOTAL_TYPE+1] = {" ", "go walk", "make a turn", "get pgv" };//eRamType:1,2,3
	char *pRamAddr[MC_LOG_TOTAL_TYPE+1] = {" ", "go walk:0x150100", "make a turn:0x130000", "get pgv:0x140100" };
	int cFrameCount[MC_LOG_TOTAL_TYPE+1] = {0, 4000, 4000, 4 };
	time_t iTime;
	char pBuf[100] = {0}; //save current time
	agv_sem_t *pAgvSem = NULL;
	time(&iTime);
	struct tm *pLocalTime = localtime(&iTime);
	if ((iFdMcLog = open(MC_LOG_PATH, O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH)) == -1) //truncate to 0 length or create for writing
	{
		LOG_INF("create %s system error:%s", MC_LOG_PATH, strerror(errno));
		return -1;
	}
	if (strftime(pBuf, sizeof(pBuf), "%F %H:%M:%S", pLocalTime) < 0)
	{
		dprintf(iFdMcLog, "ERROR:%s", strerror(errno));
	}
	if (MC_LOG_TYPE_INVALID == eRamType ||0 == eRamType)
	{
		dprintf(iFdMcLog, "[%s]need not get MC RAM data \n", pBuf);
		close(iFdMcLog);
		return -2;
	}
	else if (eRamType > MC_LOG_TOTAL_TYPE)
	{
		LOG_INF("Not supported MC log type[%d] \n", eRamType);
		close(iFdMcLog);
		return -1;
	}
	LOG_INF("get [%s] ram data\n", pLogName[eRamType]);
	
	dprintf(iFdMcLog, "[%s]: ram address [%s] \n", pBuf, pRamAddr[eRamType]); //print time and address of ram
	dprintf(iFdMcLog, "The agv is [%d]th generation ,MC version is [%d],TC version is [%d]\n", g_stAgvAttr.iDSPGeneration + 1, g_stAgvAttr.iMcVersion, g_stAgvAttr.iTcVersion);
	dprintf(iFdMcLog, "\nSuccess create %s \n", MC_LOG_PATH);
	LOG_INF("send to can : get the MC flash log \n");
	pAgvSem = agv_sem_add(SEM_CAN_TYPE, SEM_MC_BASE + FTP_MC_CANFRAME_F, 0);
	if (NULL == pAgvSem)
	{
		LOG_ERR("add sem failed\n");
	}
	set_flag(DEV_MC, GET_MC_LOG_DATA, eRamType); //send get tc ram log CAN Frame
	iRet = agv_sem_wait(SEM_CAN_TYPE, SEM_MC_BASE + FTP_MC_CANFRAME_F, 0, TIME_OUT_4S);
	if (iRet < 0)
	{
		LOG_WRN("Get MC ram ACK time out\n");
		return -EVENT_ERR_MCCOMMUNISTOP;
	}
	agv_sem_clean(SEM_CAN_TYPE, SEM_MC_BASE + FTP_MC_CANFRAME_F, 0);
	dprintf(iFdMcLog, "Get MC ram ACK \n");
	g_stDspLog.bUploadFinish = false;
	g_stDspLog.iSize = 0;
	while (false == g_stDspLog.bUploadFinish) //wait for upload data finish
	{
		sleep(1);
		if ((g_stDspLog.iSize == iPreSize) && (false == g_stDspLog.bUploadFinish ))
		{
			LOG_ERR("Disconnect with MC during upload ram data\n");
			close(iFdMcLog);
			return -EVENT_ERR_MCCOMMUNISTOP;
		}
		iPreSize = g_stDspLog.iSize;
	}
	for (i = 0; i < g_stDspLog.iSize; i += 8) //write ram data to file
	{
		iRecvFrameCount++;
		dprintf(iFdMcLog, "%f  %f  ", *((float *)(g_stDspLog.u8RamData + i)), *((float *)(g_stDspLog.u8RamData + i + 4)));
		if (iRecvFrameCount % 5 == 0)
		{
			dprintf(iFdMcLog, " \n");
		}
	}
	dprintf(iFdMcLog, "\nSuccess receive %d and %d(expect) CAN frames of %s\n", iRecvFrameCount, cFrameCount[eRamType], pLogName[eRamType]);
	fsync(iFdMcLog);
	close(iFdMcLog);
	bzero(&g_stDspLog, sizeof(DspLog));
	return 0;
}

/*******************************************************************************
*Function Name    :ftp_get_tc_log
*Description      :  
*Input       	  :enTcLogType eRamType::1,2,...  
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error,-2:need not get log ,else error code value  
*******************************************************************************/
int ftp_get_tc_log(enTcLogType eRamType)
{
	int iFdTcLog = -1;  //fd of /var/log/McFlash.log
	char *pLogName[] = { " ", "make a turn" };
	char *pRamAddr[] = { " ", "make a turn:0x130000"};
	int cFrameCount[TC_LOG_TOTAL_TYPE+1] = {0, 2400 };
	time_t iTime;
	char pBuf[100]; //save current time
	int iPreSize = 0;
	int i, iRecvFrameCount = 0;
	int iRet = 0;
	agv_sem_t *pAgvSem = NULL;
	time(&iTime);
	struct tm *pLocalTime = localtime(&iTime);
	if ((iFdTcLog = open(TC_LOG_PATH, O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH)) == -1) //truncate to 0 length or create for writing
	{
		LOG_ERR("create %s system error:%s", TC_LOG_PATH, strerror(errno));
		return -1;
	}
	if (strftime(pBuf, sizeof(pBuf), "%F %H:%M:%S", pLocalTime) < 0)
	{
		dprintf(iFdTcLog, "ERROR:%s", strerror(errno));
	}
	if (TC_LOG_TYPE_INVALID == eRamType|| 0 == eRamType)
	{
		dprintf(iFdTcLog, "[%s]need not get TC RAM data \n", pBuf);
		close(iFdTcLog);
		return -2;
	}
	else if (eRamType > TC_LOG_TOTAL_TYPE)
	{
		LOG_ERR("Not supported TC log type[%d] \n", eRamType);
		close(iFdTcLog);
		return -1;
	}
	LOG_INF("get [%s] ram data\n", pLogName[eRamType]);	
	
	

	
	dprintf(iFdTcLog, "[%s]: ram address [%s] \n", pBuf, pRamAddr[eRamType]); //print time and address of ram
	dprintf(iFdTcLog, "The agv is [%d]th generation ,MC version is [%d],TC version is [%d]\n", s_iDspType[1] + 1, g_stAgvAttr.iMcVersion, g_stAgvAttr.iTcVersion);
	dprintf(iFdTcLog, "Success create %s \n", TC_LOG_PATH);
	LOG_INF("send to can : get the TC flash log \n");
	pAgvSem = agv_sem_add(SEM_CAN_TYPE, SEM_TC_BASE + FTP_TC_CANFRAME_F, 0);
	if (NULL == pAgvSem)
	{
		LOG_ERR("add sem failed\n");
	}
	set_flag(DEV_TC, GET_TC_LOG_DATA, eRamType); //send get tc ram log CAN Frame
	iRet = agv_sem_wait(SEM_CAN_TYPE, SEM_TC_BASE + FTP_TC_CANFRAME_F, 0, TIME_OUT_4S);
	if (iRet < 0)
	{
		LOG_WRN("get TC ram ACK time out\n");
		close(iFdTcLog);
		return -EVENT_ERR_TCCOMMUNISTOP;
	}
	agv_sem_clean(SEM_CAN_TYPE, SEM_TC_BASE + FTP_TC_CANFRAME_F, 0);
	dprintf(iFdTcLog, "Get ACK \n");
	g_stDspLog.bUploadFinish = false;
	g_stDspLog.iSize = 0;
	while (false == g_stDspLog.bUploadFinish) //wait for upload data finish
	{
		sleep(1);
		if ((g_stDspLog.iSize == iPreSize) && (false == g_stDspLog.bUploadFinish))
		{
			LOG_ERR("Disconnect with TC during upload ram data\n");
			close(iFdTcLog);
			return -EVENT_ERR_TCCOMMUNISTOP;
		}
		iPreSize = g_stDspLog.iSize;
	}
	for (i = 0; i < g_stDspLog.iSize;i+=8) //write ram data to file
	{
		iRecvFrameCount++;
		dprintf(iFdTcLog, "%f  %f  ", *((float *)(g_stDspLog.u8RamData + i)), *((float *)(g_stDspLog.u8RamData + i + 4)));
		if (iRecvFrameCount % 3 == 0)
		{
			dprintf(iFdTcLog, " \n");
		}
	}
	dprintf(iFdTcLog, "\nSuccess receive %d and %d(expect) CAN frames of %s\n", iRecvFrameCount, cFrameCount[eRamType], pLogName[eRamType]);
	fsync(iFdTcLog);
	close(iFdTcLog);
	bzero(&g_stDspLog, sizeof(DspLog));	
	return 0;
}
///end by tiger .37
///end by tiger.12

/*******************************************************************************
*Function Name    :print_get_log_result
*Description      :description of getting dsp log result   
*Input       	  :int iRet:the result value   
*Output 		  :NONE
*Return           :char*:the description string  
*******************************************************************************/
char* print_get_log_result(int iRet)
{
	char *pTmp = NULL;
	iRet = abs(iRet);
	switch (iRet)
	{
	case 0:
		pTmp = "Success";
		break;
	case 1:
		pTmp = "Error";
		break;
	case 2:
		pTmp = "Need not get log";
		break;
	default:
		pTmp = get_err_str(iRet);
		if (send_error_msg(EVENT_TYPE_ERROR, iRet) < 0)
		{
			LOG_ERR("append %s to udp Tx queue failed\n", *pTmp);
		}
		break;
	}
	return pTmp;
}
#define  SAVE_EXCEPTION_TIME 10 //unit: seconds
#define  NOT_NEED_GET_LOG   (-2)
#define	 MC_HEARTBEAT_MOVE_STOP 0
pthread_mutex_t stSaveLogMutex = PTHREAD_MUTEX_INITIALIZER;

/*******************************************************************************
*Function Name    :save_log_dsp
*Description      :save log of dsp ,including MC and TC  
*Input       	  :int iException:exception error number  
*Output 		  :NONE
*Return           :int:0 if OK , -1 on error  
*******************************************************************************/
int save_log_dsp(int iException)
{
	
	int pLogSize[DSP_LOG_NUM] = { 150, 100 };
	const char *pDir = "/log_tmp";
	const char *pRetDesc[] = { "Success", "Error", "Need not get log ", "The number of can frames is wrong" };
	int iRetMc = 0, iRetTc = 0;
	char log_num[10] = { 0 };
	char log_key[10] = { 0 };
	char *log_name = NULL;
	char *log_path = NULL;
	FILE *fp_src = NULL;
	FILE *fp_des = NULL;
	int iFd;
	char c_tmp = 0;
	char log_path_tmp[MAXLINE] = { 0 }; //save des log path
	char log_name_tab[MAXLINE] = { 0 };
	char i = 0;
	off_t offset = 0, lPreOffset = 0;
	struct stat st_file_info;
	time_t t;  //save the time
	char zip_name_tab[50] = { 0 }; //save the xxx.zip name:2017-06-08-21:00:00-3004-5(С����)
	char str_excpt[10] = { 0 };
	struct tm *tmp = NULL;
	char agv_name_tab[10] = { 0 }; //agv name skywolf=020

	char zip_cmd_tab[MAXLINE] = { 0 };
	char tmp_tab[MAXLINE] = { 0 };

	char *pLogName = NULL; //by tiger.12
	static time_t lPreTime = 0;
	iException = abs(iException);
	time_t lCurTime = 0;
	
	if (g_stAgvAttr.iAGVType == AGV2_0)
	{
		return 0;
	}
	time(&lCurTime);
	if (lCurTime - lPreTime < SAVE_EXCEPTION_TIME)
	{
		LOG_INF("not save %s and %s, because time between last and current exception < %ds\n", 
			MC_LOG_PATH, TC_LOG_PATH, SAVE_EXCEPTION_TIME);
		lPreTime = lCurTime;
		return -1;
	}
	lPreTime = lCurTime;
	pthread_mutex_lock(&stSaveLogMutex); //save_flag can not be reentrant, by tiger.12
	LOG_INF("%s\n", (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus) ? "AGV has shelf" : "AGV has not shelf");
	///start ,by tiger.12	

	///start by tiger.37
	int iTimeCounter = 0;
	///wait agv to be stop
	while ((g_stAgvAttr.iMoveStatus != agv_stop) &&(g_stAgvAttr.iMoveStatus != agv_charge)&&
		(EVENT_ERR_EMERSTOPPRESS != atomic_read(&g_stAgvAttr.iException)) && (iTimeCounter <= 60)//by tiger.67
		&& (g_stAgvAttr.iMcHeartBeatStatus != MC_HEARTBEAT_MOVE_STOP))//by tiger.61
	{
		sleep(1);
		iTimeCounter++;
		LOG_INF("before get dsp ram date,wait agv stop for %ds\n", iTimeCounter);
	}
	if (iTimeCounter > 60)
	{
		LOG_INF("wait agv stop time>%d,and abandon get dsp ram date\n", iTimeCounter);
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}

	
	if ((EVENT_ERR_CHARGECURSAMLL != iException) && (EVENT_ERR_PARKPRECISION != iException) && (EVENT_ERR_TPERR != iException))//tiger.21
	{
		iRetMc = ftp_get_mc_log(MC_LOG_TYPE_WALK);
		iRetMc = abs(iRetMc);
		LOG_INF("GET MC RAM DATA Result: %s\n", print_get_log_result(iRetMc));
		if (EVENT_ERR_PROCESTOPINVALID == iException)
		{
			iRetMc = ftp_get_mc_log(MC_LOG_TYPE_PGV);
			iRetMc = abs(iRetMc);
			LOG_INF("GET MC RAM DATA Result: %s\n", print_get_log_result(iRetMc));
		}
		iRetTc = ftp_get_tc_log(g_stAgvTask.stAction.eTcLogType);
		iRetTc = abs(iRetTc);
		LOG_INF("GET TC RAM DATA Result: %s\n", print_get_log_result(iRetTc));
	}
	if ((NOT_NEED_GET_LOG == iRetTc) && (NOT_NEED_GET_LOG == iRetMc))
	{
		LOG_INF("need not get TC and MC RAM data\n");
		return 0;
	}
///end by tiger.37		
	if (stat(pDir, &st_file_info) != 0)
	{
		if (mkdir(pDir, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH) != 0)
		{
			LOG_INF("Make %s error:%s", pDir, strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
	}
	for (i = 0; i < DSP_LOG_NUM; i++)
	{
		pLogName = strrchr(pDSPLogPath[i], '/');
		strcpy(log_name_tab, ++pLogName);
		///log1=/var/log/jdagv.log 100KB
		///log2=/var/log/McuLog.log 1KB
		bzero(log_path_tmp, sizeof(log_path_tmp));
		sprintf(log_path_tmp, "%s/%s", pDir, log_name_tab);  // the destination log name

		if ((fp_src = fopen(pDSPLogPath[i], "a+b")) == NULL)
		{
			LOG_INF("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
		iFd = fileno(fp_src);
		fsync(iFd);  //flush the data to the disk
		/// get the file size
		if (fseek(fp_src, 0, SEEK_END) != 0)
		{
			LOG_INF("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
		offset = ftell(fp_src);
		pLogSize[i] = pLogSize[i] * KB;
		if (offset < pLogSize[i]) pLogSize[i] = offset;
		if (0 == pLogSize[i])
		{
			pLogSize[i] = sizeof("there is not log in the file");
			fprintf(fp_src, "%s\n", "there is not log in the file");
		}
		///set the offset
		if (fseek(fp_src, -pLogSize[i], SEEK_END) != 0)
		{
			LOG_INF("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}

		if ((fp_des = fopen(log_path_tmp, "wb")) == NULL)
		{
			LOG_INF("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
		/// copy file
		while ((pLogSize[i] != 1) && (pLogSize[i] != 0)) 
		{
			c_tmp = fgetc(fp_src);
			fputc(c_tmp, fp_des);
			pLogSize[i]--;
		}
		fputc('\0', fp_des);
		/// truncate the file, if the size of file more than 32MB
		iFd = fileno(fp_des);
		offset = lseek(iFd,0,SEEK_END);
		if (offset >= (32 * 1024 * KB))
		{
			ftruncate(iFd,0);
		}
		fsync(iFd);
		fclose(fp_src);
		fclose(fp_des);
		bzero(log_path_tmp, sizeof(log_path_tmp));

	}
	///save the xxx.zip name:2017-06-08-21:00:00-3004-5(С����)
	time(&t);
	tmp = localtime(&t);
	strftime(zip_name_tab, sizeof(zip_name_tab), "%F-%H.%M.%S-", tmp);
	sprintf(str_excpt, "%d", iException);
	strcat(zip_name_tab, str_excpt);
	ini_read(UPDATA_CONF, "skywolf_conf", "skywolf", agv_name_tab, sizeof(agv_name_tab));
	strcat(zip_name_tab, "-");
	strcat(zip_name_tab, agv_name_tab);
	strcat(zip_name_tab, "-");
	strcat(zip_name_tab, "DSP");
	sprintf(zip_cmd_tab, "sudo tar -cPzf /%s.tgz %s --remove-files", zip_name_tab, pDir); //sudo zip -rvm ./test.zip test
	if (system(zip_cmd_tab) != 0)
	{
		LOG_INF("system cmd error:%s\n", strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}

	///sync the  /xxx.zip
	sprintf(tmp_tab, "/%s.tgz", zip_name_tab);//by tiger.80
	if (stat(tmp_tab, &st_file_info) != 0)
	{
		LOG_INF("%s is not exist:%s\n", tmp_tab, strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}
	if ((iFd = open(tmp_tab, O_RDWR)) < 0)
	{
		LOG_INF("open %s failed :%s\n", tmp_tab, strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}

	fsync(iFd);
	close(iFd);
	pthread_mutex_unlock(&stSaveLogMutex);
	return 0;
}
#define CORE_DUMP_FILE "/core.jdagv"

/*******************************************************************************
*Function Name    :save_log_coredump
*Description      :zip core.jdagv and jdagv to 2017-06-08-21:00:00-core-5.zip
					add by tiger.57
*Output 		  :
*Return           :int:0 if OK ; -1 on error  
*******************************************************************************/
int save_log_coredump()
{
	pthread_mutex_lock(&stSaveLogMutex); //save_flag can not be reentrant, by tiger.12
	const char *pDir = "/log_tmp";
	int i_fd;
	struct stat st_file_info;
	time_t t;  //save the time
	char zip_name_tab[50] = { 0 }; //save the xxx.zip name:2017-06-08-21:00:00-core-5.zip(С����)
	char str_excpt[10] = { 0 };
	struct tm *tmp = NULL;
	char agv_name_tab[10] = { 0 }; //agv name skywolf=020

	char zip_cmd_tab[MAXLINE] = { 0 };
	char tmp_tab[MAXLINE] = { 0 };

	static time_t lPreTime = 0;
	time_t lCurTime = 0;
	if (stat(CORE_DUMP_FILE, &st_file_info) != 0)
	{
		LOG_INF("have not happened core dump\n");
		pthread_mutex_unlock(&stSaveLogMutex); //save_flag can not be reentrant, by tiger.12
		return 0;
	}
	if (stat(pDir, &st_file_info) != 0)
	{
		if (mkdir(pDir, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH) != 0)
		{
			LOG_ERR("make %s failed:[%d-%s]\n", errno, strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
	}
	//copy file to /log_tmp
	if (system("mv /core.jdagv /log_tmp") != 0)
	{
		LOG_ERR("mv /core.jdagv /log_tmp failed:[%d-%s]\n",errno,strerror(errno));
	}
	if (system("cp /root/jdagvclientserver/jdagvserver/jdagv /log_tmp") != 0)
	{
		LOG_ERR("cp /root/jdagvclientserver/jdagvserver/jdagv /log_tmp failed:[%d-%s]\n", errno, strerror(errno));
	}
	///save the xxx.zip name:2017-06-08-21:00:00-core-5.zip(С����)
	time(&t);
	tmp = localtime(&t);
	strftime(zip_name_tab, sizeof(zip_name_tab), "%F-%H.%M.%S-", tmp);
	sprintf(str_excpt, "%s", "core");
	strcat(zip_name_tab, str_excpt);
	ini_read(UPDATA_CONF, "skywolf_conf", "skywolf", agv_name_tab, sizeof(agv_name_tab));
	strcat(zip_name_tab, "-");
	strcat(zip_name_tab, agv_name_tab);
	sprintf(zip_cmd_tab, "sudo tar -cPzf /%s.tgz %s --remove-files", zip_name_tab, pDir); //sudo zip -rvm ./test.zip test
	if (system(zip_cmd_tab) != 0)
	{
		LOG_INF("system cmd error:%s\n", strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}

	///sync the  /xxx.zip
	sprintf(tmp_tab, "/%s.tgz", zip_name_tab);//by tiger.80
	if (stat(tmp_tab, &st_file_info) != 0)
	{
		LOG_INF("%s is not exist:%s\n", tmp_tab, strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}
	if ((i_fd = open(tmp_tab, O_RDWR)) < 0)
	{
		LOG_INF("open %s failed :%s\n", tmp_tab, strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}

	fsync(i_fd);
	close(i_fd);
	///end ,by tiger.12
	pthread_mutex_unlock(&stSaveLogMutex);
	return 0;
}
/*******************************************************************************
* Function Name  : save_log_arm
* Description    : save log in the /log_tmp ,such as:source log1=/var/log/jdagv.log 100KB  des :20170608
				   save_flag can not be reentrant
* Input          : None
* Output         : None
* Return         : 0:success;  -1:failed
*******************************************************************************/
int save_log_arm(int iException)
{
	pthread_mutex_lock(&stSaveLogMutex); //save_flag can not be reentrant, by tiger.12
	int pLogSize[ARM_LOG_NUM] = { 600, 200, 10, 100, 100, 50,50,50,100,100}; 
	const char *pDir = "/log_tmp";
	char log_num[10];
	char log_key[10];
	char *log_name = NULL;
	char *log_path = NULL;
	FILE *fp_src = NULL;
	FILE *fp_des = NULL;
	int i_fd;
	char c_tmp = 0;
	char log_path_tmp[MAXLINE] = {0}; //save des log path
	char log_name_tab[MAXLINE] = { 0 };
	char i = 0;
	off_t offset = 0,lPreOffset = 0;
	struct stat st_file_info;
	time_t t;  //save the time
	char zip_name_tab[50] = { 0 }; //save the xxx.zip name:2017-06-08-21:00:00-3004-5(С����)
	char str_excpt[10] = { 0 };
	struct tm *tmp =NULL;
	char agv_name_tab[10] = { 0 }; //agv name skywolf=020
	
	char zip_cmd_tab[MAXLINE] = { 0 };
	char tmp_tab[MAXLINE] = { 0 };
	char pDmesgCmd[1024] = { 0 };
	
	char *pLogName = NULL; //by tiger.12
	static time_t lPreTime = 0;
	time_t lCurTime = 0;
	iException = abs(iException);

	LOG_INF("%s\n", (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus) ? "AGV has shelf" : "AGV has not shelf");
	//printf car veserion ,start by tiger.38
	char pARMVerion[32] = { 0 };
	if (ini_read(VERCRC_CONF,NULL, "version", pARMVerion,sizeof(pARMVerion)) != 0)//modified by tiger.06
	{
		LOG_INF("read %s version error\n", VERCRC_CONF);
	}
	LOG_INF("the master version is :%s,the [%d]th generation ,MC version is [%d],TC version is [%d]\n", pARMVerion, s_iDspType[1] + 1, g_stAgvAttr.iMcVersion, g_stAgvAttr.iTcVersion);
	///end by tiger.38

	if (stat(pDir, &st_file_info) != 0)
	{
		if (mkdir(pDir, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH) != 0)
		{
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
	}
	for (i = 0; i < ARM_LOG_NUM; i++)
	{
		pLogName = strrchr(pARMLogPath[i], '/');
		strcpy(log_name_tab, ++pLogName);
		///log1=/var/log/jdagv.log 100KB
		///log2=/var/log/McuLog.log 1KB
		bzero(log_path_tmp, sizeof(log_path_tmp));
		sprintf(log_path_tmp, "%s/%s", pDir, log_name_tab);  // the destination log name

		if ((fp_src = fopen(pARMLogPath[i], "a+b")) == NULL)
		{
			LOG_INF("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
		i_fd = fileno(fp_src);
		fsync(i_fd);  //flush the data to the disk
		/// get the file size
		if (fseek(fp_src, 0, SEEK_END) != 0)
		{
			LOG_INF("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
		offset = ftell(fp_src);
		pLogSize[i] = pLogSize[i] * KB;
		if (offset < pLogSize[i]) pLogSize[i] = offset;
		if (0 == pLogSize[i])
		{
			pLogSize[i] = sizeof("there is not log in the file");
			fprintf(fp_src, "%s\n", "there is not log in the file");
		}
		///set the offset
		if (fseek(fp_src, -pLogSize[i], SEEK_END) != 0) 
		{
			LOG_INF("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
		
		if ((fp_des = fopen(log_path_tmp, "wb")) == NULL) 
		{
			LOG_INF("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
		while ((pLogSize[i] != 1) && (pLogSize[i] != 0)) // copy file
		{
			c_tmp = fgetc(fp_src);
			fputc(c_tmp, fp_des);
			pLogSize[i]--;
		}
		fputc('\0', fp_des);
		i_fd = fileno(fp_des);
		fsync(i_fd);
		fclose(fp_src);
		fclose(fp_des);
		bzero(log_path_tmp, sizeof(log_path_tmp));

	}
	if (EVENT_ERR_NETWORK_DISCONNECT == iException || NO_EVENT_ERR == iException) //������ʱ����Ҫ�ں���־
	{
// 		sprintf(pDmesgCmd, "dmesg > %s/dmesg.txt && cat /etc/version >> %s/dmesg.txt \
// 				&& wl roam_delta >> %s/dmesg.txt&& wl rssi >> %s/dmesg.txt\
// 				&&ifconfig wlan0 down", pDir,pDir,pDir,pDir);
		sprintf(pDmesgCmd, "dmesg > %s/dmesg.txt && cat /etc/version >> %s/dmesg.txt \
						   && wl roam_delta >> %s/dmesg.txt && wl rssi >> %s/dmesg.txt", pDir, pDir, pDir, pDir);
		if (system(pDmesgCmd) < 0)
		{
			LOG_WRN("execute cmd failed:%s\n",pDmesgCmd);
		}
		if (NO_EVENT_ERR == iException)
		{

			sprintf(pDmesgCmd, "tar -zcPf /log_tmp/AllLog.tgz  ");
			for (i = 0; i < ARM_LOG_NUM; i++)
			{
				if (stat(pARMLogPath[i], &st_file_info) == 0)
				{
					strcat(pDmesgCmd, " ");
					strcat(pDmesgCmd, pARMLogPath[i]);
				}
				if (stat(pARMLogOldPath[i], &st_file_info) == 0)
				{
					strcat(pDmesgCmd, " ");
					strcat(pDmesgCmd, pARMLogOldPath[i]);
				}
			}
				
			if (system(pDmesgCmd) < 0)
			{
				LOG_WRN("execute cmd failed:%s\n", pDmesgCmd);
			}				   			
		}
	}
	///save the xxx.zip name:2017-06-08-21:00:00-3004-5(С����)
	time(&t);
	tmp = localtime(&t);
	strftime(zip_name_tab, sizeof(zip_name_tab), "%F-%H.%M.%S-", tmp);
	sprintf(str_excpt, "%d", iException);
	strcat(zip_name_tab, str_excpt);
	ini_read(UPDATA_CONF,"skywolf_conf", "skywolf", agv_name_tab,sizeof(agv_name_tab));
	strcat(zip_name_tab, "-");
	strcat(zip_name_tab, agv_name_tab);
	strcat(zip_name_tab, "-");
	strcat(zip_name_tab, "ARM");
	sprintf(zip_cmd_tab, "sudo tar -cPzf /%s.tgz %s --remove-files", zip_name_tab, pDir); //sudo zip -rvm ./test.zip test
	if (system(zip_cmd_tab) != 0)
	{
		LOG_INF("system cmd error:%s\n", strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}
	
	///sync the  /xxx.zip
	sprintf(tmp_tab, "/%s.tgz", zip_name_tab);//by tiger.80
	if (stat(tmp_tab, &st_file_info) != 0)
	{
		LOG_INF("%s is not exist:%s\n", tmp_tab, strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}
	if ((i_fd = open(tmp_tab, O_RDWR)) < 0)
	{
		LOG_INF("open %s failed :%s\n", tmp_tab, strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}
		
	fsync(i_fd);
	close(i_fd);
	///end ,by tiger.12
	pthread_mutex_unlock(&stSaveLogMutex);
	return 0;
}

/*******************************************************************************
* Function Name		: match
* Description		: if the string match the pattern ,return 0;else return 1
* Input          	: string: th
* Output			: None 
* Return			: 0:match success;  -1:match failed
*******************************************************************************/
int match( char *string,const char *pattern)
{
	int    status;
	regex_t    re;
	if (regcomp(&re, pattern, REG_EXTENDED | REG_NOSUB) != 0) {
		return -1;      /* Report error. */
	}
	status = regexec(&re, string, (size_t)0, NULL, 0);
	regfree(&re);
	if (status != 0) {
		return -1;      /* Report error. */
	}
	return 0;
}

/*******************************************************************************
*Function Name    :sig_pipe_handle
*Description      :handle with SIGPIP 
*Input       	  :int iArgV  
*Output 		  :NONE
*Return           :void  
*******************************************************************************/
static void sig_pipe_handle(int iArgV)
{
	signal(SIGPIPE, sig_pipe_handle);
	iSigPipeFlag = true;
	///add network station ,by tiger.09
	if (system("iwconfig >>/var/log/jdagv.log") != 0)
	{
		LOG_INF("excute iwconfig cmd error:%s\n", strerror(errno));
	}
	if (system("ifconfig -a >>/var/log/jdagv.log") != 0)
	{
		LOG_INF("excute ifconfig -a cmd error:%s\n", strerror(errno));
	}
	///end ,by tiger.09
	LOG_INF("[ catch SIGPIPE ] !\n");
	if (save_log_arm(SIG_PIPE_ERROR) == 0)
	{
		LOG_INF("save_log xxx.tgz success:SIG_PIPE!\n");
	}
}

/*******************************************************************************
*Function Name    :sig_segv_handle
*Description      :handle with SIGSEGV  
*Input       	  :int iArgV  
*Output 		  :NONE
*Return           :void  
*******************************************************************************/
static void sig_segv_handle(int iArgV)
{
	int iFd = 0;
	///add network station ,by tiger.09
	if (system("iwconfig >>/var/log/jdagv.log") != 0)
	{
		LOG_INF("excute iwconfig cmd error:%s\n", strerror(errno));
	}
	if (system("ifconfig -a >>/var/log/jdagv.log") != 0)
	{
		LOG_INF("excute ifconfig -a cmd error:%s\n", strerror(errno));
	}
	///end,by tiger.09
	LOG_INF("[ catch SIGSEGV ] !\n");
	if (save_log_arm(SIG_SEG_ERROR) == 0)
	{
		LOG_INF("save_log_arm xxx.zip success:SIGSEGV!\n");
	}
	abort();
}

/*******************************************************************************
*Function Name    :ftp_init
*Description      :just for catch SIGPIPE & SIPSEGV signal  
*Input       	  :void  
*Output 		  :NONE
*Return           :void  
*******************************************************************************/
void ftp_init(void)
{
	if (signal(SIGPIPE, sig_pipe_handle) == SIG_ERR)
		LOG_INF("cannot catch SIGPIPE\n");
	if (signal(SIGSEGV, sig_segv_handle) == SIG_ERR) //by tiger.07
		LOG_INF("cannot catch SIGSEGV\n");
}
#define  MB_1 20
#define  SECOND_20 20
/*******************************************************************************
* Function Name  : put_file
* Description    : put the file to ftp
* Input          	: usr_cmd:"put" command ,such as " put  a b",
			   a:local file  b:create file name in the current dirent of  the ftp server
* Output         : None
* Return         : 0:success;  -1:connect the ftp but upload file failed  -2: unconnect the ftp server
*******************************************************************************/
int put_file(const char *pPattern)
{
	char pSrcFile[MAXLINE];
	char pDesFile[MAXLINE];
	char pDirentName[MAXLINE]; //save the xxx.zip name:2017-06-08-21:00:00-3004-5(С����)
	char pAgvName[MAXLINE];
	char pSendBuf[512];
	int iLocalFileFd;
	int iFilePutsock = -1, iCount = 0,iWriteCount = 0;
	int iReplyCode = 0;
	int iUploadOverTime = UPLOAD_OVER_TIME;
	struct stat stFileInfo = {0};

	time_t t;  //save the time
	struct tm *pTmp = NULL;
	struct dirent *pDirent = NULL;
	DIR *pDir = NULL;
	struct timeval stTimePre, stTimeNow;
	fd_set stWriteFds;
	char *pTmp1 = NULL;
	struct timeval stTimeOut =
	{
		.tv_sec = WRIET_OVER_TIME,
		.tv_usec = 0
	};
	int iTime = 0;
	char pLogNum = 0;
	
	bzero(pSrcFile, sizeof(pSrcFile));
	bzero(pDesFile, sizeof(pDesFile));
	bzero(pDirentName, sizeof(pDirentName));
	iSigPipeFlag = false;//clear SIGPIPE flag
	if ((connect_server(DEFAULT_FTP_PORT)) != 0)   //connect ftp server
	{
		LOG_INF("connect_server faild \n");
		return -2;
	}

	/// make dirent in the ftp server 
	time(&t);
	pTmp = localtime(&t);
	strftime(pDirentName, sizeof(pDirentName), "%F", pTmp);// make dirent "2017-06-15"
	//LOG_INF("make the dirent %s!\n", pDirentName);
	if (send_cmd("MKD ", pDirentName, iSockControl) < 0) return -1;
	iReplyCode = get_reply(iSockControl);
	if ((iReplyCode != DIR_CREAT_SUCCESS) && (iReplyCode != DIR_EXIST))
	{
		LOG_INF("create dirent %s error \n", pDirentName);
		return -1;
	}
	if (send_cmd("CWD ", pDirentName, iSockControl) < 0)
		return -1; //change work dirent of ftp server 
	iReplyCode = get_reply(iSockControl);
	if (iReplyCode != CHANGE_DIR_SUCCESS)
	{
		LOG_INF("change work dirent %s error \n", pDirentName);
		return -1;
	}
	ini_read(UPDATA_CONF,"skywolf_conf", "skywolf", pAgvName,sizeof(pAgvName)); // make agv's dirent,such as "021"
	//LOG_INF("make the dirent %s!\n", pAgvName);
	if (send_cmd("MKD ", pAgvName, iSockControl) < 0) return -1; //change work dirent of ftp server
	iReplyCode = get_reply(iSockControl);
	if ((iReplyCode != DIR_CREAT_SUCCESS) && (iReplyCode != DIR_EXIST))
	{
		LOG_INF("creat dirent %s error \n", pAgvName);
		return -1;
	}
	if (send_cmd("CWD ", pAgvName, iSockControl) < 0) return -1;
	iReplyCode = get_reply(iSockControl);
	if (iReplyCode != CHANGE_DIR_SUCCESS)
	{
		LOG_INF("change work dirent %s error \n", pDirentName);
		return -1;
	}

	if ((pDir = opendir("/")) == NULL)  return -1;
	while ((pDirent = readdir(pDir)) != NULL)  //upload all of xxx.zip in the dirent "/" to "/2017-06-15/020/"
	{
		if (match(pDirent->d_name, pPattern) != 0) continue;
		sprintf(pSrcFile, "/%s", pDirent->d_name);
		sprintf(pDesFile, "%s", pDirent->d_name);

		iLocalFileFd = open(pSrcFile, O_RDONLY);
		if (iLocalFileFd < 0)
		{
			LOG_INF("open local file %s error!\n", pDesFile);
			return -1;
		}
		stat(pSrcFile, &stFileInfo);
		if (stFileInfo.st_size >> MB_1)//file size bigger than 1 MB
		{
			iUploadOverTime = (stFileInfo.st_size >> MB_1)*SECOND_20;//set upload over time ,unit :s
		}
		iFilePutsock = connect_ftpdata();   //connect ftp data socket 
		if (iFilePutsock < 0)
		{
			LOG_INF("socket error,the i_get_sock is %d!\n", iFilePutsock);
			close(iLocalFileFd);
			close(iFilePutsock);
			return -1;
		}

		if (send_cmd("STOR ", pDesFile, iSockControl) < 0)
			return -1; 
		iReplyCode = get_reply(iSockControl);
		if ((iReplyCode != ENABLE) && (iReplyCode != ALREADY))
		{
			LOG_INF("ftp server not ready to store  %s \n", pDesFile);
			close(iLocalFileFd);
			close(iFilePutsock);
			closedir(pDir);
			return -1;
		}

		LOG_INF("begin upload log to ftp server\n");
		
		gettimeofday(&stTimePre, NULL);
		//LOG_INF("iTime =%ds\n", iTime);
		while ((iSigPipeFlag == false) && (iTime < iUploadOverTime))//upload one log do not overtime
		{
			//LOG_INF("in while iTime =%ds\n", iTime);
			iCount = read(iLocalFileFd, pSendBuf, sizeof(pSendBuf));
			//LOG_INF("has read %d bytes\n", iCount);
			if (iCount <= 0)
				break;
			else
			{
				pTmp1 = pSendBuf;
				while ((iCount > 0) && (iSigPipeFlag == false) )
				{
					FD_ZERO(&stWriteFds);
					FD_SET(iFilePutsock, &stWriteFds);
					stTimeOut.tv_sec = WRIET_OVER_TIME;
					if ((select(iFilePutsock + 1, NULL, &stWriteFds, NULL, &stTimeOut) > 0))
					{
						iWriteCount = write(iFilePutsock, pTmp1, iCount);
						//LOG_INF("has writen %d bytes,not written %d bytes\n", iWriteCount, iCount - iWriteCount);
						if (iWriteCount == -1)
						{
							LOG_INF("write data to ftp server error:%s\n", strerror(errno));
							close(iLocalFileFd);
							close(iFilePutsock);
							closedir(pDir);
							LOG_INF("write %s data to ftp failed !\n", pSrcFile);
							return -2; // ftp disconnect
						}
						iCount = iCount - iWriteCount;
						pTmp1 = pTmp1 + iWriteCount;
						if (iCount > 0 )
							usleep(50000); // sleep 50ms
					}
					else
					{
						LOG_INF("failed to upload log,write data to ftp server timeout(%ds)\n", WRIET_OVER_TIME);
						close(iLocalFileFd);
						close(iFilePutsock);
						closedir(pDir);
						return -2; // ftp disconnect
					}
					
				}
				
			}
			gettimeofday(&stTimeNow, NULL);
			iTime = stTimeNow.tv_sec - stTimePre.tv_sec;
			if (iTime > iUploadOverTime)
			{
				LOG_INF("failed to upload log,upload overtime %d\n", iUploadOverTime);
				close(iLocalFileFd);
				close(iFilePutsock);
				closedir(pDir);
				return -2; // ftp disconnect
			}
		}
		iTime = 0;//reset time when upload different log
		close(iLocalFileFd);
		close(iFilePutsock);
		if ((iReplyCode = get_reply(iSockControl)) != 226)
		{
			LOG_INF("upload %s failed !\n", pSrcFile);
			return -1;
		}
		LOG_INF("upload %s success !\n", pSrcFile);
		if (unlink(pSrcFile) != 0) // delete the src_file,such as xxx.zip
		{
			LOG_INF("unlink the %s error,%s/n", pSrcFile, strerror(errno));
			return -1;
		}
		bzero(pSrcFile, sizeof(pSrcFile));
		pLogNum++;
	}
	closedir(pDir);
	if (pLogNum > 0)
		LOG_INF("successed upload %d log !!!\n", pLogNum);
	return 0;
}

/*******************************************************************************
*Function Name    :put_coredump_file
*Description      :  
*Input       	  :char * pPattern  
*Output 		  :
*Return           :int:0:success;  -1:connect the ftp but upload file failed  -2: unconnect the ftp server  
*******************************************************************************/
int put_coredump_file(const char *pPattern)
{
	char pSrcFile[MAXLINE];
	char pDesFile[MAXLINE];
	char pDirentName[MAXLINE]; //save the xxx.zip name:2017-06-08-21:00:00-3004-5(С����)
	char pAgvName[MAXLINE];
	char pSendBuf[512];
	int iLocalFileFd;
	int iFilePutsock = -1, iCount = 0, iWriteCount = 0;
	int iReplyCode = 0;
	int iUploadOverTime = UPLOAD_OVER_TIME;
	struct stat stFileInfo = { 0 };
	time_t t;  //save the time
	struct tm *pTmp = NULL;
	struct dirent *pDirent = NULL;
	DIR *pDir = NULL;
	struct timeval stTimePre, stTimeNow;
	fd_set stWriteFds;
	char *pTmp1 = NULL;
	struct timeval stTimeOut =
	{
		.tv_sec = WRIET_OVER_TIME,
		.tv_usec = 0
	};
	int iTime = 0;

	bzero(pSrcFile, sizeof(pSrcFile));
	bzero(pDesFile, sizeof(pDesFile));
	bzero(pDirentName, sizeof(pDirentName));
	iSigPipeFlag = false;//clear SIGPIPE flag
	if ((connect_server(DEFAULT_FTP_PORT)) != 0)   //connect ftp server
	{
		LOG_INF("connect_server faild \n");
		return -2;
	}

	if ((pDir = opendir("/")) == NULL)  return -1;
	while ((pDirent = readdir(pDir)) != NULL)  
	{
		if (match(pDirent->d_name, pPattern) != 0) continue;//transport all 2018-03-27-17.58.06-core-xxx.zip
		sprintf(pSrcFile, "/%s", pDirent->d_name);
		sprintf(pDesFile, "%s", pDirent->d_name);

		iLocalFileFd = open(pSrcFile, O_RDONLY);
		if (iLocalFileFd < 0)
		{
			LOG_INF("open local file %s error!\n", pDesFile);
			return -1;
		}
		stat(pSrcFile, &stFileInfo);
		if (stFileInfo.st_size >> MB_1)//file size bigger than 1 MB
		{
			iUploadOverTime = (stFileInfo.st_size >> MB_1)* SECOND_20;//set upload over time ,unit :s
		}
		iFilePutsock = connect_ftpdata();   //connect ftp data socket 
		if (iFilePutsock < 0)
		{
			LOG_INF("socket error,the i_get_sock is %d!\n", iFilePutsock);
			close(iLocalFileFd);
			close(iFilePutsock);
			return -1;
		}

		if (send_cmd("STOR ", pDesFile, iSockControl) < 0)
			return -1;
		iReplyCode = get_reply(iSockControl);
		if ((iReplyCode != ENABLE) && (iReplyCode != ALREADY))
		{
			LOG_INF("ftp server not ready to store  %s \n", pDesFile);
			close(iLocalFileFd);
			close(iFilePutsock);
			closedir(pDir);
			return -1;
		}

		LOG_INF("begin upload log to ftp server\n");

		gettimeofday(&stTimePre, NULL);	
		while ((iSigPipeFlag == false) && (iTime < iUploadOverTime))//upload one log do not overtime
		{
			iCount = read(iLocalFileFd, pSendBuf, sizeof(pSendBuf));
			if (iCount <= 0)
				break;
			else
			{
				pTmp1 = pSendBuf;
				while ((iCount > 0) && (iSigPipeFlag == false))
				{
					FD_ZERO(&stWriteFds);
					FD_SET(iFilePutsock, &stWriteFds);
					stTimeOut.tv_sec = WRIET_OVER_TIME;
					if ((select(iFilePutsock + 1, NULL, &stWriteFds, NULL, &stTimeOut) > 0))
					{
						iWriteCount = write(iFilePutsock, pTmp1, iCount);
						if (iWriteCount == -1)
						{
							LOG_INF("write data to ftp server error:%s\n", strerror(errno));
							close(iLocalFileFd);
							close(iFilePutsock);
							closedir(pDir);
							LOG_INF("write %s data to ftp failed !\n", pSrcFile);
							return -2; // ftp disconnect
						}
						iCount = iCount - iWriteCount;
						pTmp1 = pTmp1 + iWriteCount;
						if (iCount > 0)
							usleep(50000); // sleep 50ms
					}
					else
					{
						LOG_INF("failed to upload log,write data to ftp server timeout(%ds)\n", WRIET_OVER_TIME);
						close(iLocalFileFd);
						close(iFilePutsock);
						closedir(pDir);
						return -2; // ftp disconnect
					}

				}

			}
			gettimeofday(&stTimeNow, NULL);
			iTime = stTimeNow.tv_sec - stTimePre.tv_sec;
			if (iTime > iUploadOverTime)
			{
				LOG_INF("failed to upload log,upload overtime %d\n", iUploadOverTime);
				close(iLocalFileFd);
				close(iFilePutsock);
				closedir(pDir);
				return -2; // ftp disconnect
			}
		}
		iTime = 0;//reset time when upload different log
		close(iLocalFileFd);
		close(iFilePutsock);
		if ((iReplyCode = get_reply(iSockControl)) != 226)
		{
			LOG_INF("upload %s failed !\n", pSrcFile);
			return -1;
		}
		LOG_INF("upload %s success !\n", pSrcFile);
		if (unlink(pSrcFile) != 0) // delete the src_file,such as xxx.zip
		{
			LOG_INF("unlink the %s error,%s/n", pSrcFile, strerror(errno));
			return -1;
		}
		bzero(pSrcFile, sizeof(pSrcFile));
	
	}
	closedir(pDir);

	return 0;
}
/*******************************************************************************
* Function Name  : upload_log
* Description    : upload log ,such as:xxx.zip
* Input          : None
* Output         : None
* Return         : 0:no log to upload;  n:the number of the xxx.zip;-1:upload failed ;
*******************************************************************************/
int upload_log(void)
{
	DIR *pDp;
	regex_t stCompiled;
	int iRet = 0;
	bool bNoLog = true;
	bool bNoCoreDump = true;
	struct dirent *pDirent = NULL;
	if (save_log_coredump() < 0)  //update coredump file ,add by tiger.57
	{
		LOG_WRN("save coredump log failed:[%d-%s]\n",errno,strerror(errno));
	}
	///match xxxx-xx-xx-xx.xx.xx-xxx-xxx.zip,such as : 2017-06-15-14.10.44-3-20.tgz  //by tiger.80	
	const char *pPattern = "^[0-9]{4}(-[0-9]{2}){3}(\.[0-9]{2}){2}-[0-9]{1,6}-[0-9]{1,7}-[a-zA-Z]{3}((\.zip)|(\.tgz))$";
	///match xxxx-xx-xx-xx.xx.xx-core-xxx.zip,such as: 2018-03-25-01.35.09-core-76.tgz //by tiger.80	
	const char *pCoreFilePattern = "^[0-9]{4}(-[0-9]{2}){3}(\.[0-9]{2}){2}-core-[0-9]{1,7}((\.zip)|(\.tgz))$";
	
	if ((pDp = opendir("/")) == NULL)  return -1;
	while ((pDirent = readdir(pDp)) != NULL)
	{
		if ((true == bNoLog) && (match(pDirent->d_name, pPattern) == 0))
		{
			bNoLog = false;
			iRet = put_file(pPattern); // put all log file to ftp server
			if (iRet != -2) 
				quit_server(); // disconnet the server
		}
		else if ((true == bNoCoreDump) && (match(pDirent->d_name, pCoreFilePattern) == 0))
		{
			bNoCoreDump = false;
			iRet = put_coredump_file(pCoreFilePattern); // put all log file to ftp server
			if (iRet != -2) 
				quit_server(); // disconnet the server
		}
		else
			continue;
	}
	
	closedir(pDp);
	if (bNoLog == true)
	{
		LOG_INF("there is not log to upload\n");
	}
	if (true == bNoCoreDump)
	{
		LOG_INF("there is not CoreDump file to upload\n");
	}
	return iRet;
}

/*******************************************************************************
*Function Name    :ftp_sendtocan
*Description      :  
*Input       	  :int sockfd:can socket  
*Input       	  :void * buf: data pointer,  
*Input       	  :int len:length  
*Output 		  :
*Return           :int:num of data if OK; -1 on error  
*******************************************************************************/
int ftp_sendtocan(int sockfd, void *buf, int len)
{
	int n;
	if (NULL == buf)
	{
		LOG_INF("buf = NULL!\n");
		return -1;		 
	}
	if (len > sizeof(struct can_frame))
	{
		LOG_INF("len > sizeof(struct can_frame)!\n");
		return -1;
	}
	n = write(sockfd, buf, len);
	if (n < 0)
	{
		LOG_INF("write error: %s\n", strerror(errno));
		return -1;
	}
	return n;
}

/*******************************************************************************
*Function Name    :file_size
*Description      :  
*Input       	  :FILE * pFile :the file description 
*Output 		  :NONE
*Return           :long:the file size  
*******************************************************************************/
long file_size(FILE *pFile)
{
	long curpos, length;
	curpos = ftell(pFile);
	fseek(pFile, 0L, SEEK_END);
	length = ftell(pFile);
	fseek(pFile, curpos, SEEK_SET);
	return length;
}

/*******************************************************************************
*Function Name    :send_app
*Description      :  
*Input       	  :bool bIsMc: 1:operate with MC  0:operate with TC  
*Input       	  :const char * pAppPath::the path of app file  
*Output 		  :NONE
*Return           :int:0 if OK ,-1 on error  
*******************************************************************************/
int send_app(bool bIsMc,const char *pAppPath)
{
	fd_set stReadFds;
	size_t uiSize = 0;
	FILE * iFd;
	int i,iRet;
	int uiFrameCount = 0;
	int uiFileSize = 0;
	char cDatabuf[CAN_LENGTH];
	struct timeval stTimeOut = { 2, 0 }; //2s
	struct can_frame stData;
	int iCanID = ((1 == bIsMc) ? FTP_MC_ACK_CANID : FTP_TC_ACK_CANID);
	bzero(&stData, sizeof(struct can_frame));
	iFd = fopen(pAppPath, "r");
	if (iFd==NULL)
	{
		LOG_INF("open file error\n");
		return -1;
	}
	uiFileSize = file_size(iFd);
	///send update cmd
	uiFrameCount = (uiFileSize * 24 / (24 * 3 + 2) % 8 > 0) ? 1 : 0;
	uiFrameCount += (uiFileSize*24/(24*3+2) / 8);
	if (mc_v1_cntl_update_cmd(bIsMc, DSP_UPDATE_CMD, uiFrameCount) == -1)
	{
		LOG_INF("error: send update cmd of %s App \n", (1 == bIsMc) ? "MC" : "TC");
		return -1;
	}
	iRet = ftp_recv_can(&stTimeOut, iCanID);
	if (iRet < 0)
	{
		return -1;
	}
		
	if (bIsMc)
		stData.can_id = FTP_MC_SEND_CAN_ID;
	else
		stData.can_id = FTP_TC_SEND_CAN_ID;
	
	LOG_INF("begin send the data of %s App\n", (bIsMc == 1) ? "MC" : "TC");
	char cLine[512];
	unsigned char cOut[512];
	int iNum;
	int iCurNum = 0;
	while (fgets(cLine, 512, iFd))// read a line data
	{
		if (strlen(cLine) < 8)
		{
			LOG_INF("load %s code end\n", (bIsMc == 1) ? "MC" : "TC");
			break;
		}	 
		iNum=parse_hex_line(cLine, cOut);
		stData.can_dlc = 8;
		int i = 0;
		for (i= 0; i<iNum/8; i++)
		{
			memcpy(stData.data, cOut+8*i, 8);
			ftp_sendtocan(g_stAgvParm.iCanSocketFd0, &stData, sizeof(struct can_frame));
			iCurNum++;
			if (iCurNum >= uiFrameCount)
			{
				break;
			}
			usleep(1000);
		}				
	}
	fclose(iFd);
	if (mc_v1_cntl_update_cmd(bIsMc, DSP_SEND_FINISHED_CMD, 0) == -1)
	{
		return -1;
	}
	iCanID = ((1 == bIsMc) ? FTP_MC_FINISH_CANID : FTP_TC_FINISH_CANID);
	iRet = ftp_recv_can(&stTimeOut, iCanID);
	if (iRet < 0)
	{
		return -1;
	}
}

/*******************************************************************************
*Function Name    :parse_hex_line
*Description      :  
*Input       	  :char * pStr:the string pointer to be  parsed  
*Input       	  :unsigned char * pOut:the hex buffer  
*Output 		  :NONE
*Return           :int:the hex num  
*******************************************************************************/
int parse_hex_line(char *pStr, unsigned char *pOut)
{
	//fgets
	char *pEnd;
	unsigned char uData;
	int i = 0;
	char *pCur = strtok(pStr," ");
	while (pCur != NULL)
	{
		uData = strtol(pCur, &pEnd, 16);
		pOut[i] = uData;
		pCur = strtok(NULL, " ");
		i++;		 
	}
	return i;

}
typedef enum
{
	FTP_RECEIVE_OK = 1,
	FTP_SEND_AGAIN,
	FTP_STOP_UPDATE,
	FTP_ERASER_FLASH_OK,
	FTP_ERASER_FLASH_FAILED,
	FTP_WRITE_FLASH_OK,
	FTP_WRITE_FLASH_FAILED,
	FTP_CHECK_FLASH_OK,
	FTP_CHECK_FLASH_FAILED,
	FTP_POWERON,
	FTP_STARTED_OK = 0x4B4F
}ftp_finish_frame;
#define FTP_DSP_RECV_ERROR 10
bool g_bRecvThreadOk = false;  // if can recv thread  start ,then not reiceve the can frame

/*******************************************************************************
*Function Name    :ftp_operate_finish
*Description      :deal with can finish frame during update dsp by ftp  
*Input       	  :bool bIsMc:1:operate with MC  0:operate with TC  
*Input       	  :ftp_finish_frame iCmd : ftp update cmd ,0x01~0x09,0x4b4f  
*Output 		  :NONE
*Return           :void  
*******************************************************************************/
void ftp_operate_finish(bool bIsMc,ftp_finish_frame iCmd)
{
	const char *pDesc[] = {" ","receive date success","receive date failed,and send app again","receive app error ,and stop update","eraser flash ok",\
							"eraser flash failed","write flash ok","wtite flash failed","check flash ok","check flash failed"\
							};
	int iGeneration = 0;
	
	struct timeval stTimeOut = { 10, 0 }; //2s
	char cBuf[MAX_LINE];
	bzero(cBuf, sizeof(cBuf));	
	switch (iCmd)
	{
	case FTP_RECEIVE_OK:
		LOG_INF("%s receive data success\n", (1 == bIsMc) ? "MC" : "TC");
		break;
	case FTP_SEND_AGAIN: 	
		LOG_INF("%s receive data error and send update error to agent\n", (1 == bIsMc) ? "MC" : "TC");
		g_stop_update = true;
		//send_excetpion_req(FTP_DSP_RECV_ERROR);
		break;
	case FTP_ERASER_FLASH_OK:
		LOG_INF("%s erase flash success\n", (1 == bIsMc) ? "MC" : "TC");
		break;
	case FTP_ERASER_FLASH_FAILED:
		LOG_INF("%s erase flash failed\n", (1 == bIsMc) ? "MC" : "TC");
		break;
	case FTP_WRITE_FLASH_OK:
		LOG_INF("%s write flash success\n", (1 == bIsMc) ? "MC" : "TC");
		break;
	case FTP_WRITE_FLASH_FAILED:
		LOG_INF("%s write flash failed\n", (1 == bIsMc) ? "MC" : "TC");
		break;
	case FTP_CHECK_FLASH_OK: 
		LOG_INF("%s check flash ok and start restart\n", (1 == bIsMc) ? "MC" : "TC");
		if (-1 == ftp_recv_can(&stTimeOut, (1 == bIsMc) ? FTP_MC_FINISH_CANID : FTP_TC_FINISH_CANID))
		{
			LOG_INF("wait for %s restart timeout\n" ,(1 == bIsMc) ? "MC" : "TC");
			return;
		}
		if (mc_get_version(&iGeneration) == 0) //
		{
			if (mc_v1_cntl_update_cmd(bIsMc, DSP_NOT_UPDATE_CMD, 0) == -1)
			{
				return ;
			}
			ftp_recv_can(&stTimeOut, ((1 == bIsMc) ? FTP_MC_ACK_CANID : FTP_TC_ACK_CANID));
			LOG_INF("%s update ok \n", (1 == bIsMc) ? "MC" : "TC");
		}
		g_stop_update = true;
		break;
	case FTP_CHECK_FLASH_FAILED:
		LOG_INF("%s %s\n", (true == bIsMc) ? "MC" : "TC", pDesc[iCmd]);
		break;
	case FTP_STARTED_OK:
		LOG_INF("%s update success ,and started app ok\n", (true == bIsMc) ? "MC" : "TC");
		///search version and send not update cmd
		sleep(1);
		mc_get_version(&iGeneration);
		usleep(5000);
		mc_v1_cntl_update_cmd(bIsMc, DSP_NOT_UPDATE_CMD, 0);
		break;
	case FTP_POWERON:
		LOG_INF("%s power on\n", (true == bIsMc) ? "MC" : "TC");
		break;
	default:
		LOG_INF("error operate type during ftp update finish\n");
		break;
	}
}

/*******************************************************************************
*Function Name    :update_d500_10_15
*Description      :change by tiger.63  
*Input       	  :void  
*Output 		  :
*Return           :int;0 if ok,-1 on error  
*******************************************************************************/
int update_d500_10_15(void)
{
	int iRet = 0;
	char pPwd[MAXLINE];

	char pTcCrc32String[DSP_TOTAL_TYPE][MAXLINE] = {0}; //modified by tiger.11
	char pMcCrc32String[DSP_TOTAL_TYPE][MAXLINE] = { 0 };//modified by tiger.11
	char pTmp[MAXLINE] = { 0 };
	int  iAGVType = 0;
	int iTcNewVersion[DSP_TOTAL_TYPE] = { 0 };//modified by tiger.11
	int iMcNewVersion[DSP_TOTAL_TYPE] = { 0 };//modified by tiger.11
	bool bMcUpdate = false;  //MC need update app
	bool bTcUpdate = false; //TC need update app
	bool bConnectOK = false; //FTP connect
	bool bWrongGenerater = false;  // if the generater is not support
	struct stat stFileInfo = { 0 };
	struct timeval stTimeOut = { 2, 0 };
	int iTcGeneration = -1;
	///add wget update,start by tiger.101 
	g_bMcAppWgetOK = false;
	iRet = wget_download_file(MC_APP_URL, MC_TGZ, TRY_5_TIMES);
	LOG_INF("wget %s %s\n", MC_TGZ, (0 == iRet) ? "Success" : "Failed");
	if (0 == iRet)
	{
		iRet = wget_untar_file(MC_TGZ, MC_TC_FILE_PATH);
		if (iRet <0)
		{
			g_bMcAppWgetOK = false;
		}
		LOG_INF("untar %s %s\n", MC_TGZ, (g_bMcAppWgetOK == true) ?("Success") : ("Failed"));
	}

	g_bTcAppWgetOK = false;
	iRet = wget_download_file(TC_APP_URL, TC_TGZ, TRY_5_TIMES);
	LOG_INF("wget %s %s\n",TC_TGZ, (0 == iRet) ? "Success" : "Failed");
	if (0 == iRet)
	{
		iRet = wget_untar_file(TC_TGZ, MC_TC_FILE_PATH);
		if (iRet<0)
		{
			g_bTcAppWgetOK = false;
		}
		LOG_INF("untar %s %s\n", TC_TGZ, (g_bTcAppWgetOK == true) ? ("Success") : ("Failed"));
	}
	///add wget update,end by tiger.101
	///save the current work director
	if (getcwd(pPwd, sizeof(pPwd)) == NULL)
	{
		LOG_ERR("getcwd error!\n");
		return -1;
	}
	else
	{
		LOG_INF("pwd = %s\n", pPwd);
	}
	///connect with ftp server
	if (((false == g_bTcAppWgetOK))&&(false == g_bMcAppWgetOK) && connect_server(DEFAULT_FTP_PORT) == 0) //by tiger.101
	{
		bConnectOK = true;
	}
	if ( true == bConnectOK) //not send cmd to a disconnect port,avoid causing SIGPIPE signal,by tiger.05
	{
		///get TC and MC version and crc from the ftp server
		get_dsp_crc(iTcNewVersion, iMcNewVersion, pTcCrc32String, pMcCrc32String);
	}
	
	///update MC app		
	///start,tiger.11
	iAGVType = g_stMcDev.iGeneration -1;
	if(iAGVType + 1> DSP_TOTAL_TYPE)
	{
		LOG_INF("MC only support [%d] generation AGV,but the current AGV is [%d] generation\n",DSP_TOTAL_TYPE,iAGVType + 1);
		LOG_INF("Error:abort MC update dsp ,and will send not update cmd!!! \n");
		bMcUpdate = false;
		bWrongGenerater = true;
	}
	if (bWrongGenerater == false)
	{
		LOG_INF("the [%dth] generation AGV's MC new version is:[%d], the current version is:[%d]\n", iAGVType + 1, iMcNewVersion[iAGVType], g_stAgvAttr.iMcVersion);
	}
	///end,tiger.11
	if ((bWrongGenerater == false) && (iMcNewVersion[iAGVType] >  g_stAgvAttr.iMcVersion))
	{			
			
		if ((download_app(pMcCrc32String[iAGVType], pMcAppName[iAGVType],g_bMcAppWgetOK)) == -1)//modified by tiger.11
		{
			iRet = -1;
			bMcUpdate = false;
		}
		else
		{
			bMcUpdate = true;	
		}
					
	}
	else
	{
		if (bWrongGenerater == false)
		{
			LOG_INF("The MC is the latest ,need not update\n");
		}
		if (mc_v1_cntl_update_cmd(DEV_MC, DSP_NOT_UPDATE_CMD, 0) == -1)
		{
			return -1;
		}
		stTimeOut.tv_sec = 2;
		ftp_recv_can(&stTimeOut, FTP_MC_ACK_CANID);
	}
	
	
	 //update tc  App
	if ((iRet = tc_get_version(&iTcGeneration)) == 0)		//get the current TC version
	{
	
		///start,tiger.11
		bWrongGenerater == false;
		iAGVType = g_stTcDev.iGeneration - 1;
		if(iAGVType + 1> DSP_TOTAL_TYPE)
		{
			LOG_INF("TC only support [%d] generation AGV,but the current AGV is [%d] generation\n", DSP_TOTAL_TYPE, iAGVType + 1);
			LOG_INF("Error:abort update TC dsp ,and will send not update cmd!!! \n");
			bTcUpdate = false;
			bWrongGenerater = true;
		}
		if (bWrongGenerater == false)
		{
			LOG_INF("the [%dth] generation AGV's TC new version is:[%d], the current version is:[%d]\n", iAGVType + 1, iTcNewVersion[iAGVType], g_stAgvAttr.iTcVersion);
		}
		///end,tiger.11
		if ((bWrongGenerater == false) && (iTcNewVersion[iAGVType] > g_stAgvAttr.iTcVersion))//modified by tiger.11
		{
			
			LOG_INF("the server version is:%d,the curren version is:%d\n", iTcNewVersion[iAGVType], g_stAgvAttr.iTcVersion);
			if ((download_app(pTcCrc32String[iAGVType], pTcAppName[iAGVType],g_bTcAppWgetOK)) == -1)//modified by tiger.11
			{
				iRet = -1;
				bTcUpdate = false;
			}
			else
			{
				bTcUpdate = true;
			}
		}
		else
		{
			LOG_INF("The TC is the latest ,need not update\n");
			if (mc_v1_cntl_update_cmd(0, DSP_NOT_UPDATE_CMD, 0) == -1)
			{
				return -1;
			}
			stTimeOut.tv_sec = 2;
			ftp_recv_can(&stTimeOut, FTP_TC_ACK_CANID);
		}
	}


	if (true == bConnectOK) //not send cmd to a disconnect port,avoid causing SIGPIPE signal,by tiger.05
	{
		quit_server();
		bConnectOK = false;//add by tiger.52
	}	

	if (bTcUpdate == true)  //update and start the app need time
	{		
		int iCount = 0;
		iRet = send_app(DEV_TC, pTcAppName[iAGVType]);//modified by tiger.11
		if (iRet == 0)
		{
			g_stop_update = false;
			while (true != g_stop_update&&iCount < 12)
			{
				stTimeOut.tv_sec = 8;
				ftp_recv_can(&stTimeOut, FTP_TC_FINISH_CANID);
				iCount++;
			}
		}
		
		if ((iRet < 0)||(iCount >= 12))
		{
			LOG_INF("wait for TC restart time out and send stop update to tc\n");
			if (mc_v1_cntl_update_cmd(0, DSP_NOT_UPDATE_CMD, 0) == -1)
			{
				return -1;
			}
			ftp_recv_can(&stTimeOut, FTP_TC_ACK_CANID);
		}
	}	
	if (bMcUpdate == true)
	{		 
		int iCount = 0;
		iRet = send_app(DEV_MC, pMcAppName[iAGVType]);//modified by tiger.11
		if (iRet == 0)	
		{
			g_stop_update = false;
			while (true != g_stop_update&&iCount < 12)
			{
				stTimeOut.tv_sec = 8;
				ftp_recv_can(&stTimeOut, FTP_MC_FINISH_CANID);
				iCount++;
			}
		}

		if ((iRet < 0) || (iCount >= 12))
		{
			LOG_INF("wait for MC restart time out and send stop update to mc\n");
			if (mc_v1_cntl_update_cmd(1, DSP_NOT_UPDATE_CMD, 0) == -1)
			{
				return -1;
			}
			ftp_recv_can(&stTimeOut, FTP_MC_ACK_CANID);
		}
	}	
	/// no need to update ,remove the version.txt 

	if (chdir(pLcd) < 0)
	{
		LOG_INF("chdir error \n");
		return -1;
	}
	unlink(pVersionPath);
	unlink(pTcAppName[iAGVType]);  //modified by tiger.11
	unlink(pMcAppName[iAGVType]); //modified by tiger.11
	chdir("/");
	if (rmdir(pLcd) < 0)
	{
		LOG_INF("rmdir error:\n");
		return -1;
	}
	
	if (chdir(pPwd) < 0)    //reset the work director
	{
		LOG_INF("chdir error\n");
		return -1;
	}
	return iRet;
}


/*******************************************************************************
* Function Name  : get_dsp_crc
* Description    : get the version and crc from the server
* Input          : NONE
* Output         : p_version;app's version;   p_crc32:the crc value of the app
* Return         : 0:success -1:failed
*******************************************************************************/
int get_dsp_crc(int iTcNewVersion[], int iMcNewVersion[], char pTcCrc32[][MAXLINE], char pMcCrc32[][MAXLINE])
{
	char pLcdCmd[MAXLINE + CMDSIZE];
	char pTcVersion[MAXLINE];
	char pMcVersion[MAXLINE];
	int i = 0;
	bzero(pLcdCmd, sizeof(pLcdCmd));
	bzero(pLcd, sizeof(pLcd));
	bzero(pVersionPath, sizeof(pVersionPath));

	strcpy(pLcd, DSP_UPDATE_DCU);
	if (opendir(pLcd) == NULL)
	{
		if (mkdir(pLcd, S_IRWXU | S_IROTH | S_IWOTH | S_IRWXG) != 0)
		{
			LOG_WRN("mkdir error\n");
			//return -1;
		}
	}
	sprintf(pLcdCmd, "%s %s", "lcd", pLcd);
	lcd_cmd(pLcdCmd);    //set download path
	if (false == g_bMcAppWgetOK || false == g_bTcAppWgetOK) //by tiger.101
	{
		if (get_file("get dsp_version.txt") < 0) return -1;
	}
	
	sprintf(pVersionPath, "%s%s", pLcd, "/dsp_version.txt");
	for(i = 0; i < DSP_TOTAL_TYPE;i++)
	{
		bzero(pTcVersion,sizeof(pTcVersion));
		bzero(pMcVersion,sizeof(pMcVersion));
		if (ini_read(pVersionPath, pDspSegName[i],"TC_Version", pTcVersion,sizeof(int)) != 0)
		{
			LOG_ERR("ini_read cwd error\n");
			return -1;
		}
		iTcNewVersion[i] = atoi(pTcVersion);
		if (ini_read(pVersionPath,pDspSegName[i], "MC_Version", pMcVersion,sizeof(int)) != 0)
		{
			LOG_ERR("ini_read cwd error\n");
			return -1;
		}
		iMcNewVersion[i] = atoi(pMcVersion);
		if (ini_read(pVersionPath, pDspSegName[i], "TC_CRC", pTcCrc32[i], MAXLINE) != 0)
		{
			LOG_ERR("ini_read CRC error\n");
			return -1;
		}
		if (ini_read(pVersionPath, pDspSegName[i], "MC_CRC", pMcCrc32[i], MAXLINE) != 0)
		{
			LOG_ERR("ini_read CRC error\n");
			return -1;
		}
	}
	///read the server's version
	
	return 0;
}

/*******************************************************************************
*Function Name    :judge_car_num
*Description      :  
*Input       	  :int iNum: car num  
*Input       	  :char *pCars: cars range string  //"20  - 30  ,31 -33,40-45\n"; 
*Output 		  :NONE
*Return           :int:0 on success , -1 on not in the range  
*******************************************************************************/
int judge_car_num(int iNum, char *pCars)
{
	char *pStr = NULL;
	char *pTemp;
	char p1[20], p2[20], p3[20];
	int d1, d2;
	pStr = strtok(pCars, ",");  //20-30,31-33,40-45\r\n";
	while (pStr != NULL)
	{
		pTemp = strchr(pStr, '-');
		*pTemp = 0;
		pTemp++;
		d1 = atoi(pStr);
		d2 = atoi(pTemp);
		if (iNum >= d1&&iNum <= d2)
		{
			return 0;
		}
		pStr = strtok(NULL, ",");
	}
	return -1;
}
/*******************************************************************************
* Function Name  : save_log_img
* Description    : save log in the /log_tmp ,such as:source log1=/var/log/jdagv.log 100KB  des :20170608
save_flag can not be reentrant
* Input          : None
* Output         : None
* Return         : 0:success;  -1:failed
*******************************************************************************/
#define IMG_LOG_NUM 1
char *pIMGLogPath[IMG_LOG_NUM] = { "/var/log/jdagv.log" };
int save_log_img(int exception)
{
	pthread_mutex_lock(&stSaveLogMutex);
	int pLogSize[IMG_LOG_NUM] = { 600 };
	const char *pDir = "/log_tmp";
	char log_num[10];
	char log_key[10];
	char *log_name = NULL;
	char *log_path = NULL;
	FILE *fp_src = NULL;
	FILE *fp_des = NULL;
	int i_fd;
	char c_tmp = 0;
	char log_path_tmp[MAXLINE]; //save des log path
	char log_name_tab[MAXLINE];
	char i = 0;
	off_t offset = 0, lPreOffset = 0;
	struct stat st_file_info;
	time_t t;  //save the time
	char zip_name_tab[50]; //save the xxx.zip name:2017-06-08-21:00:00-3004-5(С����)
	char str_excpt[10];
	struct tm *tmp = NULL;
	char agv_name_tab[10]; //agv name skywolf=020

	char zip_cmd_tab[MAXLINE];
	char tmp_tab[MAXLINE];

	char *pLogName = NULL;
	static time_t lPreTime = 0;
	time_t lCurTime = 0;
	bzero(tmp_tab, sizeof(tmp_tab));
	bzero(log_num, sizeof(log_num));
	bzero(log_key, sizeof(log_key));
	bzero(str_excpt, sizeof(str_excpt));
	//bzero(t, sizeof(time_t));
	bzero(agv_name_tab, sizeof(agv_name_tab));
	bzero(log_path_tmp, sizeof(log_path_tmp));
	bzero(&st_file_info, sizeof(struct stat));
	bzero(log_name_tab, sizeof(log_name_tab));
	bzero(zip_cmd_tab, sizeof(zip_cmd_tab));
	LOG_INF("%s\n", (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus) ? "AGV has shelf" : "AGV has not shelf");
	if (stat(pDir, &st_file_info) != 0)
	{
		if (mkdir(pDir, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH) != 0) return -1;
	}
	for (i = 0; i < IMG_LOG_NUM; i++)
	{
		pLogName = strrchr(pIMGLogPath[i], '/');
		strcpy(log_name_tab, ++pLogName);
		bzero(log_path_tmp, sizeof(log_path_tmp));
		sprintf(log_path_tmp, "%s/%s", pDir, log_name_tab);  // the destination log name
		my_printf("log_path_tmp=%s\n", log_path_tmp);

		if ((fp_src = fopen(pIMGLogPath[i], "a+b")) == NULL)
		{
			my_printf("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
		i_fd = fileno(fp_src);
		fsync(i_fd);  //flush the data to the disk
		/// get the file size
		if (fseek(fp_src, 0, SEEK_END) != 0)
		{
			my_printf("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
		offset = ftell(fp_src);
		pLogSize[i] = pLogSize[i] * KB;
		if (offset < pLogSize[i]) pLogSize[i] = offset;
		if (0 == pLogSize[i])
		{
			pLogSize[i] = sizeof("there is not log in the file");
			fprintf(fp_src, "%s\n", "there is not log in the file");
		}
		///set the offset
		if (fseek(fp_src, -pLogSize[i], SEEK_END) != 0)
		{
			my_printf("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}

		if ((fp_des = fopen(log_path_tmp, "wb")) == NULL)
		{
			my_printf("system error:%s", strerror(errno));
			pthread_mutex_unlock(&stSaveLogMutex);
			return -1;
		}
		while ((pLogSize[i] != 1) && (pLogSize[i] != 0)) // copy file
		{
			c_tmp = fgetc(fp_src);
			fputc(c_tmp, fp_des);
			pLogSize[i]--;
		}
		fputc('\0', fp_des);
		i_fd = fileno(fp_des);
		fsync(i_fd);
		fclose(fp_src);
		fclose(fp_des);
		bzero(log_path_tmp, sizeof(log_path_tmp));

	}

	char mv_failpic_cmd[64] = "cp /var/log/*.raw /log_tmp";
	int ret = system(mv_failpic_cmd);
	if (system(mv_failpic_cmd) != 0)
	{
		my_printf("mv_failpic_cmd cmd errorno=%d errmsg:%s\n", errno, strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}
	char rm_failpic_cmd[64] = "rm /var/log/*.raw";
	ret = system(rm_failpic_cmd);
	if (system(rm_failpic_cmd) != 0)
	{
		my_printf("rm_failpic_cmd cmd errorno=%d errmsg:%s\n", errno, strerror(errno));
		//pthread_mutex_unlock(&stSaveLogMutex);
		//return -1;
	}
	///save the xxx.zip name:2017-06-08-21:00:00-3004-5(С����)
	time(&t);
	tmp = localtime(&t);
	strftime(zip_name_tab, sizeof(zip_name_tab), "%F-%H.%M.%S-", tmp);
	sprintf(str_excpt, "%d", exception);
	strcat(zip_name_tab, str_excpt);
	ini_read(UPDATA_CONF, "skywolf_conf", "skywolf", agv_name_tab, sizeof(agv_name_tab));
	strcat(zip_name_tab, "-");
	strcat(zip_name_tab, agv_name_tab);
	strcat(zip_name_tab, "-");
	strcat(zip_name_tab, "IMG");
	sprintf(zip_cmd_tab, "sudo tar -cPzf /%s.tgz %s --remove-files", zip_name_tab, pDir); //sudo zip -rvm ./test.zip test
	if (system(zip_cmd_tab) != 0)
	{
		my_printf("system cmd error:%s\n", strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}
	///sync the  /xxx.zip
	sprintf(tmp_tab, "/%s.tgz", zip_name_tab);//by tiger.80
	if (stat(tmp_tab, &st_file_info) != 0)
	{
		my_printf("%s is not exist:%s\n", tmp_tab, strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}
	if ((i_fd = open(tmp_tab, O_RDWR)) < 0)
	{
		my_printf("open %s failed :%s\n", tmp_tab, strerror(errno));
		pthread_mutex_unlock(&stSaveLogMutex);
		return -1;
	}

	fsync(i_fd);
	close(i_fd);
	pthread_mutex_unlock(&stSaveLogMutex);
	return 0;
}


#define UPDATE_SUC_FILE_PATH  "/root/jdagvclientserver/jdagvserver/update_success"
#define FTP_VERSION_FILE_NAME     "version.txt"
extern ota_mc stOtaMc;
/*******************************************************************************
*Function Name    :_connect_server
*Description      :
*Input       	  :const struct sockaddr_in * pHost
*Input       	  :const char * pUserName
*Input       	  :const char * pPassword
*Output 		  :
*Return           :int:socket value if OK, -1 on error
*******************************************************************************/
static int _connect_server(const struct sockaddr_in *pHost,int iTimeout)
{
	int iRet = 0;
	int iSocketId = 0, iFlags = 0, iConnectCount = 0, iConnectSuc = 0;
	struct timeval stOutTime = { 5, 3000 };
	//static bool bPreTimeOut = false;
	if (NULL == pHost || iTimeout < 0)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}
		
	if (true == bPreTimeOut)
	{
		LOG_WRN("need not connect the server,for last connect is timeout\n");
		return -1;
	}
		

	iSocketId = socket(AF_INET, SOCK_STREAM, 0);
	if (iSocketId < 0)
	{
		LOG_ERR("failed to open ftp socket:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	iRet = setsockopt(iSocketId, SOL_SOCKET, SO_RCVTIMEO, &stOutTime, sizeof(stOutTime));
	if (iRet < 0)
	{
		LOG_ERR("set ftp socket errno:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	iFlags = fcntl(iSocketId, F_GETFL, 0);
	fcntl(iSocketId, F_SETFL, iFlags | O_NONBLOCK);

	while (++iConnectCount <= iTimeout)
	{
		iRet = connect(iSocketId, (struct sockaddr *)pHost, sizeof(struct sockaddr_in));
		if (iRet < 0)
		{
			LOG_INF("Socket[%d] can't connect to ftp server[%s:%d]:[%d-%s]\n",
				iSocketId, inet_ntoa(pHost->sin_addr), ntohs(pHost->sin_port), errno, strerror(errno));
			sleep(1);
			iConnectSuc = 0;
			continue;
		}
		LOG_INF("spend %ds connect to server[%s:%d]\n", iConnectCount - 1,
			inet_ntoa(pHost->sin_addr), ntohs(pHost->sin_port));
		iConnectSuc = 1;
		fcntl(iSocketId, F_SETFL, iFlags &(~O_NONBLOCK));
		break;
	}
	if (iConnectSuc == 0)
	{
		close(iSocketId);
		bPreTimeOut = true;
		return -1;
	}

	iRet = iSocketId;
	return iRet;
}

/*******************************************************************************
*Function Name    :_login_server
*Description      :
*Input       	  :int iSocketId
*Input       	  :const char * pUserName
*Input       	  :const char * pPassword
*Output 		  :
*Return           :int:0 if OK ,-1 on error
*******************************************************************************/
static int _login_server(int iSocketId, const char *pUserName, const char *pPassword)
{
	int iRet = 0;
	if (iSocketId < 0 || NULL == pUserName || NULL == pPassword)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}

	iRet = send_cmd("USER ", pUserName, iSocketId);
	if (iRet < 0)
	{
		LOG_ERR("Send USER cmd to ftp server failed:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	iRet = get_reply(iSocketId);
	if (iRet != USERNAMEOK)
	{
		LOG_ERR("%d:User error!\n", iRet);
		return -1;
	}
	iRet = send_cmd("PASS ", pPassword, iSocketId);
	if (iRet < 0)
	{
		LOG_ERR("Send PASS cmd to ftp server failed:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	iRet = get_reply(iSocketId);
	if (iRet != LOGGEDINOK)
	{
		LOG_ERR("%d:Password error\n", iRet);
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :_get_data_port
*Description      :get the data port number
*Input       	  :int iSocketFd:control port number
*Output 		  :nNONE
*Return           :int:data port number if OK ,-1 on error
*******************************************************************************/
static int _get_data_port(int iSocketFd)
{
	char pPortRespond[512] = { 0 };
	char *pBuf = NULL;
	int iCount = 0, iRet = 0, iPortNum = 0;
	if (iSocketFd < 0)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}

	iRet = send_cmd("PASV", NULL, iSocketFd);
	if (iRet < 0)
	{
		LOG_ERR("send PASV cmd error:[%d-%s]!\n", errno, strerror(errno));
		return -1;
	}
	iCount = read(iSocketFd, pPortRespond, 510);
	if (iCount <= 0)
		return -1;
	pPortRespond[iCount] = '\0';
	if (atoi(pPortRespond) != 227)
		return -1;
	pBuf = strrchr(pPortRespond, ',');    //get low byte of the port
	iPortNum = atoi(pBuf + 1);
	*pBuf = '\0';
	pBuf = strrchr(pPortRespond, ',');    //get high byte of the port
	iPortNum += atoi(pBuf + 1) * 256;
	return iPortNum;
}


/*******************************************************************************
*Function Name    :_get_data
*Description      :get the data of file from data port
*Input       	  :int iControlSocketID
*Input       	  :const char * pFileName:the file name to be download
*Input       	  :const char * pSavePath:the local save path
*Output 		  :NONE
*Return           :int:0 if Ok, -1 on error
*******************************************************************************/
static int _get_data(int iControlSocketID, const char *pFileName, const char *pSavePath,const struct sockaddr_in *pHost, int iTimeout)
{
	int iDataPort = 0, iDataSocketID = 0, iRet = 0, iCount = 0, iWriteCount = 0;
	char pRcvBuf[512];
	char *pTmp = NULL;
	char pLocalFile[100] = { 0 };
	int iLocalFileFd = 0;
	struct stat stFileInfo = { 0 };
	struct sockaddr_in stSockAddr = *pHost;
	
	if (NULL == pFileName || NULL == pSavePath || NULL == pHost || iTimeout < 0)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}

	//get file size
	iRet = send_cmd("SIZE ", pFileName, iControlSocketID);
	if (iRet < 0)
	{
		LOG_ERR("Send SIZE cmd to ftp server failed:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	iRet = get_reply(iControlSocketID);
	if (iRet != 213)
	{
		LOG_ERR("Get SIZE cmd reply error!\n");
		return -1;
	}
	//connect ftp data port
	iDataPort = _get_data_port(iControlSocketID);
	if (iDataPort < 0)
	{
		LOG_ERR("get date port failed\n");
		return -1;
	}
	stSockAddr.sin_port = htons(iDataPort);
	iDataSocketID = _connect_server(&stSockAddr, iTimeout);
	if (iDataSocketID < 0)
	{
		LOG_ERR("Connect ftp data port failed\n");
		return -1;
	}
	iRet = send_cmd("TYPE I", NULL, iControlSocketID);
	if (iRet < 0)
	{
		LOG_ERR("Send TYPE I cmd to ftp server failed:[%d-%s]\n", errno, strerror(errno));
		return -1;
	}
	if (get_reply(iControlSocketID) != 200)
	{
		LOG_ERR("get TYPE I cmd reply error");
		return -1;
	}
	iRet = send_cmd("RETR ", pFileName, iControlSocketID);
	if (iRet < 0)
	{
		LOG_ERR("Send RETR cmd to ftp server failed:[%d-%s]\n", errno, strerror(errno));
		close(iDataSocketID);
		return -1;
	}
	iRet = get_reply(iControlSocketID);
	if ((iRet != ENABLE) && (iRet != ALREADY))
	{
		LOG_ERR("get RETR cmd reply error");
		close(iDataSocketID);
		return -1;
	}

	iRet = stat(pSavePath, &stFileInfo);
	if (iRet < 0)
	{
		iRet = mkdir(pSavePath, S_IRWXU | S_IROTH | S_IWOTH | S_IRWXG);
		if (iRet < 0)
		{
			LOG_ERR("mkdir %s error:[%d-%s]\n", pSavePath, errno, strerror(errno));
			close(iDataSocketID);
			return -1;
		}
	}
	sprintf(pLocalFile, "%s/%s", pSavePath, pFileName);
	iLocalFileFd = open(pLocalFile, O_CREAT | O_TRUNC | O_WRONLY);
	if (iLocalFileFd < 0)
	{
		LOG_ERR("creat local file %s error:[%d-%s]\n", pLocalFile, errno, strerror(errno));
		close(iDataSocketID);
		return -1;
	}
	while (1)
	{
		iCount = read(iDataSocketID, pRcvBuf, sizeof(pRcvBuf));
		if (iCount <= 0)
			break;
		pTmp = pRcvBuf;
		while (iCount > 0)
		{
			iWriteCount = write(iLocalFileFd, pTmp, iCount);
			if (iWriteCount < 0)
			{
				LOG_ERR("ERROR:write data to %s failed:[%d-%s]\n", iLocalFileFd, errno, strerror(errno));
				fsync(iLocalFileFd);
				close(iLocalFileFd);
				close(iDataSocketID);
				return -1;
			}
			iCount = iCount - iWriteCount;
			pTmp = pTmp + iWriteCount;
		}
	}
	fsync(iLocalFileFd);
	close(iLocalFileFd);
	close(iDataSocketID);
	if (get_reply(iControlSocketID) != 226)
	{
		LOG_WRN("Warning:get ftp data reply not OK\n");
	}
	return 0;
}

/*******************************************************************************
*Function Name    :_quit_server
*Description      :disconnect the control with ftp server
*Input       	  :int iControlSocket:the control socket id
*Output 		  :NONE
*Return           :NONE
*******************************************************************************/
static void _quit_server(int iControlSocket)
{
	if (iControlSocket < 0)
	{
		LOG_ERR("invalid input argue value\n");
		return ;
	}
	int iRet = send_cmd("QUIT", NULL, iControlSocket);
	if (iRet < 0)
	{
		LOG_WRN("send QUIT cmd to ftp server failed:[%d-%s]", errno, strerror(errno));
		close(iControlSocket);
		return;
	}
	if (get_reply(iControlSocket) != 221)
	{
		LOG_WRN("Not normal quit the FTP connect\n");
	}
	close(iControlSocket);
}


/*******************************************************************************
*Function Name    :ftp_download_file
*Description      :  
*Input       	  :const char * pFileName,such as /version.txt or version.txt 
*Input       	  :const char * pSavePath  
*Input       	  :const struct sockaddr_in * pHost  
*Input       	  :const char * pUserName  
*Input       	  :const char * pPassword  
*Output 		  :
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
static int ftp_download_file(const char *pFileName, const char *pSavePath, const struct sockaddr_in *pHost, const char *pUserName, const char *pPassword,int iTimeOut)
{
	int iRet = 0, iSocketID = 0, iDataPort = 0, iDataSocketID = 0;
	char pRemotePath[100] = { 0 };
	char pName[100] = { 0 };
	char *pAddress = NULL;
	int iPathLen = 0;
	if (NULL == pFileName || NULL == pSavePath || NULL == pHost || NULL == pUserName || NULL == pPassword || iTimeOut < 0)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}

	iSocketID = _connect_server(pHost, iTimeOut); //connect ftp server
	if (iSocketID < 0)
	{
		LOG_ERR("Connect ftp server failed\n");
		return -1;
	}
	iRet = get_reply(iSocketID);
	if (iRet != 220)
	{
		LOG_ERR("%d:Connect failed\n", 220);
		return -1;
	}
	iRet = _login_server(iSocketID, pUserName,pPassword);//login ftp server
	if (iRet < 0)
	{
		LOG_ERR("Login ftp server failed\n");
		return -1;
	}
	 ///change remote dir
	strncpy(pName, pFileName,sizeof(pName));
	pAddress = strrchr(pFileName, '/');//for compatibility /version.txt and version.txt
	if (pAddress != NULL)
	{
		iPathLen = pAddress - pFileName;
		if (iPathLen == 0)
			strcpy(pRemotePath, "/home/ftpxwms");		
		else
		{
			strcpy(pRemotePath, "/home/ftpxwms"); //modified by tiger.60
			strncat(pRemotePath, pFileName, iPathLen);
		}
					
		memcpy(pName, pAddress+1,strlen(pFileName)-iPathLen);
		iRet = send_cmd("CWD ", pRemotePath, iSocketID);
		if (iRet < 0)
		{
			LOG_ERR("Send CWD cmd to ftp server failed:[%d-%s]\n", errno, strerror(errno));
			return -1;
		}
		iRet = get_reply(iSocketID);
		if (iRet != 250)
		{
			LOG_ERR("Get CWD cmd reply error!\n");
			return -1;
		}
	}
	

	iRet = _get_data(iSocketID, pName, pSavePath, pHost, iTimeOut);
	if (iRet < 0)
	{
		LOG_ERR("get %s data failed\n", pFileName);
		return -1;
	}
	_quit_server(iSocketID);
	return 0;
}

/*******************************************************************************
*Function Name    :ftp_get_new_version
*Description      :get the version info of new app
*Input       	  :u8 * pNewVersion:the string of version value
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error
*******************************************************************************/
static int ftp_get_new_version(char *pNewVersion)
{
	int iRet = 0;
	char pLocalFileName[100] = { 0 };
	char pVersion[100] = { 0 };
	if (NULL == pNewVersion)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}
	iRet = ftp_download_file(FTP_VERSION_FILE_NAME, stOtaMc.stUpdateMethod.pDownloadDir, &stOtaMc.stUpdateMethod.stNetAddr, stOtaMc.stUpdateMethod.pUserName, stOtaMc.stUpdateMethod.pPassword, stOtaMc.stUpdateMethod.u8ConnectTimeout);
	if (iRet < 0)
	{
		LOG_ERR("Download %s failed\n", FTP_VERSION_FILE_NAME);
		return -1;
	}
	sprintf(pLocalFileName, "%s/%s", stOtaMc.stUpdateMethod.pDownloadDir, FTP_VERSION_FILE_NAME);

	iRet = chmod(pLocalFileName, 0644);
	if (iRet < 0)
	{
		LOG_INF("chmod %s to 0644\n", pLocalFileName);
		return -1;
	}
	iRet = ini_read(pLocalFileName, NULL, "version", pVersion, sizeof(pVersion));
	if (iRet < 0)
	{
		LOG_ERR("Get version from %s failed\n", pLocalFileName);
		return -1;
	}
	strcpy(pNewVersion, pVersion);
	return 0;
}

/*******************************************************************************
*Function Name    :ftp_need_upgrade
*Description      :
*Input       	  :const char * pCurVersion
*Input       	  :const char * pNewVersion
*Output 		  :
*Return           :int:0 need update ;-1:need not update
*******************************************************************************/
static int ftp_need_update(const char *pCurVersion, const char *pNewVersion)
{
	int iRet = 0;

	if (NULL == pCurVersion || NULL == pNewVersion)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}

	iRet = strcasecmp(pNewVersion, pCurVersion);
	if (iRet <= 0)
		return -1;
	return 0;
}
/*******************************************************************************
*Function Name    :_ftp_init
*Description      :
*Input       	  :const char * pConfFilePath
*Input       	  :update_master * pUpdateMaster
*Output 		  :
*Return           :int
*******************************************************************************/
int _ftp_init(const char *pConfFilePath, update_method *pUpdateMaster)
{
	int iRet;
	iRet = 0;
	update_method stUpdateMaster = { 0 };
	char pHostIpAddr[64] = { 0 };
	char pTimeout[64] = { 0 };
	char pVersionFilePath[100] = { 0 };
	if (NULL == pConfFilePath || NULL == pUpdateMaster)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}

	strcpy(stUpdateMaster.pUpdateMethod, "ftp");
	iRet = ini_read(pConfFilePath, "ftp_conf", "ftp_serverip", pHostIpAddr, sizeof(pHostIpAddr));
	if (iRet < 0)
	{
		LOG_ERR("read ftp serverip configure failure\n");
		return iRet;
	}
	iRet = fill_host_addr(pHostIpAddr, &stUpdateMaster.stNetAddr, DEFAULT_FTP_PORT);
	if (iRet < 0)
	{
		LOG_ERR("fill host address configure failure\n");
		return iRet;
	}
	iRet = ini_read(pConfFilePath, "ftp_conf", "user", stUpdateMaster.pUserName, sizeof(stUpdateMaster.pUserName));
	if (iRet < 0)
	{
		LOG_ERR("read ftp user name configure failure\n");
		return iRet;
	}
	iRet = ini_read(pConfFilePath, "ftp_conf", "password", stUpdateMaster.pPassword, sizeof(stUpdateMaster.pPassword));
	if (iRet < 0)
	{
		LOG_ERR("read ftp Password configure failure\n");
		return iRet;
	}
	iRet = ini_read(pConfFilePath, "ftp_conf", "lcd", stUpdateMaster.pDownloadDir, sizeof(stUpdateMaster.pDownloadDir));
	if (iRet < 0)
	{
		LOG_ERR("read ftp DownloadDir configure failure\n");
		return iRet;
	}
	iRet = ini_read(pConfFilePath, "ftp_conf", "cwd", stUpdateMaster.pCurrentDir, sizeof(stUpdateMaster.pCurrentDir));
	if (iRet < 0)
	{
		LOG_ERR("read ftp Current Dir configure failure\n");
		return iRet;
	}
	iRet = ini_read(pConfFilePath, "ftp_conf", "pwd", stUpdateMaster.pExcuteDir, sizeof(stUpdateMaster.pExcuteDir));
	if (iRet < 0)
	{
		LOG_ERR("read ftp Excute Dir configure failure\n");
		return iRet;
	}
	
	iRet = ini_read(pConfFilePath, "ftp_conf", "time_out", pTimeout, sizeof(pTimeout));
	if (iRet < 0)
	{
		LOG_ERR("read ftp Master App Name configure failure\n");
		return iRet;
	}
	stUpdateMaster.u8ConnectTimeout = (u8)atoi(pTimeout);
	stUpdateMaster.get_new_version = ftp_get_new_version;
	stUpdateMaster.need_update = ftp_need_update;
	stUpdateMaster.download_file = ftp_download_file;
	*pUpdateMaster = stUpdateMaster;
	return 0;
}

int _ftp_mc_init(const char *pConfFilePath, update_method *pUpdateMaster)
{
	int iRet;
	iRet = 0;
	update_method stUpdateMaster = { 0 };
	char pHostIpAddr[64] = { 0 };
	char pTimeout[64] = { 0 };
	char pVersionFilePath[100] = { 0 };
	if (NULL == pConfFilePath ||NULL == pUpdateMaster)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}

	strcpy(stUpdateMaster.pUpdateMethod, "ftp");
	iRet = ini_read(pConfFilePath, "ftp_conf", "ftp_serverip", pHostIpAddr, sizeof(pHostIpAddr));
	if (iRet < 0)
	{
		LOG_ERR("read ftp serverip configure failure\n");
		return iRet;
	}
	iRet = fill_host_addr(pHostIpAddr, &stUpdateMaster.stNetAddr, DEFAULT_FTP_PORT);
	if (iRet < 0)
	{
		LOG_ERR("fill host address configure failure\n");
		return iRet;
	}
	iRet = ini_read(pConfFilePath, "ftp_conf", "user", stUpdateMaster.pUserName, sizeof(stUpdateMaster.pUserName));
	if (iRet < 0)
	{
		LOG_ERR("read ftp user name configure failure\n");
		return iRet;
	}
	iRet = ini_read(pConfFilePath, "ftp_conf", "password", stUpdateMaster.pPassword, sizeof(stUpdateMaster.pPassword));
	if (iRet < 0)
	{
		LOG_ERR("read ftp Password configure failure\n");
		return iRet;
	}
	
	iRet = ini_read(pConfFilePath, "ftp_conf", "time_out", pTimeout, sizeof(pTimeout));
	if (iRet < 0)
	{
		LOG_ERR("read ftp Master App Name configure failure\n");
		return iRet;
	}
	
	stUpdateMaster.u8ConnectTimeout = (u8)atoi(pTimeout);
	stUpdateMaster.get_new_version = ftp_get_new_version;
	stUpdateMaster.need_update = ftp_need_update;
	stUpdateMaster.download_file = ftp_download_file;
	*pUpdateMaster = stUpdateMaster;
	return 0;
}
/******************* (C) COPYRIGHT 2018  Jd.Com, Inc . *****END OF FILE****/

