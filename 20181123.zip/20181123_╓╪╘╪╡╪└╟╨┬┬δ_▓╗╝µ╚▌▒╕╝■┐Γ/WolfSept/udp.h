#ifndef _UDP_H__
#define _UDP_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <net/if.h>
#include <sys/ioctl.h> 
#include <arpa/inet.h>
#include <unistd.h>

#include "debug.h"

//add by jxu 20180918-begin
//#define MSG_SEND_PORT 5000//for the v2.0 port
//#define MSG_RECV_PORT 5001//for the v2.0 port
#define MSG_SEND_PORT 3000//for the v1.0 port
#define MSG_RECV_PORT 3001//for the v1.0 port
//add by jxu 20180918-end

#define CFG_SEND_PORT 6000
#define CFG_RECV_PORT 6001

#define INF_SEND_PORT 3010
#define INF_RECV_PORT 3011

#define UDP_DEV		"eth0"

extern int init_udp(uint16_t uiRecvPort);
extern int send_udp(int iSockfd, const void* pBuf, int iLen, uint16_t uiSendPort, char *cSendIP);
extern int send_msg2console(const void* pBuf, int iLen);
extern int send_inf2collector(const void* pBuf, int iLen);
extern int recv_udp(int iSockfd, void *pBuf, int iMaxSize, bool bBlock);
extern int close_udp(int iSockfd);

#endif/*_UDP_H*/