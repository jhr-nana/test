/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* FileName:device.H
* Author: Menghu Wang   Version: V1.0   Data:2017-08-16
* Description:THE INTERFACE OF AGV MOVE CONTROL AND TOP CONTROL FUNCTION
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
#ifndef _DEVICE_H__
#define _DEVICE_H__
#include "can.h"
#include "global_var.h"
#include <stdbool.h>
#include <sys/select.h>
#include <string.h>
#include "udp_msg.h"
#include "debug.h"
#include "bms_correctsoc.h"//add by jxu 20181017
/* Define to prevent recursive inclusion -------------------------------------*/
/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
typedef enum
{
	MC_GET_FLAG = 0,
	MC_SET_FLAG,
	MC_OPERATE,
	MC_GET_PARAM,
	MC_SET_PARAM

} mc_cmd_style;

typedef enum
{
	MC_GO_FORWARD = 0,
	MC_GO_BACKWARD,
	MC_TURN_LEFT,
	MC_TURN_RIGHT,
	MC_STOP,
	MC_BEGIN_CHARGE,
	MC_STOP_CHARGE,
	MC_RESET,
	MC_ENABLE_WDG,
	MC_SLOW_GO_BACK,
	MC_SLOW_GO_STRAIGHT,
	MC_LEFT_ARC,
	MC_RIGHT_ARC
} mc_operate_style;

typedef enum
{
	TC_OPERATE = 1,
	TC_GET_FLAG,
	TC_SET_FLAG,
	TC_GET_PARAM,
	TC_SET_PARAM
} tc_cmd_style;

typedef enum
{
	TC_LIFT_LOCK = 0,
	TC_RISE,
	TC_LAY,
	TC_PALLET_LOCK,
	TC_PALLET_LEFT,
	TC_PALLET_RIGHT,
	TC_ENABLE_WDG,
	TC_STOP
} tc_operate_style;

/* Private define ------------------------------------------------------------*/
typedef unsigned short u16;
#define ARM2MC_CMD_CANID          (0x202)
#define ARM2TC_CMD_CANID		  (0x204)
#define REVERSE_VALUE               (0)
#define OK		0x4f4b
#define REFUSE		0x4e4f
#define BERROR		0x4f56

#define OK			0x4f4b
#define NO			0x4e4f
#define BIG_ERROR	0x4f56
#define IS_UP		0x5550
#define IS_DOWN		0x444e

#define MM_ERROR_BASE			 (3000)
#define MC_ERROR_BASE			 (2000)
#define TC_ERROR_BASE			 (1000)

#define TC_CLASP				(16)
#define MAX_LINE				(1000)

#define WEIGHT_LEVEL_0			0
#define WEIGHT_LEVEL_1			1
#define WEIGHT_LEVEL_2			2
#define WEIGHT_LEVEL_3			3
#define WEIGHT_LEVEL_4			4
#define WEIGHT_LEVEL_5			5
#define WEIGHT_LEVEL_6			6
#define WEIGHT_LEVEL_7			7
#define WEIGHT_LEVEL_8			8
#define WEIGHT_LEVEL_9			9
#define WEIGHT_LEVEL_10			10
#define WEIGHT_LEVEL_11			11
#define WEIGHT_LEVEL_12			12
#define WEIGHT_LEVEL_13			13
#define WEIGHT_LEVEL_14			14
#define WEIGHT_LEVEL_15			15

///related with pallet
#define GET_PALLET_ANGLE_COUNT  (5)
#define UART_RET_SIZE			(50)

#define DIRECTION_X_P		0
#define DIRECTION_Y_P		1
#define DIRECTION_X_N		2
#define DIRECTION_Y_N		3
#define INVALID_DIRECTION	4 //by tiger.13

#define INVALID_POINT		0 //by tiger.27


#define VEH_MOVE_STATUS_OFFLINE    (1)
#define VEH_MOVE_STATUS_STOP       (2)
#define VEH_MOVE_STATUS_WALK       (3)
#define VEH_MOVE_STATUS_SYNLEFT    (4)
#define VEH_MOVE_STATUS_SYNRIGHT   (5)
#define VEH_MOVE_STATUS_TCUP       (6)
#define VEH_MOVE_STATUS_TCDOWN     (7)
#define VEH_MOVE_STATUS_CHARGE     (8)
#define VEH_MOVE_STATUS_BACKWARD   (9)
#define VEH_MOVE_STATUS_ONLINE     (10)
#define VEH_MOVE_STATUS_DPLEFT     (11)
#define VEH_MOVE_STATUS_DPRIGHT    (12)
#define VEH_MOVE_STATUS_TPLEFT     (13)
#define VEH_MOVE_STATUS_TPRIGHT    (14)

#define NO_ERROR					(2000)
#define EVENT_ERR_EMERSTOP          (2001)
#define EVENT_ERR_EMERSTOPPRESS     (2003)
#define EVENT_ERR_AGVSAFE           (2004)
#define EVENT_ERR_NOCONTACTIMPACT   (2005)
#define EVENT_ERR_LOSENAVIGATE      (2006)
#define EVENT_ERR_DERAIL            (2007)
#define EVENT_ERR_LEFTSERVOINVALID  (2008)
#define EVENT_ERR_RIGHTSERVOINVALID (2009)
#define EVENT_ERR_SYNC_CYCLE_COMBREAK       (2011)
#define EVENT_ERR_WHEEL_PLATE_ANGLEDIFFOV   (2012)
#define EVENT_ERR_ENCODERL					(2013)
#define EVENT_ERR_ENCODERR					(2014)
#define EVENT_ERR_CHARGE_FEEDBACK_OVERTIME  (2016)
#define EVENT_ERR_OB_DETECT_FAULT_EVENT     (2017)
#define EVENT_ERR_MOTORL_NO_ACTION_EVENT    (2018)
#define EVENT_ERR_MOTORR_NO_ACTION_EVENT    (2019)
#define EVENT_ERR_MC_TIMEOUT				(2034) // by tiger.41
//add by jxu 20180129:begin
#define EVENT_ERR_DIFFOV_AFTERTHREE            (2020)
#define EVENT_ERR_PLATE_CYCLE_SERVO_INVALID    (2021)
#define EVENT_ERR_LIFT_SERVO_INVALID		   (2022)
#define EVENT_ERR_LIFT_ENCODER_ERR			   (2023)
#define EVENT_ERR_LIFT_MOTION_NO_ACTION        (2024)
#define EVENT_ERR_LWHEEL_SERVO_OFFLINE         (2025)
#define EVENT_ERR_RWHEEL_SERVO_OFFLINE		   (2026)
#define EVENT_ERR_PLATE_CYCLE_SERVER_OFFLINE   (2027)
#define EVENT_ERR_LIFT_SERVO_OFFLINE           (2028)
#define EVENT_ERR_SERVO_INITIAL_FAIL           (2029)
#define EVENT_ERR_LWHEEL_SERVO_DISCONNECT      (2030)
#define EVENT_ERR_RWHEEL_SERVO_DISCONNECT      (2031)
#define EVENT_ERR_PLATE_CYCLE_SERVO_DISCONNECT (2032)
#define EVENT_ERR_LIFT_SERVO_DISCONNECT        (2033)
#define EVENT_ERR_EMO_LWHEEL_SERVO_ERROR        (2035)
#define EVENT_ERR_EMO_RWHEEL_SERVO_ERROR        (2036)
#define EVENT_ERR_EMO_PLATE_SERVO_ERROR         (2037)
#define EVENT_ERR_EMO_LIFT_SERVO_ERROR          (2038)
#define EVENT_ERR_MOTEC_LWHEEL_SERVO_ERROR      (2039)
#define EVENT_ERR_MOTEC_RWHEEL_SERVO_ERROR      (2040)
#define EVENT_ERR_MOTEC_PLATE_SERVO_ERROR       (2041)
#define EVENT_ERR_MOTEC_LIFT_SERVO_ERROR        (2042)
#define EVENT_ERR_HSLS_LWHEEL_SERVO_ERROR       (2043)
#define EVENT_ERR_HSLS_RWHEEL_SERVO_ERROR       (2044)
#define EVENT_ERR_HSLS_PLATE_SERVO_ERROR        (2045)
#define EVENT_ERR_HSLS_LIFT_SERVO_ERROR         (2046)
#define EVENT_ERR_TURNING						(2056)//by tiger.69
#define EVENT_ERR_MC_RESET						(2057)//by tiger.70

#define EVENT_ERR_PARAM_ERROR					(2900)
#define EVENT_ERR_MC_EXCEPTION					(2901)
//add by jxu 20180129:end

#define EVENT_ERR_TC_SERVO_ERR				(1001)
#define EVENT_ERR_TC_CAN_COM_BREAK			(1002)
#define EVENT_ERR_TC_LIFT_TACK_1MIN			(1003)
#define EVENT_ERR_TC_CYCLE_ENCODEER_ERR		(1004)
#define EVENT_ERR_TC_ESTOP_PRESSED			(1005)
#define EVENT_ERR_TC_CONTROL_STOP			(1006)
#define EVENT_ERR_TC_RESUMABLE_STOP			(1007)
#define EVENT_ERR_TC_WHEEL_PLATE_ANGLE_OV	(1008)
#define EVENT_ERR_TC_CYCLE_MOTOR_NO_ACTION	(1009)
#define EVENT_ERR_TC_TIMEOUT				(1010) // by tiger.41

#define EVENT_TC_SERVO_ERR					0xFF01
#define EVENT_TC_CAN_COM_BREAK				0xFF02
#define EVENT_TC_LIFT_TAKE_1MIN				0xFF03
#define EVENT_TC_CYCLE_ENCODER_ERR			0xFF04
#define EVENT_TC_ESTOP_PRESSED				0xFF05
#define EVENT_TC_CONTROL_STOP				0xFF06
#define EVENT_TC_RESUMABLE_STOP				0xFF07
#define EVENT_TC_WHEEL_PLATE_ANGLE_OV		0xFF08
#define EVENT_TC_CYCLE_MOTOR_NO_ACTION		0xFF09

#define EVENT_ERR_DAOVERFLOW        (3000)
#define EVENT_ERR_TPIDERROR         (3001)	//the contain number of shelf is different from operation
#define EVENT_ERR_MCREFUSE          (3002)
#define EVENT_ERR_DESTSTOPINVALID   (3003)
#define EVENT_ERR_PROCESTOPINVALID  (3004)
#define EVENT_ERR_DSPTPSTATUS       (3005)
#define EVENT_ERR_CURRENTPRESEQSAME (3006)
#define EVENT_ERR_VEHSTOPEXCEPTION  (3007)
#define EVENT_ERR_PARKPRECISION     (3008)
#define EVENT_ERR_SCANTPIDERROR     (3009)
#define EVENT_ERR_CHARGECURSAMLL    (3010)
//#define EVENT_ERR_CHARGECURSAMLL    (3099) //for test by tiger.0
#define EVENT_ERR_PLATEOFFSETBIG    (3011)	//after sync turn left/right ,the pallet angle offset is too big
#define EVENT_ERR_CYCLEFINSCANERR   (3012)	//after change the direction of the shelves or lift up,the pallet angle too big 
#define EVENT_ERR_JACKOFFSETBIG     (3013)
#define EVENT_ERR_MCERR				(3014) 
#define EVENT_ERR_TCERR				(3015) 
#define EVENT_ERR_TPERR				(3016) 
#define EVENT_ERR_POINTIDERR		(3017)
#define EVENT_ERR_GROUNDDIRECTERR	(3018)
#define EVENT_ERR_STOPCHARGE		(3019)
#define EVENT_ERR_SLIDING			(3020) //MC  slided , by tiger.28
#define EVENT_ERR_TILT_HEADER		(3021) //the header is tilt ,by tiger.29
#define EVENT_ERR_BIG_ANGEL			(3022) // the shelf QR's error angle is large, by tiger.30
#define EVENT_ERR_WRONG_HEADER_DIRCETION		(3024) // the task's header direction is different with current header direction, by tiger.27
#define EVENT_ERR_WRONG_LOCATION		(3025) // the task's first point is different with current location and the last point, by tiger.27
#define EVENT_ERR_GET_TPID				(3026) // get pallet info error , by tiger.32
#define EVENT_ERR_CARMEROPENFAIL    (3027)//add the errcode temp
#define EVENT_ERR_CARMERINITFAIL    (3028)//add the errcode temp
#define EVENT_ERR_CARMERCAPTUREFAIL (3029)//add the errcode temp
#define EVENT_ERR_CARMERREADFAILE   (3030)//add the errcode temp
#define EVENT_ERR_TASK_ERROR		(3031) //the go straight task is wrong 
#define EVENT_ERR_UNSUPPORTED	    (3032)//unsupported task or action
#define EVENT_ERR_INIT_CAMERAFAIL	(3033)
#define EVENT_ERR_GET_SELFCAMERAVERERR	(3034)
#define EVENT_ERR_MANUAL_MOVE_AGV	(3041) //add bytiger.62

#define EVENT_ERR_BATTYPE_FAIL			 (3042)//add jxu 20180426:begin
#define EVENT_ERR_BAT_DISCHARGEOVERTEMP  (3043)
#define EVENT_ERR_BAT_CHARGEOVERTEMP	 (3044)
#define EVENT_ERR_BAT_VOLDISBALANCE	     (3045)
#define EVENT_ERR_BAT_DISCHARGEOVERVOL	 (3046)
#define EVENT_ERR_BAT_CHARGEOVERVOL	     (3047)
#define EVENT_ERR_BAT_DISCHARGEOVERCUR	 (3048)
#define EVENT_ERR_BAT_CHARGEERR			 (3049)//add jxu 20180426:end
#define EVENT_ERR_DROPPED_SHELF			 (3050)//get QR failed becasue the shelf is dropped,by tiger.82
#define EVENT_ERR_PGV_STOPPED			 (3055) //add by tiger.90
#define EVENT_ERR_BAT_CHECK_FAILED			 (3056) //add by tiger.102
#define EVENT_ERR_BAT_NEED_OFFLINE			 (3057) //add by tiger.102
#define EVENT_ERR_BMS_SOC_DISTORTION    (3058)	// add by keodng, ��ӳ���SOCֵ����ʧ�棨��߻���ͣ�

#define EVENT_ERR_UPSERVOINVALID    (4002)
#define EVENT_ERR_CYCLESERVOINVALID (4003)
#define EVENT_ERR_BATCOMMUNISTOP    (4004)
#define EVENT_ERR_UARTCOMMUNISTOP   (4005)
#define EVENT_ERR_MCCOMMUNISTOP     (4006)
#define EVENT_ERR_TCCOMMUNISTOP     (4007)

#define EVENT_ERR_NETWORK_DISCONNECT	(5003) //by tiger.93
#define EVENT_ERR_NETWORK_RECOVERY		(5004) //by tiger.93
#define NO_EVENT_ERR					(9999)	//add by tiger.58
#define MC_HEARTBEAT_NO_EVENT_ERR					(0)	//add by tiger.58

#define SLOW_GO_BACK_SPEED         200//add by jxu 20180828
#define ACTION_NONE                99//add by jxu 20180828

#define VAR_OUT_TRACK	0x02 
#define CLEAN_FLAG		0

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
#define GENERATION_1P0		0x80  //change by tiger.17
#define GENERATION_2P0		0xff //change by tiger.17
#define GENERATION_ERR		-1

#define CAN_COM_PROTOCOL_VER	VERSION_1P0

#define WORK_MODE_NORMAL		1
#define WORK_MODE_DEBUG			2
#define WORK_MODE_UNKNOWN		-1

#define INQUIRE					0
#define UPDATE					7
#define ARM2TC_CMD_CANID (0x204)
#define ARM2MC_CMD_CANID (0x202)
///start by tiger.37
#define FTP_MC_SEND_CAN_ID		0x212
#define FTP_TC_SEND_CAN_ID		0x214
#define FTP_MC_UPDATE_CAN_ID	0x202
#define FTP_TC_UPDATE_CAN_ID	0x204
#define FTP_MC_ACK_CANID		0x182
#define FTP_TC_ACK_CANID		0x184
#define FTP_MC_FINISH_CANID		0x382
#define FTP_TC_FINISH_CANID		0x284

typedef struct mc_dev
{
	int iGeneration; //from 0,1,2....n
	int iWorkMode;
	u64 iMcHeartBeatTs;	// the timestamp(ms) of the last mc heartbeat

	int(*check_version)();
	int(*get_flag)(u8 u8FlagVar);
	int(*set_flag)(u8 u8FlagVar, u32 u32Value);
	int(*get_param)(u8 u8ParamVar);
	int(*set_param)(u8 u8ParamVar, float fValue);
	int(*enable_wdg)();
	int(*start)();
	int(*reset)();
	int(*stop)();
	int(*start_charge)();
	int(*stop_charge)();

	void(*deal_ack)(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
	void(*deal_fin)(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
	int(*deal_heartbeat)(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
	int(*deal_exception)(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);

	int(*go_forward)(u8 u8Weight, u16 u16Distance, u16 u16Speed);
	int(*go_backward)(u8 u8Weight, u16 u16Distance, u16 u16Speed);
	int(*turn_left)(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed);
	int(*turn_right)(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed);
	///start ,add by tiger.10
	int(*mc_slow_go_back)(u16 u16SRemain, u16 u16QRDistance);
	int(*mc_slow_go_straight)(u16 u16SRemain, u16 u16QRDistance);
	int(*mc_leftarc)(u16 u16Weight);
	int(*mc_rightarc)(u16 u16Weight);
	///end ,add by tiger.10

	//add by jxu 20180122:begin
	int(*send_angle_offset)(u16 u16Angle);
	int(*cntl_lift_motor)(u8 u8Operate, u8 u8Weight);
	int(*cntl_cycle_motor)(u8 u8Operate, u8 u8Weight, u16 u16Angle, u16 u16Speed);
	int(*clear_derail)(void);
	int(*clear_navigation)(void);
	int(*clear_lcoder_error)(void);
	int(*clear_rcoder_error)(void);
	int(*enter_debug_mode)(void);
	int(*quit_debug_mode)(void);
	int(*clasp_pallet)(void);
	int(*unclasp_pallet)(void);
	int(*clasp_wheel)(void);
	int(*unclasp_wheel)(void);
	int(*send_update_cmd)(void);
	//add by jxu 20180122:end
} mc_dev_t;

typedef struct tc_dev
{
	int iGeneration;
	int iWorkMode;

	int  (*check_version)();
	int(*get_flag)(u8 u8FlagVar);
	int(*set_flag)(u8 u8FlagVar, u32 u32Value);
	int(*get_param)(u8 u8ParamVar);
	int(*set_param)(u8 u8ParamVar, float fValue);
	int(*enable_wdg)();
	int(*start)();
	int(*reset)();
	int(*stop)();

	void(*deal_ack)(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
	void(*deal_fin)(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
	void(*deal_angle_ack)(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
	int(*deal_heartbeat)(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);
	int(*deal_exception)(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr);

	int(*send_angle_offset)(u16 u16Angle);
	int(*cntl_lift_motor)(u8 u8Operate, u8 u8Weight);
	int(*cntl_cycle_motor)(u8 u8Operate, u8 u8Weight, u16 u16Angle, u16 u16Speed);
} tc_dev_t;

#define CAMERA_TYPE_TOP			1
#define CAMERA_TYPE_BOT			2
#define CAMERA_TYPE_ERR			-1

#define CAMERA_VERSION_UART		0 //add by jxu 20180920 from 1->0
#define CAMERA_VERSION_V4L2		1 //add by jxu 20180920 from 2->1
#define CAMERA_VERSION_ERR		-1

#define EMO_SID					11
#define MOTEC_SID				12
#define HSLS_SID				13

typedef struct qr_info
{
	int iQR;
	float fAngle;//by tiger -180~180
	int iXOffset;
	int iYOffset;
	pthread_mutex_t stQRInfoMutex;
} qr_info_t;

typedef struct camera_dev
{
	int iVersion;
	int iWorkMode;
	int iType;
	int iUartVersion;//add by jxu 20180920

	int(*start_camera)();
	int(*stop_camera)();
	int(*get_qrinfo)(qr_info_t * pQRInfo);

} camera_dev_t;

extern mc_dev_t g_stMcDev;
extern tc_dev_t g_stTcDev;
extern qr_info_t g_stQrInfo;
extern camera_dev_t g_stTopCameraDev;
extern camera_dev_t g_stBottomCameraDev;

/* Exported functions --------------------------------------------------------*/

extern char * get_mc_evnet_desc(int iEventType);
extern char * get_tc_evnet_desc(int iEventType);
extern char * get_mm_evnet_desc(int iEventType);
extern char * get_other_evnet_desc(int iEventType);
extern char * get_move_status(int iMoveStatus);
extern char * get_direct_desc(int iHeadDirection);
extern char * get_pallet_status_desc(int iPalletStatus);
extern char * get_err_str(int iErrNo);

extern char * get_mc_cmd_name(int iMcCmd);
extern char * get_tc_cmd_name(int iTcCmd);
extern int enable_wdg(int iDevType);
extern int get_flag(int iDevType, u8 u8FlagVar);
extern int set_flag(int iDevType, u8 u8FlagVar, u32 fValue);
extern int set_param(int iDevType, u8 u8ParamVar, float fValue);
extern int get_param(int iDevType, u8 u8ParamVar);
extern int get_expected_head(u8 iCurHead, u16 u16Angle, u8 iTurnDirect);
extern int go_forward(u8 u8Weight, u16 u16Distance, u16 u16Speed, bool *bNeedSendFinish);
extern int turn_left(u8 sync, u8 u8Weight, u16 u16Angle, u16 u16Speed);
extern int turn_right(u8 sync, u8 u8Weight, u16 u16Angle, u16 u16Speed);
extern int stop_agv(int iDevType);
extern int start_charge();
extern int stop_charge();
extern int mc_reset();
extern int tc_reset();
extern int tc_rise(u8 u8Weight, const char * pContainerNum);
extern int tc_lay(u8 u8Weight, const char * pContainerNum);
extern int pallet_turn_left(u8 u8Weight, u16 u16Angle, u16 u16Speed);
extern int pallet_turn_right(u8 u8Weight, u16 u16Angle, u16 u16Speed);
extern int clear_derail();
extern void send_pallet_angle_offset(u16 u16Angle);
extern int deal_mc_heartbeat(struct can_frame* pCanFrame);
extern int deal_mc_heartbeat_v2(struct can_frame * pCanFrame);// add by jxu 20180121
extern void deal_mc_completion(struct can_frame* pCanFrame);
extern void deal_tc_completion(struct can_frame* pCanFrame);
extern void deal_mc_ack(struct can_frame* pCanFrame);
extern void deal_mc_v2_ack(struct can_frame * pCanFrame);// add by jxu 20180121
extern void deal_mc_rw_flag_param_v2_ack(struct can_frame * pCanFrame);// add by jxu 20180121
extern void deal_tc_upload(struct can_frame * pCanFrame);
extern void deal_mc_upload(struct can_frame * pCanFrame);
extern void deal_mc_angle_v2_ack(struct can_frame * pCanFrame);// add by jxu 20180125
extern void deal_tc_ack(struct can_frame* pCanFrame);
extern int deal_mc_exception(struct can_frame * pCanFrame);
extern int deal_tc_exception(struct can_frame * pCanFrame);
extern int get_pallet_info(void);

void deal_tc_angle_ack(struct can_frame* pCanFrame);
///start ,add by tiger.10
extern int mc_slow_go_back(u16 u16SRemain, u16 u16QRDistance);
extern int mc_slow_go_straight(u16 u16SRemain, u16 u16QRDistance);
extern int mc_leftarc(u16 u16Weight);
extern int mc_rightarc(u16 u16Weight);
///end ,add by tiger.10

extern void deal_tc_angle_ack(struct can_frame* pCanFrame);

extern int mc_get_version(int * pVersion);
extern int tc_get_version(int * pVersion);
extern int mc_check_version();
extern int tc_check_version();

extern int init_mc_dev(mc_dev_t *pMcDev);
extern int init_tc_dev(tc_dev_t *pTcDev);

extern int init_camera_dev(camera_dev_t *pCameraDev);
extern int camera_get_version(int * pVersion);
extern int camera_get_type(int * pType);

extern void print_can_frame(struct can_frame * pCanFrame);

extern int init_battery_type();//add by jxu 20180820
extern int qr_info_init(qr_info_t * pQrInfo);
extern int qr_info_get(int *pQR, float *pAngle, int *pXOffset, int *pYOffset, qr_info_t *pQrInfo);
extern int qr_info_set(int iQR, float fAngle, int iXOffset, int iYOffset, qr_info_t * pQrInfo);

extern void clasp_pallet(void);
extern void unclasp_pallet(void);
extern void clasp_wheel(void);
extern void unclasp_wheel(void);
extern int clear_derail(void);
extern int clear_navigation(void);
extern void reboot_agv(void);
extern int config_d500_20();
extern int deal_mc_v2_update_cmd_ack(struct can_frame * pCanFrame); //add by tiger.43
extern int get_d500_generation();//add by tiger.43
extern int deal_mc_v2_update_check_ack(struct can_frame *pCanFrame);//add by tiger.43
extern int get_mc_mac(void);
extern int ftp_recv_can_v2(int iCanID, int iTimeOut);
extern int ftp_recv_can(struct timeval *pTimeOut, int iCanID);
#endif /* _DEVICE_H__ */
/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/