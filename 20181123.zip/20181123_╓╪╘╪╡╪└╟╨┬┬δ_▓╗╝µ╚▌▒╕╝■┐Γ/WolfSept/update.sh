#!/bin/sh  
#check there is the dcu_update dir 
if [ -e dcu_update ]
then
	if [ -e dcu_backup ]  
	then  
		rm -rf dcu_backup  
	fi  
	  
	#backup the current app and version.txt to the dcu_backup dir  
	if [ -e dcu ]  
	then  
		
		cp  -r dcu dcu_backup/
		rm  -rf dcu 
	fi  
	  
	#the new app download at the dcu_update dir,copy the files to the dcu dir  
	if [ -e dcu_update ]  
	then  
		mv dcu_update dcu   
	else  
		#if there is not dcu_update dir ,then roll back  
		cp -r dcu_backup dcu  
		cd dcu 
		./jdagv &  #add '&',run in the background 
		sync
		exit 0     #eixt  
	fi  
	  
	#run the new app  
	cd dcu
	./jdagv  &   #add '&',run in the background 
	cd ..
	  
	#check the new app run success  
	updatepid=`fuser "./dcu/jdagv" | awk '{print $1}'`
	if [ "$updatepid" = "" ]  
	then  
		#the new app does not run success 
		echo "there is no new dcu !"
		rm -rf dcu  
		cp -r dcu_backup dcu  
		cd dcu   
		./jdagv  &   #add '&',run in the background  
		sync	
		exit 0  
	else  
		#if the new app run success,then we create the update_success file 
		#the new app start to check the update_success file  
		touch update_success 
		sync
	fi  
else
	sync
	./jdagv &
fi

