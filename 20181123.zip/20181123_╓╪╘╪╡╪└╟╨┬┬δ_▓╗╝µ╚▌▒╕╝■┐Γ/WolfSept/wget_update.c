/********************************************************************************
* Copyright (c) 2018, Jd.Com, Inc .
* FileName: xxx.C
* Author: Menghu Wang   Version: V1.0   Data:2018-09-29
* Description:REALIZE THE INTERFACE OF WGET_UPDATE
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include <sys/stat.h>
#include <stddef.h>
#include <stdbool.h>
#include  <errno.h>
#include "debug.h"
#include "wget_update.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
static bool gs_bConnectTimeOut = false;
#define  CONNECT_TIMEOUT 4
#define  ENAGBLE_WGET    1
/*******************************************************************************
*Function Name    :download_file
*Description      :download file by wget ,if timeout ,then not download  
*Input       	  :char * pUrl:download url  pSaveName:local save name,absolute path 
					iTryTime��times of download
*Output 		  :NONE
*Return           :int:0 if OK, -1 on error  
*******************************************************************************/
int wget_download_file(char *pUrl,char *pSaveName,int iTryTime)
{
	char strDownloadCmd[300] = {0};
	int iRet = 0;
	if (NULL == pUrl || NULL == pSaveName || true == gs_bConnectTimeOut || 1 == ENAGBLE_WGET)//һ�γ�ʱ�����еĶ���������
		return -1;
	sprintf(strDownloadCmd, "wget -rq -t1 --timeout=75 -O %s %s", pSaveName, pUrl);
	do 
	{
		iRet = system(strDownloadCmd);
		if (CONNECT_TIMEOUT == iRet)
		{
			gs_bConnectTimeOut = true; 
			return -1;
		}
		else if (0 == iRet)
			break;
	} while (--iTryTime>0 && (false == gs_bConnectTimeOut));
	if (iTryTime <= 0)
		return -1;
	return 0;
}

/*******************************************************************************
*Function Name    :wget_untar_file
*Description      : untar the file to directory 
*Input       	  :char * pTarName  
*Input       	  :char * pTarDir  
*Output 		  :NONE
*Return           :int:0 if Ok,-1 on error 
*******************************************************************************/
int wget_untar_file(char *pTarName,char *pTarDir)
{
	char pSysCmd[300] = { 0 };
	int iRet = 0;
	sprintf(pSysCmd, "mkdir %s && tar -xPzf %s -C %s && rm -rf %s  ", pTarDir, pTarName, pTarDir, pTarName);
	iRet = system(pSysCmd);
	if (iRet != 0)
	{
		LOG_INF("excute %s cmd failed:[%d-%s]\n", pSysCmd, errno, strerror(errno));
		sprintf(pSysCmd, "rm -rf %s", pTarDir);
		system(pSysCmd);		
		return -1;
	}
	LOG_INF("untar %s to %s succeed\n", pTarName, pTarDir);
	return 0;
	
}

/******************* (C) COPYRIGHT 2018  Jd.Com, Inc . *****END OF FILE****/