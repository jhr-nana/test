/********************************************************************************
* Copyright (c) 2018, JD.COM, Inc .
* All rights reserved.
* FileName: bms_correctsoc.h
* Author: Xu Jing   Version: V2.0   Data:2018-08-20
* Description:
********************************************************************************/
#ifndef _BMS_CORRECTSOC_H_
#define _BMS_CORRECTSOC_H_

#include "can.h"
#include "device.h"
#include "global_var.h"

extern int anshang_inquiry_batt_summary_info(bat_info_t *pBattInfo);
extern int anshang_inquiry_batt_cell_info(bat_info_t *pBattInfo);
extern int anshang_inquiry_batt_fault_info(bat_info_t *pBattInfo);
extern int update_batt_info(bat_info_t *pBattInfo); //modified by yyf 20181022,del anshang_
extern int dump_batt_info(bat_info_t *pBattInfo);

//add by yyf 20181022-begin��support can protocol(201800911) for songxia battery
extern int songxia_prase_batt_info(struct can_frame *pBattCanData, bat_info_t *pBattInfo);
extern int songxia_prase_batt_fault_info(struct can_frame *pBatCanData, bat_info_t *pBattInfo);   
extern int songxia_prase_batt_cell_info(struct can_frame *pBattCanData, bat_info_t *pBattInfo);
extern int songxia_log_battery_fault_info(bat_info_t *pBattInfo);
//add by yyf 20181022-end��support can protocol(201800911) for songxia battery

//add by kedong, 20181112
extern int songxia_start_charge();
extern int songxia_stop_charge();

extern int  anshang_inquiry_bms_singleinfo(uint8_t iData1);
extern void anshang_init_single_info();
extern int  anshang_parse_bms_single_info(struct can_frame *pBatCanData);
extern int  anshang_bmstype_init_check();
extern int  bms_modify_low_voltage_soc(); 

extern int songxia_inquiry_batt_summary_info(bat_info_t *pBattInfo);//add by 20181017

#endif