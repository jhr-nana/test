#ifndef _CAN_H__
#define _CAN_H__

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/can.h>
#include <linux/can/raw.h>

#define CAN0		0
#define CAN1		1

#define BLOCK		0
#define NONBLOCK	1

extern int init_can_socket(int iDevNum, int iMode, void *pFilter, int iFilterSize);
extern int close_can_socket(int iSockFd);
extern int init_can(int iDevNum, int iMod); //  CAN0 or CAN1  BLOCK or NONBLOCK
extern int send_can(int iDevNum, struct can_frame *pCanFrame);
extern int recv_can(int iDevNum, struct can_frame *pCanFrame);
extern int close_can(int iDevNum);
extern int set_can_filter(int iDevNum, void *pfilter, int iSize);

#endif/*_CAN_H__*/