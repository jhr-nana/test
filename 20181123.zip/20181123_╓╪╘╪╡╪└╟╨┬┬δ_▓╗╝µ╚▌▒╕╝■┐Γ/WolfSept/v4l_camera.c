﻿#include "v4l_camera.h"
int CAMERA_FALL = 0;
int CAMERA_RISE = 1;
int CAMERA_CONST = 2;
#define   WIDTH               (1280)
#define   HEIGHT              (720)

/*******************************************************************************
* Function Name		 : xioctl
* Description	     :  Wrapper function for ioctl()
* input			     : iFd is a file descriptor
* input			     : iRequest is a command defined by v4l2,
* input			     : pArg is a void pointer.
* Return		     : 0:success; <0:failure.
*******************************************************************************/
static int xioctl(int iFd, int iRequest, void *pArg)
{
    int iRet;
    do 
	{
        iRet = ioctl(iFd, iRequest, pArg);
    } while (-1 == iRet && EINTR == errno);

    return iRet;
}
/*******************************************************************************
* Function Name		 : init_read
* Description	     : Perform initialization operations, when IO_METHOD_READ is used.
* input			     : iFd is a file descriptor
* input			     : uiBufferSize is buffer size.
* Return		     : 0:success; -1 : error, out of memory
*******************************************************************************/
static int init_read(camera_t *pstCamera, unsigned int uiBufferSize)
{
    int iRet = 0;

    pstCamera->pstBuffer = (buffer_t *)calloc(1, sizeof(buffer_t));
    buffer_t *pstBuffers = pstCamera->pstBuffer;

    if (!pstBuffers)
    {
        iRet = -1;
		LOG_INF("\nOut of memory!\n");
    }
    else
    {
        pstBuffers[0].length = uiBufferSize;
        pstBuffers[0].start = malloc(uiBufferSize);

        if (!pstBuffers[0].start)
        {
            iRet = -1;
			LOG_INF("\nOut of memory!\n");
        }
    }

    return iRet;
}
/*******************************************************************************
* Function Name		 : init_mmap
* Description	     : Perform initialization operations, when IO_METHOD_READ is used.
* input			     : pstCamera is a pointer returned by open_camera()
* Return		     : 0:success; -1 : error
*******************************************************************************/
static int init_mmap(camera_t *pstCamera)
{
    int iRet = 0;

    struct v4l2_requestbuffers stReq;
    CLEAR(stReq);
    stReq.count = MMAP_BUFFER_COUNT;
    stReq.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    stReq.memory = V4L2_MEMORY_MMAP;

    if (-1 == xioctl(pstCamera->iFd, VIDIOC_REQBUFS, &stReq))
    {
        iRet = -1;
        if (EINVAL == errno)
        {
			LOG_INF("This device does not support memory mapping\n");
        }
        return iRet;
    }

    if (stReq.count <= MMAP_BUFFER_LOWER_LIMIT)
    {
		LOG_INF("Insufficient buffer memory on this device\n");
        return -1;
    }

    pstCamera->pstBuffer = calloc(stReq.count, sizeof(buffer_t));
    if (!pstCamera->pstBuffer)
    {
		LOG_INF("\nOut of memory\n");
        return -1;
    }

    for (pstCamera->ulBufferNum = 0; pstCamera->ulBufferNum < stReq.count; ++(pstCamera->ulBufferNum))
    {
        struct v4l2_buffer buf;
        CLEAR(buf);
        buf.type        = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf.memory      = V4L2_MEMORY_MMAP;
        buf.index       = pstCamera->ulBufferNum;

        if (-1 == xioctl(pstCamera->iFd, VIDIOC_QUERYBUF, &buf))
        {
            return -1;
        }

        (pstCamera->pstBuffer)[pstCamera->ulBufferNum].length = buf.length;
        (pstCamera->pstBuffer)[pstCamera->ulBufferNum].start = mmap(NULL /* start anywhere */,
                                                                    buf.length,
                                                                    PROT_READ | PROT_WRITE /* required */,
                                                                    MAP_SHARED /* recommended */,
                                                                    pstCamera->iFd, buf.m.offset);

        if (MAP_FAILED == (pstCamera->pstBuffer)[pstCamera->ulBufferNum].start)
        {
			LOG_INF("\nMAP_FAILED\n");
            return -1;
        }
    }

    return iRet;
}
/*******************************************************************************
* Function Name		 : init_userp
* Description	     : Perform initialization operations, when IO_METHOD_READ is used.
* input			     : pstCamera is a pointer returned by open_camera()
* input			     : uiBufferSize is buffer size.
* Return		     : 0:success; -1 : error
*******************************************************************************/
static int init_userp(camera_t *pstCamera, unsigned int uiBufferSize)
{
    int iRet = 0;

    struct v4l2_requestbuffers stReq;
    CLEAR(stReq);
    stReq.count  = USERP_BUFFER_COUNT;
    stReq.type   = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    stReq.memory = V4L2_MEMORY_USERPTR;

    if (-1 == xioctl(pstCamera->iFd, VIDIOC_REQBUFS, &stReq))
    {
        if (EINVAL == errno)
        {
			LOG_INF("This device does not support user pointer i//o/n");
            return -1;
        }
    }

    pstCamera->pstBuffer = calloc(USERP_BUFFER_COUNT, sizeof(buffer_t));
    buffer_t *pBuffers = pstCamera->pstBuffer;

    if (!pBuffers)
    {
		LOG_INF("Out of memory\n");
        return -1;
    }

    for (pstCamera->ulBufferNum = 0; pstCamera->ulBufferNum < 4; ++(pstCamera->ulBufferNum))
    {
        pBuffers[pstCamera->ulBufferNum].length = uiBufferSize;
        pBuffers[pstCamera->ulBufferNum].start = malloc(uiBufferSize);

        if (!pBuffers[pstCamera->ulBufferNum].start)
        {
			LOG_INF("Out of memouy\n");
            return -1;
        }
    }

    return iRet;
}
/*******************************************************************************
* Function Name		 : get_real_hw
* Description	     : Get video's real width and height.
* input			     : pstCamera is a pointer returned by open_camera()
* Return		     : 0:success; -1 : error
*******************************************************************************/
static int get_real_hw(camera_t *pstCamera)
{
    int iRet = 0;
    
    struct v4l2_format stFormat;
    CLEAR(stFormat);
    stFormat.type                = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    stFormat.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
    stFormat.fmt.pix.field       = V4L2_FIELD_INTERLACED;

    if(-1 == xioctl(pstCamera->iFd, VIDIOC_G_FMT, &stFormat))
    {
        iRet = -1;
    }
    else
    {
        pstCamera->uiWidth = stFormat.fmt.pix.width;
        pstCamera->uiHeight = stFormat.fmt.pix.height;
    }

    return iRet;
}
/*******************************************************************************
* Function Name		 : set_fps
* Description	     : set camera's fps value
* input			     : pstCamera is a pointer returned by open_camera()
* Return		     : 0:success; -1 : errno is set
*******************************************************************************/
static int set_fps(camera_t *pstCamera, unsigned int uiNumerator, unsigned int uiDenominator)
{
    struct v4l2_streamparm setfps;
    CLEAR(setfps);
    setfps.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    setfps.parm.capture.timeperframe.numerator = uiNumerator;
    setfps.parm.capture.timeperframe.denominator = uiDenominator;

    return xioctl(pstCamera->iFd, VIDIOC_S_PARM, &setfps);
}
/*******************************************************************************
* Function Name		 :set_frame_fmt
* Description	     : Set frame format
* input			     : pstCamera is a pointer returned by open_camera()
* input			     : pstFormat is the format parameter
* Return		     : 0:success; -1 : errno is set
*******************************************************************************/
static int set_frame_fmt(camera_t *pstCamera, struct v4l2_format* pstFormat)
{   
   /* Note: VIDIOC_S_FMT may change width and height. */
    if (-1 == xioctl(pstCamera->iFd, VIDIOC_S_FMT, pstFormat))
    {
		LOG_INF("set image width and height failed errorno=%d errmsg:%s\n", errno, strerror(errno));
        return -1;
    }

    // Note: Buggy driver paranoia.
    unsigned int uiMin = pstFormat->fmt.pix.width * BYTE_ONE_PIXEL;
    if (pstFormat->fmt.pix.bytesperline < uiMin)
    {
        pstFormat->fmt.pix.bytesperline = uiMin;
    }
    uiMin = pstFormat->fmt.pix.bytesperline * pstFormat->fmt.pix.height;
    if (pstFormat->fmt.pix.sizeimage < uiMin)
    {
        pstFormat->fmt.pix.sizeimage = uiMin;
    }
    
    return 0;
}
/*******************************************************************************
* Function Name		 : set_ctl_value
* Description	     : Set camera's control parameters, such as white blance, gamma, contrast, etc.
* input			     : the file des of pstCamera
* input			     :  ulID is parameter's ID defined in videodev2.h, for example, V4L2_CID_AUTO_WHITE_BALANCE, V4L2_CID_GAMMA, V4L2_CID_CONTRAST;
* input			     :  iValue is the conresponding parameter's value.
* Return		     : 0:success; -1 : errno is set
*******************************************************************************/
static int set_ctl_value(int iFd, size_t ulID, int iValue)
{
    int iRet = -1;
    struct v4l2_control stCtrl;
    stCtrl.id = ulID;
    stCtrl.value = iValue;
	do {
		iRet = xioctl(iFd, VIDIOC_S_CTRL, &stCtrl);
		if (-1 == iRet)
		{
			LOG_INF("set_ctl_value error:%s\n", strerror(errno));
		}
	} while (iRet);
    return iRet;
}
/*******************************************************************************
* Function Name		 : get_ctl_value
* Description	     : Get camera's control parameters, such as white blance, gamma, contrast, etc.
* input			     : the file des of pstCamera
* input			     :  ulID is parameter's ID defined in videodev2.h, for example, V4L2_CID_AUTO_WHITE_BALANCE, V4L2_CID_GAMMA, V4L2_CID_CONTRAST;
* Return		     : get camera's control parameters; -1 : errno is set
*******************************************************************************/
static int get_ctl_value(int iFd, size_t ulID)
{
    int iRet = -1;
    struct v4l2_control stCtrl;
    stCtrl.id = ulID;
    stCtrl.value = -1;
	do {
		iRet = xioctl(iFd, VIDIOC_G_CTRL, &stCtrl);
		if (-1 == iRet)
		{
			LOG_INF("get_ctl_value error:%s\n", strerror(errno));
		}
	} while (iRet);
    
    return stCtrl.value;
}
/*******************************************************************************
* Function Name		 : query_ctl_value
* Description	     : query camera's control parameters
* input			     : the file des of pstCamera
* input			     :  ulID is parameter's ID defined in videodev2.h, for example, V4L2_CID_AUTO_WHITE_BALANCE, V4L2_CID_GAMMA, V4L2_CID_CONTRAST;
* input			     :  stCtrl is used for querying controls
* Return		     : 0:success; -1 : errno is set
*******************************************************************************/
static int query_ctl_value(int iFd, size_t ulID, struct v4l2_queryctrl *stCtrl)
{
    int iRet = -1;
    assert(stCtrl);
    stCtrl->id = ulID;
	do {
		iRet = xioctl(iFd, VIDIOC_QUERYCTRL, stCtrl);
		if (-1 == iRet)
		{
			LOG_INF("query_ctl_value error:%s\n", strerror(errno));
		}
	} while (iRet);
    
	LOG_INF("%s = %d(default), min = %d, max = %d, step = %d\n",
            stCtrl->name, stCtrl->default_value, stCtrl->minimum, stCtrl->maximum, stCtrl->step);
    return iRet;          
}
/*******************************************************************************
* Function Name		 :  do_read_frame
* Description	     :  Read one frame
* input			     :  pstCamera is a pointer returned by open_camera()
* Return		     :  0:success; -1 : errno is set
*******************************************************************************/
static int do_read_frame(camera_t *pstCamera)
{
    int iRet = 0;

    int iTryTimes = 0;
    buffer_t *stBuffers = pstCamera->pstBuffer;
    struct v4l2_buffer stBuf;
    CLEAR(stBuf);

    switch (pstCamera->enIOMethod)
    {
    case IO_METHOD_READ:
        if (-1 == read(pstCamera->iFd, stBuffers[0].start, stBuffers[0].length))
        {
            return -1;
        }
        // get image data pointer and length
        pstCamera->stHead.start = stBuffers[0].start;
        pstCamera->stHead.length = stBuffers[0].length;
        break;

    case IO_METHOD_MMAP:
        stBuf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        stBuf.memory = V4L2_MEMORY_MMAP;

        if (-1 == xioctl(pstCamera->iFd, VIDIOC_DQBUF, &stBuf))
        {
			LOG_INF("VIDIOC_DQBUF error %d  strerror=%s\n", errno, strerror(errno));
            return -1;
        }
        // get the pointer, size and buffer index of image data
        assert(stBuf.index < pstCamera->ulBufferNum);
        pstCamera->stHead.start = stBuffers[stBuf.index].start;
        pstCamera->stHead.length = stBuf.bytesused;
        pstCamera->iBufferIndex = stBuf.index;
        break;

    case IO_METHOD_USERPTR:
        stBuf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        stBuf.memory = V4L2_MEMORY_USERPTR;

        if (-1 == xioctl(pstCamera->iFd, VIDIOC_DQBUF, &stBuf))
        {
            return -1;
        }
        
        unsigned int i;
        for (i = 0; i < pstCamera->ulBufferNum; ++i)
        {
            if (stBuf.m.userptr == (unsigned long)stBuffers[i].start && stBuf.length == stBuffers[i].length)
                break;
        }
        // get image data pointer and length
        assert(i < pstCamera->ulBufferNum);
        pstCamera->stHead.start = (void *)stBuf.m.userptr;
        pstCamera->stHead.length = stBuf.bytesused;
#if 0
        if (-1 == xioctl(pstCamera->iFd, VIDIOC_QBUF, &stBuf))
        {
            iRet = -1;
            return iRet;
        }
#endif
        break;
    } // end switch

    return iRet;
}
/*******************************************************************************
* Function Name		 :  readCameraConfig
* Description	     :  read Camera Config information
* input			     :  pstCamera is a pointer returned by open_camera()
* input			     :  config is the Config param
* Return		     :  TRUE:success; FALSE: read failed
*******************************************************************************/
static BOOL readCameraConfig(camera_t *pstCamera, const char * config)
{
    BOOL bRet = FALSE;
    int arrIdx = -1;
    FILE *fp = NULL;
    char *tok;
    char buffer[128];
    assert(config);
    struct stat st;
	memset(pstCamera->cameraParam,0,sizeof(pstCamera->cameraParam));

    do {
        if (-1 == stat(config, &st))
        {
			LOG_INF("Cannot identify '%s': %d, %s\n", config,
                errno, strerror(errno));
            break;
        }

        fp = fopen(config,"r");
        if (NULL == fp)
        {
			LOG_INF("Open file failed\n");
            break;
        }

        memset(buffer,0,sizeof(buffer));
        while(fgets(buffer,sizeof(buffer),fp))
        {
			if (buffer[0]=='F')
			{
				/// fall state
				arrIdx = 0;
				continue;
			}
			else if (buffer[0]=='R')
			{
				/// rise up
				arrIdx = 1;
				continue;
			}
			else if (buffer[0]=='C')
			{
				/// const state
				arrIdx = 2;
				continue;
			}

            tok = strchr(buffer,'=') + 1;
            switch (buffer[0]) {
            case 'b':
				pstCamera->cameraParam[arrIdx].brightness = atoi(tok);
                break;

            case 'c':
				pstCamera->cameraParam[arrIdx].contrast = atoi(tok);
                break;

            case 's':
				if (buffer[1]=='a')
				{
					pstCamera->cameraParam[arrIdx].saturation = atoi(tok);
				}
				else if (buffer[1]=='h')
				{
					pstCamera->cameraParam[arrIdx].sharpness = atoi(tok);
				}
                break;

			case 'h':
				pstCamera->cameraParam[arrIdx].hue = atoi(tok);

            case 'w':
				pstCamera->cameraParam[arrIdx].white_balance = atoi(tok);
                break;

            case 'g':
                if (buffer[2]=='m')
                {
                    pstCamera->cameraParam[arrIdx].gamma = atoi(tok);
                }
                else if(buffer[2]=='i')
                {
                    pstCamera->cameraParam[arrIdx].gain = atoi(tok);
                }
                break;

            case 'e':
                pstCamera->cameraParam[arrIdx].exposure = atoi(tok);
                break;

            default:
                break;
            }

            bRet = TRUE;
		}

		fclose(fp);
    }while(FALSE);
    return bRet;
}
/*******************************************************************************
* Function Name		 : open_camera
* Description	     : Open a camera device.
* input			     : pchCameraName is the camera name. For example, /dev/vedio0.
* Output		     :  return a pointer of camera_t type. if error occured, return NULL.
*******************************************************************************/
camera_t* open_camera(const char * pchCameraName)
{
    assert(pchCameraName);

    camera_t *pstCamera = NULL;
    do {
        struct stat st;

        if (-1 == stat(pchCameraName, &st))
        {
			LOG_INF("Cannot identify '%s': %d, %s\n", pchCameraName,
                    errno, strerror(errno));
            break;
        }
        
        if (!S_ISCHR(st.st_mode))
        {
			LOG_INF("%s is no device\n", pchCameraName);
            break;
        }

        int iFd = open(pchCameraName, O_RDWR | O_NONBLOCK, 0);
        if (-1 == iFd)
        {
			LOG_INF("Cannot open '%s': %d, %s\n", pchCameraName, errno,
                      strerror(errno));
            break;
        }

        pstCamera = (camera_t *)malloc(sizeof (camera_t));
        if (pstCamera)
        {
            memset(pstCamera, 0, sizeof(camera_t));
            pstCamera->iFd = iFd;
            pstCamera->pchCameraName = pchCameraName;
        }
    } while(FALSE);

    return pstCamera;
}
/*******************************************************************************
* Function Name		 : check_camera_resolution
* Description	     :Check whether the camera support resolution 1280x1080 or not.
* input			     : pstCamera is a camera handle returned by open_camera(...)
* Output		     : void
*******************************************************************************/
static void check_camera_resolution(camera_t *pstCamera)
{
    int iRet = -1;
    struct v4l2_fmtdesc fmt;
    struct v4l2_frmsizeenum frmsize;

    fmt.index = 0;
    fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	LOG_INF("check_camera_resolution begin\n");
    while (ioctl(pstCamera->iFd, VIDIOC_ENUM_FMT, &fmt) >= 0) 
    {
        frmsize.pixel_format = fmt.pixelformat;
        frmsize.index = 0;
		LOG_INF("description=%s\n", fmt.description);
        /// description is YUV
        if ('Y'==fmt.description[0])
        {
            while (ioctl(pstCamera->iFd, VIDIOC_ENUM_FRAMESIZES, &frmsize) >= 0) 
            {
				LOG_INF("frmsize.type=%d frmsize.discrete.width=%d frmsize.discrete.height=%d\n", frmsize.type, frmsize.discrete.width
					, frmsize.discrete.height);
                if (frmsize.type == V4L2_FRMSIZE_TYPE_DISCRETE
                    && en1080PWidth == frmsize.discrete.width 
                    && en1080PHeight == frmsize.discrete.height) 
                {
                    iRet = 0;
					break;
                }
                frmsize.index++;
            }
        }       
        fmt.index++;
    }
	LOG_INF("check_camera_resolution end\n");
    if (iRet)
    {
		LOG_INF("before:CAMERA_FALL=%d CAMERA_RISE=%d CAMERA_CONST=%d\n", CAMERA_FALL, CAMERA_RISE, CAMERA_CONST);
        CAMERA_FALL = CAMERA_CONST;
        CAMERA_RISE = CAMERA_CONST;
		LOG_INF("after:CAMERA_FALL=%d CAMERA_RISE=%d CAMERA_CONST=%d\n", CAMERA_FALL, CAMERA_RISE, CAMERA_CONST);
    }
}
/*******************************************************************************
* Function Name		 : init_camera
* Description	     : Initialize the camera device.
* input			     : pstCamera is a camera handle returned by open_camera(...)
* input			     : enIOMethod is I/O method (O_METHOD_MMAP, IO_METHOD_USERPTR, IO_METHOD_READ)
* input			     : uiWidth of the image
* input			     : uiHeight of the image
* Output		     : 0 : success   0 : timeout  -1 : error, errno is set appropriately.
*******************************************************************************/
int init_camera(camera_t *pstCamera, EnumIOMethod enIOMethod, uint32_t uiWidth, uint32_t uiHeight)
{
    int iRet = 0;
    pstCamera->enIOMethod = enIOMethod;
    
    // Set video image format, such as setting the image width and height, image
    // format (MJPEG, YUYV)
    struct v4l2_format stFormat;
    CLEAR(stFormat);
    stFormat.type                = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    stFormat.fmt.pix.width       = uiWidth;
    stFormat.fmt.pix.height      = uiHeight;
    stFormat.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
    stFormat.fmt.pix.field       = V4L2_FIELD_INTERLACED;
    if (-1 == set_frame_fmt(pstCamera, &stFormat))
    {
		LOG_INF("set frame format failed\n");
        return -1;
    }

    if (-1 == get_real_hw(pstCamera))
    {
		LOG_INF("get real height and width failed\n");
        return -1;
    }
    
#ifdef CONTROL_PARAMETER
    // Here are som optional parameter. If default parameters can not work well,
    // you can set them mannually.
    if (FALSE==readCameraConfig(pstCamera, "/root/jdagvclientserver/jdagvserver/camera.config"))
    {
		LOG_INF("camera config read failed!\n");
        return -1;
    }
	if ((uiWidth == WIDTH) && (uiHeight == HEIGHT))
	{
		set_camera_param(pstCamera, CAMERA_CONST);
	}
#endif
    
    switch (pstCamera->enIOMethod)
    {
    case IO_METHOD_READ:
        iRet = init_read(pstCamera, stFormat.fmt.pix.sizeimage);
        break;

    case IO_METHOD_MMAP:
        iRet = init_mmap(pstCamera);
        break;

    case IO_METHOD_USERPTR:
        iRet = init_userp(pstCamera, stFormat.fmt.pix.sizeimage);
        break;
    default:
        iRet = -1;
    }

    return iRet;
}
/*******************************************************************************
* Function Name		 : start_capturing
* Description	     : Start capturing video
* input			     : pstCamera is a camera handle returned by open_camera(...)
* Output		     : 0 : success   0 : timeout  -1 : error, errno is set appropriately.
*******************************************************************************/
int start_capturing(const camera_t *pstCamera)
{
    int iRet = 0;
    unsigned int uiCounter = 0;
    enum v4l2_buf_type enBufType = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    buffer_t *pstbuffer = pstCamera->pstBuffer;

    switch (pstCamera->enIOMethod)
    {
    case IO_METHOD_READ:
        /* Nothing to do. */
        break;

    case IO_METHOD_MMAP:
        for (uiCounter = 0; uiCounter < pstCamera->ulBufferNum; ++uiCounter)
        {
            struct v4l2_buffer stBuffer;
            CLEAR(stBuffer);
            stBuffer.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            stBuffer.memory = V4L2_MEMORY_MMAP;
            stBuffer.index = uiCounter;

            if (-1 == xioctl(pstCamera->iFd, VIDIOC_QBUF, &stBuffer))
            {
                iRet = -1;
                return iRet;
            }
        }

        if (-1 == xioctl(pstCamera->iFd, VIDIOC_STREAMON, &enBufType)) 
        {
            iRet = -1;
            return iRet;
        }
        break;

    case IO_METHOD_USERPTR:
        for (uiCounter = 0; uiCounter < pstCamera->ulBufferNum; ++uiCounter)
        {
            struct v4l2_buffer stBuf;
            CLEAR(stBuf);
            stBuf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            stBuf.memory = V4L2_MEMORY_USERPTR;
            stBuf.index = uiCounter;
            stBuf.m.userptr = (unsigned long)pstbuffer[uiCounter].start;
            stBuf.length = pstbuffer[uiCounter].length;

            if (-1 == xioctl(pstCamera->iFd, VIDIOC_QBUF, &stBuf))
            {
                iRet = -1;
                return iRet;
            }
        }

        if (-1 == xioctl(pstCamera->iFd, VIDIOC_STREAMON, &enBufType))
        {
            iRet = -1;
            return iRet;
        }
        break;
    }

    return iRet;
}
/*******************************************************************************
* Function Name		 : read_frame
* Description	     : Read one frame in given time
* input			     : pstCamera is a camera handle returned by open_camera(...)
* Output		     : 0 : success   0 : timeout  -1 : error, errno is set appropriately.
*******************************************************************************/
int read_frame(camera_t *pstCamera, struct timeval *pTimeVal)
{
    int iRet = 0;
    int iTryTimes = 0;
    
    for (;;)
    {
        fd_set fdSet;
        FD_ZERO(&fdSet);
        FD_SET(pstCamera->iFd, &fdSet);

        iRet = select(pstCamera->iFd + 1, &fdSet, NULL, NULL, pTimeVal);
        ++iTryTimes;
        
        if (-1 == iRet) /* error */
        {
            if (EINTR == errno && iTryTimes < TRY_TIMES)
            {
                continue;
            }
            else
            {
                break;
            }
        }
        else if (0 == iRet) /* timeout */
        {
			LOG_INF("\nselect timeout\n");
            break;
        }
        else
        {
            //D_PRINT(stdout, "\nselect returned in given time\n");
            if (0 == do_read_frame(pstCamera)) /* read one frame successfully */
            {
                iRet = 1;
                break;
            }
            else /* on error, when reading one frame */
            {
                iRet = -1;
				LOG_INF("No proper buffer can be readed!\n");
                if (EAGAIN == errno && iTryTimes < TRY_TIMES)
                {
                    continue;
                }
                else
                {
                    break;
                }
            }
        }
        /* EAGAIN - continue select loop. */
    }

    return iRet;
}
/*******************************************************************************
* Function Name		 : push_frame
* Description	     : push the frame buffer back to low-level driver to reuse
* input			     : pstCamera is a camera handle returned by open_camera(...)
* Output		     : 0 : success   -1 : error, errno is set appropriately.
*******************************************************************************/
int push_frame(camera_t* pstCamera)
{
    int iRet = 0;
    struct v4l2_buffer stBuffer;
    memset(&stBuffer, 0, sizeof(struct v4l2_buffer));
    stBuffer.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    stBuffer.memory = V4L2_MEMORY_MMAP;
    stBuffer.index = pstCamera->iBufferIndex;
	pstCamera->stHead.start = NULL;

	int i = 0;
	for (i; i < 10;i++)//add by jxu 20180925 change from 5 to 10
	{
		if (-1 == xioctl(pstCamera->iFd, VIDIOC_QBUF, &stBuffer))
		{
			iRet = -1;
			LOG_INF("push_frame error:%s\n", strerror(errno));
		}
		else
		{
			LOG_INF("push_frame success\n");
			break;
		}
	}
    return iRet;
}

/*******************************************************************************
* Function Name		 : stop_capturing
* Description	     : Stop capturing video.
* input			     : pstCamera is a camera handle returned by open_camera(...)
* Output		     : 0 : success   -1 : error, errno is set appropriately.
*******************************************************************************/
int stop_capturing(const camera_t *pstCamera)
{
    int iRet = 0;

    enum v4l2_buf_type enBufType = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    switch (pstCamera->enIOMethod)
    {
    case IO_METHOD_READ:
        /* Nothing to do. */
        break;
    case IO_METHOD_MMAP:
    case IO_METHOD_USERPTR:
        if (-1 == xioctl(pstCamera->iFd, VIDIOC_STREAMOFF, &enBufType))
        {
			LOG_INF("VIDIOC_STREAMOFF failed\n");
            iRet = -1;
        }
        break;
    }

    return iRet;
}

/*******************************************************************************
* Function Name		 : uninit_camera
* Description	     : Release dynamically allocated resources
* input			     : pstCamera is a camera handle returned by open_camera(...)
* Output		     : 0 : success   -1 : error, errno is set appropriately.
*******************************************************************************/
int uninit_camera(const camera_t *pstCamera)
{
    int iRet = 0;

    buffer_t *pstBuffers = pstCamera->pstBuffer;

    size_t uiCounter;
    switch (pstCamera->enIOMethod)
    {
    case IO_METHOD_READ:
        free(pstBuffers[0].start);
        break;

    case IO_METHOD_MMAP:
        for (uiCounter = 0; uiCounter < pstCamera->ulBufferNum; ++uiCounter)
        {
            iRet = munmap(pstBuffers[uiCounter].start, pstBuffers[uiCounter].length);
        }
        break;

    case IO_METHOD_USERPTR:
        for (uiCounter = 0; uiCounter < pstCamera->ulBufferNum; ++uiCounter)
        {
            free(pstBuffers[uiCounter].start);
        }
        break;
    }

    free(pstBuffers);

    return iRet;
}

/*******************************************************************************
* Function Name		 : close_camera
* Description	     : close the camera device
* input			     : pstCamera is a camera handle returned by open_camera(...)
* Output		     : NONE
* Output		     : 0 : success   -1 : error, errno is set appropriately.
*******************************************************************************/
int close_camera(camera_t *pstCamera)
{
	int iRet = close(pstCamera->iFd);
	if (pstCamera != NULL)
	{
		free(pstCamera);
		pstCamera = NULL;
	}
	return iRet;
}

/*******************************************************************************
* Function Name		 : check_capability
* Description	     : Before using, you should judege whether this device is a capture device.
* input			     : iFd is a file descriptor
* input              : enIOMethod is a kind of I/O method.
* Output		     : NONE
* Output		     :  0 : success   -1 : error, errno is set appropriately.
*******************************************************************************/
int check_capability(int iFd, EnumIOMethod enIOMethod)
{
    int iRet = 0;
    
    struct v4l2_capability stCapability;
    if (-1 == xioctl(iFd, VIDIOC_QUERYCAP, &stCapability))
    {
        iRet = -1;
    }
    else
    {
        if (!(stCapability.capabilities & V4L2_CAP_VIDEO_CAPTURE))
        {
			LOG_INF("This device is not a video capture device\n");
            return -1;
        }
    }
    
    switch (enIOMethod)
    {
    case IO_METHOD_READ:
        if (!(stCapability.capabilities & V4L2_CAP_READWRITE))
        {
			LOG_INF("\nThis device does not support read i/o\n");
            return -1;
        }
        break;

    case IO_METHOD_MMAP:
    case IO_METHOD_USERPTR:
        if (!(stCapability.capabilities & V4L2_CAP_STREAMING))
        {
			LOG_INF("\nThis device does not support streaming i/o\n");
            return -1;
        }
        break;
    }
    
    return iRet;
}

/*******************************************************************************
* Function Name		 : query_capability
* Description	     :  Get the device's capabilities in human-readable format.
* input			     : pstCamera is camera handle returned by open_camera(...)
* Output		     : NONE
*******************************************************************************/
void query_capability(camera_t *pstCamera)
{
    struct v4l2_capability stCap;

    if (-1 == ioctl(pstCamera->iFd, VIDIOC_QUERYCAP, &stCap))
    {
		LOG_INF("Error opening device %s: unable to query device.\n", pstCamera->pchCameraName);
    }
    else
    {
		LOG_INF("driver:\t\t%s\n", stCap.driver);
		LOG_INF("card:\t\t%s\n", stCap.card);
		LOG_INF("bus_info:\t%s\n", stCap.bus_info);
		LOG_INF("version:\t%d\n", stCap.version);
		LOG_INF("capabilities code:\t%x\n", stCap.capabilities);

        if ((stCap.capabilities & V4L2_CAP_VIDEO_CAPTURE) == V4L2_CAP_VIDEO_CAPTURE)
        {
			LOG_INF("Device %s: supports capture.\n", pstCamera->pchCameraName);
        }

        if ((stCap.capabilities & V4L2_CAP_STREAMING) == V4L2_CAP_STREAMING)
        {
			LOG_INF("Device %s: supports streaming.\n", pstCamera->pchCameraName);
        }
    }
}

/*******************************************************************************
* Function Name		 : list_supported_fmt
* Description	     : List all supported format of this device.
* input			     : pstCamera is camera handle returned by open_camera(...)
* Output		     : NONE
*******************************************************************************/
void list_supported_fmt(camera_t *pstCamera)
{
    struct v4l2_fmtdesc stFmtdesc;
    CLEAR(stFmtdesc);
    stFmtdesc.index = 0;
    stFmtdesc.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

	LOG_INF("Supported format:\n");
    while (-1 != ioctl(pstCamera->iFd, VIDIOC_ENUM_FMT, &stFmtdesc))
    {
		LOG_INF("\t%d.%s\n", stFmtdesc.index + 1, stFmtdesc.description);
        stFmtdesc.index++;
    }
}
/*******************************************************************************
* Function Name		 : get_current_fmt
* Description	     : Get current formart settings.
* input			     : pstCamera is camera handle returned by open_camera(...)
* Output		     : NONE
*******************************************************************************/
void get_current_fmt(camera_t *pstCamera)
{
    struct v4l2_format stFormat;
    CLEAR(stFormat);
    stFormat.type                = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    stFormat.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
    stFormat.fmt.pix.field       = V4L2_FIELD_INTERLACED;

    if (-1 == ioctl(pstCamera->iFd, VIDIOC_G_FMT, &stFormat))
    {
		LOG_INF("Unable to get format:\n");
    }
    else
    {
		LOG_INF("fmt.type:\t\t%d\n", stFormat.type);
		LOG_INF("pix.pixelformat:\t%c%c%c%c\n",
            stFormat.fmt.pix.pixelformat & 0xFF,
            (stFormat.fmt.pix.pixelformat >> 8) & 0xFF, 
            (stFormat.fmt.pix.pixelformat >> 16) & 0xFF,
            (stFormat.fmt.pix.pixelformat >> 24) & 0xFF);
		LOG_INF("pix.height:\t\t%d\n", stFormat.fmt.pix.height);
		LOG_INF("pix.width:\t\t%d\n", stFormat.fmt.pix.width);
		LOG_INF("pix.field:\t\t%d\n", stFormat.fmt.pix.field);
    }
}
/*******************************************************************************
* Function Name		 : print_ctrl
* Description	     : print the struct pQueryCtl
* input			     : v4l2_queryctrl: 
* Output		     : NONE
*******************************************************************************/
static void print_ctrl(struct v4l2_queryctrl *pQueryCtl)
{
	if (NULL == pQueryCtl)
		return;
	LOG_INF("id\ttype\t%-35s\tmin\tmax\tstep\tdefault\tflags\treserved[0]\treserved[1]\n", "name");
	LOG_INF("%0x\t%d\t%-35s\t%d\t%d\t%d\t%d\t%d\t%d\t\t%d\n\n", pQueryCtl->id,
													   pQueryCtl->type,
													   pQueryCtl->name,
													   pQueryCtl->minimum,
													   pQueryCtl->maximum,
													   pQueryCtl->step,
													   pQueryCtl->default_value,
													   pQueryCtl->flags,
													   pQueryCtl->reserved[0],
													   pQueryCtl->reserved[1]);
}
/*******************************************************************************
* Function Name		 : query_ctrl
* Description	     :  query_ctrl. e.g. brightness, constrast, gain, exposure etc.
* input			     : pstCamera: camera handle returned by open_camera(...)
* Output		     : NONE
*******************************************************************************/
void query_ctrl(camera_t *pstCamera)
{
	int i=0; 
	struct v4l2_queryctrl qctrl;
	for (i = 0; i < 44; i++)
	{
		memset(&qctrl, 0, sizeof(qctrl));
		qctrl.id = V4L2_CID_BASE+i;
		if (-1 == ioctl(pstCamera->iFd,VIDIOC_QUERYCTRL, &qctrl))
			continue;
		if (qctrl.flags & V4L2_CTRL_FLAG_DISABLED)
			continue;

		LOG_INF("(V4L2_CID_BASE+%d) infomation : \n", i);
		print_ctrl(&qctrl);
	}	

	for (i = 0; i < 32; i++)
	{
		memset(&qctrl, 0, sizeof(qctrl));
		qctrl.id = V4L2_CID_CAMERA_CLASS_BASE+i;
		if (-1 == ioctl(pstCamera->iFd,VIDIOC_QUERYCTRL, &qctrl))
			continue;
		if (qctrl.flags & V4L2_CTRL_FLAG_DISABLED)
			continue;

		LOG_INF("(V4L2_CID_CAMERA_CLASS_BASE+%d) infomation : \n", i);
		print_ctrl(&qctrl);
	}	
}
/*******************************************************************************
* Function Name		 : my_camera_ctl
* Description	     :  Set camera parameters. e.g. brightness, constrast, gain, exposure etc.
* input			     : pstCamera: camera handle returned by open_camera(...)
* input			     : ulID:  V4L2_CID_BRIGHTNESS,V4L2_CID_CONTRAST,V4L2_CID_SATURATION etc.
* input			     : value: the value of V4L2_CID_BRIGHTNESS,V4L2_CID_CONTRAST,V4L2_CID_SATURATION etc.
* Output		     : NONE
*******************************************************************************/
static void my_camera_ctl(camera_t *pstCamera, size_t ulID, int value)
{
	int iValue = 0;
	char para[128];
	memset(para,0,sizeof(para));

	if (NULL == pstCamera)
		return;

	switch(ulID)
	{
	case V4L2_CID_BRIGHTNESS:
		sprintf(para,"V4L2_CID_BRIGHTNESS");
		break;

	case V4L2_CID_CONTRAST:
		sprintf(para,"V4L2_CID_CONTRAST");
		break;

	case V4L2_CID_SATURATION:
		sprintf(para,"V4L2_CID_SATURATION");
		break;

	case V4L2_CID_HUE:
		sprintf(para,"V4L2_CID_HUE");
		break;

	case V4L2_CID_SHARPNESS:
		sprintf(para,"V4L2_CID_SHARPNESS");
		break;

	case V4L2_CID_WHITE_BALANCE_TEMPERATURE:
		sprintf(para,"V4L2_CID_WHITE_BALANCE_TEMPERATURE");
		break;

	case V4L2_CID_GAMMA:
		sprintf(para,"V4L2_CID_GAMMA");
		break;

	case V4L2_CID_GAIN:
		sprintf(para,"V4L2_CID_GAIN");
		break;

	case V4L2_CID_EXPOSURE_ABSOLUTE:
		sprintf(para,"V4L2_CID_EXPOSURE_ABSOLUTE");
		break;

	default:
		break;
	}
	iValue = get_ctl_value(pstCamera->iFd, ulID);
	LOG_INF("Before %s = %d\n", para, iValue);
	set_ctl_value(pstCamera->iFd, ulID, value);
	iValue = get_ctl_value(pstCamera->iFd, ulID);
	LOG_INF("After %s = %d\n", para, iValue);
}

/*******************************************************************************
* Function Name		 : set_camera_param
* Description	     :  Set camera parameters. e.g. brightness, constrast, gain, exposure etc.
* input			     : pstCamera: camera handle returned by open_camera(...)
* input			     : state:  CAMERA_FALL , CAMERA_RISE or CAMERA_CONST
* Output		     : NONE
* Return		     : 0:success; <0:failure.
*******************************************************************************/
void set_camera_param(camera_t *pstCamera, int state)
{
#ifdef CONTROL_PARAMETER
	camera_param_t *pParam = NULL;
	if (NULL == pstCamera || state >CAMERA_STATES-1 || state < 0)
		return;

	pParam = &pstCamera->cameraParam[state];
	set_ctl_value(pstCamera->iFd, V4L2_CID_EXPOSURE_AUTO, V4L2_EXPOSURE_MANUAL);
	//set_ctl_value(pstCamera->iFd, V4L2_CID_AUTO_WHITE_BALANCE, V4L2_WHITE_BALANCE_MANUAL);
	set_ctl_value(pstCamera->iFd, V4L2_CID_AUTO_WHITE_BALANCE, 0);

	my_camera_ctl(pstCamera,V4L2_CID_BRIGHTNESS, pParam->brightness);
	my_camera_ctl(pstCamera,V4L2_CID_CONTRAST, pParam->contrast);
	my_camera_ctl(pstCamera,V4L2_CID_SATURATION, pParam->saturation);
	my_camera_ctl(pstCamera,V4L2_CID_HUE,pParam->hue);
	my_camera_ctl(pstCamera,V4L2_CID_SHARPNESS,pParam->sharpness);
	my_camera_ctl(pstCamera,V4L2_CID_WHITE_BALANCE_TEMPERATURE, pParam->white_balance);
	my_camera_ctl(pstCamera,V4L2_CID_GAMMA, pParam->gamma);
	my_camera_ctl(pstCamera,V4L2_CID_GAIN, pParam->gain);	
	my_camera_ctl(pstCamera,V4L2_CID_EXPOSURE_ABSOLUTE, pParam->exposure);
#endif
}
