#ifndef COMMON_H
#define COMMON_H

#ifdef __cplusplus
extern "C" {
#endif

#include "globaldefine.h"
#include "databank.h"


bool isInBoxf(snake_pointf *point, int with,int height);
bool isInBox(snake_point *point, int with,int height);

float PI2PI(const float angle);


int FuncBlackExtract(const uint8_t *srcDataHeader, snake_point srcRec[4], snake_point *dstRecData, int *pWhiteCount);

#ifdef __cplusplus
}
#endif

#endif // COMMON_H
