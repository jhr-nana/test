/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* All rights reserved.
* FileName: can.c
* Author: Zhiyong Xu   Version: V1.0   Data:2017-06-23
* Description:
set can para cmd:
ip link set can0 up type can bitrate 500000

ip link set can0 down
ip link set can0 up
********************************************************************************/
#include "global_var.h"
#include "can.h"
#include "debug.h"

#define CAN_RCV_BUFF_SIZE	1024*1024	//Bytes
#define CAN_SND_BUFF_SIZE	1024*1024	//Bytes

/*******************************************************************************
* Function Name		 : init_can_socket
* Description	     : init the socket of can, and set can filter
* Input 		     : iDevNum: the index of can device
* Input 		     : iMode: BLOCK or NONBLOCK
* Input 		     : pFilter: can filter buffer
* Output		     : NONE
* Return		     : 0: success; -1:failure
*******************************************************************************/
int init_can_socket(int iDevNum, int iMode, void *pFilter, int iFilterSize)
{
	int iRet = 0;
	int iFlags = 0;
	int iSockFd = 0;

	int iRcvSize = 0;
	int iSndSize = 0;
	
	struct sockaddr_can stSockAddr = {0};
	struct ifreq stIfReq = {0};
	char ifName[16] = {0};
	int iLoopBack      = 0; /* 0 = disabled, 1 = enabled (default) */
	int iRecvOwnMsgs = 0; /* 0 = disabled (default), 1 = enabled */

	if (pFilter == NULL) {
		LOG_ERR("can_filter is NULL");
		return -1;
	}
	
	if ((iDevNum < 0) || (iDevNum > 1)) {
		LOG_ERR("Wrong devnum: %d", iDevNum);
		return -1;
	}	
	sprintf(ifName, "%s%d", "can", iDevNum);

	iSockFd = socket(PF_CAN, SOCK_RAW, CAN_RAW);
	if(iSockFd < 0) {
		LOG_ERR("socket error: %s", strerror(errno));
		return -1;
	}

	strcpy(stIfReq.ifr_name, ifName);
	ioctl(iSockFd, SIOCGIFINDEX, &stIfReq);

	stSockAddr.can_family  = PF_CAN;
	stSockAddr.can_ifindex = stIfReq.ifr_ifindex; 

	iRet = bind(iSockFd, (struct sockaddr *)&stSockAddr, sizeof(stSockAddr));
	if(iRet < 0) {
		LOG_ERR("bind error: %s", strerror(errno));
		goto error_0;
	}

	// set socket option with O_NONBLOCK or not
	iFlags = fcntl(iSockFd, F_GETFL, 0);
	if (iFlags == -1) {
		LOG_ERR("can%d fcntl F_GETFL fail:%s\n", iDevNum, strerror(errno));
		iRet = -1;
		goto error_0;
	}	
	if (NONBLOCK == iMode) {
		iFlags |= O_NONBLOCK;
	} else {
		iFlags &= ~O_NONBLOCK;
	}	
	if (fcntl(iSockFd, F_SETFL, iFlags) == -1)
	{
		LOG_ERR("can%d set block fail:%s\n", iDevNum, strerror(errno));
		goto error_0;
	}

	// set socket option with CAN_RAW_LOOPBACK\CAN_RAW_RECV_OWN_MSGS\CAN_RAW_FILTER
	setsockopt(iSockFd, SOL_CAN_RAW, CAN_RAW_LOOPBACK, &iLoopBack, sizeof(iLoopBack));
	setsockopt(iSockFd, SOL_CAN_RAW, CAN_RAW_RECV_OWN_MSGS, &iRecvOwnMsgs, sizeof(iRecvOwnMsgs));
	iRet = setsockopt(iSockFd, SOL_CAN_RAW, CAN_RAW_FILTER, pFilter, iFilterSize);
	if (iRet < 0)
	{
		LOG_WRN("set CAN_RCV_BUFF_SIZE failed:[%d-%s]\n", errno, strerror(errno));
	}
	// set socket option with SO_RCVBUF
	iRcvSize = CAN_RCV_BUFF_SIZE;
	iRet = setsockopt(iSockFd, SOL_CAN_RAW, SO_RCVBUF, (char*)&iRcvSize, sizeof(iRcvSize));
	if (iRet < 0 )
	{
		LOG_WRN("set CAN_RCV_BUFF_SIZE failed:[%d-%s]\n",errno,strerror(errno));
	}
	// set socket option with SO_SNDBUF
	iSndSize = CAN_SND_BUFF_SIZE;
	iRet = setsockopt(iSockFd, SOL_CAN_RAW, SO_SNDBUF, (char*)&iSndSize, sizeof(iSndSize));
	if (iRet < 0)
	{
		LOG_WRN("set CAN_RCV_BUFF_SIZE failed:[%d-%s]\n", errno, strerror(errno));
	}
 
	int iSokLen = sizeof(iSndSize);
	iRet = getsockopt(iSockFd, SOL_CAN_RAW, SO_SNDBUF, (char*)&iSndSize, &iSokLen);
	if (iRet == 0)
	{
		LOG_INF("CAN SO_SNDBUF size = %d\n",iSndSize);
	}
	return iSockFd;
	
error_0:
	if (iSockFd > 0) {
		close(iSockFd);
		iSockFd = 0;
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : close_can_socket
* Description	     : close the socket of can
* Input 		     : iSockFd: the fd of can socket
* Output		     : NONE
* Return		     : 0: success; -1:failure
*******************************************************************************/
int close_can_socket(int iSockFd)
{
	if (iSockFd > 0) {
		close(iSockFd);
		iSockFd = 0;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : init_can
* Description	     : int can filter.
* input			     : iDevNum:can bus number, 0:can0, 1:can1
* input			     : pfilter: filter buffer;
* input			     : iSize: filter size.
* Output		     : NONE
* Return		     : 0:success. <0:failure
*******************************************************************************/
int init_can(int iDevNum, int iMode)
{
	struct ifreq if_dev;
	struct sockaddr_can stAddr;
	int iSockFd = 0;
	int iFlags = 0;

	if ((iSockFd = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0)
	{
		LOG_ERR("can socket error:[%s]\n", strerror(errno));
		return -1;
	}

	if (iDevNum == CAN0)
	{
		strncpy(if_dev.ifr_name, "can0", IFNAMSIZ); // set name of can
		g_stAgvParm.iCanSocketFd0 = iSockFd;
	}
	else if (iDevNum == CAN1)
	{
		strncpy(if_dev.ifr_name, "can1", IFNAMSIZ); // set name of can
		g_stAgvParm.iCanSocketFd1 = iSockFd;
	}
	else
	{
		LOG_ERR("wrong can bus num\n");
		return -1;
	}	
	ioctl(iSockFd, SIOCGIFINDEX, &if_dev);
	stAddr.can_family = PF_CAN;
	stAddr.can_ifindex = if_dev.ifr_ifindex;

	if (bind(iSockFd, (struct sockaddr *)&stAddr, sizeof(stAddr)) < 0) // bind the socket to device
	{
		LOG_ERR("can%d bind error: %s!\n", iDevNum, strerror(errno));
		return -1;
	}

	if ((iFlags = fcntl(iSockFd, F_GETFL, 0)) == -1)
	{
		LOG_ERR("can%d fcntl F_GETFL fail:%s\n", iDevNum, strerror(errno));
		exit(1);
	}
	if (NONBLOCK == iMode)
	{
		iFlags |= O_NONBLOCK;
		if (fcntl(iSockFd, F_SETFL, iFlags) == -1)
		{
			LOG_ERR("can%d set nonblock fail:%s\n", iDevNum, strerror(errno));
			return -1;
		}
	}
	else
	{
		iFlags &= ~O_NONBLOCK;
		if (fcntl(iSockFd, F_SETFL, iFlags) == -1)
		{
			LOG_ERR("can%d set block fail:%s\n", iDevNum, strerror(errno));
			return -1;
		}
	}
	// TODO
	//setsockopt(iSockFd, SOL_CAN_RAW, CAN_RAW_FILTER, &filter, sizeof(filter)); 
	
	return 0;

}

/*******************************************************************************
* Function Name		 : set_can_filter
* Description	     : set  can filter.
* input			     : iDevNum:can bus number, 0:can0, 1:can1
* input			     : pfilter: filter buffer;
* input			     : iSize: filter size.
* Output		     : NONE
* Return		     : 0:success. <0:failure
*******************************************************************************/
int set_can_filter(int iDevNum, void *pfilter,int iSize )
{
	int iSockFd = 0;
	int iRet = 0;

	if (pfilter == NULL)
	{
		LOG_ERR("can%d filter NULL\n", iDevNum);
		return -1;
	}

	if (iDevNum == CAN0)
	{
		iSockFd = g_stAgvParm.iCanSocketFd0;
	}
	else if (iDevNum == CAN1)
	{
		iSockFd = g_stAgvParm.iCanSocketFd1;
	}
	else
	{
		LOG_ERR("wrong can bus num\n");
		return -1;
	}

	iRet = setsockopt(iSockFd, SOL_CAN_RAW, CAN_RAW_FILTER, pfilter, iSize);
	return iRet;
}

/*******************************************************************************
* Function Name		 : send_can
* Description	     : send can.frame to bus.
* input			     : iDevNum:can bus number, 0:can0, 1:can1
* input			     : pCanFrame:can frame buffer
* Output		     : NONE
* Return		     : return the send byte number on success. <0:failure
*******************************************************************************/
int send_can(int iDevNum, struct can_frame *pCanFrame)
{
	int iSockFd = 0;
	int iNum = 0;

	if (pCanFrame == NULL)
	{
		LOG_ERR("can%d send buffer is null\n", iDevNum);
		return -1;
	}

	if (iDevNum == CAN0)
	{		
		iSockFd = g_stAgvParm.iCanSocketFd0;
	}
	else if (iDevNum == CAN1)
	{		
		iSockFd = g_stAgvParm.iCanSocketFd1;
	}
	else
	{
		LOG_ERR("wrong can bus num\n");
		return -1;
	}

	iNum = write(iSockFd, pCanFrame, sizeof(struct can_frame));
	if (iNum < 0)
	{
		LOG_WRN("can%d send error:[%s]\n", iDevNum, strerror(errno));
	}

	return iNum;
}

/*******************************************************************************
* Function Name		 : recv_can
* Description	     : receive can.frame from bus.
* input			     : iDevNum:can bus number, 0:can0, 1:can1
* input			     : pCanFrame:can frame buffer
* Output		     : NONE
* Return		     : return the receive byte number on success. <0:failure
*******************************************************************************/
int recv_can(int iDevNum, struct can_frame *pCanFrame)
{
	int iSockFd = 0;
	int iRet = 0;

	if (pCanFrame == NULL)
	{
		LOG_ERR("can%d recv buffer is null\n", iDevNum);
		return -1;
	}
	if (iDevNum == CAN0)
	{
		iSockFd = g_stAgvParm.iCanSocketFd0;
	}
	else if (iDevNum == CAN1)
	{
		iSockFd = g_stAgvParm.iCanSocketFd1;
	}
	else
	{
		LOG_ERR("wrong can bus num\n");
		return -1;
	}

	iRet = read(iSockFd, pCanFrame, sizeof(struct can_frame));

	return iRet;

}

/*******************************************************************************
* Function Name		 : close_can
* Description	     : close can.
* input			     : iDevNum:can bus number, 0:can0, 1:can1
* Output		     : NONE
* Return		     : 0:success. <0:failure
*******************************************************************************/
int close_can(int iDevNum)
{
	int iRet = 0;
	
	if (iDevNum == CAN0)
	{
		iRet = close(g_stAgvParm.iCanSocketFd0);
	}
	else if (iDevNum == CAN1)
	{
		iRet = close(g_stAgvParm.iCanSocketFd1);
	}
	else
	{
		LOG_ERR("wrong can bus num\n");
		return -1;
	}

	return iRet;
}
