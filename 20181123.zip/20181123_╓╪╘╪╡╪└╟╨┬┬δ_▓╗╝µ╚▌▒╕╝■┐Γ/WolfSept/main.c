/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <math.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "version.h"
#include "global_var.h"
#include "device.h"
#include "udp.h"
#include "can.h"
#include "uart.h"
#include "config.h"
#include "linkqueue.h"
#include "bms.h"
#include "ftp.h"
#include "netstat.h"
#include "v4l2_camera.h"
#include "statistical_info.h"
#include "atomic.h"
#include "udp_msg_v1.h"
#include "can_msg.h" //by tiger.90
#include "bms_update.h"//add by jxu 20180910

#define TWENTY_SECOND "20" //unit seconds

/*******************************************************************************
* Function Name		 : test
* Description	     : just fot test 
* Input 		     : NONE
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void test(void)
{
	;
}

/*******************************************************************************
* Function Name      : sig_pipe_handle
* Description	     : handle with SIGPIPE
* Input 		     : iArgV:
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
static void sig_pipe_handle(int iArgV)
{
	///add network station ,by tiger.09
	if (system("iwconfig wlan0 >>/var/log/jdagv.log") != 0)
	{
		LOG_ERR("excute iwconfig wlan0 cmd error:%s\n", strerror(errno));
	}

	if (system("ifconfig -a >>/var/log/jdagv.log") != 0)
	{
		LOG_ERR("excute ifconfig -a cmd error:%s\n", strerror(errno));
	}
	///end ,by tiger.09
	LOG_ERR("[ catch SIGPIPE ] !\n");
	signal(SIGPIPE, sig_pipe_handle);
	//save log , tiger.0
}

/*******************************************************************************
* Function Name      : sig_segv_handle
* Description	     : handle with SIGSEGV
* Input 		     : iArgV:
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
static void sig_segv_handle(int iArgV)
{
	///add network station ,by tiger.09
	if (system("iwconfig wlan0 >>/var/log/jdagv.log") != 0)
	{
		LOG_ERR("excute iwconfig wlan0 cmd error:%s\n", strerror(errno));
	}

	if (system("ifconfig -a >>/var/log/jdagv.log") != 0)
	{
		LOG_ERR("excute ifconfig -a cmd error:%s\n", strerror(errno));
	}

	///end ,by tiger.09
	LOG_ERR("[ catch SIGSEGV ] !\n");
	//save log , tiger.0
	abort();
}

/*******************************************************************************
* Function Name      : init_system_signal
* Description	     : just for catch SIGPIPE and SIGSEGV signal
* Input 		     : iArgV:
* Output		     : NONE
* Return		     : 0 if OK ,-1 on error
*******************************************************************************/
int init_system_signal(void)
{
	if (signal(SIGPIPE, sig_pipe_handle) == SIG_ERR)
	{
		LOG_ERR("cannot catch SIGPIPE\n");
		return -1;
	}

#if 0
	if (signal(SIGSEGV, sig_segv_handle) == SIG_ERR)
	{
		LOG_ERR("cannot catch SIGSEGV\n");
		return -1;
	}
#endif

	return 0;
}

#define AUTO_REBOOT  1
#define MANUL_REBOOT 0
#define AGENT_NOT_AUTO_SYSTEM_SOC 50  //����̨��������20���Զ��г�ϵͳģʽ��by tiger.105 
/*******************************************************************************
* Function Name		 : init_agv_attr
* Description	     : int the attribute of agv
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int init_agv_attr()
{
	int iRet = 0;
	int iAgvName = 0;
	int iBigVerDate = 0, iBigVer = 0;
	
	// Read the config of "skywolf" from config file
	iRet = get_agv_name(&iAgvName);
	if (iRet < 0) {
		LOG_ERR("Read the config of skywolf from config file error\n");
		return -1;
	}
	g_stAgvAttr.iAgvName = iAgvName;

	// Read the config of "version" from config file
	iRet = get_big_ver_date(&iBigVer, &iBigVerDate);
	if (iRet < 0) {
		LOG_ERR("Read the config of version from config file error\n");
		return -1;
	}
	g_stAgvAttr.iBigVer = iBigVer;
	g_stAgvAttr.iBigVerDate = iBigVerDate;

	LOG_INF("AgvName    = %d\n", iAgvName);
	LOG_INF("BigVer     = %d\n", iBigVer);
	LOG_INF("BigVerDate = %d\n", iBigVerDate);

	g_stAgvAttr.iLocation = 0;
	memset(&g_stAgvAttr.bms, 0, sizeof(struct bat_info));
	g_stAgvAttr.bms.uSoc = AGENT_NOT_AUTO_SYSTEM_SOC; //by tiger.105
	g_stAgvAttr.bms.uCurrent = 0;
	g_stAgvAttr.iBatType = 0;//add by jxu 20180820-begin
	g_stAgvAttr.iBmsVID = 0;//add by jxu 20180910
	g_stAgvAttr.iAnshangBmsType = 0;
	g_stAgvAttr.bms.iBattVersion = 0;
	g_stAgvAttr.iQueryFlag = QUERY_FIRST_SECTION_SINGLEVOL;
	g_stAgvAttr.iMoidfySocFlag = 0;
	g_stAgvAttr.iModifySocVal = 0;
	g_stAgvAttr.iStopChargeConflict = 0;//add by jxu 20180820-end
	g_stAgvAttr.iStopChargeFromMM = 0;//add by jxu 20181017
	g_stAgvAttr.iStatus = 0;
	g_stAgvAttr.iSpeed = 0;
	g_stAgvAttr.iVehHeadDirect = INVALID_DIRECTION;
	g_stAgvAttr.iGXOffset = 0;
	g_stAgvAttr.iGYOffset = 0;
	g_stAgvAttr.iGAngleOffset = 0;
	g_stAgvAttr.iTXOffset = 0;
	g_stAgvAttr.iTYOffset = 0;
	g_stAgvAttr.iPalletDirect = INVALID_DIRECTION; //by tiger.105
	g_stAgvAttr.iTaskPalletDirect = INVALID_DIRECTION;
	g_stAgvAttr.iTAngleOffset = 0;
	g_stAgvAttr.iMoveStatus = agv_stop;
	g_stAgvAttr.iEvent = 0;
	g_stAgvAttr.iServoSubErr = 0;//add by jxu 20180511
	g_stAgvAttr.iPalletStatus = PALLET_STATUS_NULL;
	atomic_set(&g_stAgvAttr.iException, 0);//by tiger.67
	atomic_set(&g_stAgvAttr.iAckException, 0);//add by jxu 20180524
	g_stAgvAttr.iTokenNum = RESERVE_TOKEN_ID;//add by tiger.34

	g_stAgvAttr.iMCStatus = 0;
	g_stAgvAttr.iMCVerDate = 0;
	g_stAgvAttr.iTCVerDate = 0;
	g_stAgvAttr.iDSPStatus = AGV_OK;//add by tiger.54
	g_stAgvAttr.iMCVehType = 0;
	g_stAgvAttr.iTCVehType = 0;
	g_stAgvAttr.iRaiseTAngle = 0;
	g_stAgvAttr.bCheckGroundDir = false;//disable check ground dir by tiger.49
	g_stAgvAttr.i8PgvState = 0; //add by tiger.51
	g_stAgvAttr.iBootMethod = MANUL_REBOOT; //by tiger.105
	/*ADD BY YU START 20181024*/
	iRet = check_boot_method(&g_stAgvAttr);
	if (iRet < 0)
	{
		LOG_ERR("Check boot method error\n");
		return -1;
	}
	/*ADD BY YU END 20181024*/

	memset(&g_stAgvAttr.cContainer, 0, CONTAINER_SIZE);
	sprintf(g_stAgvAttr.cContainer, "%s", "NONE");//add by tiger.51
	
	strcpy(g_stAgvTask.pStartTime, "NONE");
	strcpy(g_stAgvTask.pEndTime, "NONE");

	// used for deal_mc_ack
	g_stAgvAttr.iMcAction = 0;
	g_stAgvAttr.iMcStyle = 0;
	g_stAgvAttr.iMcVersion = 0;
	g_stAgvAttr.iMcState = 0;
	g_stAgvAttr.iMcError = 0;
	// used for deal_tc_ack
	g_stAgvAttr.iTcAction = 0;
	g_stAgvAttr.iTcStyle = 0;
	g_stAgvAttr.iTcVersion = 0;
	g_stAgvAttr.iTcState = 0;
	g_stAgvAttr.iTcError = 0;
	
	strcpy(g_stAgvAttr.pMcMAC, DEFAULT_MC_MAC);//add by tiger.66	
	//intial ftp & warehouse server ip,start by tiger.64 tiger.65
	iRet = ini_read(CONFIGURE_FILE_PATH, "ftp_conf", "ftp_serverip", g_stAgvAttr.pFtpServerIp, sizeof(g_stAgvAttr.pFtpServerIp));
	if (iRet < 0 )
	{
		strcpy(g_stAgvAttr.pFtpServerIp, "0.0.0.0");
		LOG_INF("read ftp_serverip failed,and use default: %s\n", g_stAgvAttr.pFtpServerIp);
	}

	//modified by tiger, 20180606
	//use console'ip instead of brain_serverip
	//all warehouse, brain_serverip == serverip
	//iRet = ini_read(CONFIGURE_FILE_PATH, "warehouse_brain", "brain_serverip", g_stAgvAttr.pWarehouseBrainIp, sizeof(g_stAgvAttr.pWarehouseBrainIp));
	iRet = ini_read(CONFIGURE_FILE_PATH, "upserverip_conf", "serverip", g_stAgvAttr.pWarehouseBrainIp, sizeof(g_stAgvAttr.pWarehouseBrainIp));
	if (iRet < 0)
	{
		strcpy(g_stAgvAttr.pWarehouseBrainIp, "10.44.0.205");
		LOG_INF("read warehouse brain serverip failed,and use default: %s\n", g_stAgvAttr.pWarehouseBrainIp);
	}
	LOG_INF("warehouse brain serverip:%s\n",g_stAgvAttr.pWarehouseBrainIp);
	//intial ftp & warehouse server ip,end by tiger.64 tiger.65

	return 0;
}

/*******************************************************************************
* Function Name		 : init_agv_conf
* Description	     : int the confiure of agv
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int init_agv_conf()
{
	int iRet = 0;
	char cSendPoint = 0;
	char cCheckPoint = 0;	
	char cDebugEnable = 0;
	char cChargeType = 0;
	char cNeedCheckSoc = 0; //by tiger.102
	char cSendStatistical = 0;//add by tiger.51
	char cPgvPeriod = 0;//add by jxu 20180709

	iRet = get_point_report(&cSendPoint);
	if (iRet < 0) {
		return -1;
	}
	g_stAgvConf.cSendPoint = cSendPoint;

	iRet = get_check_point(&cCheckPoint);
	if (iRet < 0) {
		return -1;
	}
	g_stAgvConf.cCheckPoint = cCheckPoint;

	iRet = get_enable_debug(&cDebugEnable);
	if (iRet < 0) {
		return -1;
	}
	g_stAgvConf.cDebugEnable = cDebugEnable;

	iRet = get_charge_type(&cChargeType);
	if (iRet < 0) {
		return -1;
	}
	g_stAgvConf.cChargeType = cChargeType;
	iRet = get_check_soc_flag(&cNeedCheckSoc); //by tiger.102
	if (iRet < 0) {
		return -1;
	}
	g_stAgvAttr.bms.uNeedCheckSoc = cNeedCheckSoc;

#if 1 //by tiger.0
	iRet = ini_write(CONFIGURE_FILE_PATH,"skywolf_conf","enablestatistical","1");
	if (iRet < 0)
	{
		LOG_WRN("set enablestatistical = 1 failed\n");
	}

#endif 
	//start ,add by tiger.51
	iRet = get_enable_send_statistical(&cSendStatistical);
	if (iRet < 0) {
		return -1;
	}
	cSendStatistical = 1;//enable send stat info,by tiger.88
	g_stAgvConf.cSendStatistical = cSendStatistical;
	//end ,add by tiger.51

	//add by jxu 20180709 begin
#if 1
	iRet = ini_write(CONFIGURE_FILE_PATH, "skywolf_conf", "pgvperiod", "1");
	if (iRet < 0)
	{
		LOG_WRN("set pgvperiod = 1 failed\n");
	}
#endif 
	iRet = get_enable_pgv_period(&cPgvPeriod);
	if (iRet < 0) {
		return -1;
	}
	g_stAgvConf.cPgvPeriod = cPgvPeriod;
	//add by jxu 20180709 end

	LOG_INF("SendPoint    = %d\n", cSendPoint);
	LOG_INF("CheckPoint   = %d\n", cCheckPoint);
	LOG_INF("DebugEnable  = %d\n", cDebugEnable);
	LOG_INF("ChargeType   = %d\n", cChargeType);
	LOG_INF("SendStatInfo = %d\n", cSendStatistical);
	LOG_INF("cPgvPeriod = %d\n", cPgvPeriod);

	return 0;
}
#define SERVER_SECTION "upserverip_conf" //by tiger.15
/*******************************************************************************
* Function Name		 : init_agv_parm
* Description	     : int the parameter of agv
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int init_agv_parm()
{
	int iRet = 0;
	
	int iCanSocketFd0 = 0;
	int iCanSocketFd1 = 0;
	int iMsgSocketFd = 0;
	int iCfgSocketFd = 0;
	int iInfSocketFd = 0;
	int iUartFd = 0;
	char pServerIP[100] = { 0 };

	struct stLinkQueue * pUdpTxQueue = NULL;
	struct stLinkQueue * pUdpRxQueue = NULL;
	
	struct stQueueType * pTaskQueue = NULL;  //the task circle queue 
	struct stQueueType * pSendQueue = NULL;  //the messege circle queue to send
	
	struct stLinkQueue * pPathQueue = NULL;
	struct stLinkQueue * pCanRxQueue = NULL; //by tiger
	struct stLinkQueue * pErrorRxQueue = NULL; //by tiger
	// initial uart
	uart_attr_t stUartAttr =
	{
		.cDateBit  = DATA_BIT_8,
		.cParity   = PARITY_NONE,
		.cStopBit  = STOP_BIT_1,
		.iBaud     = BAUD_115200,
		.pUartName = UART_NAME
	};

	// create link queue for UdpTx\UdpRx\Path
	pUdpTxQueue = linkqueue_create();
	pUdpRxQueue = linkqueue_create();
	pPathQueue  = linkqueue_create(); 
	pCanRxQueue = linkqueue_create();//by tiger
	pErrorRxQueue = linkqueue_create();//by tiger
	if (NULL == pUdpTxQueue || NULL == pUdpRxQueue || NULL == pPathQueue ||
		NULL == pCanRxQueue || NULL == pErrorRxQueue)
	{
		LOG_ERR("create link queue error\n");
		//goto error_0;
	}

	iUartFd = init_uart(&stUartAttr);
	if (iUartFd < 0)
	{
		LOG_ERR("uart init error:[%s]\n", strerror(errno));
		//goto error_0;
	}
	else
	{
		LOG_INF("init uart success\n");
	}

	// get server ip from configure file
#if 0
	///write ip ,start,by tiger.15		
	bzero(pServerIP, sizeof(pServerIP));
	strcpy(pServerIP, "10.44.0.205");
	if (0 == set_console_server_ip(pServerIP))
	{
		LOG_INF("set serverip =  %s success \n", pServerIP);
	}
	///end,by tiger.15

#endif
	iRet = get_server_ip(g_stAgvParm.cServerIp);
	if (iRet < 0) {
		LOG_ERR("get server ip error:[%s]\n", strerror(errno));
		//goto error_1;
	}
	else
	{
		LOG_INF("console server ip = %s\n", g_stAgvParm.cServerIp);
	}

	// initial socket for msg udp server
	iMsgSocketFd = init_udp(MSG_RECV_PORT);
	if (iMsgSocketFd < 0)
	{
		LOG_ERR("init socket for msg udp server error:[%s]\n", strerror(errno));
		//goto error_1;
	}
	else
	{
		LOG_INF("init udp socket for message communication success, port=%d\n", MSG_RECV_PORT);
	}

	iRet = get_ip_sn(iMsgSocketFd);
	if (iRet < 0)
	{
		LOG_ERR("get ip failed\n");
	}

	// initial socket for information udp server
	iInfSocketFd = init_udp(INF_RECV_PORT);
	if (iInfSocketFd < 0)
	{
		LOG_ERR("init socket for infomation udp server error:[%s]\n", strerror(errno));
		//goto error_1;
	}
	else
	{
		LOG_INF("init udp socket for infomation communication success, port=%d\n", INF_RECV_PORT);
	}

	// initial socket for cfg udp server
	iCfgSocketFd = init_udp(CFG_RECV_PORT);
	if (iCfgSocketFd < 0) {
		LOG_ERR("init socket for cfg udp server error:[%s]\n", strerror(errno));
		//goto error_2;
	}
	else
	{
		LOG_INF("init udp socket for config  communication success, port=%d\n", CFG_RECV_PORT);
	}

	// initial can bus 0
	iCanSocketFd0 = init_can_socket(CAN0, NONBLOCK, &g_stCtrlCanFilter, sizeof(g_stCtrlCanFilter));
	if (iCanSocketFd0 < 0)
	{
		LOG_ERR("init_can for CAN0 error:[%s]\n", strerror(errno));
		//goto error_3;
	}
	else
	{
		LOG_INF("init can[0] socket success\n");
	}

	// initial can bus 1
	iCanSocketFd1 = init_can_socket(CAN1, NONBLOCK, &g_stBatCanFilter, sizeof(g_stBatCanFilter));
	if (iCanSocketFd1 < 0)
	{
		LOG_ERR("init_can for CAN1 error:[%s]\n", strerror(errno));
		//goto error_4;
	}
	else
	{
		LOG_INF("init can[1] socket success\n");
	}

	// TODO
	// pTaskQueue = ?
	// pSendQueue = ?

	// everything init ok
	g_stAgvParm.pUdpTxQueue = pUdpTxQueue;
	g_stAgvParm.pUdpRxQueue = pUdpRxQueue;
	g_stAgvParm.pPathQueue  = pPathQueue; 
	g_stAgvParm.pCanRxQueue = pCanRxQueue;//by tiger
	g_stAgvParm.pErrorRxQueue = pErrorRxQueue;//by tiger

	g_stAgvParm.pTaskQueue = pTaskQueue;
	g_stAgvParm.pSendQueue = pSendQueue;

	g_stAgvParm.iUartFd = iUartFd;
	g_stAgvParm.iMsgRecvServerPort = MSG_RECV_PORT;
	g_stAgvParm.iMsgSendServerPort = MSG_SEND_PORT;
	g_stAgvParm.iInfRecvServerPort = INF_RECV_PORT;
	g_stAgvParm.iInfSendServerPort = INF_SEND_PORT;
	g_stAgvParm.iCfgRecvServerPort = CFG_RECV_PORT;
	g_stAgvParm.iCfgSendServerPort = CFG_SEND_PORT;
	g_stAgvParm.iMsgSocketFd = iMsgSocketFd;
	g_stAgvParm.iInfSocketFd = iInfSocketFd;
	g_stAgvParm.iCfgSocketFd = iCfgSocketFd;
	g_stAgvParm.iCanSocketFd0 = iCanSocketFd0;
	g_stAgvParm.iCanSocketFd1 = iCanSocketFd1;

	return 0;

//error_5:
//	if (iCanSocketFd1 > 0) {
//		close_can(iCanSocketFd1);
//		iCanSocketFd1 = 0;
//	}	

error_4:
	if (iCanSocketFd0 > 0) {
		close_can(iCanSocketFd0);
		iCanSocketFd0 = 0;
	}

error_3:
	if (iCfgSocketFd > 0) {
		close_udp(iCfgSocketFd);
		iCfgSocketFd = 0;
	}

error_2:
	if (iMsgSocketFd > 0) {
		close_udp(iMsgSocketFd);
		iMsgSocketFd = 0;
	}
	
error_1:
	if (iUartFd > 0) {
		close_uart(iUartFd);
		iUartFd = 0;
	}

error_0:
	if (pUdpTxQueue) {
		linkqueue_destroy(pUdpTxQueue);
		pUdpTxQueue = NULL;
	}

	if (pUdpRxQueue) {
		linkqueue_destroy(pUdpRxQueue);
		pUdpRxQueue = NULL;
	}

	if (pPathQueue) {
		linkqueue_destroy(pPathQueue);
		pPathQueue = NULL;
	}

	return -1;
}

typedef struct _update_result_req
{
	u32 u32MsgType;
	u32 u32Sequence;
	u32 u32AgvName;
	u32 u32BigVer;
	u32 u32BigVerDate;
	u32 u32BigVerStatus;
	u32 u32MCVer;
	u32 u32MCVerStatus;
	u32 u32TCVer;
	u32 u32TCVerStatus;
	u32 u32TokenNum;
}update_result_req_st;
typedef struct _update_result_ack
{
	u32 u32MsgType;
	u32 u32Sequence;
	u32 u32AGVName;
	u32 u32TokenNum;
}update_result_ack_st;

/*******************************************************************************
*Function Name    :msgv1_report_update_result
*Description      :should execute before create work_thread_create()  
*Output 		  :NONE
*Return           :int:0:success; <0:failure  
*******************************************************************************/

/*******************************************************************************
*Function Name    :msgv1_report_update_result
*Description      :  
*Input       	  :int iMasterStatus:1 if OK ,0 on false  
*Input       	  :int iMcStatus:1 if OK ,0 on false  
*Input       	  :int iTcStatus:1 if OK ,0 on false  
*Output 		  :
*Return           :int  
*******************************************************************************/
int msgv1_report_update_result(int iMasterStatus,int iMcStatus,int iTcStatus)
{
	char pMsgBuff[UDP_MSG_SIZE] = { 0 };
	update_result_ack_st *pMsgRegAck = NULL;

	int iRet = 0;
	int iTryTime = 1;
	int iTimeOut = TIME_OUT_2S;
	int iCount = 0;
	int iChargeType = 0;

	

	// build a register msg
	update_result_req_st stMsgReg =
	{
		.u32MsgType = htonl(MSG_TYPE_UPDATE_RESULT),
		.u32Sequence = htonl(get_seq(AGENENT_SEQ_ID)),
		.u32AgvName = htonl(g_stAgvAttr.iAgvName),
		.u32BigVer = htonl(g_stAgvAttr.iBigVer),
		.u32BigVerDate = htonl(g_stAgvAttr.iBigVerDate),
		.u32BigVerStatus = htonl(iMasterStatus),
		.u32MCVer = htonl(g_stAgvAttr.iMCVerDate),
		.u32MCVerStatus = htonl(iMcStatus),
		.u32TCVer = htonl(g_stAgvAttr.iTCVerDate), //add by tiger.13
		.u32TCVerStatus = htonl(iTcStatus), //add by tiger.40
		.u32TokenNum = htonl(0),
		//.iPalletStatus = htonl(g_stAgvAttr.iPalletStatus),
	};

#if(DEBUG_AGV == TRUE)
	// print debug info for sending message
	LOG_DBG("send msg to console[%s:%d]\n", g_stAgvParm.cServerIp, g_stAgvParm.iMsgSendServerPort);
	msgv1_head_dump((const char *)&stMsgReg);
#endif

	while (iTryTime++) {
		if (iTryTime < 10)
			iTimeOut = TIME_OUT_2S;
		else if ((iTryTime >= 10) && (iTryTime < 20))
			iTimeOut = TIME_OUT_8S;
		else if ((iTryTime >= 20) && (iTryTime < 50))
			iTimeOut = TIME_OUT_20S;
		else
			iTimeOut = TIME_OUT_60S;

		iRet = send_msg2console(&stMsgReg, sizeof(stMsgReg));
		if (iRet < 0)
		{
			LOG_WRN("send update result msg error:[%d-%s]\n", errno,strerror(errno));
			usleep(iTimeOut * 1000); //100ms
			continue;
		}

		//wait console ack
		iCount = 10;
		while (iCount--)
		{
			int iMsgType = 0;
			int iMsgSize = 0;
			int iSequence = 0;
			int iTokenNum = 0;

			bzero(pMsgBuff, sizeof(pMsgBuff));
			// default: when no console, recv udp will be blocked
			iMsgSize = recv_udp(g_stAgvParm.iMsgSocketFd, pMsgBuff, UDP_MSG_SIZE, FALSE);
			pMsgRegAck = (update_result_ack_st *)pMsgBuff;

			// Case1:recv udp msg from server failure
			if (iMsgSize <= 0) {
				usleep(100000); //100ms
				continue;
			}

			// Case2:msg type is not MSG_TYPE_REGISTER?
			iMsgType = ntohl(pMsgRegAck->u32MsgType);
			iSequence = ntohl(pMsgRegAck->u32Sequence);
			if (iMsgType != MSG_TYPE_UPDATE_RESULT) {
				usleep(100000); //100ms
				continue;
			}

			// Case3:udp msg sequence is invalid
			iRet = sequence_is_valid(iSequence, iMsgType);
			if (iRet < 0) {
				usleep(100000); //100ms
				continue;
			}



			LOG_INF("recv ack of msg[%d-%s] sequence=%d, \n",
				iMsgType, get_msg_name(iMsgType), iSequence);

			g_stAgvAttr.iMoveStatus = agv_stop;
			return 0;
		}
		LOG_INF("recv update result ack of msg failed\n");
		usleep(iTimeOut * 1000);
	}

	return iRet;
}

#define TEN_SECOND "10"
/*******************************************************************************
* Function Name      : realize_poweron
* Description	     : initialize uart can udp 
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0 on ok;-1 on error
*******************************************************************************/
int realize_poweron(void)
{
	int iRet = 0;
	int iCount = 0;
	int iMasterUpdateRet = 0;
	time_t iSysTime = 0;
	
	//start,add by tiger.79
	//init system seq for different seq every register
	time_t iTimer = 0;
	time(&iTimer);
	init_seq((int)iTimer, 0, 0, 0);//add by tiger.79
	//end,add by tiger.79

	// init software and hardware environment of agv
	iRet = init_system_signal();
	if (iRet < 0) //by tiger.07
	{
		LOG_ERR("init system signal\n");
	}
	else
	{
		LOG_INF("init system signal success\n");
	}

	// Step1: init the g_stAgvConf of AGV
	iRet = init_agv_conf();
	if (iRet < 0) {
		LOG_ERR("init agv conf failure\n");
	} else {
		LOG_INF("init agv conf success\n");
	}	
	// in DebugEnable=TRUE, no need to connect ftp server,by tiger.44
	if (TRUE == g_stAgvConf.cDebugEnable)
	{
		iRet = ini_write(UPDATA_CONF, FTP_SECTION, "time_out", TEN_SECOND);
		if (iRet < 0 )
		{
			LOG_WRN("set time_out =%s failed\n", TEN_SECOND);
		}
	}

	// Step2: init the g_stAgvParm of AGV
	iRet = init_agv_parm();
	if (iRet < 0) {
		LOG_ERR("init agv parm failure\n");
	}
	else
	{
		LOG_INF("init agv parm success\n");
	}

	// Step3: init the g_stAgvAttr of AGV
	iRet = init_agv_attr();
	if (iRet < 0) {
		LOG_ERR("init agv attr failure\n");
	}
	else
	{
		LOG_INF("init agv attr success\n");
	}

	// modified by kedong, 2018-05-14
	// create heartbeat thread here
	// avoid 5003-heartbeat timeout from console
	g_stAgvAttr.iProtoVer = MSG_TYPE_V1P0;//add by jxu 20180918 modify the version MSG_TYPE_V2P0 to MSG_TYPE_V1P0
	iRet = heartbeat_thread_create();
	if (iRet < 0)
	{
		LOG_WRN("create heartbeat thread failed\n");
	}

	// upload log and update app, when not in debug mode
	while ((iCount < 2) && (upload_log() != 0))
	{
		sleep(1); // 1s
		iCount++; // update 2 times if upload failed
	}
	LOG_INF("resend log %d times !\n", iCount);

	iMasterUpdateRet = update_app();
	
	iRet = get_d500_generation();
	if (iRet < 0)
	{
		LOG_ERR("get d500 generation failed,and use defult generation[-1]\n");
	}
	//update D500-10��D500-15
	if (AGV1_0 == g_stAgvAttr.iAGVType)//by tiger.63
	{
		iRet = update_d500_10_15();
		(iRet < 0) ? (LOG_WRN("update D500-10/D500-15 failed\n")) : (LOG_INF("update D500-10/D500-15 success\n"));
	}
	//update D500-20
	else if (AGV2_0 == g_stAgvAttr.iAGVType)//by tiger.63
	{
		iRet = ota_update_d500_20();
		(iRet < 0) ? (LOG_WRN("update D500-20 failed\n")) : (LOG_INF("update D500-20 success\n"));
	}
	//add by jxu 20180910-begin
	iRet = init_battery_type();
	if (iRet < 0)
	{
		LOG_ERR("init agv battery type failure\n");
		g_stAgvAttr.iDSPStatus = AGV_NOT_OK;
	}
	else
	{
		LOG_INF("init agv battery type success g_stAgvAttr.iBmsVersion=%d g_stAgvAttr.bms.uSoc=%d\n", g_stAgvAttr.iBmsVersion, g_stAgvAttr.bms.uSoc);
	}
	if (g_stAgvAttr.iBatType == BAT_TYPE_SONGXIA)
	{
		iRet = songxia_battery_lasterfive_poweroff();
		if (iRet<0)
		{
			LOG_ERR("init lasterfive_poweroff failure\n");
		}
		//add by yyf 20181022-begin: prase 0x1d command ?
		iRet = songxia_battery_get_pack_model();
		if (iRet<0)
		{
			LOG_ERR("get songxia_battery pack model failure\n");
		}
		//add by yyf 20181022-begin: prase 0x1d command ?

	}
	if ((g_stAgvAttr.iBatType == BAT_TYPE_SONGXIA) && (g_stAgvAttr.bms.uSoc > BMS_UPDATE_MIN_SOC))
	{
		iRet = songxia_battery_vid_pid();
		(iRet < 0) ? (LOG_WRN("search vid&pid failed\n")) : (LOG_INF("search vid&pid success  g_stAgvAttr.iBmsVID[%d]\n", g_stAgvAttr.iBmsVID));
		//if (g_stAgvAttr.iBmsVID == BMS_PANSONIC_VID)
		{
			iRet = update_agv_bms(g_stAgvAttr.iBatType);
			(iRet < 0) ? (LOG_WRN("update agv bms failed\n")) : (LOG_INF("update agv bms success\n"));
		}
		//else
		//{
		//	LOG_INF("g_stAgvAttr.iBmsVID=%d is not Pansonic Vid and will not update\n", g_stAgvAttr.iBmsVID);
		//}
	}
	//add by jxu 20180910-end
	// init semaphore for communication of multi-thread
	iRet = agv_sem_init();
	if (iRet < 0)
	{
		LOG_ERR("init semaphore failure\n");
	}
	else
	{
		LOG_INF("init semaphore success\n");
	}

	// init sequence buffer
	iRet = sequence_buff_init();
	if (iRet < 0)
	{
		LOG_ERR("init sequence buffer failure\n");
	}
	else
	{
		LOG_INF("init sequence buffer success\n");
	}

	// init agv head direction and location
	// must do it before agv_register
	iRet = init_agv_location_head_direct();
	if (iRet < 0)
	{
		LOG_ERR("init agv location and head direct failure\n");
		g_stAgvAttr.iDSPStatus = AGV_NOT_OK;//add by tiger.54
	}
	else
	{
		LOG_INF("init agv location and head direct success\n");
	}

	// init the mc device, should do it after agv_sem_init()
	// beacuse init_mc_dev will use agv_sem_wait()
	// when mc_check_version();
	iRet = init_mc_dev(&g_stMcDev);
	if (iRet < 0)
	{
		LOG_ERR("init mc device failure\n");
		g_stAgvAttr.iDSPStatus = AGV_NOT_OK;//add by tiger.54
	}
	else
	{
		LOG_INF("init mc device success\n");		
	}

	// add by jxu 20180116:two generation version donot init_tc_dev begin
	// init the tc device
	if (!((g_stMcDev.iGeneration > GENERATION_1P0) && (g_stMcDev.iGeneration <= GENERATION_2P0)))
	{
		iRet = init_tc_dev(&g_stTcDev);
		if (iRet < 0)
		{
			LOG_ERR("init tc device failure\n");
			g_stAgvAttr.iDSPStatus = AGV_NOT_OK;//add by tiger.54
		}
		else
		{
			LOG_INF("init tc device success\n");
		}
	}
	// add by jxu 20180116:two generation version donot init_tc_dev end

	// init top camera device
	g_stTopCameraDev.iType = CAMERA_TYPE_TOP;
	iRet = init_camera_dev(&g_stTopCameraDev);
	if (iRet < 0)
	{
		LOG_ERR("init top camera device failure\n");
		g_stAgvAttr.iDSPStatus = AGV_NOT_OK;//add by tiger.54
	}
	else
	{
		LOG_INF("init top camera device success\n");
	}
	//add by jxu 20180227:begin
	//if (g_stTopCameraDev.iVersion == CAMERA_VERSION_V4L2)
	//{
	//	start_v4camera();
	//}
	//add by jxu 20180227:end

	// init bottom camera device
	g_stBottomCameraDev.iType = CAMERA_TYPE_BOT;
	iRet = init_camera_dev(&g_stBottomCameraDev);
	if (iRet < 0)
	{
		LOG_ERR("init bottom camera device failure\n");
		g_stAgvAttr.iDSPStatus = AGV_NOT_OK;//add by tiger.54
	}
	else
	{
		LOG_INF("init bottom camera device success\n");
	}
	
	// init agv pallet status
	// must do it before agv_register
	iRet = init_agv_pallet_status();
	if (iRet < 0)
	{
		LOG_ERR("init agv pallet status failure\n");
		g_stAgvAttr.iDSPStatus = AGV_NOT_OK;//add by tiger.54
	}
	else
	{
		LOG_INF("init agv pallet status success\n");
	}
	//add by jxu 20180719:begin
	if (g_stTopCameraDev.iVersion == CAMERA_VERSION_V4L2)
	{
		start_v4camera();
	}
	//add by jxu 20180719:end

	//��ȡ���̷���, start by tiger.105
	if (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus)
	{
		if (get_pallet_info() < 0)
		{
			LOG_WRN("get pallet info failed after leftarc\n");
		}
	}
	else 
		g_stAgvAttr.iPalletDirect = 0; //�³����ֵ�һ���ϱ����̷���Ϊ��Ч���������
	//�رջ������ذ忴�Ź���������л����ذ壬�򲻻�ִ��sed����
	//�л���������version�ļ�������sed����ᱻִ��
	if (system("cat /etc/version || sed -i '13c #chmod a+x watchdog' /etc/rc.local && sync") == 0)
		LOG_INF("close watchdog of huabei success and will valid next reboot system\n");	
	// end by tiger.105

	//add by jxu 20180917-begin need add after the get the version
	iRet = recvcan0_thread_create();
	if (iRet < 0)
	{
		LOG_WRN("create recv can0 thread failed\n");
	}
	//add by jxu 20180917-end
	//add by jxu 20180709-begin
	if (g_stAgvConf.cDebugEnable == TRUE)
	{
		iRet = sync_time_to_mc();
		if (iRet < 0)
			LOG_WRN("sync time to mc failure\n");
		else
			LOG_INF("sync time to mc success\n");
	}
	//add by jxu 20180709-end
// 	if (iMasterUpdateRet == 1)
// 	{
// 		iRet = msgv1_report_update_result(1,0,0);
// 		if (iRet < 0)
// 		{
// 			LOG_WRN("report_update_result failed\n");
// 		}
// 		else
// 		{
// 			LOG_INF("report_update_result success\n");
// 		}
// 	}
	
	// register agv
	// TODO:will check udp msg protocol version auto
	iRet = agv_register();
	if (iRet < 0)
	{
		LOG_WRN("agv register failure\n");
	}
	else
	{
		LOG_INF("agv register success\n");
	}


	//start by tiger.72
	time(&iSysTime);
	iRet = sync_agent_time(iSysTime);
	if (iRet < 0)
		LOG_WRN("sync agent time failed\n");
	else
		LOG_WRN("sync agent time success\n");
	//end,by tiger.72

	if (AGV2_0 == g_stAgvAttr.iAGVType)
	{
		config_d500_20();//add by tiger.65
	}

	update_net_stat();//by tiger
	update_mcu_log();
	
	//start ,add by tiger.51
	//iRet = sta_send_event_info(SATISTICAL_SEND_PERIOD_30S);
	iRet = sta_send_event_info(SATISTICAL_SEND_NOW);
	if (iRet < 0)
	{
		LOG_WRN("send statistical event info failed:[%d-%s]\n", errno, strerror(errno));
	}
	//end ,add by tiger.51
	
	// create agv work threads
	iRet = work_thread_create();
	if (iRet != 0) //by tiger.39 ,tiger.25
	{
		LOG_ERR("work thread create failed\n");
	}

	// wait for all the thread init done
	iRet = wait_thread_ready(4);
	if (iRet < 0)	//timeout = 4s,by tiger.39
	{
		LOG_ERR("wait thread ready failed \n");
	}
		
	return 0;
}
///start by tiger.29

/*******************************************************************************
*Function Name    :check_agv_head_angle
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :float:the agv head's offset angle  
*******************************************************************************/
#define DEGREE_4    4.0001f
int check_agv_head_angle()
{
	//add by jxu 20180308:begin
	if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		LOG_INF("Donot check the agv head angle to the two generation\n");
		return 0;
	}
	//add by jxu 20180308:end
	float fTmpDiffAngle = 0;
	float fOffAngle = 0;
	float fAngle = (float)g_stAgvAttr.iGAngleOffset / 10;

	LOG_INF("check agv head angle.....\n");
	if (((fAngle > 0.0001f) && (fAngle <= 45.0001f)))
	{
		fTmpDiffAngle = fAngle;
	}
	else if ((fAngle > 45.0001f) && (fAngle <= 135.0001f))
	{
		fTmpDiffAngle = fAngle - 90.0f;
	}
	else if (((fAngle > 135.0001f) && (fAngle <= 225.0001f)))
	{
		fTmpDiffAngle = fAngle - 180.0f;
	}
	else if ((fAngle > 225.0001f) && (fAngle <= 315.0001f))
	{
		fTmpDiffAngle = fAngle - 270.0f;
	}
	else if (fAngle > 315.0001f)
	{
		fTmpDiffAngle = fAngle - 360.0f;
	}

	fOffAngle = fabs(fTmpDiffAngle);
	LOG_INF("current agv head angl=%.2f, offset=%.2f\n", fAngle, fOffAngle);

	//if AGV header offset angle bigger than 4��
	if (fOffAngle > DEGREE_4) 
	{
		LOG_ERR("current agv head angle offset is bigger than 4\n");
		return EVENT_ERR_TILT_HEADER;
	}
	LOG_INF("check agv head angle success\n");

	return 0;
}

/*******************************************************************************
* Function Name      : check_mc_version
* Description	     : check mc version
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int check_mc_version()
{
	LOG_INF("check mc version.....\n");
	if (g_stAgvAttr.iMcVersion <= 0)
	{
		LOG_ERR("check mc version failure\n");
		return EVENT_ERR_MCERR;
	}
	LOG_INF("check mc version success\n");

	return 0;
}

/*******************************************************************************
* Function Name      : check_camera_version
* Description	     : check camera version
* Input 		     : camera_dev_t
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int check_camera_version()
{
	LOG_INF("check camera version.....\n");
	if ((g_stTopCameraDev.iType == CAMERA_TYPE_TOP) && (g_stTopCameraDev.iVersion == CAMERA_VERSION_ERR))
	{
		LOG_ERR("Check uart and v4l2 camera are all failed\n");
		return EVENT_ERR_INIT_CAMERAFAIL;
	}
	LOG_INF("check camera version success\n");

	return 0;
}


/*******************************************************************************
* Function Name      : check_tc_version
* Description	     : check tc version
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int check_tc_version()
{
	LOG_INF("check tc version.....\n");
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		if (g_stAgvAttr.iTcVersion <= 0)
		{
			LOG_ERR("check tc version failure\n");
			return EVENT_ERR_TCERR;
		}
	}
	LOG_ERR("check tc version success\n");

	return 0;
}

/*******************************************************************************
* Function Name      : check_agv_location
* Description	     : check agv location
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int check_agv_location()
{
	sleep(1);
	if (g_stAgvAttr.i8PgvState != PGV_OPERATIONAL_STATE) //by tiger.90
	{
		LOG_INF("PGV have not heartbeat!!!\n");
		return EVENT_ERR_PGV_STOPPED;
	}

	LOG_INF("check agv location.....\n");
	if (g_stAgvAttr.iLocation <= INVALID_POINT)
	{
		return EVENT_ERR_POINTIDERR;
	}
	LOG_INF("check agv location success\n");

	return 0;
}

///end by tiger.29
/*******************************************************************************
* Function Name      : realize_standby
* Description	     : register agv and check dsp version
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0 on ok;-1 on error
*******************************************************************************/
typedef int(*check_fun_t)(void);
int realize_standby(void)
{
	int iRet = 0;
	int i = 0;
	int iCheckFuncNum = 0;
	check_fun_t check_fun[] = {
								check_agv_location, //by tiger.106
								check_agv_head_angle,//by tiger.106
								check_mc_version,//by tiger.106
								check_tc_version,
								check_camera_version, 
								check_pallet,//by tiger.106
								check_pallet_QR };//add by jxu 20180306

	// check the device
	iCheckFuncNum = sizeof(check_fun) / sizeof(check_fun_t);
	for (i = 0; i < iCheckFuncNum; i++)
	{
		if (check_fun[i] == NULL) {
			continue;		
		}

		iRet = check_fun[i]();
		if (iRet != 0)
		{
			send_error_msg(EVENT_TYPE_ERROR, iRet);
		}
	}
	return 0;
}

/*******************************************************************************
* Function Name      : realize_running
* Description	     : realize agv running
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0 on ok;-1 on error
*******************************************************************************/
int realize_running(void)
{
	int iRet;
#if 0 //not get
	if (0 == strcasecmp(g_stAgvAttr.pMcMAC, DEFAULT_MC_MAC)) 
	{
		iRet = get_mc_mac();//by tiger.66
		if (iRet < 0)
		{
			LOG_WRN("get mc mac address failed:[%d-%s]", errno, strerror(errno));
		}
	}
#endif
	return 0;
}

/*******************************************************************************
* Function Name      : realize_reset
* Description	     : realize agv reset
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0 on ok;-1 on error
*******************************************************************************/
int realize_reset(void)
{
	close_uart(g_stAgvParm.iUartFd);
	close_can_socket(g_stAgvParm.iCanSocketFd0);
	close_can_socket(g_stAgvParm.iCanSocketFd1);
	close_udp(g_stAgvParm.iMsgSocketFd);
	close_udp(g_stAgvParm.iCfgSocketFd);
	agv_sem_destroy();
	
	send_pgv_req(PGV_OFF);
	//add by jxu 20180227:begin
	if (g_stTopCameraDev.iVersion == CAMERA_VERSION_V4L2)
	{
		free_camera();
	}
	//add by jxu 20180227:end

	return 0;
}

void set_coredump_file()
{
	int iRet = 0;
	struct rlimit stRlp;
	getrlimit(RLIMIT_CORE, &stRlp);
	stRlp.rlim_cur = 16 * 1024 * 1024;// RLIM_INFINITY;	// unit:bytes //size:unlimits modified by tiger.56
	iRet = setrlimit(RLIMIT_CORE, &stRlp);
	if (iRet < 0)
	{
		LOG_ERR("set Maximum size of core file failed:[%d-%s]\n", errno, strerror(errno));
	}
	iRet = system("sudo echo /core.%e >  /proc/sys/kernel/core_pattern");
	if (iRet < 0)
	{
		LOG_ERR("set core file path failed:[%d-%s]\n", errno, strerror(errno));
	}
}
/*******************************************************************************
* Function Name      : realize_poweron_check
* Description	     : initialize uart can udp
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0 on ok;-1 on error
*******************************************************************************/
int realize_poweron_check(void)
{
	int iRet = 0;
	int iCount = 0;
	int iMasterUpdateRet = 0;
	// init software and hardware environment of agv
	iRet = init_system_signal();
	if (iRet < 0) //by tiger.07
	{
		LOG_ERR("init system signal\n");
	}
	else
	{
		LOG_INF("init system signal success\n");
	}

	iRet = init_agv_parm();
	if (iRet < 0) {
		LOG_ERR("init agv parm failure\n");
	}
	else
	{
		LOG_INF("init agv parm success\n");
	}

	// Step3: init the g_stAgvAttr of AGV
	iRet = init_agv_attr();
	if (iRet < 0) {
		LOG_ERR("init agv attr failure\n");
	}
	else
	{
		LOG_INF("init agv attr success\n");
	}

	// init semaphore for communication of multi-thread
	iRet = agv_sem_init();
	if (iRet < 0)
	{
		LOG_ERR("init semaphore failure\n");
	}
	else
	{
		LOG_INF("init semaphore success\n");
	}

	// init sequence buffer
	iRet = sequence_buff_init();
	if (iRet < 0)
	{
		LOG_ERR("init sequence buffer failure\n");
	}
	else
	{
		LOG_INF("init sequence buffer success\n");
	}
	// init top camera device
	g_stTopCameraDev.iType = CAMERA_TYPE_TOP;
	iRet = init_camera_dev(&g_stTopCameraDev);
	if (iRet < 0)
	{
		LOG_ERR("init top camera device failure\n");
		g_stAgvAttr.iDSPStatus = AGV_NOT_OK;//add by tiger.54
	}
	else
	{
		LOG_INF("init top camera device success\n");
	}
	//add by jxu 20180227:begin
	if (g_stTopCameraDev.iVersion == CAMERA_VERSION_V4L2)
	{
		start_v4camera();
	}
	//add by jxu 20180227:end
	return 0;
}
/*******************************************************************************
* Function Name      : main
* Description	     : the entrance of agv program
* Input 		     : argc: the count of arg
* Input 		     : argv: the value of arg
* Output		     : NONE
* Return		     : 0 on ok;-1 on error
*******************************************************************************/
int main(int argc, char *argv[])
{
	int iRet = 0, c = 0;
	char * pServerIp = NULL;
	while ((c = getopt(argc, argv, "u:f:cbvh?")) > 0)
	{
		switch (c)
		{
		case 'u':
			pServerIp = optarg;
			if (pServerIp != NULL)
			{
				fprintf(stdout, "the console server ip[%s] will update into flow.conf\n", pServerIp);
				iRet = set_console_server_ip(pServerIp);
				if (iRet < 0)
				{
					fprintf(stderr, "update console server ip into flow.conf failure\n");
					exit(1);
				}
			}
			else
			{
				fprintf(stderr, "no server ip\n");
			}
			exit(0);
		case 'f':
			pServerIp = optarg;
			if (pServerIp != NULL)
			{
				fprintf(stdout, "the ftp server ip[%s] will update into flow.conf\n", pServerIp);
				iRet = set_ftp_server_ip(pServerIp);
				if (iRet < 0)
				{
					fprintf(stderr, "update ftp server ip into flow.conf failure\n");
					exit(1);
				}
			}
			else
			{
				fprintf(stderr, "no server ip\n");
			}
			exit(0);
		case 'v':
			version(stdout);
			exit(0);
		//add by jxu 20180719-begin
		case 'c':
			realize_poweron_check();
			if (g_stTopCameraDev.iVersion == CAMERA_VERSION_V4L2)
			{
				iRet = v4l2_camera_get_qrinfo_check(&g_stQrInfo, stdout);
				if (iRet < 0)
				{
					fprintf(stderr, "check v4l2 camera is failed\n");
					realize_reset();
					exit(1);
				}
			}
			else if (g_stTopCameraDev.iVersion == CAMERA_VERSION_UART)
			{
				iRet = uart_camera_get_qrinfo_check(&g_stQrInfo, stdout);
				if (iRet < 0)
				{
					fprintf(stderr, "check uart camera is failed\n");
					realize_reset();
					exit(1);
				}
			}
			else
			{
				fprintf(stderr, "check camera version is failed g_stTopCameraDev.iVersion=%d\n", g_stTopCameraDev.iVersion);
			}
			realize_reset();
			exit(0);
		case 'b':
			realize_poweron_check();
			iRet = check_bms_monitor(stdout);
			if (iRet < 0)
			{
				fprintf(stderr, "check battery is failed\n");
				realize_reset();
				exit(1);
			}
			realize_reset();
			exit(0);
		//add by jxu 20180719-end
		case 'h':
		case '?':
			usage(stdout, 0);
			break;
		default:
			fprintf(stderr, "ERROR: unkown option '%c'\n", c);
			usage(stderr, 1);
			break;
		}
	}

	daemon(1, 1);
	set_coredump_file();

	// Set AGV state to PowerOn at first
	LOG_INF("==========================================\n");
	version(stdout);

	enAgvState = PowerOn;

	while (1)
	{
		switch (enAgvState)
		{
		case PowerOn:
			iRet = realize_poweron();
			enAgvState = StandBy;
			LOG_INF("agv status: initialize success\n");
			//if (iRet == 0) {
			//	enAgvState = StandBy;
			//	LOG_INF("agv status: initialize success\n");
			//} else {
			//	LOG_ERR("agv status: initialize failure\n");
			//	goto error_0;
			//}
			break;
		case StandBy:
			iRet = realize_standby();
			enAgvState = Running;
			LOG_INF("agv status: running\n");
			
			//if (iRet == 0) {
			//	enAgvState = Running;
			//	LOG_INF("agv status: running\n");
			//}else {
			//	LOG_ERR("agv status: not running correctly\n");
			//	goto error_0;
			//}
			break;
		case Running:
			realize_running();
			break;
		case Reset:
			realize_reset();
			break;

		default:
			break;
		}
		sleep(1);
	}

error_0:
	work_thread_destroy();
	
	realize_reset();

	LOG_INF("agv status: exit\n");

	return 0;
}
