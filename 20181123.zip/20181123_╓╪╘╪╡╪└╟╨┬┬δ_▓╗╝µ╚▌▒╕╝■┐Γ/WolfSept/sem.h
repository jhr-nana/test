#ifndef _SEM_H__
#define _SEM_H__

#define SIGNAL_NUM			3
#define SIG_SEND_ID		0
#define SIG_MSG_ID		1
#define SIG_CAN_ID		2

struct signal_t
{
	sem_t sSem[SIGNAL_NUM];
	int iSignal[SIGNAL_NUM];
};

#define INVALID_SEM_TYPE	-1
#define INVALID_SEM_ID		-1

#define SEM_MSG_TYPE		0
#define SEM_CAN_TYPE		1
#define UPDATE_MSG_SEQ		(1)//by tiger.44
#define STOP_AGV_SEM_SEQ	(1)//by tiger.48

#define MAX_SEM_TYPE_NUM	2
#define MAX_SEM_NUM			20
#define SEM_MC_BASE			2000
#define SEM_TC_BASE			1000


typedef struct agv_sem {
	sem_t stSem;
	int iSemType;
	int iSemId;
	int iSequence;
} agv_sem_t;

extern int wait_signal(int iID, int iSignal, uint iMs);
extern int init_signal();
extern int clean_signal(int iID);
extern int post_signal(int iID, int iSignal);
extern int destroy_signal();

extern int agv_sem_init();
extern int agv_sem_clean(int iSemType, int iSemId, int iSequence);
extern int agv_sem_destroy();
extern agv_sem_t * agv_sem_get(int iSemType, int iSemId, int iSequence);
extern agv_sem_t * agv_sem_add(int iSemType, int iSemId, int iSequence);
extern int agv_sem_wait(int iSemType, int iSemId, int iSequence, int iMs);
extern int agv_sem_post(int iSemType, int iSemId, int iSequence);
extern int _sem_wait(sem_t * pSem, int iMs);
extern int _sem_post(sem_t * pSem);

#endif/*_SEM_H__*/