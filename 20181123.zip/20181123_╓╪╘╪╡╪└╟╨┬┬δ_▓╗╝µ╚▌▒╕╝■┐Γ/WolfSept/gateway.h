#ifndef _GATEWAY_H_
#define _GATEWAY_H_

extern int get_gateway(char *gateway, char *ifName);

#endif //_GATEWAY_H_