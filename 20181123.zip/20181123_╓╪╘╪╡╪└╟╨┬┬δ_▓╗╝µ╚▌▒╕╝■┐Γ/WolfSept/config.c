#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

#include "global_var.h"
#include "config.h"
#include "ini_rw.h"

typedef struct tagItem
{
	char *key;
	char *value;
}item;

/*******************************************************************************
* Function Name		 : strtrimr
* Description	     : delete right space .
* Input 		     : pStr: string data.
* Output		     : NONE
* Return		     : string pointer.
*******************************************************************************/
char *strtrimr(char *pStr)
{
	int iNum;
	iNum = strlen(pStr) - 1;

	while (isspace(pStr[iNum]) && (iNum >= 0))
		pStr[iNum--] = '\0';

	return pStr;
}

/*******************************************************************************
* Function Name		 : strtriml
* Description	     : delete left space .
* Input 		     : pStr: string data.
* Output		     : NONE
* Return		     : string pointer.
*******************************************************************************/
char *strtriml(char *pStr)
{
	int iIndex = 0, iNum;
	iNum = strlen(pStr) - 1;

	while (isspace(pStr[iIndex]) && (iIndex <= iNum))
		iIndex++;

	if (0 < iIndex)
		return &pStr[iIndex];
		//strcpy(pStr, &pStr[iIndex]); // source address and destination address overlap, but this is ok
	return pStr;
}

/*******************************************************************************
* Function Name		 : strtrim
* Description	     : delete spaces of string .
* Input 		     : pStr: string data.
* Output		     : NONE
* Return		     : string pointer.
*******************************************************************************/
char *strtrim(char *pStr)
{
	char *p = NULL;	
	p = strtrimr(pStr);
	return strtriml(p);
}

/*******************************************************************************
* Function Name		 : get_item_from_line
* Description	     : get item from line
* Input 		     : pLine: the line of config file
* Input 		     : pStItem: the config key need to read
* Output		     : NONE
* Return		     : 0 on success, 1 on data length is zero, 2 on the comment line,3 on not right parameter .
*******************************************************************************/
int  get_item_from_line(char *pLine, item *pStItem)
{
	char *p = strtriml(pLine);	
	int len = strlen(p);
	
	if (len <= 1)
	{
		return 1;
	}
	else if (p[0] == '#')
	{
		return 2;
	}
	else
	{
		char *p1 = strchr(p, '=');
		if (p1 == NULL)
			return 3; // not a configure line

		*p1++ = '\0';
		p = strtrimr(p);
		p1 = strtriml(p1);
		pStItem->key = (char *)malloc(strlen(p) + 1);
		pStItem->value = (char *)malloc(strlen(p1) + 1);
		sscanf(p, "%[a-zA-Z0-9._]", pStItem->key);
		sscanf(p1, "%[a-zA-Z0-9._]", pStItem->value);

		return 0;	//get the value succeed 
	}
	
}

/*******************************************************************************
* Function Name		 : get_value
* Description	     : read value from config file
* Input 		     : pKey: the config key need to update
* Input 		     : pValue: the config value need to update
* Input 		     : pFile: the name of config file
* Output		     : NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_value( char *pKey,  char *pValue, const char *pFile)
{
	char cLine[1024];
	char cKeyBuff[30] = {0};
	FILE *fp;
	item stItem;
 
	fp = fopen(pFile, "r");
	if (fp == NULL || pKey == NULL)
		return -1;	 

	sscanf(pKey, "%s", cKeyBuff);	 // delete spaces int the word and Use spaces as delimiters.

   	while (fgets(cLine, 1023, fp))
	{		
		if (0 == get_item_from_line(cLine, &stItem))
		{			 
			if (0 == strcmp(stItem.key, cKeyBuff))
			{
				strcpy(pValue, stItem.value);
				free(stItem.key);
				free(stItem.value);
				fclose(fp);
				return 0;
			}
			free(stItem.key);
			free(stItem.value);
		}
		
	}
	fclose(fp);

	return -1; 

}

/*******************************************************************************
* Function Name		 : set_value
* Description	     : write value to config file
* Input 		     : pKey: the config key need to update
* Input 		     : pValue: the config value need to update
* Input 		     : pFile: the name of config file
* Output		     : NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int set_value(char *pKey, char *pValue, const char *pFile)
{
	char cLine[1024];
	char cKeyBuff[30] = { 0 };
	FILE *pFp;
	int iLineNum = 0; // line number
	char cNewLine[1024];
	char cCmd[100];
	item stItem;

	pFp = fopen(pFile, "r");
	if (pFp == NULL || pKey == NULL)
		return -1;

	sscanf(pKey, "%s", cKeyBuff);	 // delete spaces int the word and Use spaces as delimiters.

	while (fgets(cLine, 1023, pFp))
	{
		iLineNum++;
		char *p = strtriml(cLine);
		int iLen = strlen(p);
		 
		if (iLen <= 1)
		{
			continue;
		}
		else if (p[0] == '#')
		{
			continue;
		}
		else
		{			 
			char *p1 = strchr(p, '=');
			if (p1 == NULL)
				continue; // not a configure line

			*p1++ = '\0';
			p = strtrimr(p);
			p1 = strtriml(p1);
			stItem.key = (char *)malloc(strlen(p) + 1);
			stItem.value = (char *)malloc(strlen(p1) + 1);
			sscanf(p, "%[a-zA-Z0-9.]", stItem.key);
			sscanf(p1, "%[a-zA-Z0-9.]", stItem.value);

			if (0 == strcmp(stItem.key, cKeyBuff))
			{
				p1 += strlen(stItem.value);
				sprintf(cNewLine, "sed -i '%da %s=%s%s' %s", (iLineNum - 1), stItem.key, pValue, p1, pFile);
				sprintf(cCmd, "sed -i '%dd' %s", iLineNum, pFile);// delete current line		
				system(cCmd);
				usleep(100);
				system(cNewLine);
				usleep(100);
				free(stItem.key);
				free(stItem.value);
				return 0;	//get the value succeed 
			}

			free(stItem.key);
			free(stItem.value);
		}
	}

	sprintf(cNewLine, "sed -i '$a %s=%s' %s", pKey, pValue, pFile); 
	system(cNewLine); 
	usleep(100);
	fclose(pFp);

	return -1;

}

/*******************************************************************************
* Function Name		 : get_agv_name
* Description	     : get agv name from config file
* Input 		     : NONE
* Output		     : pAgvName: the config value of EnableTest
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_agv_name(int * pAgvName)
{
	int iRet = 0;
	int iAgvName = 0;
	char cValue[50] = {0};

	if (pAgvName == NULL) {
		return -1;
	}
	
	// Read the config of "skywolf" from config file
	iRet = get_value("skywolf", cValue, CONFIGURE_FILE);
	if (iRet < 0) {
		LOG_ERR("read skywolf from config file error\n");
		return -1;
	}

	// check the validity of AgvName read from config file
	iAgvName = atoi(cValue);
	if (iAgvName <= 0) {
		LOG_ERR("skywolf car num is error:[%s]\n", cValue);
		return -1;
	}

	*pAgvName = iAgvName;

	return 0;
}

/*******************************************************************************
* Function Name		 : get_big_ver_date
* Description	     : get bigver and bigverdate from config file
* Input 		     : NONE
* Input 		     : NONE
* Output		     : pBigVer: bigver
* Output		     : pBigVerDate: bigverdate
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_big_ver_date(int * pBigVer, int * pBigVerDate)
{
	int iRet = 0;
	char *pStr = NULL;
	int iBigVer = 0, iBigVerDate = 0;
	char cValue[50] = {0};

	if ((pBigVer == NULL) || (pBigVerDate == NULL)) {
		return -1;
	}
	
	// Read the config of "version" from config file
	iRet = get_value("version", cValue, VERCRC_CONF);
	if (iRet < 0) {
		iBigVer = 0;
		iBigVerDate = 171111;
		LOG_WRN("read version from config file error, use default:0-171111\n");
		goto skip;
	}

	pStr = strtok(cValue, "._");
	if (pStr != NULL) {
		iBigVer = 0;
		iBigVer += atoi(pStr);
		iBigVer *= 10;
	}
	
	pStr=strtok(NULL, "._");
	if (pStr != NULL) {
		iBigVer += atoi(pStr);
		iBigVer *= 10;
	}
	
	pStr = strtok(NULL, "._");
	if (pStr != NULL) {
		iBigVer += atoi(pStr);
	}

	pStr = strtok(NULL, "._");
	if (pStr != NULL) {
		iBigVerDate = 0;
		iBigVerDate = atoi(pStr) % 10000;
		iBigVerDate *= 100;
	}

	pStr = strtok(NULL, "._");
	pStr = strtok(NULL, "._");
	if (pStr != NULL) {
		iBigVerDate += atoi(pStr);
	}

skip:
	*pBigVer = iBigVer;
	*pBigVerDate = iBigVerDate;

	return 0;
}


/*******************************************************************************
* Function Name		 : check_ip
* Description	     : check ipstring is valid?
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int check_ip(const char * ip)
{
	int n[4] = {0};
	char c[4] = { 0 };

	if (ip == NULL)
	{
		return -1;
	}

	if (sscanf(ip, "%d%c%d%c%d%c%d%c",
			&n[0], &c[0], &n[1], &c[1],
			&n[2], &c[2], &n[3], &c[3]) == 7)
	{
		int i = 0;
		for(i = 0; i < 3; ++i) {
			if (c[i] != '.') {
				return -1;
			}
		}
		
		for(i = 0; i < 4; ++i) {
			if (n[i] > 255 || n[i] < 0) {
				return -1;
			}
		}

		return 0;
	} else {
		return -1;
	}
}

/*******************************************************************************
* Function Name		 : get_server_ip
* Description	     : get console server ip from config file
* Input 		     : NONE
* Output		     : pServerIp: the server ip
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_server_ip(char * pServerIp)
{
	int iRet = 0;
	char cValue[50] = {0};

	if (pServerIp == NULL) {
		return -1;
	}

	// Read the config of "serverip" from config file
	iRet = get_value("serverip", cValue, CONFIGURE_FILE);
	if (iRet < 0) {
		LOG_ERR("Read serverip from config file error\n");
		return -1;
	}

	// check the validity of ServerIp read from config file
	iRet = check_ip(cValue);
	if (iRet < 0) {
		LOG_ERR("the serverip is invalid\n");
		return -1;
	}	
	strncpy(pServerIp, cValue, strlen(cValue));

	return 0;
}

/*******************************************************************************
* Function Name      : set_console_server_ip
* Description	     : update console serverip into configfile
* Input 		     : pServerIp: server ip
* Output		     : NONE
* Return		     : 0 if OK ,-1 on error
*******************************************************************************/
int set_console_server_ip(char * pServerIp)
{
	int iRet = 0;
	char cValue[50] = { 0 };

	if (pServerIp == NULL)
		return -1;

	iRet = check_ip(pServerIp);
	if (iRet < 0)
	{
		fprintf(stderr, "console serverip[%s] is not correct\n", pServerIp);
		return -1;
	}

	///write ip ,start,by tiger.15		
	bzero(cValue, sizeof(cValue));
	sprintf(cValue, "%s #The vip of agent", pServerIp);
	iRet = ini_write(CONFIGURE_FILE, CONSOLE_SERVER_SECTION, "serverip", cValue);
	if (iRet < 0)
		fprintf(stderr, "ini_write console serverip failure\n");

	///end,by tiger.15

	return iRet;
}

/*******************************************************************************
* Function Name      : set_ftp_server_ip
* Description	     : update ftp server ip into configfile
* Input 		     : pServerIp: server ip
* Output		     : NONE
* Return		     : 0 if OK ,-1 on error
*******************************************************************************/
int set_ftp_server_ip(char * pServerIp)
{
	int iRet = 0;
	char cValue[50] = { 0 };

	if (pServerIp == NULL)
		return -1;

	iRet = check_ip(pServerIp);
	if (iRet < 0)
	{
		fprintf(stderr, "ftp_serverip[%s] is not correct\n", pServerIp);
		return -1;
	}

	///write ip ,start,by tiger.15		
	bzero(cValue, sizeof(cValue));
	sprintf(cValue, "%s", pServerIp);
	iRet = ini_write(CONFIGURE_FILE, FTP_SERVER_SECTION, "ftp_serverip", cValue);
	if (iRet < 0)
		fprintf(stderr, "ini_write ftp serverip failure\n");

	///end,by tiger.15

	return iRet;
}

/*******************************************************************************
* Function Name		 : get_check_point
* Description	     : get check point from config file
* Input 		     : NONE
* Output		     : pServerIp: the server ip
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_check_point(char * pCheckPoint)
{
	int iRet = 0;
	int iCheckPoint= 0;
	char cValue[50] = {0};

	if (pCheckPoint == NULL) {
		return -1;
	}

	// Read the config of "checkpoint" from config file
	iRet = get_value("checkpoint", cValue, CONFIGURE_FILE);
	if (iRet < 0) {
		LOG_WRN("read checkpoint from config file error, use default: 0=disable\n");
		// if read conf failure, use default: 0=disable
		sprintf(cValue, "%s", "0");
	}

	// check the validity of checkpoint read from config file
	iCheckPoint = atoi(cValue);
	if ((iCheckPoint < 0) || (iCheckPoint > 1)) {
		LOG_ERR("the checkpoint is set error:[%s]\n", cValue);
		return -1;
	}

	*pCheckPoint = iCheckPoint;

	return 0;
}

/*******************************************************************************
* Function Name		 : get_point_report
* Description	     : get point report from config file
* Input 		     : NONE
* Output		     : pPointReport: the config value of PointReport
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_point_report(char * pPointReport)
{
	int iRet = 0;
	int iPointReport = 0;
	char cValue[50] = {0};

	if (pPointReport == NULL) {
		return -1;
	}

	// Read the config of "pointrpt" from config file
	iRet = get_value("pointrpt", cValue, CONFIGURE_FILE);
	if (iRet < 0) {
		LOG_WRN("read pointrpt from config file error, use default: 0=disable\n");
		// if read conf failure, use default: 0=disable
		sprintf(cValue, "%s", "0");
	}

	// check the validity of pointrpt read from config file
	iPointReport = atoi(cValue);
	if ((iPointReport < 0) || (iPointReport > 1)) {
		LOG_ERR("the pointrpt is set error:[%s]\n", cValue);
		return -1;
	}

	*pPointReport = iPointReport;

	return 0;
}

/*******************************************************************************
* Function Name		 : get_enable_test
* Description	     : get enable test from config file
* Input 		     : NONE
* Output		     : pEnableTest: the config value of EnableTest
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_enable_test(char * pEnableTest)
{
	int iRet = 0;
	int iEnableTest= 0;
	char cValue[50] = {0};

	if (pEnableTest == NULL) {
		return -1;
	}

	// Read the config of "pEnableTest" from config file
	iRet = get_value("enabletest", cValue, CONFIGURE_FILE);
	if (iRet < 0) {
		LOG_WRN("read enabletest from config file error, use default: 1=enable\n");
		// if read conf failure, use default: 1=enable
		sprintf(cValue, "%s", "1");
	}

	// check the validity of pEnableTest read from config file
	iEnableTest = atoi(cValue);
	if ((iEnableTest < 0) || (iEnableTest > 1)) {
		LOG_ERR("the pEnableTest is set error:[%s]\n", cValue);
		return -1;
	}

	*pEnableTest = iEnableTest;

	return 0;
}

/*******************************************************************************
* Function Name		 : get_enable_debug
* Description	     : get enable debug from config file
* Input 		     : NONE
* Output		     : pEnableDebug: the config value of EnableDebug
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_enable_debug(char * pEnableDebug)
{
	int iRet = 0;
	int iEnableTest = 0;
	char cValue[50] = { 0 };

	if (pEnableDebug == NULL) {
		return -1;
	}

	// Read the config of "pEnableTest" from config file
	iRet = get_value("enabledebug", cValue, CONFIGURE_FILE);
	if (iRet < 0) {
		LOG_WRN("read enabledebug from config file error, use default: 0=disable\n");
		// if read conf failure, use default: 1=enable
		sprintf(cValue, "%s", "0");
	}

	// check the validity of pEnableTest read from config file
	iEnableTest = atoi(cValue);
	if ((iEnableTest < 0) || (iEnableTest > 1)) {
		LOG_ERR("the enabledebug is set error:[%s]\n", cValue);
		return -1;
	}

	*pEnableDebug = iEnableTest;

	return 0;
}

/*******************************************************************************
* Function Name		 : get_enable_send_statistical
* Description	     : get enable send statistical from config file
* Input 		     : NONE
* Output		     : pEnableDebug: the config value of EnableDebug
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_enable_send_statistical(char * pEnableStatistical)
{
	int iRet = 0;
	int iEnableStatistical = 0;
	char cValue[50] = { 0 };

	if (pEnableStatistical == NULL) {
		return -1;
	}

	// Read the config of "pEnableTest" from config file
	iRet = get_value("enablestatistical", cValue, CONFIGURE_FILE);
	if (iRet < 0) {
		LOG_WRN("read enablestatistical from config file error, use default: 0=disable\n");
		// if read conf failure, use default: 0=disable
		sprintf(cValue, "%s", "0");
	}

	// check the validity of pEnableTest read from config file
	iEnableStatistical = atoi(cValue);
	if ((iEnableStatistical < 0) || (iEnableStatistical > 1)) {
		LOG_ERR("the enablestatistical is set error:[%s]\n", cValue);
		return -1;
	}

	*pEnableStatistical = iEnableStatistical;

	return 0;
}
/*******************************************************************************
* Function Name		 : get_enable_pgv_period
* Description	     : get_enable_pgv_period from config file
* Input 		     : NONE
* Output		     : pEnableDebug: the config value of EnableDebug
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_enable_pgv_period(char * pEnablePgvPeriod)
{
	int iRet = 0;
	int iEnablePgvPeriod = 0;
	char cValue[50] = { 0 };

	if (pEnablePgvPeriod == NULL) {
		return -1;
	}

	// Read the config of "pEnableTest" from config file
	iRet = get_value("pgvperiod", cValue, CONFIGURE_FILE);
	if (iRet < 0) {
		LOG_WRN("read pgvperiod from config file error, use default: 0=disable\n");
		// if read conf failure, use default: 0=disable
		sprintf(cValue, "%s", "0");
	}

	// check the validity of pEnableTest read from config file
	iEnablePgvPeriod = atoi(cValue);
	if ((iEnablePgvPeriod < 0) || (iEnablePgvPeriod > 1)) {
		LOG_ERR("the enablestatistical is set error:[%s]\n", cValue);
		return -1;
	}

	*pEnablePgvPeriod = iEnablePgvPeriod;

	return 0;
}
/*******************************************************************************
* Function Name		 : get_charge_type
* Description	     : get charge type from config file
* Input 		     : NONE
* Output		     : charge method
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_charge_type(char * pChargeType)
{
	int iRet = 0;
	int iChargeType = 0;
	char cValue[50] = { 0 };

	if (pChargeType == NULL) {
		return -1;
	}

	// Read the config of "charge method" from config file
	iRet = get_value("chargemethod", cValue, CONFIGURE_FILE);
	if (iRet < 0) {
		LOG_WRN("read chargemethod from config file error, use default: 0=ON_GROUND\n");
		// if read conf failure, use default: 0=ON_GROUND
		sprintf(cValue, "%s", "0");
	}

	// check the validity of AgvName read from config file
	iChargeType = atoi(cValue);
	if (iChargeType < 0) {
		LOG_ERR("iChargeType num is error:[%s]\n", cValue);
		return -1;
	}

	*pChargeType = iChargeType;

	return 0;
}
/*******************************************************************************
* Function Name		 : get_check_soc_flag
* Description	     : get NeedCheckSoc flag from config file
* Input 		     : NONE
* Output		     : pNeedCheckSoc: NeedCheckSoc value
* Return		     : 0:success; -1:failure
*******************************************************************************/
int get_check_soc_flag(char * pNeedCheckSoc)
{
	int iRet = 0;
	int iNeedCheckSoc = 0;
	char cValue[50] = { 0 };

	if (pNeedCheckSoc == NULL) {
		return -1;
	}

	// Read the config of "charge method" from config file
	iRet = get_value("NeedCheckSoc", cValue, CONFIGURE_FILE);
	if (iRet < 0) {
		LOG_WRN("read NeedCheckSoc from config file error, use default: 0\n");
		// if read conf failure, use default: 0=ON_GROUND
		sprintf(cValue, "%s", "0");
	}

	// check the validity of AgvName read from config file
	iNeedCheckSoc = atoi(cValue);
	if (iNeedCheckSoc < 0) {
		LOG_ERR("iSoc num is error:[%s]\n", iNeedCheckSoc);
		return -1;
	}

	*pNeedCheckSoc = iNeedCheckSoc;

	return 0;
}
/*******************************************************************************
* Function Name		 : set_check_soc_flag
* Description	     : set NeedCheckSoc flag from config file
* Input 		     : pNeedCheckSoc:NeedCheckSoc flag value string
* Output		     :NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int set_check_soc_flag(const char * pNeedCheckSoc)
{
	int iRet = -1;
	iRet = ini_write(CONFIGURE_FILE_PATH, "skywolf_conf", "NeedCheckSoc", pNeedCheckSoc);
	if (iRet < 0)
	{
		LOG_WRN("set NeedCheckSoc = %s failed\n", pNeedCheckSoc);
	}
	else
	{
		LOG_INF("set NeedCheckSoc = %s success\n", pNeedCheckSoc);
	}

	return iRet;
}
