/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* FileName: device.C
* Author: Menghu Wang   Version: V1.0   Data:2017-08-16
* Description:THE INTERFACE OF AGV MOVE CONTROL AND TOP CONTROL FUNCTION
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include <math.h>
#include "global_var.h"
#include "device.h"
#include "debug.h"
#include "mc_v1.h"
#include "tc_v1.h"
#include "mc_v2.h"
#include "v4l2_camera.h"
#include "uart_camera.h"
#include "ftp.h"
#include "statistical_info.h"
#include "atomic.h"
mc_dev_t g_stMcDev;
tc_dev_t g_stTcDev;
qr_info_t g_stQrInfo;
camera_dev_t g_stTopCameraDev;
camera_dev_t g_stBottomCameraDev;

/* Private macro -------------------------------------------------------------*/
#define YYMMDD_PARAM_ID			0xe0
#define HHMMSS_PARAM_ID			0xe1
#define AGVNO					0xe2	//add by tiger.53
#define SN_H_3_BYTE				0xe3	//add by tiger.53
#define SN_L_3_BYTE				0xe4	//add by tiger.53
#define FTP_SERVER_IP			0xe5    //add by tiger.64
#define WAREHOUSE_BRAIN_IP		0xe6	//add by tiger.65
#define MC_MAC_L_3_BYTE			0xe7	//add by tiger.66
#define MC_MAC_H_3_BYTE			0xe8	//add by tiger.66

/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name		 : _sem_wait_exclude_safe
* Description	     : wait semaphore for agv exclude safe.
* input			     : pSem: the pointer of semaphore
* input			     : iMs: time out, in ms;
* Output		     : NONE
* Return		     : 0:success; <0:failure.
*******************************************************************************/
int _sem_wait_exclude_safe(sem_t * pSem, int iMs)
{
	int iTimeCount = 0;
	int iRet = 0;
	int iException = 0;//by tiger.67
	if (pSem == NULL) {
		return -1;
	}

	while (iTimeCount < iMs)
	{
		iRet = _sem_wait(pSem, TIME_OUT_100MS);
		if (iRet < 0)
		{
			iException = atomic_read(&g_stAgvAttr.iException);//by tiger.67
			if ((EVENT_ERR_AGVSAFE == iException)//by tiger.67
				|| (EVENT_ERR_NOCONTACTIMPACT == iException)
				|| (EVENT_ERR_EMERSTOPPRESS) == iException)
				iTimeCount = 0;
			else
				iTimeCount += TIME_OUT_100MS;

			continue;
		}
		break;
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : update_global_pallet_angle_offset
* Description	     : update g_stAgvAttr.iTAngleOffset.
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure.
*******************************************************************************/
int update_global_pallet_angle_offset()
{
	int iRet = 0;

	// add by kedong, 20180302
	// before send_pallet_angle_offset, get current pallet info for comparing with last
	int iLastPalletDirect = 0, iLastPalletAngle = 0, iLastOffset = 0;
	int iCurrPalletDirect = 0, iCurrPalletAngle = 0, iCurrOffset = 0;

	// save PalletDirect into iLastPalletDirect, before get current pallet info
	// save PalletAngle  into iLastPalletAngle, before get current pallet info
	iLastPalletDirect = g_stAgvAttr.iPalletDirect;
	iLastPalletAngle = g_stAgvAttr.iTAngleOffset;

	LOG_INF("get the pallet info once again, just compare as last\n");
	//just get pallet info by tiger
	iRet = get_pallet_info();
	if (iRet < 0)
	{
		g_stAgvAttr.iTAngleOffset = iLastPalletAngle;
		g_stAgvAttr.iPalletDirect = iLastPalletDirect;
		LOG_WRN("get the pallet info failed\n");
		return -1;//add by jxu 20180820-modify by jxu return 0->-1	
	}

	iCurrPalletDirect = g_stAgvAttr.iPalletDirect;
	iCurrPalletAngle = g_stAgvAttr.iTAngleOffset;

	iLastOffset = compute_angle_offset(iLastPalletAngle);
	iCurrOffset = compute_angle_offset(iCurrPalletAngle);

	// only update angle offset when pallet direct is not change and last angle is correct updated
	if ((iCurrPalletDirect == iLastPalletDirect) && (iLastPalletAngle != 0))
	{
		iLastOffset = abs(iLastOffset);
		iCurrOffset = abs(iCurrOffset);

		if (iLastOffset < iCurrOffset)
			g_stAgvAttr.iTAngleOffset = iLastPalletAngle;
		else
			g_stAgvAttr.iTAngleOffset = iCurrPalletAngle;
	}
	else
	{
		g_stAgvAttr.iTAngleOffset = iCurrPalletAngle;
	}

	LOG_INF("last.PalletDirect=%d, current.PalletDirect=%d\n",iLastPalletDirect, iCurrPalletDirect);
	LOG_INF("pallet angle:last[%5d/%5d], current[%5d/%5d], use[%5d]\n",
		iLastOffset, iLastPalletAngle, iCurrOffset, iCurrPalletAngle, g_stAgvAttr.iTAngleOffset);

	return 0;
}

int mc_default_check_version()
{
	return 0;
}

int mc_default_get_flag(u8 u8FlagVar)
{
	return 0;
}

int mc_default_set_flag(u8 u8FlagVar, u32 u32Value)
{
	return 0;
}

int mc_default_get_param(u8 u8ParamVar)
{
	return 0;
}

int mc_default_set_param(u8 u8ParamVar, float fValue)
{
	return 0;
}

int mc_default_enable_wdg()
{
	return 0;
}

int mc_default_start()
{
	return 0;
}

int mc_default_reset()
{
	return 0;
}

int mc_default_stop()
{
	return 0;
}

void mc_default_deal_ack(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	return;
}

void mc_default_deal_fin(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	return;
}

int mc_default_deal_heartbeat(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	return 0;
}

int mc_default_deal_exception(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	return 0;
}

int mc_default_start_charge()
{
	return 0;
}

int mc_default_stop_charge()
{
	return 0;
}

int mc_default_go_forward(u8 u8Weight, u16 u16Distance, u16 u16Speed)
{
	return 0;
}

int mc_default_go_backward(u8 u8Weight, u16 u16Distance, u16 u16Speed)
{
	return 0;
}

int mc_default_turn_left(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	return 0;
}

int mc_default_turn_right(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	return 0;
}

int mc_default_slow_go_back(u16 u16SRemain, u16 u16QRDistance)
{
	return 0;
}

int mc_default_slow_go_straight(u16 u16SRemain, u16 u16QRDistance)
{
	return 0;
}

int mc_default_leftarc(u16 u16Weight)
{
	return 0;
}

int mc_default_rightarc(unsigned short u16Weight)
{
	return 0;
}

int mc_default_clear_derail(void)
{
	return 0;
}

int mc_default_clear_navigation(void)
{
	return 0;
}

int mc_default_clear_lcoder_error(void)
{
	return 0;
}

int mc_default_clear_rcoder_error(void)
{
	return 0;
}

int mc_default_enter_debug_mode(void)
{
	return 0;
}

int mc_default_quit_debug_mode()
{
	return 0;
}

int mc_default_clasp_pallet(void)
{
	return 0;
}

int mc_default_unclasp_pallet(void)
{
	return 0;
}

int mc_default_clasp_wheel(void)
{
	return 0;
}

int mc_default_unclasp_wheel(void)
{
	return 0;
}

int tc_default_check_version()
{
	return 0;
}

int tc_default_get_flag(u8 u8FlagVar)
{
	return 0;
}

int tc_default_set_flag(u8 u8FlagVar, u32 u32Value)
{
	return 0;
}

int tc_default_get_param(u8 u8ParamVar)
{
	return 0;
}

int tc_default_set_param(u8 u8ParamVar, float fValue)
{
	return 0;
}

int tc_default_enable_wdg(){
	return 0;
}

int tc_default_start()
{
	return 0;
}

int tc_default_reset()
{
	return 0;
}

int tc_default_stop()
{
	return 0;
}

void tc_default_deal_ack(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	return;
}

void tc_default_deal_angle_ack(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	return;
}

void tc_default_deal_fin(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	return;
}

int tc_default_deal_heartbeat(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	return 0;
}

int tc_default_deal_exception(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	return 0;
}

int tc_default_send_angle_offset(u16 u16Angle)
{
	return 0;
}

int tc_default_cntl_lift_motor(u8 u8Operate, u8 u8Weight)
{
	return 0;
}

int tc_default_cntl_cycle_motor(u8 u8Operate, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	return 0;
}

/*******************************************************************************
*Function Name    :agv_task_init
*Description      : init agv task struct.  
*Input       	  :agv_task_t * pAgvTask:the operate msg  
*Input       	  :int iDevType:the device type, such as:DEV_MC, DEC_TC  
*Input       	  :u8 u8Action : the action type, such as:MC_GO_FORWARD... 
*Input       	  :enMcLogType eMcLogType��the MC log type need to get
*Input       	  :enTcLogType eTcLogType��the TC log type need to get  
*Output 		  :NONE
*Return           :int:0:success; <0:failure  
*******************************************************************************/
int agv_task_init(agv_task_t *pAgvTask, int iDevType, u8 u8Action, enMcLogType eMcLogType,enTcLogType eTcLogType)
{
	int iRet = 0;

	if (pAgvTask == NULL)
		return -1;
	if (FALSE == g_stAgvTask.iWalkContinue) //by tiger.71
		get_current_time(pAgvTask->pStartTime, TIME_STR_LEN);
	pAgvTask->bSliding = false;
	pAgvTask->iDevType = iDevType;
	pAgvTask->iWalkTimeout = TIME_OUT_10M;
	pAgvTask->stAction.iType = u8Action;
	pAgvTask->stAction.iResult = REFUSE;
	pAgvTask->stAction.eMcLogType = eMcLogType;
	pAgvTask->stAction.eTcLogType = eTcLogType;
	pthread_mutex_init(&pAgvTask->stAction.stActLock, NULL);
	iRet = sem_init(&pAgvTask->stAction.stActSem, 0, 0);

	if (iDevType == DEV_MC)
		LOG_INF("mc execute:[%d-%s]..........\n", u8Action, get_mc_cmd_name(u8Action));

	if (iDevType == DEV_TC)
		LOG_INF("tc execute:[%d-%s]..........\n", u8Action, get_tc_cmd_name(u8Action));

	return iRet;
}

/*******************************************************************************
* Function Name		 : agv_task_exit
* Description	     : exit agv task struct.
* input			     : pMsg: the operate msg.
* input			     : iDevType: the device type, such as:DEV_MC, DEC_TC
* input			     : u8Action: the action type, such as:MC_GO_FORWARD...
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int agv_task_exit(agv_task_t *pAgvTask, int iDevType, u8 u8Action)
{
	if (pAgvTask == NULL)
		return -1;
	int iRet = 0;
	char pActionName[100] = { 0 };

	get_current_time(pAgvTask->pEndTime, TIME_STR_LEN);
	pAgvTask->stAction.eMcLogType = MC_LOG_TYPE_INVALID;
	pAgvTask->stAction.eTcLogType = TC_LOG_TYPE_INVALID;
	pthread_mutex_init(&pAgvTask->stAction.stActLock, NULL);
	sem_init(&pAgvTask->stAction.stActSem, 0, 0);

	if ((iDevType == DEV_MC )&& (FALSE == g_stAgvTask.iWalkContinue))  //by tiger.71
	{
		sprintf(pActionName, "%s", get_mc_cmd_name(u8Action));
		ACTION_LOG("%s\t%s\t%d\t%s\n",
		pAgvTask->pStartTime, pAgvTask->pEndTime, u8Action, pActionName);
		
		LOG_INF("mc execute:[%d-%s] success\n", u8Action, pActionName);
	}

	if (iDevType == DEV_TC) {
		sprintf(pActionName, "%s", get_tc_cmd_name(u8Action));
		ACTION_LOG("%s\t%s\t%d\t%s\n",
			pAgvTask->pStartTime, pAgvTask->pEndTime, u8Action, pActionName);
		
		LOG_INF("tc execute:[%d-%s] success\n", u8Action, pActionName);
	}

	//start ,add by tiger.51	
	if (FALSE == g_stAgvTask.iWalkContinue) //by tiger.71
	{
		//iRet = sta_send_action_info(SATISTICAL_SEND_PERIOD_30S, pActionName);
		iRet = sta_send_action_info(SATISTICAL_SEND_NOW, pActionName);
		if (iRet < 0)
		{
			LOG_WRN("send statistical action info failed:[%d-%s]\n", errno, strerror(errno));
		}
		//end ,add by tiger.51
	}	

	return pAgvTask->stAction.iResult;
}

/*******************************************************************************
* Function Name		 : get_mc_evnet_desc
* Description	     : get event description for mc
* input			     : iEventType: event type
* Output		     : NONE
* Return		     : the pointer of event description
*******************************************************************************/
char * get_mc_evnet_desc(int iEventType)
{
	char *pEventDesc = NULL;

	switch (iEventType) {
	case NO_ERROR:
		pEventDesc = "NO_ERROR";
		break;
	case EVENT_ERR_EMERSTOP:
		pEventDesc = "EVENT_ERR_EMERSTOP";
		break;
	case EVENT_ERR_EMERSTOPPRESS:
		pEventDesc = "EVENT_ERR_EMERSTOPPRESS";
		break;
	case EVENT_ERR_AGVSAFE:
		pEventDesc = "EVENT_ERR_AGVSAFE";
		break;
	case EVENT_ERR_NOCONTACTIMPACT:
		pEventDesc = "EVENT_ERR_NOCONTACTIMPACT";
		break;
	case EVENT_ERR_LOSENAVIGATE:
		pEventDesc = "EVENT_ERR_LOSENAVIGATE";
		break;
	case EVENT_ERR_DERAIL:
		pEventDesc = "EVENT_ERR_DERAIL";
		break;
	case EVENT_ERR_LEFTSERVOINVALID:
		pEventDesc = "EVENT_ERR_LEFTSERVOINVALID";
		break;
	case EVENT_ERR_RIGHTSERVOINVALID:
		pEventDesc = "EVENT_ERR_RIGHTSERVOINVALID";
		break;
	case EVENT_ERR_SYNC_CYCLE_COMBREAK:
		pEventDesc = "EVENT_ERR_SYNC_CYCLE_COMBREAK";
		break;
	case EVENT_ERR_WHEEL_PLATE_ANGLEDIFFOV:
		pEventDesc = "EVENT_ERR_WHEEL_PLATE_ANGLEDIFFOV";
		break;
	case EVENT_ERR_ENCODERL:
		pEventDesc = "EVENT_ERR_ENCODERL";
		break;
	case EVENT_ERR_ENCODERR:
		pEventDesc = "EVENT_ERR_ENCODERR";
		break;
	case EVENT_ERR_CHARGE_FEEDBACK_OVERTIME:
		pEventDesc = "EVENT_ERR_CHARGE_FEEDBACK_OVERTIME";
		break;
	case EVENT_ERR_OB_DETECT_FAULT_EVENT:
		pEventDesc = "EVENT_ERR_OB_DETECT_FAULT_EVENT";
		break;
	case EVENT_ERR_MOTORL_NO_ACTION_EVENT:
		pEventDesc = "EVENT_ERR_MOTORL_NO_ACTION_EVENT";
		break;
	case EVENT_ERR_MOTORR_NO_ACTION_EVENT:
		pEventDesc = "EVENT_ERR_MOTORR_NO_ACTION_EVENT";
		break;
	case EVENT_ERR_DIFFOV_AFTERTHREE:
		pEventDesc = "EVENT_ERR_DIFFOV_AFTERTHREE";
		break;
	case EVENT_ERR_PLATE_CYCLE_SERVO_INVALID:
		pEventDesc = "EVENT_ERR_PLATE_CYCLE_SERVO_INVALID";
		break;
	case EVENT_ERR_LIFT_SERVO_INVALID:
		pEventDesc = "EVENT_ERR_LIFT_SERVO_INVALID";
		break;
	case EVENT_ERR_LIFT_ENCODER_ERR:
		pEventDesc = "EVENT_ERR_LIFT_ENCODER_ERR";
		break;
	case EVENT_ERR_LIFT_MOTION_NO_ACTION:
		pEventDesc = "EVENT_ERR_LIFT_MOTION_NO_ACTION";
		break;
	case EVENT_ERR_LWHEEL_SERVO_OFFLINE:
		pEventDesc = "EVENT_ERR_LWHEEL_SERVO_OFFLINE";
		break;
	case EVENT_ERR_RWHEEL_SERVO_OFFLINE:
		pEventDesc = "EVENT_ERR_RWHEEL_SERVO_OFFLINE";
		break;
	case EVENT_ERR_PLATE_CYCLE_SERVER_OFFLINE:
		pEventDesc = "EVENT_ERR_PLATE_CYCLE_SERVER_OFFLINE";
		break;
	case EVENT_ERR_LIFT_SERVO_OFFLINE:
		pEventDesc = "EVENT_ERR_LIFT_SERVO_OFFLINE";
		break;
	case EVENT_ERR_SERVO_INITIAL_FAIL:
		pEventDesc = "EVENT_ERR_SERVO_INITIAL_FAIL";
		break;
	case EVENT_ERR_LWHEEL_SERVO_DISCONNECT:
		pEventDesc = "EVENT_ERR_LWHEEL_SERVO_DISCONNECT";
		break;
	case EVENT_ERR_RWHEEL_SERVO_DISCONNECT:
		pEventDesc = "EVENT_ERR_RWHEEL_SERVO_DISCONNECT";
		break;
	case EVENT_ERR_PLATE_CYCLE_SERVO_DISCONNECT:
		pEventDesc = "EVENT_ERR_PLATE_CYCLE_SERVO_DISCONNECT";
		break;
	case EVENT_ERR_LIFT_SERVO_DISCONNECT:
		pEventDesc = "EVENT_ERR_LIFT_SERVO_DISCONNECT";
		break;
	case EVENT_ERR_MC_TIMEOUT:
		pEventDesc = "EVENT_ERR_MC_TIMEOUT";
		break;
	case EVENT_ERR_EMO_LWHEEL_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_EMO_LWHEEL_SERVO_ERROR";
		break;
	case EVENT_ERR_EMO_RWHEEL_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_EMO_RWHEEL_SERVO_ERROR";
		break;
	case EVENT_ERR_EMO_PLATE_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_EMO_PLATE_SERVO_ERROR";
		break;
	case EVENT_ERR_EMO_LIFT_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_EMO_LIFT_SERVO_ERROR";
		break;
	case EVENT_ERR_MOTEC_LWHEEL_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_MOTEC_LWHEEL_SERVO_ERROR";
		break;
	case EVENT_ERR_MOTEC_RWHEEL_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_MOTEC_RWHEEL_SERVO_ERROR";
		break;
	case EVENT_ERR_MOTEC_PLATE_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_MOTEC_PLATE_SERVO_ERROR";
		break;
	case EVENT_ERR_MOTEC_LIFT_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_MOTEC_LIFT_SERVO_ERROR";
		break;
	case EVENT_ERR_HSLS_LWHEEL_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_HSLS_LWHEEL_SERVO_ERROR";
		break;
	case EVENT_ERR_HSLS_RWHEEL_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_HSLS_RWHEEL_SERVO_ERROR";
		break;
	case EVENT_ERR_HSLS_PLATE_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_HSLS_PLATE_SERVO_ERROR";
		break;
	case EVENT_ERR_HSLS_LIFT_SERVO_ERROR:
		pEventDesc = "EVENT_ERR_HSLS_LIFT_SERVO_ERROR";
		break;
	case EVENT_ERR_TURNING: //add by tiger.69
		pEventDesc = "EVENT_ERR_TURNING";
		break;
	case EVENT_ERR_MC_RESET: //add by tiger.69
		pEventDesc = "EVENT_ERR_MC_RESET";
		break;
	default:
		pEventDesc = "UNKNOWN_EVNET_ERROR";
		break;
	}

	return pEventDesc;
}

/*******************************************************************************
* Function Name		 : get_tc_evnet_desc
* Description	     : get event description for tc
* input			     : iEventType: event type
* Output		     : NONE
* Return		     : the pointer of event description
*******************************************************************************/
char * get_tc_evnet_desc(int iEventType)
{
	char *pEventDesc = NULL;

	switch (iEventType) {
	case EVENT_ERR_TC_SERVO_ERR:
		pEventDesc = "EVENT_ERR_TC_SERVO_ERR";
		break;
	case EVENT_ERR_TC_CAN_COM_BREAK:
		pEventDesc = "EVENT_ERR_TC_CAN_COM_BREAK";
		break;
	case EVENT_ERR_TC_LIFT_TACK_1MIN:
		pEventDesc = "EVENT_ERR_TC_LIFT_TACK_1MIN";
		break;
	case EVENT_ERR_TC_CYCLE_ENCODEER_ERR:
		pEventDesc = "EVENT_ERR_TC_CYCLE_ENCODEER_ERR";
		break;
	case EVENT_ERR_TC_ESTOP_PRESSED:
		pEventDesc = "EVENT_ERR_TC_ESTOP_PRESSED";
		break;
	case EVENT_ERR_TC_CONTROL_STOP:
		pEventDesc = "EVENT_ERR_TC_CONTROL_STOP";
		break;
	case EVENT_ERR_TC_RESUMABLE_STOP:
		pEventDesc = "EVENT_ERR_TC_RESUMABLE_STOP";
		break;
	case EVENT_ERR_TC_WHEEL_PLATE_ANGLE_OV:
		pEventDesc = "EVENT_ERR_TC_WHEEL_PLATE_ANGLE_OV";
		break;
	case EVENT_ERR_TC_CYCLE_MOTOR_NO_ACTION:
		pEventDesc = "EVENT_ERR_TC_CYCLE_MOTOR_NO_ACTION";
		break;
	case EVENT_ERR_TC_TIMEOUT:
		pEventDesc = "EVENT_ERR_TC_TIMEOUT";
		break;
	default:
		pEventDesc = "UNKNOWN_EVNET_ERROR";
		break;
	}

	return pEventDesc;
}

/*******************************************************************************
* Function Name		 : get_mm_evnet_desc
* Description	     : get event description for main manager
* input			     : iEventType: event type
* Output		     : NONE
* Return		     : the pointer of event description
*******************************************************************************/
char * get_mm_evnet_desc(int iEventType)
{
	char *pEventDesc = NULL;

	switch (iEventType) {
	case EVENT_ERR_DAOVERFLOW:
		pEventDesc = "EVENT_ERR_DAOVERFLOW";
		break;
	case EVENT_ERR_TPIDERROR:
		pEventDesc = "EVENT_ERR_TPIDERROR";
		break;
	case EVENT_ERR_MCREFUSE:
		pEventDesc = "EVENT_ERR_MCREFUSE";
		break;
	case EVENT_ERR_DESTSTOPINVALID:
		pEventDesc = "EVENT_ERR_DESTSTOPINVALID";
		break;
	case EVENT_ERR_PROCESTOPINVALID:
		pEventDesc = "EVENT_ERR_PROCESTOPINVALID";
		break;
	case EVENT_ERR_DSPTPSTATUS:
		pEventDesc = "EVENT_ERR_DSPTPSTATUS";
		break;
	case EVENT_ERR_CURRENTPRESEQSAME:
		pEventDesc = "EVENT_ERR_CURRENTPRESEQSAME";
		break;
	case EVENT_ERR_VEHSTOPEXCEPTION:
		pEventDesc = "EVENT_ERR_VEHSTOPEXCEPTION";
		break;
	case EVENT_ERR_PARKPRECISION:
		pEventDesc = "EVENT_ERR_PARKPRECISION";
		break;
	case EVENT_ERR_SCANTPIDERROR:
		pEventDesc = "EVENT_ERR_SCANTPIDERROR";
		break;
	case EVENT_ERR_CHARGECURSAMLL:
		pEventDesc = "EVENT_ERR_CHARGECURSAMLL";
		break;
	case EVENT_ERR_PLATEOFFSETBIG:
		pEventDesc = "EVENT_ERR_PLATEOFFSETBIG";
		break;
	case EVENT_ERR_CYCLEFINSCANERR:
		pEventDesc = "EVENT_ERR_CYCLEFINSCANERR";
		break;
	case EVENT_ERR_JACKOFFSETBIG:
		pEventDesc = "EVENT_ERR_JACKOFFSETBIG";
		break;
	case EVENT_ERR_MCERR:
		pEventDesc = "EVENT_ERR_MCERR";
		break;
	case EVENT_ERR_TCERR:
		pEventDesc = "EVENT_ERR_TCERR";
		break;
	case EVENT_ERR_TPERR:
		pEventDesc = "EVENT_ERR_TPERR";
		break;
	case EVENT_ERR_POINTIDERR:
		pEventDesc = "EVENT_ERR_POINTIDERR";
		break;
	case EVENT_ERR_GROUNDDIRECTERR:
		pEventDesc = "EVENT_ERR_GROUNDDIRECTERR";
		break;
	case EVENT_ERR_STOPCHARGE:
		pEventDesc = "EVENT_ERR_STOPCHARGE";
		break;
	case EVENT_ERR_SLIDING:
		pEventDesc = "EVENT_ERR_SLIDING";
		break;
	case EVENT_ERR_TILT_HEADER:
		pEventDesc = "EVENT_ERR_TILT_HEADER";
		break;
	case EVENT_ERR_BIG_ANGEL:
		pEventDesc = "EVENT_ERR_BIG_ANGEL";
		break;
	case EVENT_ERR_WRONG_HEADER_DIRCETION:
		pEventDesc = "EVENT_ERR_WRONG_HEADER_DIRCETION";
		break;
	case EVENT_ERR_WRONG_LOCATION:
		pEventDesc = "EVENT_ERR_WRONG_LOCATION";
		break;
	case EVENT_ERR_GET_TPID:
		pEventDesc = "EVENT_ERR_GET_TPID";
		break;
	case EVENT_ERR_CARMEROPENFAIL:
		pEventDesc = "EVENT_ERR_CARMEROPENFAIL";
		break;
	case EVENT_ERR_CARMERINITFAIL:
		pEventDesc = "EVENT_ERR_CARMERINITFAIL";
		break;
	case EVENT_ERR_CARMERCAPTUREFAIL:
		pEventDesc = "EVENT_ERR_CARMERCAPTUREFAIL";
		break;
	case EVENT_ERR_CARMERREADFAILE:
		pEventDesc = "EVENT_ERR_CARMERREADFAILE";
		break;
	case EVENT_ERR_DROPPED_SHELF://add by tiger.82
		pEventDesc = "EVENT_ERR_DROPPED_SHELF";
		break;
	//add by 20180925-begin
	case EVENT_ERR_BAT_DISCHARGEOVERTEMP:
		pEventDesc = "EVENT_ERR_BAT_DISCHARGEOVERTEMP";
		break;
	case EVENT_ERR_BAT_CHARGEOVERTEMP:
		pEventDesc = "EVENT_ERR_BAT_CHARGEOVERTEMP";
		break;
	case EVENT_ERR_BAT_VOLDISBALANCE:
		pEventDesc = "EVENT_ERR_BAT_VOLDISBALANCE";
		break;
	case EVENT_ERR_BAT_DISCHARGEOVERVOL:
		pEventDesc = "EVENT_ERR_BAT_DISCHARGEOVERVOL";
		break;
	case EVENT_ERR_BAT_CHARGEOVERVOL:
		pEventDesc = "EVENT_ERR_BAT_CHARGEOVERVOL";
		break;
	case EVENT_ERR_BAT_DISCHARGEOVERCUR:
		pEventDesc = "EVENT_ERR_BAT_DISCHARGEOVERCUR";
		break;
	case EVENT_ERR_BAT_CHARGEERR:
		pEventDesc = "EVENT_ERR_BAT_CHARGEERR";
		break;
	case EVENT_ERR_BAT_CHECK_FAILED:
		pEventDesc = "EVENT_ERR_BAT_CHECK_FAILED";
		break;
	case EVENT_ERR_BAT_NEED_OFFLINE:
		pEventDesc = "EVENT_ERR_BAT_NEED_OFFLINE";
		break;
	case EVENT_ERR_BMS_SOC_DISTORTION:
		pEventDesc = "EVENT_ERR_BMS_SOC_DISTORTION";
		break;
	//add by jxu 20180925-end
	default:
		pEventDesc = "UNKNOWN_EVNET_ERROR";
		break;
	}

	return pEventDesc;
}

/*******************************************************************************
* Function Name		 : get_other_evnet_desc
* Description	     : get event description for other
* input			     : iEventType: event type
* Output		     : NONE
* Return		     : the pointer of event description
*******************************************************************************/
char * get_other_evnet_desc(int iEventType)
{
	char *pEventDesc = NULL;

	switch (iEventType) {
	case EVENT_ERR_UPSERVOINVALID:
		pEventDesc = "EVENT_ERR_UPSERVOINVALID";
		break;
	case EVENT_ERR_CYCLESERVOINVALID:
		pEventDesc = "EVENT_ERR_CYCLESERVOINVALID";
		break;
	case EVENT_ERR_BATCOMMUNISTOP:
		pEventDesc = "EVENT_ERR_BATCOMMUNISTOP";
		break;
	case EVENT_ERR_UARTCOMMUNISTOP:
		pEventDesc = "EVENT_ERR_UARTCOMMUNISTOP";
		break;
	case EVENT_ERR_MCCOMMUNISTOP:
		pEventDesc = "EVENT_ERR_MCCOMMUNISTOP";
		break;
	case EVENT_ERR_TCCOMMUNISTOP:
		pEventDesc = "EVENT_ERR_TCCOMMUNISTOP";
		break;
	default:
		pEventDesc = "UNKNOWN_EVNET_ERROR";
		break;
	}

	return pEventDesc;
}

/*******************************************************************************
* Function Name		 : get_move_status
* Description	     : get move status of agv
* input			     : iEventType: event type
* Output		     : NONE
* Return		     : the pointer of event description
*******************************************************************************/
char * get_move_status(int iMoveStatus)
{
	char *pMoveStatus = NULL;

	switch (iMoveStatus) {
	case VEH_MOVE_STATUS_OFFLINE:
		pMoveStatus = "OFFLINE";
		break;
	case VEH_MOVE_STATUS_STOP:
		pMoveStatus = "STOP";
		break;
	case VEH_MOVE_STATUS_WALK:
		pMoveStatus = "WALK";
		break;
	case VEH_MOVE_STATUS_SYNLEFT:
		pMoveStatus = "SYNLEFT";
		break;
	case VEH_MOVE_STATUS_SYNRIGHT:
		pMoveStatus = "SYNRIGHT";
		break;
	case VEH_MOVE_STATUS_TCUP:
		pMoveStatus = "TCUP";
		break;
	case VEH_MOVE_STATUS_TCDOWN:
		pMoveStatus = "TCDOWN";
		break;
	case VEH_MOVE_STATUS_CHARGE:
		pMoveStatus = "CHARGE";
		break;
	case VEH_MOVE_STATUS_BACKWARD:
		pMoveStatus = "BACKWARD";
		break;
	case VEH_MOVE_STATUS_ONLINE:
		pMoveStatus = "ONLINE";
		break;
	case VEH_MOVE_STATUS_DPLEFT:
		pMoveStatus = "DPLEFT";
		break;
	case VEH_MOVE_STATUS_DPRIGHT:
		pMoveStatus = "DPRIGHT";
		break;
	case VEH_MOVE_STATUS_TPLEFT:
		pMoveStatus = "TPLEFT";
		break;
	case VEH_MOVE_STATUS_TPRIGHT:
		pMoveStatus = "TPRIGHT";
		break;
	default:
		pMoveStatus = "UNKNOWN";
		break;
	}

	return pMoveStatus;
}

/*******************************************************************************
* Function Name		 : get_direct_desc
* Description	     : get direction description of agv
* input			     : iDirection: head direction'value
* Output		     : NONE
* Return		     : the pointer of event description
*******************************************************************************/
char * get_direct_desc(int iDirection)
{
	char *pDirection = NULL;

	switch (iDirection) {
	case DIRECTION_X_P:
		pDirection = "X+";
		break;
	case DIRECTION_Y_P:
		pDirection = "Y+";
		break;
	case DIRECTION_X_N:
		pDirection = "X-";
		break;
	case DIRECTION_Y_N:
		pDirection = "Y-";
		break;
	default:
		pDirection = "UNKNOWN_DIRECTION";
		break;
	}

	return pDirection;
}

/*******************************************************************************
* Function Name		 : get_pallet_status_desc
* Description	     : get pallet status desc of agv
* input			     : iDirection: head direction'value
* Output		     : NONE
* Return		     : the pointer of event description
*******************************************************************************/
char * get_pallet_status_desc(int iPalletStatus)
{
	char *pPalletStatus = NULL;

	switch (iPalletStatus) {
	case PALLET_STATUS_NULL:
		pPalletStatus = "between top and bottom";
		break;
	case PALLET_STATUS_TOP:
		pPalletStatus = "on top limit";
		break;
	case PALLET_STATUS_BOT:
		pPalletStatus = "on bottom limit";
		break;
	default:
		pPalletStatus = "unknown pallet status";
		break;
	}

	return pPalletStatus;
}

/*******************************************************************************
* Function Name		 : get_err_str
* Description	     : get error string by errorno.
* input			     : iErrNo: error no,such as 1003,3001,4002
* Output		     : NONE
* Return		     : the pointer of error string
*******************************************************************************/
char * get_err_str(int iErrNo)
{
	char * pError = NULL;
	iErrNo = abs(iErrNo);

	if ((iErrNo >= TC_ERROR_BASE) && (iErrNo < (TC_ERROR_BASE + 999)))
		pError = get_tc_evnet_desc(iErrNo);
	else if ((iErrNo >= MC_ERROR_BASE) && (iErrNo < (MC_ERROR_BASE + 999)))
		pError = get_mc_evnet_desc(iErrNo);
	else if ((iErrNo >= MM_ERROR_BASE) && (iErrNo < (MM_ERROR_BASE + 999)))
		pError = get_mm_evnet_desc(iErrNo);
	else
		pError = get_other_evnet_desc(iErrNo);

	return pError;
}

/*******************************************************************************
* Function Name		 : get_mc_cmd_name
* Description	     : get mc operate style
* input			     : iMcCmd: mc operate style
* Output		     : NONE
* Return		     : the pointer of event description
*******************************************************************************/
char * get_mc_cmd_name(int iMcCmd)
{
	char *pMcCmdName = "UNKNOWN_MC_OPERATE_STYLE";

	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		switch (iMcCmd) {
		case MC_GO_FORWARD:
			pMcCmdName = "MC_GO_FORWARD";
			break;
		case MC_GO_BACKWARD:
			pMcCmdName = "MC_GO_BACKWARD";
			break;
		case MC_TURN_LEFT:
			pMcCmdName = "MC_TURN_LEFT";
			break;
		case MC_TURN_RIGHT:
			pMcCmdName = "MC_TURN_RIGHT";
			break;
		case MC_STOP:
			pMcCmdName = "MC_STOP";
			break;
		case MC_BEGIN_CHARGE:
			pMcCmdName = "MC_BEGIN_CHARGE";
			break;
		case MC_STOP_CHARGE:
			pMcCmdName = "MC_STOP_CHARGE";
			break;
		case MC_RESET:
			pMcCmdName = "MC_RESET";
			break;
		case MC_ENABLE_WDG:
			pMcCmdName = "MC_ENABLE_WDG";
			break;
		case MC_SLOW_GO_BACK:
			pMcCmdName = "MC_SLOW_GO_BACK";
			break;
		case MC_SLOW_GO_STRAIGHT:
			pMcCmdName = "MC_SLOW_GO_STRAIGHT";
			break;
		case MC_LEFT_ARC:
			pMcCmdName = "MC_LEFT_ARC";
			break;
		case MC_RIGHT_ARC:
			pMcCmdName = "MC_RIGHT_ARC";
			break;
		default:
			pMcCmdName = "UNKNOWN_MC_OPERATE_STYLE";
			break;
		}
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		switch (iMcCmd) {
		case MC_CAN_CMD_GOFORWARD_V2:
			pMcCmdName = "MC_CAN_CMD_GOFORWARD_V2";
			break;
		case MC_CAN_CMD_GOBACKWARD_V2:
			pMcCmdName = "MC_CAN_CMD_GOBACKWARD_V2";
			break;
		case MC_CAN_CMD_TURNLEFT_V2:
			pMcCmdName = "MC_CAN_CMD_TURNLEFT_V2";
			break;
		case MC_CAN_CMD_TURNRIGHT_V2:
			pMcCmdName = "MC_CAN_CMD_TURNRIGHT_V2";
			break;
		case MC_CMD_LEFT_ARC_V2:
			pMcCmdName = "MC_CMD_LEFT_ARC_V2";
			break;
		case MC_CMD_RIGHT_ARC_V2:
			pMcCmdName = "MC_CMD_RIGHT_ARC_V2";
			break;
		case MC_CMD_BACK_TO_CHARGE_V2:
			pMcCmdName = "MC_CMD_BACK_TO_CHARGE_V2";
			break;
		case MC_CMD_FORWARD_LEAVE_CHARGE_V2:
			pMcCmdName = "MC_CMD_FORWARD_LEAVE_CHARGE_V2";
			break;
		case MC_CMD_FORWARD_TO_CHARGE_V2:
			pMcCmdName = "MC_CMD_FORWARD_TO_CHARGE_V2";
			break;
		case MC_CMD_BACK_LEAVE_CHARGE_V2:
			pMcCmdName = "MC_CMD_BACK_LEAVE_CHARGE_V2";
			break;
		case TC_CAN_CMD_CYCLELEFT_V2:
			pMcCmdName = "TC_CAN_CMD_CYCLELEFT_V2";
			break;
		case TC_CAN_CMD_CYCLERIGHT_V2:
			pMcCmdName = "TC_CAN_CMD_CYCLERIGHT_V2";
			break;
		case TC_CAN_CMD_JACK_V2:
			pMcCmdName = "TC_CAN_CMD_JACK_V2";
			break;
		case TC_CAN_CMD_PUT_V2:
			pMcCmdName = "TC_CAN_CMD_PUT_V2";
			break;
		case MC_CAN_CMD_STOP_V2:
			pMcCmdName = "MC_CAN_CMD_STOP_V2";
			break;
		case MC_CAN_CMD_PARK_V2:
			pMcCmdName = "MC_CAN_CMD_PARK_V2";
			break;
		case MC_CAN_CMD_STOPPARK_V2:
			pMcCmdName = "MC_CAN_CMD_STOPPARK_V2";
			break;
		case MC_CAN_CMD_RESTART_V2:
			pMcCmdName = "MC_CAN_CMD_RESTART_V2";
			break;
		default:
			pMcCmdName = "UNKNOWN_MC_OPERATE_STYLE";
			break;
		}
	}

	return pMcCmdName;
}

/*******************************************************************************
* Function Name		 : get_tc_cmd_name
* Description	     : get tc operate style
* input			     : iMcCmd: tc operate style
* Output		     : NONE
* Return		     : the pointer of event description
*******************************************************************************/
char * get_tc_cmd_name(int iTcCmd)
{
	char *pTcCmdName = "UNKNOWN_TC_OPERATE_STYLE";

	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		switch (iTcCmd) {
		case TC_LIFT_LOCK:
			pTcCmdName = "TC_LIFT_LOCK";
			break;
		case TC_RISE:
			pTcCmdName = "TC_RISE";
			break;
		case TC_LAY:
			pTcCmdName = "TC_LAY";
			break;
		case TC_PALLET_LOCK:
			pTcCmdName = "TC_PALLET_LOCK";
			break;
		case TC_PALLET_LEFT:
			pTcCmdName = "TC_PALLET_LEFT";
			break;
		case TC_PALLET_RIGHT:
			pTcCmdName = "TC_PALLET_RIGHT";
			break;
		case TC_ENABLE_WDG:
			pTcCmdName = "TC_ENABLE_WDG";
			break;
		case TC_STOP:
			pTcCmdName = "TC_STOP";
			break;
		default:
			pTcCmdName = "UNKNOWN_TC_OPERATE_STYLE";
			break;
		}
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		switch (iTcCmd) {
		case MC_CAN_CMD_GOFORWARD_V2:
			pTcCmdName = "MC_CAN_CMD_GOFORWARD_V2";
			break;
		case MC_CAN_CMD_GOBACKWARD_V2:
			pTcCmdName = "MC_CAN_CMD_GOBACKWARD_V2";
			break;
		case MC_CAN_CMD_TURNLEFT_V2:
			pTcCmdName = "MC_CAN_CMD_TURNLEFT_V2";
			break;
		case MC_CAN_CMD_TURNRIGHT_V2:
			pTcCmdName = "MC_CAN_CMD_TURNRIGHT_V2";
			break;
		case MC_CMD_LEFT_ARC_V2:
			pTcCmdName = "MC_CMD_LEFT_ARC_V2";
			break;
		case MC_CMD_RIGHT_ARC_V2:
			pTcCmdName = "MC_CMD_RIGHT_ARC_V2";
			break;
		case MC_CMD_BACK_TO_CHARGE_V2:
			pTcCmdName = "MC_CMD_BACK_TO_CHARGE_V2";
			break;
		case MC_CMD_FORWARD_LEAVE_CHARGE_V2:
			pTcCmdName = "MC_CMD_FORWARD_LEAVE_CHARGE_V2";
			break;
		case MC_CMD_FORWARD_TO_CHARGE_V2:
			pTcCmdName = "MC_CMD_FORWARD_TO_CHARGE_V2";
			break;
		case MC_CMD_BACK_LEAVE_CHARGE_V2:
			pTcCmdName = "MC_CMD_BACK_LEAVE_CHARGE_V2";
			break;
		case TC_CAN_CMD_CYCLELEFT_V2:
			pTcCmdName = "TC_CAN_CMD_CYCLELEFT_V2";
			break;
		case TC_CAN_CMD_CYCLERIGHT_V2:
			pTcCmdName = "TC_CAN_CMD_CYCLERIGHT_V2";
			break;
		case TC_CAN_CMD_JACK_V2:
			pTcCmdName = "TC_CAN_CMD_JACK_V2";
			break;
		case TC_CAN_CMD_PUT_V2:
			pTcCmdName = "TC_CAN_CMD_PUT_V2";
			break;
		case MC_CAN_CMD_STOP_V2:
			pTcCmdName = "MC_CAN_CMD_STOP_V2";
			break;
		case MC_CAN_CMD_PARK_V2:
			pTcCmdName = "MC_CAN_CMD_PARK_V2";
			break;
		case MC_CAN_CMD_STOPPARK_V2:
			pTcCmdName = "MC_CAN_CMD_STOPPARK_V2";
			break;
		case MC_CAN_CMD_RESTART_V2:
			pTcCmdName = "MC_CAN_CMD_RESTART_V2";
			break;
		default:
			pTcCmdName = "UNKNOWN_MC_OPERATE_STYLE";
			break;
		}
	}

	return pTcCmdName;
}

/*******************************************************************************
* Function Name		 : print_can_frame
* Description	     : print the data of can frame to the log
* input			     : pCanFrame : point to the can frame
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
void print_can_frame(struct can_frame * pCanFrame)
{
	if (pCanFrame == NULL) {
		return;
	}

	LOG_INF("-----------------------\n");
	LOG_INF("can_id    = 0x%x[%s]\n", pCanFrame->can_id, get_can_desc(pCanFrame->can_id));
	LOG_INF("can_dlc   = 0x%x\n", pCanFrame->can_dlc);
	if (pCanFrame->can_dlc != 0)//add by jxu 20180910 for bms update
	LOG_INF("data[7-0] = 0x%02x %02x %02x %02x %02x %02x %02x %02x\n",
		pCanFrame->data[7], pCanFrame->data[6], pCanFrame->data[5], pCanFrame->data[4],
		pCanFrame->data[3], pCanFrame->data[2], pCanFrame->data[1], pCanFrame->data[0]);
	LOG_INF("-----------------------\n");
}

/*******************************************************************************
* Function Name		 : enable_wdg
* Description	     : enable watchdog for MC or TC
* input			     : iDevType : =0 TC, =1 MC;
* input			     : u8FlagVar : series number of flag var
* Output		     : NONE
* Return		     : 0 if OK, -1 on error
*******************************************************************************/
int enable_wdg(int iDevType)
{
	int iRet = -1;

	if (iDevType == DEV_MC)
	{
		iRet = g_stMcDev.enable_wdg();
	}
	
	if (iDevType == DEV_TC)
	{
		iRet = g_stTcDev.enable_wdg();
	}	
	return iRet;
}

/*******************************************************************************
* Function Name		 : get_flag
* Description	     : get flag of MC or TC
* input			     : iDevType : =0 TC, =1 MC;
* input			     : u8FlagVar : series number of flag var
* Output		     : NONE
* Return		     : 0 if OK, -1 on error
*******************************************************************************/
int get_flag(int iDevType, u8 u8FlagVar)
{
	int iRet = -1;

	if (iDevType == DEV_MC)
	{
		iRet = g_stMcDev.get_flag(u8FlagVar);
	}
	
	if (iDevType == DEV_TC)
	{
		iRet = g_stTcDev.get_flag(u8FlagVar);
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : set_flag
* Description	     : set flag of MC or TC
* input			     : iDevType : =0 TC, =1 MC;
* input			     : u8FlagVar : series number of flag var
* Output		     : NONE
* Return		     : 0 if OK, -1 on error
*******************************************************************************/
int set_flag(int iDevType, u8 u8FlagVar, u32 u32Value)
{
	int iRet = -1;

	if (iDevType == DEV_MC)
	{
		iRet = g_stMcDev.set_flag(u8FlagVar, u32Value);
	}

	if (iDevType == DEV_TC)
	{
		iRet = g_stTcDev.set_flag(u8FlagVar, u32Value);;
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : set_param
* Description	     : set param of MC or TC
* input			     : iDevType : =0 TC, =1 MC;
* input			     : u8ParamVar : series number of param var
* input			     : fValue : the value of param var
* Output		     : NONE
* Return		     : 0 if OK, -1 on error
*******************************************************************************/
int set_param(int iDevType, u8 u8ParamVar, float fValue)
{
	int iRet = -1;

	if (iDevType == DEV_MC)
	{
		iRet = g_stMcDev.set_param(u8ParamVar, fValue);
	}

	if (iDevType == DEV_TC)
	{
		iRet = g_stTcDev.set_param(u8ParamVar, fValue);
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : get_param
* Description	     : get param from MC or TC
* input			     : iDevType : =0 TC, =1 MC;
* input			     : u8ParamVar : series number of param var
* input			     : fValue : the value of param var
* Output		     : NONE
* Return		     : 0 if OK, -1 on error
*******************************************************************************/
int get_param(int iDevType, u8 u8ParamVar)
{
	int iRet = -1;

	if (iDevType == DEV_MC)
	{
		iRet = g_stMcDev.get_param(u8ParamVar);
	}

	if (iDevType == DEV_TC)
	{
		iRet = g_stTcDev.get_param(u8ParamVar);
	}

	return iRet;
}

#define GET_SEM 0
/*******************************************************************************
* Function Name		 : go_forward
* Description	     : set go forward command to mc
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Distance : distance(unit:0.1 degree)
* input			     : u16Speed : speed(unit:millimeter/second)
* Output		     : NONE
* Return		     : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
						timeout,else negative of error code value
*******************************************************************************/
int go_forward(u8 u8Weight, u16 u16Distance, u16 u16Speed, bool *bNeedSendFinish)
{
	int iRet = 0;

	int iTimeCount = 0;
	int iRemaindTimeCount = 0;
	u8 u8Action = 0;
	int iPathQueuePointID = 0; //by tiger.91
	int iException = 0;//by tiger.67
	g_stAgvAttr.iMoveStatus = agv_walk;
	//add by jxu 20180121 begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		u8Action = MC_GO_FORWARD;		
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		u8Action = MC_CAN_CMD_GOFORWARD_V2;
	}
	iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_WALK, TC_LOG_TYPE_INVALID);
	//add by jxu 20180121 end
	if (iRet < 0)
		return iRet;

	g_stAgvTask.iWalkTimeout = TIME_OUT_10M + (u16Distance / 1000) * TIME_OUT_60S;
	g_stAgvTask.iWalkContinue = FALSE;
	int iExpectedHead = g_stAgvAttr.iVehHeadDirect;
	iRet = g_stMcDev.go_forward(u8Weight, u16Distance, u16Speed);
	if (iRet < 0 )
		return -1;

	while ((iTimeCount < g_stAgvTask.iWalkTimeout) && (g_stAgvTask.iWalkContinue == FALSE))
	{
		iRet = _sem_wait(&g_stAgvTask.stAction.stActSem, TIME_OUT_100MS);
		if (iRet < 0)
		{
			iException = atomic_read(&g_stAgvAttr.iException);//by tiger.67
			if ((EVENT_ERR_AGVSAFE == iException)//by tiger.67
				|| (EVENT_ERR_NOCONTACTIMPACT == iException)
				|| (EVENT_ERR_EMERSTOPPRESS == iException))
				iTimeCount = 0;
			else
				iTimeCount += TIME_OUT_100MS;

			continue;
		}

		// modified by tiger, 20180206
		// when in debug mode, g_stAgvTask.iDstPoint == 0
		// so no need to check (g_stAgvTask.iDstPoint == g_stAgvAttr.iLocation), in debug mode
		// send finish to agent during continue walk
		if ((true == g_stAgvConf.cDebugEnable) || (g_stAgvTask.iDstPoint == g_stAgvAttr.iLocation)) //send finish to agent during continue walk
		{
			break;
		}
		else if (g_stAgvAttr.iFinishPointId == g_stAgvTask.iDstPoint) //by tiger.91,get mc finish ,then check
		{
			while ((linkqueue_length(g_stAgvParm.pPathQueue)>0 )&& (g_stAgvAttr.iFinishPointId != g_stAgvAttr.iLocation))
			{
				if (linkqueue_retrieve(g_stAgvParm.pPathQueue, &(g_stAgvAttr.iLocation)) > 0)
				{
					LOG_INF("pop the point[%d] of path queue\n", g_stAgvAttr.iLocation);
					send_point_msg(g_stAgvAttr.iLocation, DRIVER_MODE_AUTO);	//report the point
				}
			}
			break;
		}
		else if (g_stAgvTask.iDstPoint != g_stAgvAttr.iLocation &&true == g_stAgvTask.bSliding ) //add by tiger.28
		{
			return -EVENT_ERR_SLIDING;
		}
		//add by jxu 20180514-begin,to return the exception immediately add by jxu 0524
		if ((iRet == FALSE) && (0 != atomic_read(&g_stAgvAttr.iAckException)))
		{
			LOG_INF("pAgvTask->stAction.iResult=%d g_stAgvAttr.iAckException=%d\n", g_stAgvTask.stAction.iResult, atomic_read(&g_stAgvAttr.iAckException));
			atomic_set(&g_stAgvAttr.iAckException, 0);//add by jxu 20180524
			break;
		}
		//add by jxu 20180514-end
	}

	if (g_stAgvTask.iWalkContinue == TRUE) {
		iRemaindTimeCount = g_stAgvTask.iWalkTimeout - iTimeCount;
		g_stAgvTask.iWalkTimeout = iRemaindTimeCount + TIME_OUT_30S;

		LOG_INF("recv walk continue task, update WalkTimeOut[%d->%d]ms\n",
			iRemaindTimeCount, g_stAgvTask.iWalkTimeout);

		// add by kedong, 20180213
		// when recv walk continue, we no need send this walk'finish msg to console
		if (bNeedSendFinish != NULL)
			*bNeedSendFinish = FALSE;
	}

	if (iTimeCount >= g_stAgvTask.iWalkTimeout)
	{
		LOG_INF("pAgvTask->stAction.iResult=%d\n", g_stAgvTask.stAction.iResult);//add by jxu 20180503
		return -EVENT_ERR_MC_TIMEOUT;
	}
		

	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);
	//add by jxu 201804011:begin
	if ((iRet == REFUSE) && (g_stAgvTask.iWalkContinue == TRUE))
	{
		LOG_WRN("Lost of the ACK when the walk is continue\n");
		iRet = OK;
	}
	//add by jxu 201804011:end
	//add by jxu 20180313:begin
	if (g_stAgvAttr.iVehHeadDirect != iExpectedHead)
	{
		pgvjitter_printf("ExpVHead[%d] != CurVHead[%d], CurGAngle[%4d],WARN!!!\n", iExpectedHead, g_stAgvAttr.iVehHeadDirect, g_stAgvAttr.iGAngleOffset);
	}
	else
	{
		pgvjitter_printf("ExpVHead[%d]  = CurVHead[%d], CurGAngle[%4d]\n", iExpectedHead, g_stAgvAttr.iVehHeadDirect, g_stAgvAttr.iGAngleOffset);
	}
	//add by jxu 20180313:end
	return iRet;
}
/*******************************************************************************
* Function Name		 : get_expected_head
* Description	     : get expected head direction
* input			     : iCurHead : 
* input			     : u16Angle :
* input			     : iTurnDirect : (0 turn left,1 turn right)
* Output		     : NONE
* Return		     : Get expected head direction
timeout,else negative of error code value
*******************************************************************************/
extern int get_expected_head(u8 iCurHead, u16 u16Angle,u8 iTurnDirect)
{
	int iRet = -1;
	if (iCurHead == INVALID_DIRECTION)
	{
		LOG_INF("Invalid head direction\n");
		return iRet;
	}
	if (iTurnDirect == FALSE)
	{
		int iTurnleftNum = u16Angle / 900;
		int iExpectedHead = (iCurHead + iTurnleftNum) % 4;
		iRet = iExpectedHead;
	}
	else if (iTurnDirect == TRUE)
	{
		int iTurnRightNum = u16Angle / 900;
		int iTurnleftNum = 4 - iTurnRightNum;
		int iExpectedHead = (iCurHead + iTurnleftNum) % 4;
		iRet = iExpectedHead;
	}
	return iRet;
}

/*******************************************************************************
* Function Name		 : turn_left
* Description	     : set turn left command to mc
* input			     : u8Sync : 1 if u8Sync,0 on async  
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Distance : distance(unit:0.1 degree)
* input			     : u16Speed : speed(unit:millimeter/second)
* Output		     : NONE
* Return		     : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame 
						timeout,else negative of error code value
*******************************************************************************/
static int g_iSyncTurnFailed = 0;//add by jxu 20181008
#define  MAX_SCAN_TIMES 3
int turn_left(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	int iSync = u8Sync;
	int iRet = 0;
	u8 u8Action = 0;
	int iResult = 0;//add by tiger.82
	int iScanQRFlag = FALSE;//add by jxu 20180820

	g_stAgvAttr.iMoveStatus = (iSync == 1 ? agv_sync_left : agv_wheel_left);
	if (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus)
	{
		iSync = 1;

		// add by kedong, 20180302
		// before send_pallet_angle_offset, 
		// update and get current pallet info for comparing with last
		//add by jxu 20180820 -begin
		int iFlag = update_global_pallet_angle_offset();
		if (iFlag < 0)
			iScanQRFlag = TRUE;
		// add by jxu 20180820 - end
		
		// modified by kedong, 20180205
		// g_stAgvAttr.iTAngleOffset is used for recording 
		// last rise/turn_left/turn_right'pallet angle offset,
		// when execute next turn_left/turn_right, send pallet angle offset to mc
		float fAngleOffset = (float)g_stAgvAttr.iTAngleOffset / 100;

		LOG_INF("send pallet angle offset[%0.2f] before sync turn right/left\n", fAngleOffset);
		if (g_stAgvAttr.iTAngleOffset != 0)
			send_pallet_angle_offset(g_stAgvAttr.iTAngleOffset);
	}
	else if(PALLET_STATUS_BOT == g_stAgvAttr.iPalletStatus)
	{
		iSync = 0;
	}

	enTcLogType eTcLogType = (iSync == 1) ? TC_LOG_TYPE_TURN : TC_LOG_TYPE_INVALID;

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		u8Action = MC_TURN_LEFT;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		u8Action = MC_CAN_CMD_TURNLEFT_V2;
	}
	iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_TURN, eTcLogType);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;
	int iExpectedHead = get_expected_head(g_stAgvAttr.iVehHeadDirect, u16Angle, FALSE);
	iRet = g_stMcDev.turn_left(iSync, u8Weight, u16Angle, u16Speed);
	if (iRet < 0)
	{
		LOG_INF("send MC turn left can frame error\n");
		return iRet;
	}

	iRet = _sem_wait_exclude_safe(&g_stAgvTask.stAction.stActSem, TIME_OUT_10M);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n", 
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_MC_TIMEOUT;
	}

	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);
	//add by jxu 20180313:begin
	if (g_stAgvAttr.iVehHeadDirect != iExpectedHead)
	{
		pgvjitter_printf("ExpVHead[%d] != CurVHead[%d], CurGAngle[%4d],WARN!!!\n", iExpectedHead, g_stAgvAttr.iVehHeadDirect, g_stAgvAttr.iGAngleOffset);
	}
	else
	{
		pgvjitter_printf("ExpVHead[%d]  = CurVHead[%d], CurGAngle[%4d]\n", iExpectedHead, g_stAgvAttr.iVehHeadDirect, g_stAgvAttr.iGAngleOffset);
	}
	//add by jxu 20180313:end

	//start,add by tiger.82
	//if action is OK,then check the shelf state
	if ((1 == iSync) && (OK == iRet))
	{
		LOG_INF("get the pallet info after sync turn right/left\n");
		iResult  = get_pallet_info(); //just get pallet info by tiger
		//add by jxu 20181008-begin report the 3050-when three sync turn are all failed.
		if ((iResult < 0) && (iScanQRFlag == TRUE)) //add by jxu 20180820-condition(ScanQRFlag == TRUE)
		{
			g_iSyncTurnFailed = g_iSyncTurnFailed + 1;
			LOG_ERR("ATTENTION:the shelf is dropped g_iSyncTurnFailed=%d\n", g_iSyncTurnFailed);
			if (g_iSyncTurnFailed == MAX_SCAN_TIMES)
			{
				g_iSyncTurnFailed = 0;
				return -EVENT_ERR_DROPPED_SHELF;
			}
		}
		else
		{
			g_iSyncTurnFailed = 0;
		}
		//add by jxu 20181008-end
	}
	//end by tiger.82

	return iRet;
}

/*******************************************************************************
* Function Name		 : turn_right
* Description	     : set turn right command to mc
* input			     : u8Sync : 1 if u8Sync,0 on async
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Distance : distance(unit:0.1 degree)
* input			     : u16Speed : speed(unit:millimeter/second)
* Output		     : NONE
* Return		     : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
                       timeout,else negative of error code value
*******************************************************************************/
int turn_right(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	int iSync = u8Sync;
	int iRet = 0;
	u8 u8Action = 0;
	int iResult = 0;//add by tiger.82
	int iScanQRFlag = FALSE;//add by jxu 20180820

	g_stAgvAttr.iMoveStatus = (iSync == 1 ? agv_sync_right : agv_wheel_right);
	if (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus)
	{
		iSync = 1;

		// add by kedong, 20180302
		// before send_pallet_angle_offset, 
		// update and get current pallet info for comparing with last
		//add by jxu 20180820 -begin
		int iFlag = update_global_pallet_angle_offset();
		if (iFlag < 0)
			iScanQRFlag = TRUE;
		// add by jxu 20180820 - end

		// modified by kedong, 20180205
		// g_stAgvAttr.iTAngleOffset is used for recording 
		// last rise/turn_left/turn_right'pallet angle offset,
		// when execute next turn_left/turn_right, send pallet angle offset to mc
		float fAngleOffset = (float)g_stAgvAttr.iTAngleOffset / 100;

		LOG_INF("send pallet angle offset[%0.2f] before sync turn right/left\n", fAngleOffset);
		if (g_stAgvAttr.iTAngleOffset != 0)
			send_pallet_angle_offset(g_stAgvAttr.iTAngleOffset);
	}
	else if(PALLET_STATUS_BOT == g_stAgvAttr.iPalletStatus)
	{
		iSync = 0;
	}	
	
	enTcLogType eTcLogType = (iSync == 1) ? TC_LOG_TYPE_TURN : TC_LOG_TYPE_INVALID;

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		u8Action = MC_TURN_RIGHT;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		u8Action = MC_CAN_CMD_TURNRIGHT_V2;
	}
	iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_TURN, eTcLogType);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;
	int iExpectedHead = get_expected_head(g_stAgvAttr.iVehHeadDirect, u16Angle, TRUE);
	iRet = g_stMcDev.turn_right(iSync, u8Weight, u16Angle, u16Speed);
	if (iRet < 0)
	{
		LOG_ERR("send MC turn right can frame error\n");
		return iRet;
	}

	iRet = _sem_wait_exclude_safe(&g_stAgvTask.stAction.stActSem, TIME_OUT_10M);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_MC_TIMEOUT;
	}

	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);
	//add by jxu 20180313:begin
	if (g_stAgvAttr.iVehHeadDirect != iExpectedHead)
	{
		pgvjitter_printf("ExpVHead[%d] != CurVHead[%d], CurGAngle[%4d],WARN!!!\n", iExpectedHead, g_stAgvAttr.iVehHeadDirect, g_stAgvAttr.iGAngleOffset);
	}
	else
	{
		pgvjitter_printf("ExpVHead[%d]  = CurVHead[%d], CurGAngle[%4d]\n", iExpectedHead, g_stAgvAttr.iVehHeadDirect, g_stAgvAttr.iGAngleOffset);
	}
	//add by jxu 20180313:end

	//start,add by tiger.82
	//if action is OK,then check the shelf state
	if ((1 == iSync) && (OK == iRet))
	{
		LOG_INF("get the pallet info after sync turn right/left\n");
		iResult = get_pallet_info(); //just get pallet info by tiger
		//add by jxu 20181008-begin report the 3050-when three sync turn are all failed.
		if ((iResult < 0) && (iScanQRFlag == TRUE))//add by jxu 20180820-condition(ScanQRFlag == TRUE)
		{
			g_iSyncTurnFailed = g_iSyncTurnFailed + 1;
			LOG_ERR("ATTENTION:the shelf is dropped g_iSyncTurnFailed=%d\n", g_iSyncTurnFailed);
			if (g_iSyncTurnFailed == MAX_SCAN_TIMES)
			{
				g_iSyncTurnFailed = 0;
				return -EVENT_ERR_DROPPED_SHELF;
			}
		}
		else
		{
			g_iSyncTurnFailed = 0;
		}
		//add by jxu 20181008-end
	}
	//end by tiger.82
	return iRet;
}

/*******************************************************************************
* Function Name		 : stop_agv
* Description	     : stop agv
* input			     : iDevType : =0 TC, =1 MC;
* input			     : u8FlagVar : series number of flag var
* Output		     : NONE
* Return		     : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
						timeout,else negative of error code value
*******************************************************************************/
int stop_agv(int iDevType)
{
	int iRet = -1;
	u8 u8Action = 0;

	if (iDevType == DEV_MC)
	{
		//add by jxu 20180121: begin
		if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
		{
			u8Action = MC_STOP;
		}
		else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
		{
			u8Action = MC_CAN_CMD_STOP_V2;
		}
		iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_INVALID, TC_LOG_TYPE_INVALID);
		//add by jxu 20180121: end

		if (iRet < 0)
			return iRet;

		iRet = g_stMcDev.stop();
		if (iRet < 0 )
		{
			LOG_ERR("send MC stop can frame failed\n");
			return iRet;
		}

		iRet = _sem_wait(&g_stAgvTask.stAction.stActSem, TIME_OUT_180S);
		if (iRet < 0)
		{
			LOG_WRN("wait [%d-%s] finish time out\n",
				g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
			return -EVENT_ERR_MC_TIMEOUT;
		}

		iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);
	}
	
	if (iDevType == DEV_TC)
	{
		//add by jxu 20180121: begin
		if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
		{
			u8Action = TC_STOP;
		}
		else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
		{
			u8Action = MC_CAN_CMD_STOP_V2;
		}
		iRet = agv_task_init(&g_stAgvTask, DEV_TC, u8Action, MC_LOG_TYPE_INVALID, TC_LOG_TYPE_INVALID);
		//add by jxu 20180121: end
		if (iRet < 0)
			return iRet;

		iRet = g_stTcDev.stop();
		if (iRet<0)
		{
			LOG_ERR("send TC stop can frame failed\n");
		}
		
		iRet = _sem_wait(&g_stAgvTask.stAction.stActSem, TIME_OUT_180S);
		if (iRet < 0)
		{
			LOG_WRN("wait [%d-%s] finish time out\n",
				g_stAgvTask.stAction.iType, get_tc_cmd_name(g_stAgvTask.stAction.iType));
			return -EVENT_ERR_MC_TIMEOUT;
		}

		iRet = agv_task_exit(&g_stAgvTask, DEV_TC, u8Action);
	}
	g_stAgvAttr.iMoveStatus = agv_stop;//by tiger.46
	return iRet;
}
/*******************************************************************************
* Function Name		 : start_charge
* Description	     : start charge power
* input			     : NONE
* Output		     : NONE
* Return		     : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
						timeout,else negative of error code value
*******************************************************************************/
int start_charge()
{
	int iRet = 0;
	u8 u8Action = 0;
	g_stAgvAttr.iStopChargeConflict = FALSE;//add by jxu 20180820

	// add by kedong 20180212
	// if already in charge mode, recv start charge cmd, return OK
	if (agv_charge == g_stAgvAttr.iMoveStatus)
	{
		LOG_INF("agv is already in charge mode, do nothing\n");
		return OK;
	}

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		u8Action = MC_BEGIN_CHARGE;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		u8Action = MC_CAN_CMD_PARK_V2;
	}
	iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_INVALID, TC_LOG_TYPE_INVALID);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;

	iRet = g_stMcDev.start_charge();
	if (iRet < 0)
	{
		LOG_ERR("send MC start charge can frame failed\n");
		return iRet;
	}
	
	iRet = _sem_wait(&g_stAgvTask.stAction.stActSem, TIME_OUT_180S);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_MC_TIMEOUT;
	}

	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);

	if (OK == iRet) //add by tiger.83
	{
		g_stAgvAttr.iMoveStatus = agv_charge;
	}

	return iRet;
}

#define CURRENT_2A 20  //by tiger.38
#define CURRENT_10A 100  //by tiger.38
extern int g_iNotReport3019;
/*******************************************************************************
* Function Name		 : stop_charge
* Description	     : stop charge power
* input			     : NONE
* Output		     : NONE
* Return		     : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
						timeout,else negative of error code value
*******************************************************************************/
int stop_charge()
{
	int iRet = 0;
	int iCurrentPre = 0;//by tiger.38
	int iCurrentCur = 0;//by tiger.38
	u8 u8Action = 0;

	//get battery current ,start by tiger.38
	iCurrentPre = g_stAgvAttr.bms.uCurrent;
	///not excute the cmd if the agv is not in charging,and send finish to agent,start by tiger.41
	pthread_mutex_lock(&g_stChargeStatusMutexLock);
	if (agv_charge == g_stAgvAttr.iMoveStatus)
	{
		g_stAgvAttr.iMoveStatus = agv_stop_charge;
	}		
	else
	{
		LOG_INF("Happen more stopping charge after the chage\n");//add by jxu 20180820-begin
		g_stAgvAttr.iStopChargeConflict = TRUE;//add by jxu 20180820-end
		pthread_mutex_unlock(&g_stChargeStatusMutexLock);
		return OK;
	}
	pthread_mutex_unlock(&g_stChargeStatusMutexLock);

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		u8Action = MC_STOP_CHARGE;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		u8Action = MC_CAN_CMD_STOPPARK_V2;
	}
	iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_INVALID, TC_LOG_TYPE_INVALID);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;

	iRet = g_stMcDev.stop_charge();
	if (iRet < 0)
	{
		LOG_ERR("send stop charge can frame failure\n");
		return -1;
	}

	///resend stop park cmd,start by tiger.18
	iRet = _sem_wait(&g_stAgvTask.stAction.stActSem, TIME_OUT_180S);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_MC_TIMEOUT;
	}


	g_stAgvAttr.iMoveStatus = agv_stop;
	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);
	while (0 != g_stAgvAttr.bms.uCalibrateTime) //battery is calibrating,by tiger.89
	{
		LOG_INF("wait for battery's calibration compeletion\n");
		sleep(1);
	}	
	//wait charging pile stop charging and the result of check battery info
	sleep(10);
	//add by jxu 20181017-begin update the bms info to slove the stop_charge which send by myslelf.
	if (g_stAgvAttr.iStopChargeFromMM == TRUE)
	{
		g_stAgvAttr.iStopChargeFromMM = FALSE;
		if (g_stAgvAttr.iBatType == BAT_TYPE_ANSHANG)
		{
			iRet = anshang_inquiry_batt_summary_info(&g_stAgvAttr.bms);
			if (iRet < 0)
			{
				LOG_WRN("anshang_inquiry_batt_summary_info is failed\n");
				return 0;
			}
		}
	}

	//add by jxu 20181017-end
	iCurrentCur = g_stAgvAttr.bms.uCurrent;
	
	float fCurrentPre = (float)iCurrentPre / 10;
	float fCurrentCur = (float)iCurrentCur / 10;
	LOG_INF("stop charge: current status:[%0.2fA --> %0.2fA]\n", fCurrentPre, fCurrentCur);

	//check from charge stat to stop charge
	if ((iCurrentPre >= CURRENT_10A) && ((iCurrentPre - iCurrentCur) < CURRENT_2A) 
		&& (TRUE != g_iNotReport3019)) //by tiger.102
	{
		LOG_WRN("stop charge failure\n");
		return -EVENT_ERR_STOPCHARGE;
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : mc_reset
* Description	     : safe reset mc
* input			     : NONE
* Output		     : NONE
* Return		     : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
						timeout,else negative of error code value
*******************************************************************************/
int mc_reset()
{
	int iRet = -1;
	LOG_INF("mc execute:safe reset\n");
	g_stAgvAttr.iMoveStatus = agv_reset;

	iRet = agv_task_init(&g_stAgvTask, DEV_MC, MC_RESET, MC_LOG_TYPE_INVALID, TC_LOG_TYPE_INVALID);
	if (iRet < 0)
		return iRet;
	iRet = g_stMcDev.reset();
	if (iRet < 0 )
	{
		LOG_ERR("send MC reset CAN frame failed\n");
		return iRet;
	}

	iRet = _sem_wait(&g_stAgvTask.stAction.stActSem, TIME_OUT_180S);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_MC_TIMEOUT;
	}

	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, MC_RESET);
	return iRet;
}

/*******************************************************************************
* Function Name		 : tc_reset
* Description	     : safe reset tc
* input			     : NONE
* Output		     : NONE
* Return		     : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
						timeout,else negative of error code value
*******************************************************************************/
int tc_reset()
{
	int iRet = -1;
	g_stAgvAttr.iMoveStatus = agv_reset;

	iRet = agv_task_init(&g_stAgvTask, DEV_TC, TC_ENABLE_WDG, MC_LOG_TYPE_INVALID, TC_LOG_TYPE_INVALID);
	if (iRet < 0)
		return iRet;

	iRet = g_stTcDev.reset();
	if (iRet < 0 )
	{
		LOG_ERR("send TC reset CAN frame failed\n");
		return -1;
	}

	iRet = _sem_wait(&g_stAgvTask.stAction.stActSem, TIME_OUT_180S);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_tc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_TC_TIMEOUT;
	}

	iRet = agv_task_exit(&g_stAgvTask, DEV_TC, TC_ENABLE_WDG);
	return iRet;
}

///start by tiger.19
#define TURN_TIMES 4
#define SYNC_TURN  1
#define ASYNC_TURN 0
/*******************************************************************************
* Function Name		 : turn_right_90
* Description	     : master cmd mc turn 90 ,and get the shelf QR
* Input 		     : iSync: 1:sync turn right;0:async turn right
* Output		     : NONE
* Return		     : the state of action:OK if OK,-1 on send CAN frame
						timeout,else negative of error code value
*******************************************************************************/
int turn_right_90(int iSync)
{
	int iRet = 0;
	u8 u8Action = 0;
	(iSync == 1) ? (g_stAgvAttr.iMoveStatus = agv_sync_right) : (g_stAgvAttr.iMoveStatus = agv_wheel_right);

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		u8Action = MC_TURN_RIGHT;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		u8Action = MC_CAN_CMD_TURNRIGHT_V2;
	}
	iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_TURN, TC_LOG_TYPE_INVALID);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;

	iRet = g_stMcDev.turn_right(iSync, 0, 900, 600);//async turn right
	if (iRet < 0)
	{
		LOG_ERR("send MC turn right 90 failed\n");
		return -1;
	}

	iRet = _sem_wait(&g_stAgvTask.stAction.stActSem, TIME_OUT_30S);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_TC_TIMEOUT;
	}
	
	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);
	if (iRet != OK)
	{
		return -1;
	}
	g_stAgvAttr.iMoveStatus = agv_stop;

	return iRet;
}


///start ,add by tiger.10
/*******************************************************************************
*Function Name    :mc_slow_go_back
*Description      :
*Input       	  :u16 u16SRemain
*Input       	  :u16 u16QRDistance
*Output 		  :
* Return		  :the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
timeout,else negative of error code value
*******************************************************************************/
int mc_slow_go_back(u16 u16SRemain, u16 u16QRDistance)
{
	int iRet = 0;
	u8 u8Action = 0;

	g_stAgvAttr.iMoveStatus = agv_slow_go_back;

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		u8Action = MC_SLOW_GO_BACK;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		u8Action = MC_CMD_BACK_TO_CHARGE_V2;
	}
	iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_WALK, TC_LOG_TYPE_INVALID);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;

	iRet = g_stMcDev.mc_slow_go_back(u16SRemain, u16QRDistance);
	if (iRet < 0)
	{
		LOG_ERR("send slow go back cmd failed\n");
		return -1;
	}

	iRet = _sem_wait(&g_stAgvTask.stAction.stActSem, TIME_OUT_30S);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_MC_TIMEOUT;
	}

	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);
	return iRet;
}

/*******************************************************************************
*Function Name    :mc_slow_go_straight
*Description      :
*Input       	  :u16 u16SRemain
*Input       	  :u16 u16QRDistance
*Output 		  :
* Return		  :the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
timeout,else negative of error code value
*******************************************************************************/
int mc_slow_go_straight(u16 u16SRemain, u16 u16QRDistance)
{
	int iRet = 0;
	u8 u8Action = 0;

	g_stAgvAttr.iMoveStatus = agv_slow_go_straight;

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		u8Action = MC_SLOW_GO_STRAIGHT;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		u8Action = MC_CMD_FORWARD_LEAVE_CHARGE_V2;
	}
	iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_WALK, TC_LOG_TYPE_INVALID);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;

	iRet = g_stMcDev.mc_slow_go_straight(u16SRemain, u16QRDistance);
	if (iRet < 0)
	{
		LOG_ERR("send slow go straight cmd failed\n");
		return -1;
	}

	iRet = _sem_wait(&g_stAgvTask.stAction.stActSem, TIME_OUT_30S);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_MC_TIMEOUT;
	}

	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);
	return iRet;
}

/*******************************************************************************
*Function Name    :mc_leftarc
*Description      :
*Input       	  :u16 u16Weight
*Output 		  :
* Return		  :the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
timeout,else negative of error code value
*******************************************************************************/
int mc_leftarc(u16 u16Weight)
{
	int iRet = 0;
	u8 u8Action = 0;

	g_stAgvAttr.iMoveStatus = agv_left_arc;

	if (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus)
	{
		// add by kedong, 20180302
		// before send_pallet_angle_offset, 
		// update and get current pallet info for comparing with last
		update_global_pallet_angle_offset();

		// modified by kedong, 20180205
		// g_stAgvAttr.iTAngleOffset is used for recording 
		// last rise/turn_left/turn_right'pallet angle offset,
		// when execute next turn_left/turn_right, send pallet angle offset to mc
		float fAngleOffset = (float)g_stAgvAttr.iTAngleOffset / 100;

		LOG_INF("send pallet angle offset[%0.2f] before right_arc/left_arc\n", fAngleOffset);
		if (g_stAgvAttr.iTAngleOffset != 0)
			send_pallet_angle_offset(g_stAgvAttr.iTAngleOffset);
	}

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		u8Action = MC_LEFT_ARC;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		u8Action = MC_CMD_LEFT_ARC_V2;
	}
	iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_TURN, TC_LOG_TYPE_INVALID);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;

	iRet = g_stMcDev.mc_leftarc(u16Weight);
	if (iRet < 0)
	{
		LOG_ERR("send left arc failed\n");
		return -1;
	}

	iRet = _sem_wait_exclude_safe(&g_stAgvTask.stAction.stActSem, TIME_OUT_10M);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_MC_TIMEOUT;
	}

	// add by kedong, 20180324
	// get pallet info after leftarc for next action compare
	if (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus)
	{
		if (get_pallet_info() < 0)
		{
			LOG_WRN("get pallet info failed after leftarc\n");
		}
	}

	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);
	return iRet;
}

/*******************************************************************************
*Function Name    :mc_rightarc
*Description      :
*Input       	  :u16 u16Weight
*Output 		  :
* Return		  :the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
timeout,else negative of error code value
*******************************************************************************/
int mc_rightarc(u16 u16Weight)
{
	int iRet;
	u8 u8Action = 0;

	g_stAgvAttr.iMoveStatus = agv_right_arc;

	if (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus)
	{
		// add by kedong, 20180302
		// before send_pallet_angle_offset, 
		// update and get current pallet info for comparing with last
		update_global_pallet_angle_offset();

		// modified by kedong, 20180205
		// g_stAgvAttr.iTAngleOffset is used for recording 
		// last rise/turn_left/turn_right'pallet angle offset,
		// when execute next turn_left/turn_right, send pallet angle offset to mc
		float fAngleOffset = (float)g_stAgvAttr.iTAngleOffset / 100;

		LOG_INF("send pallet angle offset[%0.2f] before right_arc/left_arc\n", fAngleOffset);
		if (g_stAgvAttr.iTAngleOffset != 0)
			send_pallet_angle_offset(g_stAgvAttr.iTAngleOffset);
	}

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		u8Action = MC_RIGHT_ARC;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		u8Action = MC_CMD_RIGHT_ARC_V2;
	}
	iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_TURN, TC_LOG_TYPE_INVALID);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;

	iRet = g_stMcDev.mc_rightarc(u16Weight);
	if (iRet<0)
	{
		LOG_ERR("send right arc failed\n");
		return -1;
	}

	iRet = _sem_wait_exclude_safe(&g_stAgvTask.stAction.stActSem, TIME_OUT_10M);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_MC_TIMEOUT;
	}

	// add by kedong, 20180324
	// get pallet info after leftarc for next action compare
	if (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus)
	{
		if (get_pallet_info() < 0)
		{
			LOG_WRN("get pallet info failed after leftarc\n");
		}
	}

	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);
	return iRet;
}
///end ,add by tiger.10

///start by tiger.19
#define A_CYCLE 3600
/*******************************************************************************
*Function Name    :sync_turn_degree
*Description      :  
*Input       	  :int iDegree  
*Output 		  :
* Return		  :the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
					timeout,else negative of error code value
*******************************************************************************/
int sync_turn_degree(int iDegree)
{
	int iRet = 0;
	u8 u8Action = 0;

	g_stAgvAttr.iMoveStatus = agv_sync_right;

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		u8Action = MC_TURN_RIGHT;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		// modify by kedong, 20180213
		// bug:when turn_right, we should set u8Action=MC_CAN_CMD_TURNRIGHT_V2, 
		// not MC_CAN_CMD_TURNLEFT_V2
		u8Action = MC_CAN_CMD_TURNRIGHT_V2;
	}
	iRet = agv_task_init(&g_stAgvTask, DEV_MC, u8Action, MC_LOG_TYPE_TURN, TC_LOG_TYPE_INVALID);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;

	iRet = g_stMcDev.turn_right(1, WEIGHT_LEVEL_15, iDegree, 600);
	if (iRet < 0 )
	{
		LOG_ERR("send MC turn right CAN frame failed during sync turn degree\n");
		return -1;
	}

	iRet = _sem_wait_exclude_safe(&g_stAgvTask.stAction.stActSem, TIME_OUT_180S);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_MC_TIMEOUT;
	}

	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, u8Action);
	return iRet;
}

/*******************************************************************************
*Function Name    :cntl_lift_motor
*Description      :cntl lift motor
*input			  :u8Operate : 0 if lock,  1 on up ,2 when down,
*Input       	  :u8Weight  : weight level, 0~15
*Output 		  :
*Return		      :the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
                  :timeout,else negative of error code value
*******************************************************************************/
int cntl_lift_motor(u8 u8Operate, u8 u8Weight)
{
	int iRet = 0;
	int iDevType = 0;
	
	if (TC_RISE == u8Operate)
		g_stAgvAttr.iMoveStatus = agv_tc_rise;
	else if (TC_LAY == u8Operate)
		g_stAgvAttr.iMoveStatus = agv_tc_lay;
	else
		return -1;

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		iDevType = DEV_TC;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		iDevType = DEV_MC;
		if (TC_RISE == u8Operate)
		{
			u8Operate = TC_CAN_CMD_JACK_V2;
		}
		else if (TC_LAY == u8Operate)
		{
			u8Operate = TC_CAN_CMD_PUT_V2;
		}
		else
		{
			LOG_WRN("error operate=%d type\n", u8Operate);
			return -1;
		}
	}
	iRet = agv_task_init(&g_stAgvTask, iDevType, u8Operate, MC_LOG_TYPE_INVALID, TC_LOG_TYPE_INVALID);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;

	//add by jxu 20180123 begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		iRet = g_stTcDev.cntl_lift_motor(u8Operate, u8Weight);
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		iRet = g_stMcDev.cntl_lift_motor(u8Operate, u8Weight);
	}
	//add by jxu 20180123 end
	if (iRet < 0)
	{
		LOG_ERR("send TC raise CAN frame failed\n");
		return iRet;
	}

	iRet = _sem_wait_exclude_safe(&g_stAgvTask.stAction.stActSem, TIME_OUT_10M);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_tc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_TC_TIMEOUT;
	}

	iRet = agv_task_exit(&g_stAgvTask, iDevType, u8Operate);
	return iRet;
}

///start by tiger.30
/*******************************************************************************
*Function Name    :get_pallet_angle_offset
*Description      :get pallet angle offset
*Input       	  :void
*Output 		  :
*Return           :double: the offset angle of shelf
*******************************************************************************/
double get_pallet_angle_offset(void)
{
	//add by jxu 20180425:begin
	unsigned int uiAngleOffset = 0;
	if (g_stTopCameraDev.iVersion == CAMERA_VERSION_UART)
	{
		uiAngleOffset = g_stAgvAttr.iTAngleOffset;
	}
	else if (g_stTopCameraDev.iVersion == CAMERA_VERSION_V4L2)
	{
		uiAngleOffset = (g_stQrInfo.fAngle + 180)*100;
	}
	else
	{
		LOG_WRN("Top camera type is error g_stTopCameraDev.iVersion=%d\n", g_stTopCameraDev.iVersion);
		return 0;
	}
	//add by jxu 20180425:end
	float fPlateAngle = uiAngleOffset*0.01 - 180;
	float fPlateDiffAngle = 0;
	double dDiffAngle = 0;

	if (((fPlateAngle > 0.0001f) && (fPlateAngle <45.0001f)) || ((fPlateAngle > -45.0001f) && (fPlateAngle<0.0001f)))
	{
		fPlateDiffAngle = fPlateAngle;
	}
	else if ((fPlateAngle > 45.0001f) && (fPlateAngle < 135.0001f))
	{
		fPlateDiffAngle = fPlateAngle - 90.0f;
	}
	else if (((fPlateAngle > 135.0001f) && (fPlateAngle<180.0001f)) || ((fPlateAngle < -135.0001f) && (fPlateAngle > -180.0001f)))
	{
		fPlateDiffAngle = (fPlateAngle > 0.1f) ? (fPlateAngle - 180.0f) : (180.0f + fPlateAngle);
	}
	else if ((fPlateAngle > -135.0001f) && (fPlateAngle < -45.0001f))
	{
		fPlateDiffAngle = fPlateAngle + 90.0f;
	}

	dDiffAngle = fabs(fPlateDiffAngle);
	LOG_INF("the plate angle is offset angle=%.2f\n", dDiffAngle);
	return dDiffAngle;
}
///end by tiger.30


/*******************************************************************************
* Function Name		 : send_pallet_angle_offset
* Description	     : send plate angle offset
* input			     : u16Angle : In unit of 0.01 degree
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void send_pallet_angle_offset(u16 u16Angle)
{
	agv_sem_t *pAgvSem = NULL;
	pAgvSem = agv_sem_add(SEM_CAN_TYPE, ARM2TC_ANGLE_ACK, 0);
	if (NULL == pAgvSem)
	{
		LOG_ERR("add sem failed\n");
	}
	//add by jxu 20180125 begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		g_stTcDev.send_angle_offset(u16Angle);
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		g_stMcDev.send_angle_offset(u16Angle);
	}
	//add by jxu 20180125end

	if (0 == agv_sem_wait(SEM_CAN_TYPE, ARM2TC_ANGLE_ACK, 0, 6000))
	{
		agv_sem_clean(SEM_CAN_TYPE, ARM2TC_ANGLE_ACK, 0);
		LOG_INF("get pallet angle ack ok\n");
	}
	else
	{
		LOG_WRN("get pallet angle ack time out\n");
	}
}

/*******************************************************************************
*Function Name    :tc_rise
*Description      :tc raise
*input			  :u8Weight : weight, 0~15 corresponding to 0~300KG
*input			  :pContainNum : the string of container number if lift up; NULL on other.
*Output 		  :
*Return		      :the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
                  :timeout,else negative of error code value
*******************************************************************************/
#define PALLET_OFFSET_DEGREE 5.0001f 
int tc_rise(u8 u8Weight, const char * pContainerNum)
{
	int iRet = 0;
	int iResult = 0;
	int iTurnCount = 0;
	int iTurnAngle = 0;

	//if (g_stAgvAttr.iPalletStatus == PALLET_STATUS_TOP)
	//{
	//	LOG_WRN("the pallet is already at PALLET_STATUS_TOP\n");
	//	return OK;
	//}

	iTurnAngle = 0;
	for (iTurnCount = 0; iTurnCount < TURN_TIMES; iTurnCount++)
	{
		iRet = get_pallet_info();
		if (iRet >= 0) //get success
		{
			LOG_INF("get pallet info success, after [%dth] turn 90\n", iTurnCount);
			break;
		}

		iResult = turn_right_90(ASYNC_TURN);
		if (iResult < 0)
			LOG_WRN("turn right 90 failure, after [%dth] turn 90\n", iTurnCount + 1);
		else
		{
			iTurnAngle = (iTurnCount + 1) * 900; // by tiger.19
			LOG_INF("[%dth] turn 90 success during get pallet info\n", iTurnCount + 1);
		}
	}

	if (iRet < 0)
	{
		iRet = get_pallet_info();
	}

	if (iRet < 0)
	{
		// 1), jack shelf
		g_stAgvAttr.iMoveStatus = agv_tc_rise;
		iRet = cntl_lift_motor(TC_RISE, WEIGHT_LEVEL_15);
		if (iRet < 0)
			return iRet;

		//add by jxu 20180228:begin
		int iRetRise = get_pallet_info();
		if (iRetRise < 0)
		{
			LOG_INF("get the pallet info failed after jack shelf\n");
		}
		//add by jxu 20180228:end

		// add by kedong, 20180302
		// before send_pallet_angle_offset, get current pallet info for comparing with last
		int iLastPalletAngle = g_stAgvAttr.iTAngleOffset;

		// 2), put shelf
		g_stAgvAttr.iMoveStatus = agv_tc_lay;
		iRet = cntl_lift_motor(TC_LAY, WEIGHT_LEVEL_15);
		if (iRet < 0)
			return iRet;

		//modify by jxu 20180228:begin
		int iRetDown = get_pallet_info();
		if (iRetDown < 0)
		{
			LOG_INF("get the pallet info failed after put shelf\n");
		}

		// add by kedong, 20180302
		// before send_pallet_angle_offset, get current pallet info for comparing with last
		int iCurrPalletAngle = g_stAgvAttr.iTAngleOffset;

		if ((iRetRise < 0) && (iRetDown < 0))
		{
			LOG_ERR("get the pallet info failed, after tc jack and put shelf, and will send the exception\n");
			return -EVENT_ERR_SCANTPIDERROR;
		}
		//modify by jxu 20180228:end

		LOG_INF("get the pallet info success, after tc jack and put shelf\n");
		if (abs(iCurrPalletAngle - iLastPalletAngle) < 4500)
		{
			int iLastOffset = compute_angle_offset(iLastPalletAngle);
			int iCurrOffset = compute_angle_offset(iCurrPalletAngle);

			iLastOffset = abs(iLastOffset);
			iCurrOffset = abs(iCurrOffset);

			if (iLastOffset < iCurrOffset)
				g_stAgvAttr.iTAngleOffset = iLastPalletAngle;
			else
				g_stAgvAttr.iTAngleOffset = iCurrPalletAngle;

			LOG_WRN("get the pallet info, angle last[%d/%d] != current[%d/%d]\n",
				iLastOffset, iLastPalletAngle, iCurrOffset, iCurrPalletAngle);
		}
	}

	float fAngleOffset = (float)g_stAgvAttr.iTAngleOffset / 100;

	LOG_INF("send pallet angle offset[%0.2f] before cntl_cycle_motor\n", fAngleOffset);

	//send_pallet_angle_offset(g_stAgvAttr.iTAngleOffset);//add by jxu 20180709
	// check point and container is not null
	if ((g_stAgvConf.cCheckPoint != 0) && (pContainerNum != NULL))
	{
		// TO TEST some null pContainerNum
		if (strcmp(pContainerNum, g_stAgvAttr.cContainer) != 0)//add by jxu 20180820-modify the strncmp->strcmp
		{
			LOG_ERR("the shelf'contain[%s] != operation'contain[%s], try again\n",
				g_stAgvAttr.cContainer, pContainerNum);

			if (get_pallet_info() >= 0)
			{
				if (strcmp(pContainerNum, g_stAgvAttr.cContainer) != 0)//add by jxu 20180820-modify the strncmp->strcmp
				{
					LOG_ERR("the shelf'contain[%s] != operation'contain[%s], send error msg to console\n",
						g_stAgvAttr.cContainer, pContainerNum);
					return -EVENT_ERR_TPIDERROR;
				}
			}
			else
			{
				LOG_ERR("get pallet info again failure, send error msg to console\n");
				return -EVENT_ERR_SCANTPIDERROR;
			}
		}
		else
		{
			LOG_INF("the shelf'contain[%s] == operation'contain[%s]\n",
				g_stAgvAttr.cContainer, pContainerNum);

			///start by tiger.30
			double dOffAngle = get_pallet_angle_offset();
			if (dOffAngle > PALLET_OFFSET_DEGREE)
			{
				return -EVENT_ERR_BIG_ANGEL;
			}
			///end by tiger.30

		}
	}
	send_pallet_angle_offset(g_stAgvAttr.iTAngleOffset);//add by jxu 20180709
	///start by tiger.19
	iRet = cntl_lift_motor(TC_RISE, u8Weight);
	if (iRet < 0)
		return iRet;

	g_stAgvAttr.iPalletStatus = PALLET_STATUS_TOP;
	///start ,by tiger.19
	//TODO: sleep(2);
	sleep(2);

	if (get_pallet_info() < 0)
	{
		LOG_WRN("get pallet info failed, after rise pallet finish\n"); //by tiger
		//return -EVENT_ERR_SCANTPIDERROR; //to be the same with old version,by tongkedong 
	}	
	else
	{
		g_stAgvAttr.iRaiseTAngle = g_stAgvAttr.iTAngleOffset;
	}
	

	if ((iTurnAngle != A_CYCLE) && (iTurnAngle > 0)) //turned a cycle
	{
		iRet = sync_turn_degree(A_CYCLE - iTurnAngle); //sync turn ,including send operate complete  		
	}

	return iRet;
	///end by tiger.19
}

/*******************************************************************************
*Function Name    :tc_lay
*Description      :tc lay
*input			  :u8Weight : weight, 0~15 corresponding to 0~300KG
*input			  :pContainNum : the string of container number if lift up; NULL on other.
*Output 		  :
*Return		      :the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
                  :timeout,else negative of error code value
*******************************************************************************/
int tc_lay(u8 u8Weight, const char * pContainerNum)
{
	int iRet = 0;
	int iResult = 0;
	int iTurnCount = 0;

	g_stAgvAttr.iMoveStatus = agv_tc_lay;
	//if (g_stAgvAttr.iPalletStatus == PALLET_STATUS_BOT)
	//{
	//	LOG_WRN("the pallet is already at PALLET_STATUS_BOT\n");
	//	return OK;
	//}
	
	sleep(2);//wait for shelf stable

	for (iTurnCount = 0; iTurnCount < TURN_TIMES; iTurnCount++)
	{
		iResult = get_pallet_info();
		if (iResult >= 0) //get success
		{
			iResult = OK;
			LOG_INF("get pallet info success, after [%dth] turn 90\n", iTurnCount);
			break;
		}
		iRet = turn_right_90(SYNC_TURN);
		if (iRet < 0)
			LOG_WRN("get pallet info failure, after [%dth] turn 90\n", iTurnCount+1);
		else
			LOG_INF("[%dth] turn 90 success during get pallet info\n", iTurnCount + 1);
	
	}

	if (iResult < 0)
	{
		iResult = get_pallet_info();
	}

	if (iResult < 0)
	{
		///if not get top QR ,then send the EVENT_ERR_GET_TPID, start by tiger.32
		LOG_WRN("get pallet info failed when put down the shelf\n");
		iResult = -EVENT_ERR_GET_TPID;
		///end by tiger.32
	}
	else
	{
		iResult = OK;
	}

	float fAngleOffset = (float)g_stAgvAttr.iTAngleOffset / 100;

	LOG_INF("send pallet angle offset[%0.2f] before cntl_cycle_motor\n", fAngleOffset);
	send_pallet_angle_offset(g_stAgvAttr.iTAngleOffset);

	iRet = cntl_lift_motor(TC_LAY, u8Weight);
	if (iRet < 0)
		return iRet;

	g_stAgvAttr.iPalletStatus = PALLET_STATUS_BOT;
	sprintf(g_stAgvAttr.cContainer, "%s", "NONE");//add by tiger.51
	return iResult;
}

///start by tiger.19
/*******************************************************************************
* Function Name		 : cntl_cycle_motor
* Description	     : make cycle motor lock ,turn left or turn right
* input			     : u8Operate : 0 if lock,  1 on up ,2 when down,
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Angle : In unit of 0.1 degree
* input			     : u16Speed : In unit of millimeter per second
* Output		     : NONE
* Return			 : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
                     : timeout,else negative of error code value
*******************************************************************************/
int cntl_cycle_motor(u8 u8Operate, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	int iRet = -1;
	int iDevType = 0;

	if (TC_PALLET_LEFT == u8Operate)
		g_stAgvAttr.iMoveStatus = agv_pallet_left;
	else if (TC_PALLET_RIGHT == u8Operate)
		g_stAgvAttr.iMoveStatus = agv_pallet_right;
	else
		return -1;

	//add by jxu 20180121: begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		iDevType = DEV_TC;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		iDevType = DEV_MC;
		if (TC_PALLET_LEFT == u8Operate)
		{
			u8Operate = TC_CAN_CMD_CYCLELEFT_V2;
		}
		else if (TC_PALLET_RIGHT == u8Operate)
		{
			u8Operate = TC_CAN_CMD_CYCLERIGHT_V2;
		}
		else
		{
			LOG_WRN("error operate=%d type\n", u8Operate);
			return -1;
		}
	}

	if ((TC_PALLET_RIGHT == u8Operate) || (TC_PALLET_LEFT == u8Operate)
		|| (TC_CAN_CMD_CYCLELEFT_V2 == u8Operate) || (TC_CAN_CMD_CYCLERIGHT_V2 == u8Operate))  //cycle motor turn left/right
	{
		LOG_INF("get pallet info before operate[%d-%s]\n", u8Operate, get_tc_cmd_name(u8Operate));
		
		if (PALLET_STATUS_TOP == g_stAgvAttr.iPalletStatus)
		{
			// add by kedong, 20180302
			// before send_pallet_angle_offset, 
			// update and get current pallet info for comparing with last
			LOG_INF("get pallet info before pallet right/left:\n");
			update_global_pallet_angle_offset();

			//already call get_pallet_info() in update_global_pallet_angle_offset()
			// so no need call get_pallet_info() again
			LOG_INF("task.PalletDirect=%d, current.PalletDirect=%d\n", 
				g_stAgvAttr.iTaskPalletDirect, g_stAgvAttr.iPalletDirect);
			if (g_stAgvAttr.iTaskPalletDirect == g_stAgvAttr.iPalletDirect)
			{
				LOG_INF("May be click recover task button on the console\n");
				return OK;
			}
			
			// modified by kedong, 20180205
			// g_stAgvAttr.iTAngleOffset is used for recording 
			// last rise/turn_left/turn_right'pallet angle offset,
			// when execute next turn_left/turn_right, send pallet angle offset to mc
			float fAngleOffset = (float)g_stAgvAttr.iTAngleOffset / 100;

			LOG_INF("send pallet angle offset[%0.2f] before cntl_cycle_motor\n", fAngleOffset);
			if (g_stAgvAttr.iTAngleOffset != 0)
				send_pallet_angle_offset(g_stAgvAttr.iTAngleOffset);
		}
	}

	iRet = agv_task_init(&g_stAgvTask, iDevType, u8Operate, MC_LOG_TYPE_INVALID, TC_LOG_TYPE_INVALID);
	//add by jxu 20180121: end

	if (iRet < 0)
		return iRet;

	//add by jxu 20180125 begin
	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		iRet = g_stTcDev.cntl_cycle_motor(u8Operate, u8Weight, u16Angle, u16Speed);
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		iRet = g_stMcDev.cntl_cycle_motor(u8Operate, u8Weight, u16Angle, u16Speed);
	}
	//add by jxu 20180125 end
	if (iRet < 0)
	{
		LOG_ERR("send TC turn pallet CAN frame failed\n");
		return -1;
	}

	iRet = _sem_wait_exclude_safe(&g_stAgvTask.stAction.stActSem, TIME_OUT_10M);
	if (iRet < 0)
	{
		LOG_WRN("wait [%d-%s] finish time out\n",
			g_stAgvTask.stAction.iType, get_tc_cmd_name(g_stAgvTask.stAction.iType));
		return -EVENT_ERR_TC_TIMEOUT;
	}

	iRet = agv_task_exit(&g_stAgvTask, iDevType, u8Operate);
	return iRet;
}

///start by tiger.19
/*******************************************************************************
*Function Name    :tc_put_jack
*Description      :
*Input       	  :void
*Output 		  :
*Return           :int :0 if OK ,-1 on error
*******************************************************************************/
int tc_put_jack(void)
{
	int iResult = 0;

	int iPreHead = g_stAgvAttr.iVehHeadDirect;//get agv head direct
	int iCurHead = iPreHead;

	// 1), put shelf
	g_stAgvAttr.iMoveStatus = agv_tc_lay;
	// no need check return value
	cntl_lift_motor(TC_LAY, WEIGHT_LEVEL_15);

	iResult = get_pallet_info();
	if (iResult < 0)
	{
		LOG_ERR("get the pallet info failure, after tc jack and put shelf\n");
	}
	else
	{
		LOG_INF("get the pallet info success, after tc jack and put shelf\n");
	}

	iCurHead = g_stAgvAttr.iVehHeadDirect;
	if (iPreHead != iCurHead)
	{
		//TODO: need to optimize
		int iDirectOffset = iPreHead - iCurHead;
		u16 u16Angle = 0;

		if (iDirectOffset < 0)
			iDirectOffset += 4;
		u16Angle = iDirectOffset * 900;

		turn_left(1, WEIGHT_LEVEL_15, u16Angle, 600);
	}

	// 2), jack shelf
	g_stAgvAttr.iMoveStatus = agv_tc_rise;
	// no need check return value
	cntl_lift_motor(TC_RISE, WEIGHT_LEVEL_15);

	if (iResult < 0)
	{
		iResult = get_pallet_info();
		if (iResult < 0)
			LOG_ERR("get the pallet info failure, after tc jack and put shelf, and will send the exception\n");
		else
			LOG_ERR("get the pallet info success, after tc jack and put shelf\n");
	}

	return iResult;
}
/*******************************************************************************
*Function Name   : check_pallet_direction
*Description     : According the the diffrence value to cycle the pallet
*input			 : iTaskPalletDirect,
*input			 : iCurPalletDirect,
*input			 : u8Weight : weight, 0~15 corresponding to 0~300KG
*input			 : u16Speed : In unit of millimeter per second
*Output		     : NONE
* Return		 : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
: timeout,else negative of error code value
*******************************************************************************/
int check_pallet_direction(int iTaskPalletDirect, int iCurPalletDirect, u8 u8Weight, u16 u16Speed)
{
	int iResult = -1;
	int iDiffValue = iTaskPalletDirect - iCurPalletDirect;
	u16 u16Angle = 0;
	if (iDiffValue == 1)
	{
		u16Angle = 900 * iDiffValue;
		iResult = cntl_cycle_motor(TC_PALLET_LEFT, u8Weight, u16Angle, u16Speed);
		if (iResult < 0)
			return iResult;
	}
	else if (iDiffValue == 2)
	{
		u16Angle = 900 * iDiffValue;
		iResult = cntl_cycle_motor(TC_PALLET_LEFT, u8Weight, u16Angle, u16Speed);
		if (iResult < 0)
			return iResult;
	}
	else if (iDiffValue == 3)
	{
		u16Angle = 900;
		iResult = cntl_cycle_motor(TC_PALLET_RIGHT, u8Weight, u16Angle, u16Speed);
		if (iResult < 0)
			return iResult;
	}
	else if (iDiffValue == -1)
	{
		u16Angle = 900 * abs(iDiffValue);
		iResult = cntl_cycle_motor(TC_PALLET_RIGHT, u8Weight, u16Angle, u16Speed);
		if (iResult < 0)
			return iResult;
	}
	else if (iDiffValue == -2)
	{
		u16Angle = 900 * abs(iDiffValue);
		iResult = cntl_cycle_motor(TC_PALLET_RIGHT, u8Weight, u16Angle, u16Speed);
		if (iResult < 0)
			return iResult;
	}
	else if (iDiffValue == -3)
	{
		u16Angle = 900;
		iResult = cntl_cycle_motor(TC_PALLET_LEFT, u8Weight, u16Angle, u16Speed);
		if (iResult < 0)
			return iResult;
	}
	else
	{
		LOG_WRN("The pallet direction is invalid-iTaskPalletDirect[%d] and iCurPalletDirect[%d]\n", iTaskPalletDirect, iCurPalletDirect);
	}
	return iResult;
}
/*******************************************************************************
*Function Name   : pallet_turn_left
*Description     : pallet turn left
*input			 : u8Operate : 0 if lock,  1 on up ,2 when down,
*input			 : u8Weight : weight, 0~15 corresponding to 0~300KG
*input			 : u16Angle : In unit of 0.1 degree
*input			 : u16Speed : In unit of millimeter per second
*Output		     : NONE
*Return			 : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
                 : timeout,else negative of error code value
*******************************************************************************/
int pallet_turn_left(u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	int iRet = 0;
	int iResult = 0;

	iResult = cntl_cycle_motor(TC_PALLET_LEFT, u8Weight, u16Angle, u16Speed);
	if (iResult < 0)
		return iResult;

	// add by kedong, 20180301
	// if the pallet is already in bottom,
	// no need get pallet info
	if (g_stAgvAttr.iPalletStatus == PALLET_STATUS_BOT)
	{
		LOG_INF("the pallet is already in bottom, no need get pallet info\n");
		return iResult;
	}

	LOG_INF("get pallet info after pallet right/left:\n");
	iRet = get_pallet_info();
	if (iRet < 0)
	{
		LOG_INF("get pallet info failure, after pallet turn left, and then put and rise the shelf\n");
		iRet = tc_put_jack();
		if (iRet < 0)
			return -EVENT_ERR_CYCLEFINSCANERR;

	}
	LOG_INF("get pallet info success, after pallet turn left\n");
	//add by jxu 20180423:beign
	if ((g_stAgvAttr.iTaskPalletDirect != g_stAgvAttr.iPalletDirect) && (g_stAgvConf.cDebugEnable!=TRUE))
	{
		LOG_INF("The iTaskPalletDirect[%d] is different with iPalletDirect[%d]\n", g_stAgvAttr.iTaskPalletDirect, g_stAgvAttr.iPalletDirect);
		iResult = check_pallet_direction(g_stAgvAttr.iTaskPalletDirect, g_stAgvAttr.iPalletDirect, u8Weight, u16Speed);
		LOG_INF("The check pallete result is iResult =%d\n", iResult);
		if (iResult < 0)
			return iResult;
		if (g_stAgvAttr.iPalletStatus == PALLET_STATUS_BOT)
		{
			LOG_INF("the pallet is already in bottom, no need get pallet info\n");
			return iResult;
		}
		iRet = get_pallet_info();
		if (iRet < 0)
		{
			LOG_INF("get pallet info failure, after pallet turn left, and then put and rise the shelf\n");
			iRet = tc_put_jack();
			if (iRet < 0)
				return -EVENT_ERR_CYCLEFINSCANERR;
		}
	}
	//add by jxu 20180423:end
	return iResult;
}

/*******************************************************************************
*Function Name   : pallet_turn_right
*Description     : pallet turn right
*input			 : u8Operate : 0 if lock,  1 on up ,2 when down,
*input			 : u8Weight : weight, 0~15 corresponding to 0~300KG
*input			 : u16Angle : In unit of 0.1 degree
*input			 : u16Speed : In unit of millimeter per second
*Output		     : NONE
*Return			 : the state of action:OK(0x4f4b) if OK, -1 on send CAN frame
                 : timeout,else negative of error code value
*******************************************************************************/
int pallet_turn_right(u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	int iRet = 0;
	int iResult = 0;

	iResult = cntl_cycle_motor(TC_PALLET_RIGHT, u8Weight, u16Angle, u16Speed);
	if (iResult < 0)
		return iResult;

	// add by kedong, 20180301
	// if the pallet is already in bottom,
	// no need get pallet info
	if (g_stAgvAttr.iPalletStatus == PALLET_STATUS_BOT)
	{
		LOG_INF("the pallet is already in bottom, no need get pallet info\n");
		return iResult;
	}

	LOG_INF("get pallet info after pallet right/left:\n");
	iRet = get_pallet_info();
	if (iRet < 0)
	{
		LOG_INF("failed to get pallet info after pallet turn right,and then put and rise the shelf\n");
		iRet = tc_put_jack();
		if (iRet < 0)
			return -EVENT_ERR_CYCLEFINSCANERR;

	}
	LOG_INF("get pallet info success, after pallet turn right\n");
	//add by jxu 20180423:beign
	if ((g_stAgvAttr.iTaskPalletDirect != g_stAgvAttr.iPalletDirect) && (g_stAgvConf.cDebugEnable != TRUE))
	{
		LOG_INF("The iTaskPalletDirect[%d] is different with iPalletDirect[%d]\n", g_stAgvAttr.iTaskPalletDirect, g_stAgvAttr.iPalletDirect);
		iResult = check_pallet_direction(g_stAgvAttr.iTaskPalletDirect, g_stAgvAttr.iPalletDirect, u8Weight, u16Speed);
		LOG_INF("The check pallete result is iResult =%d\n", iResult);
		if (iResult < 0)
			return iResult;
		if (g_stAgvAttr.iPalletStatus == PALLET_STATUS_BOT)
		{
			LOG_INF("the pallet is already in bottom, no need get pallet info\n");
			return iResult;
		}
		iRet = get_pallet_info();
		if (iRet < 0)
		{
			LOG_INF("get pallet info failure, after pallet turn left, and then put and rise the shelf\n");
			iRet = tc_put_jack();
			if (iRet < 0)
				return -EVENT_ERR_CYCLEFINSCANERR;
		}
	}
	//add by jxu 20180423:end
	return iResult;
}

typedef enum
{
	MC_CLEAR_DERAIL = 2,
	MC_CLEAR_NAVIGATE = 3,
	MC_CLEAR_LCODER_ERROR = 0x0a,
	MC_CLEAR_RCODER_ERROR = 0x0b,
}mc_flag;

/*******************************************************************************
*Function Name    :clear_derail
*Description      :clear derail
*input			  :NONE
*Output 		  :NONE
* Return		  :OK if clear derail success,-1 on error,
					-EVENT_ERR_MCCOMMUNISTOP when Recv ACK timeout
*******************************************************************************/
int clear_derail(void)
{
	int iRet = 0;

	iRet = agv_task_init(&g_stAgvTask, DEV_MC, MC_CLEAR_DERAIL, MC_LOG_TYPE_INVALID, TC_LOG_TYPE_INVALID);
	iRet = g_stMcDev.clear_derail();
	if (iRet < 0 )
	{
		LOG_ERR("Send clear derail CAN frame failed\n");
		return -1;
	}
	iRet = _sem_wait_exclude_safe(&g_stAgvTask.stAction.stActSem, TIME_OUT_180S);
	if (iRet < 0)
	{
		LOG_WRN("Get clear derail ACK timeout\n");
		return -EVENT_ERR_MCCOMMUNISTOP;
	}
	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, MC_CLEAR_DERAIL);
	return iRet;
}

/*******************************************************************************
*Function Name    :clear_navigation
*Description      :clear lost navigation  
*Input       	  :NONE  
*Output 		  :NONE
*Return           :int:OK if clear navigation success,-1 on error,
					-EVENT_ERR_MCCOMMUNISTOP when Recv timeout
*******************************************************************************/
int clear_navigation(void)
{
	int iRet = 0;

	iRet = agv_task_init(&g_stAgvTask, DEV_MC, MC_CLEAR_NAVIGATE, MC_LOG_TYPE_INVALID, TC_LOG_TYPE_INVALID);
	iRet = g_stMcDev.clear_navigation();
	if (iRet < 0)
	{
		LOG_ERR("Send clear navigation CAN frame failed\n");
		return -1;
	}

	iRet = _sem_wait_exclude_safe(&g_stAgvTask.stAction.stActSem, TIME_OUT_180S);
	if (iRet < 0)
	{
		LOG_WRN("get clear navigation ACK timeout\n");
		return -EVENT_ERR_MCCOMMUNISTOP;
	}

	iRet = agv_task_exit(&g_stAgvTask, DEV_MC, MC_CLEAR_NAVIGATE);

	return iRet;
}

/*******************************************************************************
* Function Name		 : deal_mc_heartbeat
* Description	     : deal with the MC heartbeat frame
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : 0 if no event; else negative of event value
*******************************************************************************/
int deal_mc_heartbeat(struct can_frame * pCanFrame)
{
	int iErrorCode = 0;
	int iEvent = 0;
	static int iPreCheckSum = 0;
	static unsigned int iHeartBeat = 0;
	int iCurCheckSum = 0;

	if (pCanFrame == NULL)
		return -1;

	iCurCheckSum = g_stMcDev.deal_heartbeat(pCanFrame, &g_stAgvAttr);

	// add by kedong, 20180301
	// monitor mc'heartbeat, 
	// will reset mc when no mc'heartbeat a long time
	get_current_timestamp_ms(&g_stMcDev.iMcHeartBeatTs);
#if(DEBUG_AGV == 333)
	LOG_DBG("recv mc'heartbeat at timestamp[%lld] ms\n", g_stMcDev.iMcHeartBeatTs);
#endif

	iEvent = g_stAgvAttr.iEvent;

	if (0 != iEvent && 15 != iEvent)//not report the charge
	{
		// if mc'heartbeat include error event continuously
		// is necessary to send error msg continuously? NO
		iErrorCode = MC_ERROR_BASE + iEvent;

		if (iErrorCode != atomic_read(&g_stAgvAttr.iException)) //by tiger.67
		{
			LOG_INF("mc heartbeat:error/event[%d-%s]\n", iErrorCode, get_err_str(iErrorCode));
			print_can_frame(pCanFrame);

			atomic_set(&g_stAgvAttr.iException, iErrorCode);//by tiger.67
			return -iErrorCode;
		}
	}
	atomic_set(&g_stAgvAttr.iException, iErrorCode);//by tiger.67

	// modified by kedong, 20180209
	// when the info mc'heartbeat is change and each 1 min = 600 * 100 ms
	iHeartBeat++;
	if ((iCurCheckSum != iPreCheckSum) || (iHeartBeat % 600 == 0)) //add by tiger.35
	{
		mcheartbeat_printf("mcheartbeat:style:%d, status:[%d-%s], headdirect:[%d-%s],event:[%d-%s],Sremain:%d,speed:%d\n",
			g_stAgvAttr.iMcStyle, g_stAgvAttr.iMoveStatus, get_move_status(g_stAgvAttr.iMoveStatus),
			g_stAgvAttr.iVehHeadDirect, get_direct_desc(g_stAgvAttr.iVehHeadDirect),
			iEvent, get_mc_evnet_desc(MC_ERROR_BASE + iEvent),g_stAgvAttr.iSreamin, 
			g_stAgvAttr.iSpeed);
	}
	iPreCheckSum = iCurCheckSum;

	return 0;
}

/*******************************************************************************
* Function Name		 : deal_mc_heartbeat_v2
* Description	     : deal with the MC heartbeat frame
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : 0 if no event; else negative of event value
*******************************************************************************/
int deal_mc_heartbeat_v2(struct can_frame * pCanFrame)
{
	static int iPreCheckSum = 0;
	static unsigned int iHeartBeat = 0;
	int iCurCheckSum = 0;

	if (pCanFrame == NULL)
		return -1;

	iCurCheckSum = g_stMcDev.deal_heartbeat(pCanFrame, &g_stAgvAttr);

	if (MC_HEARTBEAT_NO_EVENT_ERR == g_stAgvAttr.iEvent) //clear g_stAgvAttr.iException,add by tiger.58,tiger.107
	{
		atomic_set(&g_stAgvAttr.iException, MC_HEARTBEAT_NO_EVENT_ERR);//by tiger.67,tiger.107
	}

	// add by kedong, 20180301
	// monitor mc'heartbeat, 
	// will reset mc when no mc'heartbeat a long time
	get_current_timestamp_ms(&g_stMcDev.iMcHeartBeatTs);
#if(DEBUG_AGV == 333)
	LOG_DBG("recv mc'heartbeat at timestamp[%lld] ms\n", g_stMcDev.iMcHeartBeatTs);
#endif

	// modified by kedong, 20180209
	// when the info mc'heartbeat is change and each 1 min = 600 * 100 ms
	iHeartBeat++;
	if ((iCurCheckSum != iPreCheckSum) || (iHeartBeat % 600 == 0)) //add by tiger.35
	{
		mc_can_status_heartbeat_st * pMcHeartBeat = (mc_can_status_heartbeat_st *)pCanFrame;
		mcheartbeat_printf("mcheartbeat:MoveState=%d,nheaddirect=%d,nmode=%d,event=%d,nnewtag=%d,nipath=%d,sremain=%d, nvagv=%d\n",
			pMcHeartBeat->iMoveState, pMcHeartBeat->iHeaddirect, pMcHeartBeat->iMode, pMcHeartBeat->iEvent, pMcHeartBeat->iNewTag, pMcHeartBeat->iPath, pMcHeartBeat->iData1, pMcHeartBeat->iData2);
	}
	iPreCheckSum = iCurCheckSum;

	return 0;
}

/*******************************************************************************
* Function Name		 : task_convert_action
* Description	     : deal with the MC heartbeat frame
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
mc_operate_style task_convert_action(task_type_t enTaskType)
{
	mc_operate_style enMcCmd = -1;
	switch (enTaskType)
	{
	case ACTION_BACK_LEAVE_CHARGE:
		enMcCmd = MC_SLOW_GO_BACK;
		break;
	case ACTION_BACK_TO_CHARGE:
		enMcCmd = MC_SLOW_GO_BACK;
		break;
	case ACTION_CHARGE:
		enMcCmd = MC_BEGIN_CHARGE;
		break;
	case ACTION_FORWARD_LEAVE_CHARGE:
		enMcCmd = MC_SLOW_GO_STRAIGHT;
		break;
	case ACTION_FORWARD_TO_CHARGE:
		enMcCmd = MC_SLOW_GO_STRAIGHT;
		break;
	case ACTION_LAY:
		enMcCmd = TC_LAY;
		break;
	case  ACTION_RISE:
		enMcCmd = TC_RISE;
		break;
	case ACTION_STOP_CHARGE:
		enMcCmd = MC_STOP_CHARGE;
		break;
	case ACTION_TURN_LEFT:
		enMcCmd = MC_TURN_LEFT;
		break;
	case ACTION_TURN_RIGHT:
		enMcCmd = MC_TURN_RIGHT;
		break;
	case ACTION_RIGHT_ARC:
		enMcCmd = MC_RIGHT_ARC;
		break;
	case ACTION_LEFT_ARC:
		enMcCmd = MC_LEFT_ARC;
		break;
	case ACTION_PALLET_TURN_LEFT:
		enMcCmd = TC_PALLET_LEFT;
		break;
	case ACTION_PALLET_TURN_RIGHT:
		enMcCmd = TC_PALLET_RIGHT;
		break;
	case ACTION_WALK:
		enMcCmd = MC_GO_FORWARD;
		break;
	case ACTION_PARK:
		enMcCmd = MC_STOP;
		break;
	default:
		break;
	}
	return enMcCmd;
}
/*******************************************************************************
* Function Name		 : deal_mc_completion
* Description	     : deal with MC completion and send msg to console
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void deal_mc_completion(struct can_frame * pCanFrame)
{
	u8 u8Action = 0;
	//u8 u8Style =0;

	if (pCanFrame == NULL)
		return;

	g_stMcDev.deal_fin(pCanFrame, &g_stAgvAttr);

	u8Action = (u8)g_stAgvAttr.iMcAction;
	//u8Style = (u8)g_stAgvAttr.iMcStyle;
	if ((MC_UPLOAD_LOG_OK == pCanFrame->data[6]) && (MC_UPLOAD_LOG_FLAG == pCanFrame->data[4]) && (UPLOAD_OK_DATA_5 == pCanFrame->data[5]))
	{
		g_stDspLog.bUploadFinish = true;
	}
	if (g_stAgvTask.stAction.iType != u8Action)
	{
		LOG_WRN("recv action[%d-%s] finish, expect action[%d-%s] finish can frame\n",
			u8Action, get_mc_cmd_name(u8Action),
			g_stAgvTask.stAction.iType, get_mc_cmd_name(g_stAgvTask.stAction.iType));

		return;
	}

	// add by kedong, 20180202
	// in MCv2, maybe loss ACK frame, so g_stAgvTask.stAction.iResult = REFUSE will not change
	// add by jxu 20180411:begin
	if (g_stAgvTask.stAction.iResult == REFUSE)
	{
		LOG_WRN("Maybe loss ACK frame when receive the finishment frame\n");
		g_stAgvTask.stAction.iResult = OK;
	}
	// add by jxu 20180411:end

	LOG_INF("recv action[%d-%s] finish can frame\n", u8Action, get_mc_cmd_name(u8Action));
	if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
	{
		LOG_ERR("post %s sem failed\n", get_action_name(g_stAgvTask.stAction.iType));
	}
}

/*******************************************************************************
* Function Name		 : deal_tc_completion
* Description	     : deal with TC completion and send msg to console
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void deal_tc_completion(struct can_frame * pCanFrame)
{
	u8 u8Action = 0;
	u8 u8Style = 0;

	if (pCanFrame == NULL)
		return;

	g_stTcDev.deal_fin(pCanFrame, &g_stAgvAttr);
	u8Action = (u8)g_stAgvAttr.iTcAction;
	u8Style = (u8)g_stAgvAttr.iTcStyle;
	if ((TC_UPLOAD_LOG_OK == pCanFrame->data[6]) && (TC_UPLOAD_LOG_FLAG == pCanFrame->data[4]) && (UPLOAD_OK_DATA_5 == pCanFrame->data[5]))
	{
		g_stDspLog.bUploadFinish = true;
	}
	if (4 != u8Style) //whether a tc action finish
	{
		LOG_INF("recieve unknown TC completion msg\n");
		return;
	}

	if (g_stAgvTask.stAction.iType != u8Action)
	{
		LOG_WRN("recv action[%d-%s] finish, expect action[%d-%s] finish can frame\n",
			u8Action, get_tc_cmd_name(u8Action),
			g_stAgvTask.stAction.iType, get_tc_cmd_name(g_stAgvTask.stAction.iType));

		return;
	}

	LOG_INF("receive [%d-%s] finish can frame\n", u8Action, get_tc_cmd_name(u8Action));
	if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
	{
		LOG_ERR("post %s sem failed\n", get_action_name(g_stAgvTask.stAction.iType));
	}
}

char* get_flag_name(u8 u8Key)
{
	char *pStr = NULL;
	switch (u8Key)
	{
	case MC_CLEAR_DERAIL_F:
		pStr = "MC_CLEAR_DERAIL_F";
		break;
	case MC_CLEAR_NAVIGATE_F:
		pStr = "MC_CLEAR_NAVIGATE_F";
		break;
	case MC_CLEAR_LCODER_ERROR_F:
		pStr = "MC_CLEAR_LCODER_ERROR_F";
		break;
	case MC_CLEAR_RCODER_ERROR_F:
		pStr = "MC_CREAR_LCODER_ERROR_F";
		break;
	case  GET_MC_LOG_DATA:
		pStr = "GET_MC_LOG_DATA";
		break;
	default:
		pStr = "INVALID FLAG VALUE";
		break;
	}
	return pStr;
}

/*******************************************************************************
* Function Name		 : deal_mc_ack
* Description	     : deal with MC ACK msg, and send finish msg to console
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void deal_mc_ack(struct can_frame * pCanFrame)
{
	u8 u8Action = 0;
	u8 u8Style = 0;
	u16 u16Status = 0;

	if (pCanFrame == NULL)
		return;

	g_stMcDev.deal_ack(pCanFrame, &g_stAgvAttr);
	u8Action = (u8)g_stAgvAttr.iMcAction;
	u8Style = (u8)g_stAgvAttr.iMcStyle;
	u16Status = (u16)g_stAgvAttr.iMcState;

	switch (u8Style)
	{
	case MC_GET_FLAG:
		//modified by kedong, 20180130
		//if recv get flag/param'ACK, means OK
		g_stAgvTask.stAction.iResult = OK;
		if (MC_VERSION_F == g_stAgvAttr.stMcProperty.key) //get version
		{
			g_stAgvAttr.iMcVersion = g_stAgvAttr.stMcProperty.value & 0xffff;
			g_stAgvAttr.iDSPGeneration = g_stAgvAttr.stMcProperty.value >> 16;
			g_stMcDev.iGeneration = g_stAgvAttr.stMcProperty.value >> 16;
			agv_sem_post(SEM_CAN_TYPE, SEM_MC_BASE+MC_VERSION_F, 0);
		}
		break;
	case MC_SET_FLAG:
		//modified by kedong, 20180130
		//if recv set flag/param'ACK, means OK
		//g_stAgvTask.stAction.iResult = u16Status;
		g_stAgvTask.stAction.iResult = OK;
		if (GET_MC_LOG_DATA  == g_stAgvAttr.stMcProperty.key)
		{
			agv_sem_post(SEM_CAN_TYPE, SEM_MC_BASE + FTP_MC_CANFRAME_F, 0);
		}
		LOG_INF("Get %s ACK\n",get_flag_name(g_stAgvAttr.stMcProperty.key));
		break;
	case MC_GET_PARAM:
		LOG_INF("get MC_TYPE_GET_V1_PARAM[%d]=%f ACK\n", g_stAgvAttr.stMcPropertyPram.key, g_stAgvAttr.stMcPropertyPram.value);
		agv_sem_post(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_READ_V2_PARAM, g_stAgvAttr.stMcPropertyPram.key);
		break;
	case MC_SET_PARAM:
		LOG_INF("get MC_TYPE_SET_V1_PARAM[%d]=%f ACK\n", g_stAgvAttr.stMcPropertyPram.key, g_stAgvAttr.stMcPropertyPram.value);
		agv_sem_post(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_SET_V2_PARAM, g_stAgvAttr.stMcPropertyPram.key);
		break;
	case MC_OPERATE:
		g_stAgvTask.stAction.iResult = u16Status;
		if (OK == u16Status) // ACCEPT ACK
		{
			LOG_INF("receive MC'ACK:cmd[%d-%s], and accept this cmd\n", u8Action, get_mc_cmd_name(u8Action));
			// why use CAN.ACK as finish for charge or stop charge power??
			if ((MC_BEGIN_CHARGE == u8Action) || (MC_STOP_CHARGE == u8Action)) //action =5(charge)
			{
				if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
				{
					LOG_ERR("post %s sem failed\n",get_action_name(g_stAgvTask.stAction.iType));
				}
			}
			
		}
		else if (REFUSE == u16Status) // REFUSE ACK
		{
			
			LOG_INF("received MC'ACK:refuse this cmd!\n");

			if(MC_GO_FORWARD == u8Action)
				atomic_set(&g_stAgvAttr.iAckException, EVENT_ERR_MCREFUSE);//add by jxu 0524
			if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
			{
				LOG_ERR("post %s sem failed\n", get_action_name(g_stAgvTask.stAction.iType));
			}
		}
		else if (BERROR == u16Status)
		{
			LOG_INF("received MC'ACK:mc is has error!\n");

			if(MC_GO_FORWARD == u8Action)
				atomic_set(&g_stAgvAttr.iAckException, EVENT_ERR_PARKPRECISION);//add by jxu 0524
			if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
			{
				LOG_ERR("post %s sem failed\n", get_action_name(g_stAgvTask.stAction.iType));
			}
		}
		break;
	default:
		LOG_INF("received MC'ACK :nothing to do\n");
		break;
	}

}

/*******************************************************************************
* Function Name		 : deal_mc_v2_ack
* Description	     : deal with MC ACK msg, and send finish msg to console
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void deal_mc_v2_ack(struct can_frame * pCanFrame)
{
	struct mc_can_action_ack *req = (struct mc_can_action_ack*)pCanFrame;
	int iRet = req->iRetInfo;
	int iCmd = req->iAction;

	g_stAgvTask.stAction.iResult = iRet;
	if (iRet == MC_ACTION_ACK_OK_V2)
	{
		g_stAgvTask.stAction.iResult = OK;
		if (iCmd == MC_CAN_CMD_PARK_V2)
		{
			LOG_INF("[MCU ACK]:Response success to MC_CAN_CMD_PARK\n");
			if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
			{
				LOG_ERR("post %s sem failed\n", get_action_name(g_stAgvTask.stAction.iType));
			}
		}
		else if (iCmd == MC_CAN_CMD_STOPPARK_V2)
		{
			LOG_INF("[MCU ACK]:Response success to MC_CAN_CMD_STOPPARK\n");
			if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
			{
				LOG_ERR("post %s sem failed\n", get_action_name(g_stAgvTask.stAction.iType));
			}
		}
		else if(iCmd == MC_CAN_CMD_RESTART_V2)
		{
			LOG_INF("[MCU ACK]:Response success to MC_CAN_CMD_RESTART_V2\n");
			if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
			{
				LOG_ERR("post %s sem failed\n", get_action_name(g_stAgvTask.stAction.iType));
			}
		}
		else
		{
			LOG_INF("[MCU ACK]:Response success\n");
		}
	}
	else if (iRet == MC_ACTION_ACK_PARAM_ERR_V2)
	{
		LOG_INF("[MCU ACK]:Parameter is error\n");

		if (MC_CAN_CMD_GOFORWARD_V2 == iCmd)
			atomic_set(&g_stAgvAttr.iAckException, EVENT_ERR_PARAM_ERROR);//add by jxu 0524
		if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
		{
			LOG_ERR("post iCmd=%d sem failed\n", iCmd);
		}
	}
	else if (iRet == MC_ACTION_ACK_MC_ERR_V2)
	{
		LOG_INF("[MCU ACK]:MCU is error\n");

		if (MC_CAN_CMD_GOFORWARD_V2 == iCmd)
			atomic_set(&g_stAgvAttr.iAckException, EVENT_ERR_MC_EXCEPTION);//add by jxu 0524
		if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
		{
			LOG_ERR("post iCmd=%d sem failed\n", iCmd);
		}
	}
	else if (iRet == MC_ACTION_ACK_PARK_PRECESION_ERR_V2)
	{
		LOG_INF("[MCU ACK]:Parking precision cannot meet to the parking request\n");

		if (MC_CAN_CMD_GOFORWARD_V2 == iCmd)
			atomic_set(&g_stAgvAttr.iAckException, EVENT_ERR_PARKPRECISION);//add by jxu 0524
		if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
		{
			LOG_ERR("post iCmd=%d sem failed\n", iCmd);
		}
	}
	else if (iRet == MC_ACTION_ACK_PLATE_UP_LEVEL_V2)
	{
		LOG_INF("[MCU ACK]:Plate is jack status but still recv the jack cmd and prepare to snd the complete\n");
		if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
		{
			LOG_ERR("post iCmd=%d sem failed\n", iCmd);
		}
	}
	else if (iRet == MC_ACTION_ACK_PLATE_DOWN_LEVEL_V2)
	{
		LOG_INF("[MCU ACK]:Plate is down status but still recv the down cmd and prepare to snd the complete\n");
		if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
		{
			LOG_ERR("post iCmd=%d sem failed\n", iCmd);
		}
	}
	else if (iRet == MC_ACTION_ACK_REFUSE_V2)
	{
		LOG_INF("[MCU ACK]:received MC'ACK:refuse this cmd!\n");
	
		if (MC_CAN_CMD_GOFORWARD_V2 == iCmd)
			atomic_set(&g_stAgvAttr.iAckException, EVENT_ERR_MCREFUSE);//add by jxu 0524
		if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
		{
			LOG_ERR("post iCmd=%d sem failed\n", iCmd);
		}
	}
	else if (iRet == MC_ACTION_OTHER_ERR_V2)
	{
		LOG_INF("[MCU ACK]:MCU other error\n");
	}

	print_can_frame(pCanFrame);
}

#define MC_V2_WHEEL_CALSP          (0x1)
#define MC_V2_PALLET_CALSP		   (0x1)
#define MC_V2_CLEAR_DERAIL_FLAG    (0x03)
#define MC_V2_CLEAR_NAVIGATE_FLAG  (0x04)
#define MC_V2_WHELL_CLASP_FLAG	   (0x08)
#define MC_V2_PALLET_CLASP_FLAG    (0x09)
#define MC_V2_CLEAR_LCODER_ERROR   (0x0B)
#define MC_V2_CLEAR_RCODER_ERROR   (0x0C)

/*******************************************************************************
*Function Name    :get_mc_v2_flag_name
*Description      :  
*Input       	  :u16 u16Key  
*Input       	  :u32 u32Value  
*Output 		  :
*Return           :char*  
*******************************************************************************/
char* get_mc_v2_flag_name(u16 u16Key, u32 u32Value)
{
	char *pStr = NULL;

	switch (u16Key)
	{
	case MC_V2_CLEAR_DERAIL_FLAG:
		pStr = "CLEAR_DERAIL_FLAG";
		break;
	case MC_V2_CLEAR_NAVIGATE_FLAG:
		pStr = "CLEAR_NAVIGATE_FLAG";
		break;
	case  MC_V2_WHELL_CLASP_FLAG:
		pStr = (MC_V2_WHEEL_CALSP == u32Value) ? "WHELL_CLASP_FLAG" : "WHELL_UNCLASP_FLAG";
		break;
	case  MC_V2_PALLET_CLASP_FLAG:
		pStr = (MC_V2_PALLET_CALSP == u32Value) ? "PALLET_CLASP_FLAG" : "PALLET_UNCLASP_FLAG";
		break;
	case MC_V2_CLEAR_LCODER_ERROR:
		pStr = "CLEAR_LCODER_ERROR";
		break;
	case MC_V2_CLEAR_RCODER_ERROR:
		pStr = "CLEAR_RCODER_ERROR";
		break;
	default:
		pStr = "INVALID_FLAG";
		break;
	}
	return	pStr;
}

/*******************************************************************************
* Function Name		 : deal_mc_rw_flag_param_v2_ack
* Description	     : deal with MC ACK msg, and send finish msg to console
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void deal_mc_rw_flag_param_v2_ack(struct can_frame * pCanFrame)
{
	mc_can_rw_flag_param_ack_st *ack = (mc_can_rw_flag_param_ack_st*)pCanFrame;
	int iCmd = ack->iCmd;
	int iPramId = ack->iParamId;
	int iPramVaule = ack->iParamVal;
	float fPramValue = *((float *)(&ack->iParamVal));
	static int s_iMcMacLowByte = 0;
	switch (iCmd)
	{
	case MC_TYPE_READ_V2_FLAG:
		//modified by kedong, 20180130
		//if recv get flag/param'ACK, means OK
		g_stAgvTask.stAction.iResult = OK;
		g_stAgvAttr.stMcProperty.key = iPramId;//by tiger.42
		g_stAgvAttr.stMcProperty.value = iPramVaule; //by tiger.42
		LOG_INF("get MC_TYPE_READ_V2_FLAG[%d]=%d ACK\n", iPramId, iPramVaule);
		if (MC_PLATE_STATUS_KEY_V2_F == iPramId)
		{
			g_stAgvAttr.iPalletStatus = iPramVaule;
			agv_sem_post(SEM_CAN_TYPE, SEM_TC_BASE + PALLET_STATUS_F, 0);
		}
		///start ,by tiger.66
		else if (MC_MAC_L_3_BYTE == iPramId)
		{
			s_iMcMacLowByte = iPramVaule;
		}
		else if (MC_MAC_H_3_BYTE == iPramId)
		{
			sprintf(g_stAgvAttr.pMcMAC, "%.6x%.6x", iPramVaule, s_iMcMacLowByte);
			LOG_INF("the MAC address of mc is : %s\n", g_stAgvAttr.pMcMAC);
			s_iMcMacLowByte = 0;
		}
		///end by tiger.66
		break;
	case  MC_TYPE_SET_V2_FLAG:
		//modified by kedong, 20180130
		//if recv set flag/param'ACK, means OK
		//g_stAgvTask.stAction.iResult = iPramVaule;
		g_stAgvTask.stAction.iResult = OK;
		g_stAgvAttr.stMcProperty.key = iPramId;//by tiger.42
		g_stAgvAttr.stMcProperty.value = iPramVaule; //by tiger.42
		LOG_INF("get MC_TYPE_SET_V2_FLAG[%d-%s]=%d ACK\n", iPramId, get_mc_v2_flag_name(iPramId, iPramVaule), iPramVaule);
		if ((MC_V2_CLEAR_DERAIL_FLAG == iPramId) || (MC_V2_CLEAR_NAVIGATE_FLAG == iPramId)||
			(MC_V2_CLEAR_LCODER_ERROR == iPramId) || (MC_V2_CLEAR_RCODER_ERROR == iPramId))
		{
			_sem_post(&g_stAgvTask.stAction.stActSem);
		}		
		break;
	case MC_TYPE_READ_V2_PARAM:
		LOG_INF("get MC_TYPE_READ_V2_PARAM[%d]=%f ACK\n", iPramId, fPramValue);
		g_stAgvAttr.stMcPropertyPram.key = iPramId;//by tiger.42
		g_stAgvAttr.stMcPropertyPram.value = fPramValue; //by tiger.42
		agv_sem_post(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_READ_V2_PARAM, iPramId);
		break;
	case MC_TYPE_SET_V2_PARAM:
		LOG_INF("get MC_TYPE_SET_V2_PARAM[%d]=%f ACK\n", iPramId, fPramValue);
		g_stAgvAttr.stMcPropertyPram.key = iPramId;//by tiger.42
		g_stAgvAttr.stMcPropertyPram.value = fPramValue; //by tiger.42
		agv_sem_post(SEM_CAN_TYPE, SEM_MC_BASE + MC_TYPE_SET_V2_PARAM, iPramId);
		break;
	default:
		break;
	}
	
	print_can_frame(pCanFrame);
}

/*******************************************************************************
*Function Name    :deal_tc_upload
*Description      :  
*Input       	  :struct can_frame * pCanFrame  
*Output 		  :NONE
*Return           :NONE  
*******************************************************************************/
void deal_tc_upload(struct can_frame * pCanFrame)
{
	if (pCanFrame == NULL)
		return;

	if (g_stDspLog.iSize >= ONE_MB)
	{
		LOG_ERR("the receive ram data buffer is full\n");
		return;
	}

	if (pCanFrame->data != NULL)
	{
		memcpy(&g_stDspLog.u8RamData[g_stDspLog.iSize], pCanFrame->data, 8);
		g_stDspLog.iSize += 8;
	}	

	return;
}

/*******************************************************************************
*Function Name    :deal_mc_upload
*Description      :  
*Input       	  :struct can_frame * pCanFrame  
*Output 		  :NONE
*Return           :NONE  
*******************************************************************************/
void deal_mc_upload(struct can_frame * pCanFrame)
{
	if (pCanFrame == NULL)
		return;

	if (g_stDspLog.iSize >= ONE_MB)
	{
		LOG_ERR("the receive ram data buffer is full\n");
		return;
	}

	if (pCanFrame->data != NULL)
	{
		memcpy(&g_stDspLog.u8RamData[g_stDspLog.iSize], pCanFrame->data, 8);
		g_stDspLog.iSize += 8;
	}

	return;
}

/*******************************************************************************
* Function Name		 : deal_mc_angle_v2_ack
* Description	     : deal with angle ack of MC
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void deal_mc_angle_v2_ack(struct can_frame * pCanFrame)
{
	if (pCanFrame == NULL)
		return;

	LOG_INF("deal mc angle ack can frame\n");
	print_can_frame(pCanFrame);

	agv_sem_post(SEM_CAN_TYPE, ARM2TC_ANGLE_ACK, 0);
}

/*******************************************************************************
* Function Name		 : deal_tc_ack
* Description	     : deal with MC ACK msg, and send finish msg to console
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void deal_tc_ack(struct can_frame * pCanFrame)
{
	u16 u16Status = 0;
	u8 u8Action = 0;
	u8 u8Style = 0;

	if (pCanFrame == NULL)
		return;

	g_stTcDev.deal_ack(pCanFrame, &g_stAgvAttr);
	u8Action = (u8)g_stAgvAttr.iTcAction;
	u8Style = (u8)g_stAgvAttr.iTcStyle;
	u16Status = (u16)g_stAgvAttr.iTcState;

	switch (u8Style)
	{
	case TC_SET_FLAG:
		if (TC_CLASP_F == g_stAgvAttr.stTcProperty.key	)//set clasp 
		{
			LOG_INF("received TC ACK:set the agv into %s state\n", (0 == (g_stAgvAttr.stTcProperty.value & 0xff)) ? "unclasp" : "clasp");		
		}
		else if (PALLET_STATUS_F == g_stAgvAttr.stTcProperty.key)//set pallet status
		{
			g_stAgvAttr.iPalletStatus = g_stAgvAttr.stTcProperty.value & 0xff;
			LOG_INF("received TC ACK:set the agv into %s state\n", (1 == g_stAgvAttr.iPalletStatus) ? "top" : "down");
		}
		else if (GET_TC_LOG_DATA == g_stAgvAttr.stTcProperty.key)
		{
			agv_sem_post(SEM_CAN_TYPE, SEM_TC_BASE + FTP_TC_CANFRAME_F, 0);
		}
		break;
	case TC_GET_FLAG:
		if (TC_VERSION_F == g_stAgvAttr.stTcProperty.key) //get version
		{
			g_stAgvAttr.iTcVersion = g_stAgvAttr.stTcProperty.value & 0xffff; //by tige.17
			g_stTcDev.iGeneration = g_stAgvAttr.stTcProperty.value >> 16; //by tiger.17
			agv_sem_post(SEM_CAN_TYPE, SEM_TC_BASE + TC_VERSION_F, 0);			
		}
		if (PALLET_STATUS_F == g_stAgvAttr.stTcProperty.key) //get pallet status
		{
			g_stAgvAttr.iPalletStatus = g_stAgvAttr.stTcProperty.value;
			agv_sem_post(SEM_CAN_TYPE, SEM_TC_BASE + PALLET_STATUS_F, 0);
		}
		break;
	case TC_OPERATE:
		g_stAgvTask.stAction.iResult = u16Status;
		if (OK == u16Status)
		{
			LOG_INF("received TC'ACK:%s\n", get_tc_cmd_name(u8Action));
		}
		else if (IS_UP == u16Status)
		{
			LOG_INF("received TC'ACK:pallet is in top limit state\n");
			if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
			{
				LOG_ERR("post %s sem failed\n", get_action_name(g_stAgvTask.stAction.iType));
			}
		}
		else if (IS_DOWN == u16Status)
		{
			LOG_INF("received TC'ACK:pallet is in down limit state\n");
			if (_sem_post(&g_stAgvTask.stAction.stActSem) < 0)
			{
				LOG_ERR("post %s sem failed\n", get_action_name(g_stAgvTask.stAction.iType));
			}
		}
		break;
	default:
		//this log is printed in tc_v1.c tc_v1_deal_ack()
		//LOG_INF("received TC'ACK :noting to do\n");
		break;
	}
}

/*******************************************************************************
* Function Name		 : deal_mc_exception
* Description	     : deal with the exceptions of MC
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : 0 if no event ,else event value
*******************************************************************************/
int deal_mc_exception(struct can_frame * pCanFrame)
{
	int iRet = 0;
	int iError = 0;

	if (pCanFrame == NULL)
		return -1;

	iRet = g_stMcDev.deal_exception(pCanFrame, &g_stAgvAttr);
	// modified by kedong, 20180301
	// if error event continuously happen
	// is necessary to send error msg continuously? NO
	if (iRet < 0)
	{
		iError = g_stAgvAttr.iMcError;

		if (iError != 0)
			LOG_WRN("receive mc event[%d-%s]!\n", iError, get_err_str(iError));

		atomic_set(&g_stAgvAttr.iException, iError);//by tiger.67

		return -iError;
	}
	
	return 0; //by tiger.106
}

/*******************************************************************************
* Function Name		 : deal_tc_exception
* Description	     : deal with the exceptions of TC
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : 0 if no event ,else event value
*******************************************************************************/
int deal_tc_exception(struct can_frame * pCanFrame)
{
	int iRet = 0;
	int iError = 0;

	if (pCanFrame == NULL)
		return -1;

	iRet = g_stTcDev.deal_exception(pCanFrame, &g_stAgvAttr);
	// modified by kedong, 20180301
	// if error event continuously happen
	// is necessary to send error msg continuously? NO
	if (iRet < 0)
	{
		iError = g_stAgvAttr.iTcError;

		if (iError != 0)
			LOG_WRN("receive tc event[%d-%s] !\n", iError, get_tc_evnet_desc(iError));

		atomic_set(&g_stAgvAttr.iException, iError);//by tiger.67
		return -iError;
	}
	else
	{
		return 0;
	}
}

/*******************************************************************************
* Function Name		 : deal_tc_angle_ack
* Description	     : deal with angle ack of TC
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void deal_tc_angle_ack(struct can_frame * pCanFrame)
{
	if (pCanFrame == NULL)
		return;

	g_stTcDev.deal_angle_ack(pCanFrame, &g_stAgvAttr);
	agv_sem_post(SEM_CAN_TYPE, ARM2TC_ANGLE_ACK, 0);
}

/*******************************************************************************
* Function Name		 : get_pallet_info
* Description	     : save pallet direction in the g_stAgvAttr.iPalletDirect ,
                     : angle offset in the g_stAgvAttr.iGAngleOffset,
                     : and container number in g_stAgvAttr.cContainer
* input			     : NONE
* Output		     : NONE
* Return		     : 0 if OK, -1 on error 
*******************************************************************************/
int get_pallet_info(void)
{
	int iRet = 0;
	float fAngle = 0.0;

	iRet = g_stTopCameraDev.get_qrinfo(&g_stQrInfo);
	if (iRet != 0)
	{
		LOG_ERR("get pallet QR failed\n");
		return -1;
	}

	fAngle = g_stQrInfo.fAngle;
	if ((fAngle > -45) && (fAngle < 45))
	{
		g_stAgvAttr.iPalletDirect = g_stAgvAttr.iVehHeadDirect;
	}
	else if ((fAngle > -135) && (fAngle < -45))
	{
		g_stAgvAttr.iPalletDirect = (g_stAgvAttr.iVehHeadDirect == DIRECTION_X_P) ? DIRECTION_Y_N : (g_stAgvAttr.iVehHeadDirect - 1);
	}
	else if ((fAngle > 45) && (fAngle < 135))
	{
		g_stAgvAttr.iPalletDirect = (g_stAgvAttr.iVehHeadDirect == DIRECTION_Y_N) ? DIRECTION_X_P : (g_stAgvAttr.iVehHeadDirect + 1);
	}
	else if ((fAngle > 135) && (fAngle < 181))
	{
		g_stAgvAttr.iPalletDirect = (g_stAgvAttr.iVehHeadDirect + 2) % 4;
	}
	else if ((fAngle > -181) && (fAngle < -135))
	{
		g_stAgvAttr.iPalletDirect = (g_stAgvAttr.iVehHeadDirect + 2) % 4;
	}
	else
	{
		LOG_WRN("pallet angle offset =%.2f, TOO big\n", fAngle);
	}

	//add by jxu 20180226:begin
	if (g_stTopCameraDev.iVersion == CAMERA_VERSION_UART)
	{
		g_stAgvAttr.iTAngleOffset = (fAngle + 180) * 100;
		LOG_INF("pallet QR[%s], PalletAngleOffset=%.2f, AgvHeadDirect=[%d-%s], PalletDirect=[%d-%s]\n",
			g_stAgvAttr.cContainer, (float)g_stAgvAttr.iTAngleOffset / 100,
			g_stAgvAttr.iVehHeadDirect, get_direct_desc(g_stAgvAttr.iVehHeadDirect),
			g_stAgvAttr.iPalletDirect, get_direct_desc(g_stAgvAttr.iPalletDirect));
	}
	else if (g_stTopCameraDev.iVersion == CAMERA_VERSION_V4L2)
	{
		int iFinalAngle = 0;
		if (fAngle > 0)
		{
			iFinalAngle = fAngle * 10 + 0.5;
		}
		else if (fAngle < 0)
		{
			iFinalAngle = (fAngle + 360) * 10 + 0.5;
		}
		else
		{
			iFinalAngle = fAngle;
			LOG_INF("iFinalAngle is 0.iFinalAngle=%d\n", iFinalAngle);
		}
		g_stAgvAttr.iTAngleOffset = iFinalAngle;
		LOG_INF("pallet QR[%s], PalletAngleOffset=%.1f, AgvHeadDirect=[%d-%s], PalletDirect=[%d-%s]\n",
			g_stAgvAttr.cContainer, (float)g_stAgvAttr.iTAngleOffset / 10,
			g_stAgvAttr.iVehHeadDirect, get_direct_desc(g_stAgvAttr.iVehHeadDirect),
			g_stAgvAttr.iPalletDirect, get_direct_desc(g_stAgvAttr.iPalletDirect));
	}
	//add by jxu 20180226:end

	return 0;
}

/*******************************************************************************
* Function Name      : mc_get_version
* Description	     : get mc software'version
* Input 		     : NONE
* Output		     : pVersion: the version of mc
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int mc_get_version(int * pGeneration)
{
	int iTimeOut = 40000; // ms
	int iCount = 0;
	struct can_frame stCanFrame = { 0 };

	if (pGeneration == NULL)
		return -1;

	stCanFrame.can_id  = MC_CANID_REQ;
	stCanFrame.can_dlc = MC_DATA_DLC;
	stCanFrame.data[4] = MC_VERSION_F;
	stCanFrame.data[6] = MC_TYPE_READ_F;
	stCanFrame.data[7] = get_seq(MC_SEQ_ID);

	// get mc'version by protocol v1
	LOG_INF("send to can:get mc version by protocol v1\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		LOG_ERR("send get mc version can frame failed\n");
		return -1;
	}

	// add by jxu 20180115:Search the two generation version begin
	struct mc_can_rw_flag_param_req stReq = {
		.iCanId = MC_CAN_FLAG_PARAM_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID),
		.iCmd = MC_TYPE_READ_V2_FLAG,
		.iParamId = MC_VERSION_KEY_V2_F,
		.iParamVal = MC_CAN_RESERVE_V2,
	};

	// get mc'version by protocol v2
	LOG_INF("send to can:get mc version by protocol v2\n");
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(struct can_frame))
	{
		LOG_ERR("send check Second generation mc version can frame failed\n");
		return -1;
	}

	// add by jxu 20180115:Search the two generation version end
	while (iTimeOut--)
	{
		bzero(&stCanFrame, sizeof(stCanFrame));
		iCount = recv_can(CTRL_CAN_DEV, &stCanFrame);
		if (iCount != sizeof(struct can_frame)) {
			//LOG_WRN("control can recv error[%s]\n", strerror(errno));
			usleep(1000);
			continue;
		}

		int iCanId = stCanFrame.can_id;
		if (MC_CANID_ACK == iCanId)
		{
			//u8 iMcAction = (u8)stCanFrame.data[5];//cmd
			u8 iMcStyle = (u8)stCanFrame.data[6];//Style;
			u8 key = stCanFrame.data[4]; //key;
			int value = *((int*)&stCanFrame.data[0]); //value;

			if ((MC_CANID_ACK == iCanId) && (MC_GET_FLAG == iMcStyle) && (MC_VERSION_F == key)) {
				g_stAgvAttr.iMcVersion = value & 0xffff;
				g_stAgvAttr.iDSPGeneration = value >> 16;
				g_stMcDev.iGeneration = value >> 16;
				print_can_frame(&stCanFrame);

				LOG_INF("get mc generation=%d version=%d success\n",
					g_stAgvAttr.iDSPGeneration , g_stAgvAttr.iMcVersion);
				*pGeneration = g_stMcDev.iGeneration; //by tiger.17
				break;
			}
		}
		// add by jxu 20180115:get the two generation version begin
		else if (MC_CAN_FLAG_PARAM_ACK_V2_CANID == iCanId)
		{
			u8 iMcStyle = (u8)stCanFrame.data[6];//Style;
			u8 iKey = stCanFrame.data[4]; //key;
			if ((MC_TYPE_READ_V2_FLAG == iMcStyle) && (MC_VERSION_KEY_V2_F == iKey))
			{
				mc_can_rflag_version_ack_st *pVerReq = (mc_can_rflag_version_ack_st *)&stCanFrame;

				int iMajorVerId = pVerReq->iMajorVerId;
				int iMinorVerId = pVerReq->iMinorVerId;
				int iModifyVerId = pVerReq->iModifyVerId;
				LOG_INF("[MCU ACK]:MCU iMajorVerId=%d iMinorVerId=%d iModifyVerId=%d\n", iMajorVerId, iMinorVerId, iModifyVerId);
				char sMCVersion[64] = { 0 };

				sprintf(sMCVersion, "%02x%02x%02x", iMajorVerId, iMinorVerId, iModifyVerId);
				sscanf(sMCVersion, "%d", &g_stAgvAttr.iMcVersion);
				g_stAgvAttr.iDSPGeneration = iMajorVerId;
				g_stMcDev.iGeneration = iMajorVerId;
				print_can_frame(&stCanFrame);

				LOG_INF("get the second generation mc version ok Mc.Version = %d\n", g_stMcDev.iGeneration);
				*pGeneration = g_stMcDev.iGeneration;
				break;
			}
		}
		// add by jxu 20180115:get the two generation version begin
	}

	if (iTimeOut <= 0)
	{
		LOG_WRN("get mc version timeout\n");
		*pGeneration = GENERATION_ERR;
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name      : tc_get_version
* Description	     : get tc software'version
* Input 		     : NONE
* Output		     : pVersion: the version of tc
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int tc_get_version(int * pGeneration)
{
	int iTimeOut = 4000; // ms
	int iCount = 0;
	struct can_frame stCanFrame = { 0 };

	if (pGeneration == NULL)
		return -1;

	stCanFrame.can_id = TC_CANID_REQ;
	stCanFrame.can_dlc = TC_DATA_DLC;
	stCanFrame.data[4] = TC_VERSION_F;
	stCanFrame.data[6] = TC_TYPE_READ_F;
	stCanFrame.data[7] = get_seq(TC_SEQ_ID);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		LOG_ERR("send check tc version can frame failed\n");
		return -1;
	}

	while (iTimeOut--)
	{
		bzero(&stCanFrame, sizeof(struct can_frame));
		iCount = recv_can(CTRL_CAN_DEV, &stCanFrame);
		if (iCount != sizeof(stCanFrame)) {
			//LOG_WRN("control can recv error[%s]\n", strerror(errno));
			usleep(1000);
			continue;
		}

		int iCanId = stCanFrame.can_id;
		//u8 iTcAction = (u8)stCanFrame.data[5];//cmd
		u8 iTcStyle = (u8)stCanFrame.data[6];//Style;
		u8 key = stCanFrame.data[4]; //key;
		int value = *((int*)&stCanFrame.data[0]); //value;
		if ((TC_CANID_ACK == iCanId) && (TC_GET_FLAG == iTcStyle) && (TC_VERSION_F == key)) {
			g_stAgvAttr.iTcVersion = value & 0xffff;
			g_stAgvAttr.iDSPGeneration = value >> 16;
			g_stTcDev.iGeneration = value >> 16;

			LOG_INF("get tc generation=%d version=%d success\n",
				g_stAgvAttr.iDSPGeneration, g_stAgvAttr.iTcVersion);
			*pGeneration = g_stTcDev.iGeneration; //by tiger.17
			break;
		}
	}

	if (iTimeOut <= 0)
	{
		LOG_WRN("get tc version timeout, default=GENERATION_1P0\n");
		*pGeneration = GENERATION_ERR;
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : init_mc_dev
* Description	     : deal with angle ack of TC
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : 0 if OK, -1 on error
*******************************************************************************/
int init_mc_dev(mc_dev_t *pMcDev)
{
	int iRet = 0;
	int iGeneration = 0;

	if (pMcDev == NULL)
		return -1;

	iRet = mc_get_version(&iGeneration);
	if (iRet < 0)
		LOG_WRN("get mc version failure\n");

	pMcDev->iGeneration = iGeneration;
	pMcDev->iWorkMode = WORK_MODE_NORMAL;
	pMcDev->iMcHeartBeatTs = 0;

	if ((pMcDev->iGeneration <= GENERATION_1P0) && (pMcDev->iGeneration != GENERATION_ERR))
	{
		g_stAgvAttr.iAGVType = AGV1_0;//tiger.97
		pMcDev->check_version = mc_v1_check_version;
		pMcDev->get_flag = mc_v1_get_flag;
		pMcDev->set_flag = mc_v1_set_flag;
		pMcDev->get_param = mc_v1_get_param;
		pMcDev->set_param = mc_v1_set_param;
		pMcDev->enable_wdg = mc_v1_enable_wdg;
		pMcDev->start = mc_v1_start;
		pMcDev->reset = mc_v1_reset;
		pMcDev->stop = mc_v1_stop;
		pMcDev->deal_ack = mc_v1_deal_ack;
		pMcDev->deal_fin = mc_v1_deal_fin;
		pMcDev->deal_heartbeat = mc_v1_deal_heartbeat;
		pMcDev->deal_exception = mc_v1_deal_exception;
		pMcDev->start_charge = mc_v1_start_charge;
		pMcDev->stop_charge = mc_v1_stop_charge;
		pMcDev->go_forward = mc_v1_go_forward;
		pMcDev->go_backward = mc_v1_go_backward;
		pMcDev->turn_left = mc_v1_turn_left;
		pMcDev->turn_right = mc_v1_turn_right;
		///start ,add by tiger.10
		pMcDev->mc_slow_go_back = mc_v1_slow_go_back;
		pMcDev->mc_slow_go_straight = mc_v1_slow_go_straight;
		pMcDev->mc_leftarc = mc_v1_leftarc;
		pMcDev->mc_rightarc = mc_v1_rightarc;
		pMcDev->clear_derail = mc_v1_clear_derail;
		pMcDev->clear_navigation = mc_v1_clear_navigation;
		pMcDev->clear_lcoder_error = mc_v1_clear_lcoder_error;
		pMcDev->clear_rcoder_error = mc_v1_clear_rcoder_error;
		pMcDev->enter_debug_mode = mc_v1_enter_debug_mode;
		pMcDev->quit_debug_mode = mc_v1_quit_debug_mode;
		pMcDev->clasp_pallet = mc_v1_clasp_pallet;
		pMcDev->unclasp_pallet = mc_v1_unclasp_pallet;
		pMcDev->clasp_wheel = mc_v1_clasp_wheel;
		pMcDev->unclasp_wheel = mc_v1_unclasp_wheel;
		///end ,add by tiger.10
		
	}
	else if ((pMcDev->iGeneration <= GENERATION_2P0) && (pMcDev->iGeneration > GENERATION_1P0))
	{
		g_stAgvAttr.iAGVType = AGV2_0;//tiger.97
		//TODO
		//TODO
		//pMcDev->check_version = mc_v2_check_version;
		pMcDev->get_flag = mc_v2_get_flag;
		pMcDev->set_flag = mc_v2_set_flag;//by tiger.41
		pMcDev->get_param = mc_v2_get_param;
		pMcDev->set_param = mc_v2_set_param;
		pMcDev->enable_wdg = mc_v2_restart;
		//pMcDev->start = mc_v2_start;
		pMcDev->reset = mc_v2_restart;
		pMcDev->stop = mc_v2_stop;
		//pMcDev->deal_ack = mc_v2_deal_ack;
		pMcDev->deal_fin = mc_v2_deal_fin;
		pMcDev->deal_heartbeat = mc_v2_deal_heartbeat;
		pMcDev->deal_exception = mc_v2_deal_exception;
		pMcDev->start_charge = mc_v2_start_charge;
		pMcDev->stop_charge = mc_v2_stop_charge;
		pMcDev->go_forward = mc_v2_go_forward;
		pMcDev->go_backward = mc_v2_go_backward;
		pMcDev->turn_left = mc_v2_turn_left;
		pMcDev->turn_right = mc_v2_turn_right;
		pMcDev->mc_leftarc = mc_v2_leftarc;
		pMcDev->mc_rightarc = mc_v2_rightarc;
		pMcDev->mc_slow_go_back = mc_v2_slow_go_back;
		pMcDev->mc_slow_go_straight = mc_v2_slow_go_straight;

		pMcDev->send_angle_offset = mc_v2_send_angle_offset;
		pMcDev->cntl_lift_motor = mc_v2_cntl_lift_motor;
		pMcDev->cntl_cycle_motor = mc_v2_cntl_cycle_motor;
		pMcDev->clear_derail = mc_v2_clear_derail;
		pMcDev->clear_navigation = mc_v2_clear_navigation;
		pMcDev->clear_lcoder_error = mc_v2_clear_lcoder_error;
		pMcDev->clear_rcoder_error = mc_v2_clear_rcoder_error;
		pMcDev->enter_debug_mode = mc_v2_enter_debug_mode;
		pMcDev->quit_debug_mode = mc_v2_quit_debug_mode;
		pMcDev->clasp_pallet = mc_v2_clasp_pallet;
		pMcDev->unclasp_pallet = mc_v2_unclasp_pallet;
		pMcDev->clasp_wheel = mc_v2_clasp_wheel;
		pMcDev->unclasp_wheel = mc_v2_unclasp_wheel; 
	}
	else
	{
		g_stAgvAttr.iAGVType = -1;//by tiger.97
		pMcDev->check_version = mc_default_check_version;
		pMcDev->get_flag = mc_default_get_flag;
		pMcDev->set_flag = mc_default_set_flag;
		pMcDev->get_param = mc_default_get_param;
		pMcDev->set_param = mc_default_set_param;
		pMcDev->enable_wdg = mc_default_enable_wdg;
		pMcDev->start = mc_default_start;
		pMcDev->reset = mc_default_reset;
		pMcDev->stop = mc_default_stop;
		pMcDev->deal_ack = mc_default_deal_ack;
		pMcDev->deal_fin = mc_default_deal_fin;
		pMcDev->deal_heartbeat = mc_default_deal_heartbeat;
		pMcDev->deal_exception = mc_default_deal_exception;
		pMcDev->start_charge = mc_default_start_charge;
		pMcDev->stop_charge = mc_default_stop_charge;
		pMcDev->go_forward = mc_default_go_forward;
		pMcDev->go_backward = mc_default_go_backward;
		pMcDev->turn_left = mc_default_turn_left;
		pMcDev->turn_right = mc_default_turn_right;
		///start ,add by tiger.10
		pMcDev->mc_slow_go_back = mc_default_slow_go_back;
		pMcDev->mc_slow_go_straight = mc_default_slow_go_straight;
		pMcDev->mc_leftarc = mc_default_leftarc;
		pMcDev->mc_rightarc = mc_default_rightarc;
		pMcDev->clear_derail = mc_default_clear_derail;
		pMcDev->clear_navigation = mc_default_clear_navigation;
		pMcDev->clear_lcoder_error = mc_default_clear_lcoder_error;
		pMcDev->clear_rcoder_error = mc_default_clear_rcoder_error;
		pMcDev->enter_debug_mode = mc_default_enter_debug_mode;
		pMcDev->quit_debug_mode = mc_default_quit_debug_mode;
		pMcDev->clasp_pallet = mc_default_clasp_pallet;
		pMcDev->unclasp_pallet = mc_default_unclasp_pallet;
		pMcDev->clasp_wheel = mc_default_clasp_wheel;
		pMcDev->unclasp_wheel = mc_default_unclasp_wheel;
		///end ,add by tiger.10
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : init_tc_dev
* Description	     : deal with angle ack of TC
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int init_tc_dev(tc_dev_t *pTcDev)
{
	int iGeneration = 0;
	int iRet = 0;

	if (pTcDev == NULL)
		return -1;

	iRet = tc_get_version(&iGeneration);
	if (iRet < 0)
		LOG_WRN("get tc version failure\n");

	pTcDev->iGeneration = iGeneration;
	pTcDev->iWorkMode = WORK_MODE_NORMAL;

	if ((pTcDev->iGeneration <= GENERATION_1P0) && (pTcDev->iGeneration != GENERATION_ERR))
	{
		pTcDev->check_version = tc_v1_check_version;
		pTcDev->get_flag = tc_v1_get_flag;
		pTcDev->set_flag = tc_v1_set_flag;
		pTcDev->get_param = tc_v1_get_param;
		pTcDev->set_param = tc_v1_set_param;
		pTcDev->enable_wdg = tc_v1_enable_wdg;
		pTcDev->start = tc_v1_start;
		pTcDev->reset = tc_v1_reset;
		pTcDev->stop = tc_v1_stop;
		pTcDev->deal_ack = tc_v1_deal_ack;
		pTcDev->deal_fin = tc_v1_deal_fin;
		pTcDev->deal_heartbeat = tc_v1_deal_heartbeat;
		pTcDev->deal_exception = tc_v1_deal_exception;
		pTcDev->deal_angle_ack = tc_v1_deal_angle_ack;

		pTcDev->send_angle_offset = tc_v1_send_angle_offset;
		pTcDev->cntl_lift_motor = tc_v1_cntl_lift_motor;
		pTcDev->cntl_cycle_motor = tc_v1_cntl_cycle_motor;
	}
	else if ((pTcDev->iGeneration <= GENERATION_2P0) && (pTcDev->iGeneration != GENERATION_ERR))
	{
		//TODO
	}
	else
	{
		pTcDev->check_version = tc_default_check_version;
		pTcDev->get_flag = tc_default_get_flag;
		pTcDev->set_flag = tc_default_set_flag;
		pTcDev->get_param = tc_default_get_param;
		pTcDev->set_param = tc_default_set_param;
		pTcDev->enable_wdg = tc_default_enable_wdg;
		pTcDev->start = tc_default_start;
		pTcDev->reset = tc_default_reset;
		pTcDev->stop = tc_default_stop;
		pTcDev->deal_ack = tc_default_deal_ack;
		pTcDev->deal_fin = tc_default_deal_fin;
		pTcDev->deal_heartbeat = tc_default_deal_heartbeat;
		pTcDev->deal_exception = tc_default_deal_exception;
		pTcDev->deal_angle_ack = tc_default_deal_angle_ack;

		pTcDev->send_angle_offset = tc_default_send_angle_offset;
		pTcDev->cntl_lift_motor = tc_default_cntl_lift_motor;
		pTcDev->cntl_cycle_motor = tc_default_cntl_cycle_motor;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : camera_get_version
* Description	     : get camera version, such as uart or v4l2
* input			     : pType : the pointer of camera device type
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int camera_get_version(int * pVersion)
{
	int iRet = 0;
	if (pVersion == NULL)
		return -1;
	//add by jxu 20180719:beign optimize the timing seq to reduce the waiting to the D1000
	int iV4lRet = v4l2_camera_init_check_id();
	if (iV4lRet < 0)
	{
		LOG_WRN("v4l2 camera initiation is failed\n");
	}
	else
	{
		*pVersion = CAMERA_VERSION_V4L2;
		LOG_INF("v4l2 camera initiation is success\n");
		return iRet;
	}
	int iUartRet = uart_camera_init_check();
	if (iUartRet < 0)
	{
		LOG_WRN("uart camera initiation is failed\n");
	}
	else
	{
		*pVersion = CAMERA_VERSION_UART;
		LOG_INF("uart camera initiation is success\n");
		return iRet;
	}
	if ((iUartRet < 0) && (iV4lRet < 0))
	{
		//Need to add an exception
		LOG_ERR("v4l2&uart camera initiation is failed iV4lRet=%d iUartRet=%d\n", iV4lRet, iUartRet);
		*pVersion = CAMERA_VERSION_ERR;
		return -1;
	}
	//add by jxu 20180719:end
}

/*******************************************************************************
* Function Name		 : init_camera_dev
* Description	     : init camera device for uart or v4l2 type camera
* input			     : pCameraDev : the pointer of camera device
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int init_camera_dev(camera_dev_t *pCameraDev)
{
	int iRet = 0;
	int iVersion = 0;
	if (pCameraDev == NULL)
		return -1;
	//add by jxu 20180306:begin
	if (pCameraDev->iType == CAMERA_TYPE_BOT)
	{
		LOG_INF("Bottom camera doesnot need init now!\n");
		return 0;
	}
	//add by jxu 20180306:end

	iRet = camera_get_version(&iVersion);
	if (iRet < 0)
	{
		pCameraDev->iVersion = iVersion;
		pCameraDev->iUartVersion = 0;//add by jxu 20180920
		pCameraDev->get_qrinfo = camera_default_get_qrinfo;
		return -1;
	}

	pCameraDev->iVersion = iVersion;
	pCameraDev->iWorkMode = WORK_MODE_NORMAL;

	if (pCameraDev->iVersion == CAMERA_VERSION_UART)
	{
		pCameraDev->start_camera = uart_camera_start;
		pCameraDev->stop_camera = uart_camera_stop;
		pCameraDev->get_qrinfo = uart_camera_get_qrinfo;
		//add by jxu 20180920-begin
		int iVersion = get_camera_version_supportdiff();
		if (iVersion == 0)
		{
			pCameraDev->iUartVersion = CAMERA_VERSION_SUPDIFF;
		}
		else if (iVersion == 1)
		{
			pCameraDev->iUartVersion = CAMERA_VERSION_CHECK;	//add by du for version 42bba
		}
		else
		{
			pCameraDev->iUartVersion = CAMERA_VERSION_NOSUPDIFF;
		}
		//add by jxu 20180920-end
	}
	else if (pCameraDev->iVersion == CAMERA_VERSION_V4L2)
	{
		//pCameraDev->start_camera = v4l2_camera_start;//add by jxu 20180227
		//pCameraDev->stop_camera = v4l2_camera_stop;//add by jxu 20180227
		pCameraDev->get_qrinfo = v4l2_camera_get_qrinfo;
	}

	return 0;
}
/*******************************************************************************
* Function Name		 : init_battery_type
* Description	     : get the battery type
* input			     : NONE
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int init_battery_type()
{
	int iRet = 0;
	LOG_INF("Begin to the recognize the battery\n");
	int iSongxia = songxia_battery_init_check();
	if (iSongxia < 0)
	{
		g_stAgvAttr.iBatType = BAT_TYPE_ANSHANG;
		g_stAgvAttr.bms.iBattManufactor = BAT_TYPE_ANSHANG;//add by jxu 20181017
		LOG_WRN("The battery is anshang in default\n");

	}
	else
	{
		g_stAgvAttr.iBatType = BAT_TYPE_SONGXIA;
		g_stAgvAttr.bms.iBattManufactor = BAT_TYPE_SONGXIA;//add by jxu 20181017
		LOG_INF("Songxia battery initiation is success\n");
	}
	return iRet;
}
/*******************************************************************************
*Function Name    :qr_info_init
*Description      :init qr_info_t variable
*Input       	  :pQrInfo : the pointer of qr_info_t
*Output 		  :pQrInfo : the pointer of qr_info_t
*Return		      :0 if OK, -1 on error
*******************************************************************************/
int qr_info_init(qr_info_t * pQrInfo)
{
	if (pQrInfo == NULL)
		return -1;

	pthread_mutex_init(&pQrInfo->stQRInfoMutex, NULL);
	pQrInfo->iQR = 0;
	pQrInfo->fAngle = 0.0f;
	pQrInfo->iXOffset = 0;
	pQrInfo->iYOffset = 0;
	return 0;
}

/*******************************************************************************
*Function Name    :qr_info_set
*Description      :set qr_info_t variable with parameter
*Input       	  :pQrInfo : the pointer of qr_info_t
*Input       	  :iQR : qr
*Input       	  :fAngle : angle
*Input       	  :iXOffset : x-offset
*Input       	  :iYOffset : y-offset
*Output 		  :pQrInfo : the pointer of qr_info_t
*Return		      :0 if OK, -1 on error
*******************************************************************************/
int qr_info_set(int iQR, float fAngle, int iXOffset, int iYOffset, qr_info_t * pQrInfo)
{
	if (pQrInfo == NULL)
		return -1;

	pthread_mutex_lock(&pQrInfo->stQRInfoMutex);
	pQrInfo->iQR      = iQR;
	pQrInfo->fAngle   = fAngle;
	pQrInfo->iXOffset = iXOffset;
	pQrInfo->iYOffset = iYOffset;
	pthread_mutex_unlock(&pQrInfo->stQRInfoMutex);

	return 0;
}

/*******************************************************************************
*Function Name    :qr_info_get
*Description      :get qr_info_t variable
*Input       	  :pQrInfo : the pointer of qr_info_t
*Input       	  :pQR : the pointer of qr
*Input       	  :pAngle : the pointer of angle
*Input       	  :pXOffset : the pointer of x-offset
*Input       	  :pYOffset : the pointer of y-offset
*Output 		  :pQrInfo : the pointer of qr_info_t
*Return		      :0 if OK, -1 on error
*******************************************************************************/
int qr_info_get(int *pQR, float *pAngle, int *pXOffset, int *pYOffset, qr_info_t *pQrInfo)
{
	if ((pQrInfo == NULL) || (pQR == NULL) || (pAngle == NULL) || (pXOffset == NULL) || (pYOffset ==NULL))
		return -1;

	pthread_mutex_lock(&pQrInfo->stQRInfoMutex);
	*pQR = pQrInfo->iQR;
	*pAngle = pQrInfo->fAngle;
	*pXOffset = pQrInfo->iXOffset;
	*pYOffset = pQrInfo->iYOffset;
	pthread_mutex_unlock(&pQrInfo->stQRInfoMutex);

	return 0;
}

/*******************************************************************************
*Function Name    :reboot_agv
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :void  
*******************************************************************************/
void reboot_agv(void)
{
	if (AGV1_0 == g_stAgvAttr.iAGVType)
	{
		LOG_INF("reboot the AGV1_0\n");
		enable_wdg(DEV_MC);
		enable_wdg(DEV_TC);
		sleep(1);
		system("sync");
		sleep(1);
		system("sync");
		system("sudo reboot");
		
	}
	else if (AGV2_0 == g_stAgvAttr.iAGVType)
	{
		LOG_INF("reboot the AGV2_0\n");
		enable_wdg(DEV_MC);
		sleep(1);
		system("sync");
		system("sudo reboot");
		LOG_INF("reboot the agv\n");
	}
	else
		LOG_INF("reboot failed:wrong agv generation-%d\n",g_stAgvAttr.iAGVType);
	
}

/*******************************************************************************
*Function Name    :clasp_pallet
*Description      :  
*Output 		  :
*Return           :void  
*******************************************************************************/
void clasp_pallet(void)
{
	int iRet = 0;
	LOG_INF("deal with pallet clasp cmd\n");
	iRet = g_stMcDev.clasp_pallet();
	if (iRet < 0)
	{
		LOG_ERR("Send clasp pallet CAN frame failed\n");
	}
}

/*******************************************************************************
*Function Name    :unclasp_pallet
*Description      :  
*Output 		  :
*Return           :void  
*******************************************************************************/
void unclasp_pallet(void)
{
	int iRet = 0;
	LOG_INF("deal with pallet unclasp cmd\n");
	iRet = g_stMcDev.unclasp_pallet();
	if (iRet < 0)
	{
		LOG_ERR("Send unclasp pallet CAN frame failed\n");
	}
}

/*******************************************************************************
*Function Name    :clasp_wheel
*Description      :  
*Output 		  :
*Return           :void  
*******************************************************************************/
void clasp_wheel(void)
{
	int iRet = 0;
	LOG_INF("deal with wheel clasp cmd\n");
	iRet = g_stMcDev.clasp_wheel();
	if (iRet < 0)
	{
		LOG_ERR("Send clasp wheel CAN frame failed\n");
	}
}

/*******************************************************************************
*Function Name    :unclasp_wheel
*Description      :  
*Output 		  :
*Return           :void  
*******************************************************************************/
void unclasp_wheel(void)
{
	int iRet = 0;
	LOG_INF("deal with wheel unclasp cmd\n");
	iRet = g_stMcDev.unclasp_wheel();
	if (iRet < 0 )
	{
		LOG_ERR("Send unclasp wheel CAN frame failed\n");
	}
}

/*******************************************************************************
*Function Name    :sync_time_to_mc
*Description      :sync time to mc  
*Input       	  :void  
*Output 		  :
*Return           :int  
*******************************************************************************/
int sync_time_to_mc(void)
{
	time_t liTime = 0;
	int iRet = 0;
	time(&liTime);
	int iYYMMDD = 0;
	int iHHMMSS = 0;
	int iYear = 0, iMonth = 0, iDay = 0;
	struct tm *pLocalTime = localtime(&liTime);

	iYear = pLocalTime->tm_year + 1900 - 2000;
	iMonth = pLocalTime->tm_mon + 1;
	iDay = pLocalTime->tm_mday;

	iYYMMDD = (iYear << 16) + (iMonth << 8) + iDay;
	iHHMMSS = (pLocalTime->tm_hour << 16) + (pLocalTime->tm_min << 8) + pLocalTime->tm_sec;

	LOG_INF("sync date[%02d-%02d-%02d] to mc\n", iYear, iMonth, iDay);
	iRet = set_flag(DEV_MC, YYMMDD_PARAM_ID, iYYMMDD);

	usleep(5000);

	LOG_INF("sync time[%02d:%02d:%02d] to mc\n", pLocalTime->tm_hour, pLocalTime->tm_min, pLocalTime->tm_sec);
	iRet = set_flag(DEV_MC, HHMMSS_PARAM_ID, iHHMMSS);

	return iRet;
}

/*******************************************************************************
*Function Name    :sync_sn_no_to_mc
*Description      :sync agv number and agv SN to MC
*Input       	  :void  
*Output 		  :
*Return           :int: 0 if OK, -1 on error 
*******************************************************************************/
int sync_sn_no_to_mc(void)
{
	int iRet = 0;
	char pHighSixBytes[10] = { '0','x' };
	char pLowSixBytes[10] = { '0', 'x' };
	int iHighSixBytesValue = 0;
	int iLowSixBytesValue = 0;

	LOG_INF("sync agv name[%d] to mc\n", g_stAgvAttr.iAgvName);
	iRet = set_flag(DEV_MC, AGVNO, g_stAgvAttr.iAgvName);

	usleep(5000);

	strncpy(pHighSixBytes+2, g_stAgvAttr.pSN, 6);
	iHighSixBytesValue = strtoul(pHighSixBytes, NULL, 16);
	strncpy(pLowSixBytes+2, g_stAgvAttr.pSN + 6, 6);
	iLowSixBytesValue = strtoul(pLowSixBytes, NULL, 16);
	LOG_INF("sync agv high 6 bytes of SN [%s] to mc\n", pHighSixBytes);
	iRet = set_flag(DEV_MC, SN_H_3_BYTE, iHighSixBytesValue);
	LOG_INF("sync agv low 6 bytes of SN [%s] to mc\n", pLowSixBytes);
	iRet = set_flag(DEV_MC, SN_L_3_BYTE, iLowSixBytesValue);

	return iRet;
}

/*******************************************************************************
*Function Name    :sync_ftp_server_ip_to_mc
*Description      :sync ftp server ip tO mc  
*Input       	  :NONE  
*Output 		  :NONE
*Return           :int: 0 if OK, -1 on error  
*******************************************************************************/
int sync_ftp_server_ip_to_mc(void)
{
	int iRet = 0;
	in_addr_t u32Ip = 0;

	u32Ip = inet_addr(g_stAgvAttr.pFtpServerIp);
	u32Ip = ntohl(u32Ip);
	LOG_INF("sync ftp server ip to mc:[%s:%d]\n", g_stAgvAttr.pFtpServerIp,u32Ip);

	iRet = set_flag(DEV_MC, FTP_SERVER_IP, u32Ip);

	return iRet;
}

/*******************************************************************************
*Function Name    :sync_warehouse_brain_ip_to_mc
*Description      :sync warehouse brain ip to mc
*Input       	  :NONE  
*Output 		  :NONE
*Return           :int: 0 if OK, -1 on error  
*******************************************************************************/
int sync_warehouse_brain_ip_to_mc(void)
{
	int iRet = 0;
	in_addr_t u32Ip = 0;

	u32Ip = inet_addr(g_stAgvAttr.pWarehouseBrainIp);
	u32Ip = ntohl(u32Ip);
	LOG_INF("sync warehouse brain server ip to mc:[%s:%d]\n", g_stAgvAttr.pWarehouseBrainIp, u32Ip);

	iRet = set_flag(DEV_MC, WAREHOUSE_BRAIN_IP, u32Ip);

	return iRet;

}

/*******************************************************************************
*Function Name    :get_mc_mac
*Description      :get mc mac address  
*Input       	  :NONE  
*Output 		  :NONE
*Return           :int: 0 if OK, -1 on error  
*******************************************************************************/
int get_mc_mac(void)
{
	int iRet = 0;

	LOG_INF("send get mc MAC can frame\n");
	iRet = get_flag(DEV_MC, MC_MAC_L_3_BYTE);
	iRet = get_flag(DEV_MC, MC_MAC_H_3_BYTE);

	return iRet;

}
/*******************************************************************************
*Function Name    :deal_mc_v2_update_cmd_ack
*Description      :
*Input       	  :struct can_frame * pCanFrame
*Output 		  :
*Return           :int:0 if OK,-1 on error
*******************************************************************************/
int deal_mc_v2_update_cmd_ack(struct can_frame * pCanFrame)
{
	mc_update_ack *pAck = (mc_update_ack *)pCanFrame;
	int iStyle = pAck->u8Style;
	int iRet = 0;
	if (MC_UPDATE_DATA_ACK != iStyle)
	{
		LOG_INF("recv mc ack[seq=%d style=%d data=0x%04x]\n",
			pAck->u8Seq, pAck->u8Style, pAck->u32Data);
		print_can_frame(pCanFrame);
	}

	iRet = 0;
	switch (iStyle)
	{
	case MC_UPDATE_CRC_CMD:
		g_stAgvAttr.iAppCrc = ntohl(pAck->u32Data);
		LOG_INF("[MCU ACK]:success receive MC_UPDATE_CRC_CMD ACK\n");
		break;
	case MC_UPDATE_LENGTH_CMD:
		g_stAgvAttr.iFileSize = ntohl(pAck->u32Data);
		LOG_INF("[MCU ACK]:success receive MC_UPDATE_LENGTH_CMD ACK\n");
		break;
	case  MC_UPDATE_ABORT_CMD:
		LOG_INF("[MCU ACK]:success receive MC_UPDATE_ABORT_CMD ACK\n");
		break;
	case  MC_UPDATE_DATA_ACK:
		//LOG_INF("[MCU ACK]:success receive MC_UPDATE_DATA_ACK ACK\n");
		break;
	default:
		LOG_ERR("receive wrong style(%d) update_cmd_ack\n", iStyle);
		iRet = -1;
		break;
	}
	
	return iRet;
}
typedef struct _mc_update_check_ack
{
	canid_t can_id;  /* 32 bit CAN_ID + EFF/RTR/ERR flags */
	__u8    can_dlc; /* data length code: 0 .. 8 */
	u8 u8Ret __attribute__((aligned(8)));//data[0]
	u8 u8Reserve1  __attribute__((aligned(8)));//data[1]
	u8 u8Reserve2  __attribute__((aligned(8)));//data[2]
	u8 u8Reserve3  __attribute__((aligned(8)));//data[3]
	u8 u8Reserve4  __attribute__((aligned(8)));//data[4]
	u8 u8Reserve5  __attribute__((aligned(8)));//data[5]
	u8 u8Style  __attribute__((aligned(8)));//data[6]
	u8 u8Seq  __attribute__((aligned(8)));//data[7]

}mc_update_check_ack;
#define CRC_CHECK_RET 0x01
#define MC_UPDATE_OK  0x02

/*******************************************************************************
*Function Name    :deal_mc_v2_update_check_ack
*Description      :  
*Input       	  :struct can_frame * pCanFrame  
*Output 		  :
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int deal_mc_v2_update_check_ack(struct can_frame *pCanFrame)
{
	mc_update_check_ack *pAck = (mc_update_check_ack *)pCanFrame;
	int iRet = -1;;
	LOG_INF("recv mc ack[seq=0x%02x style=0x%02x data=0x%02x]\n",
		pAck->u8Seq, pAck->u8Style, pAck->u8Ret);
	print_can_frame(pCanFrame);

	if (CRC_CHECK_RET == pCanFrame->data[6])
	{
		g_stAgvAttr.iCrcCheckRet = pCanFrame->data[0];
		iRet = 0;
		LOG_INF("[MCU ACK]:success receive MC_UPDATE_DATA_CHECK_V2 ACK\n");
	}
	else if (MC_UPDATE_OK == pCanFrame->data[6])
	{
		LOG_INF("[MCU ACK]:success receive MC_UPDATE_RESTART_OK_V2 ACK\n");
		iRet = 0;
	}
	else
	{
		LOG_WRN("[MCU ACK]:Wrong ACK");
		iRet = -1;
	}
	
	return iRet;
}

/*******************************************************************************
*Function Name    :get_d500_generation
*Description      :
*Output 		  :
*Return           :int:0 if OK,-1 on error
*******************************************************************************/
int get_d500_generation()
{
	int iRet = -1, iGeneration = 0;

	g_stAgvAttr.iAGVType = -1;
	iRet = mc_get_version(&iGeneration);
	if (iRet != 0)
	{
		LOG_ERR("send search MC version to can failed\n");
		return -1;
	}

	if ((g_stMcDev.iGeneration <= GENERATION_1P0) && (g_stMcDev.iGeneration != GENERATION_ERR))
	{
		g_stAgvAttr.iAGVType = AGV1_0;
	}
	else if ((g_stMcDev.iGeneration <= GENERATION_2P0) && (g_stMcDev.iGeneration > GENERATION_1P0))
	{
		g_stAgvAttr.iAGVType = AGV2_0;
	}

	return 0;
}
/*******************************************************************************
*Function Name    :ftp_recv_can
*Description      :
*Input       	  :struct timeval * pTimeOut;block read for some time
*Input       	  :int iCanID;the can frame id
*Output 		  :NONE
*Return           :int:0 if OK, -1 on error
*******************************************************************************/
int ftp_recv_can(struct timeval *pTimeOut, int iCanID)
{
	const char *pDesc[] = { "not update", "need update", "finished sending data" };
	fd_set stReadFds;
	bool bTimeOut = false;
	bool bIsMc = 0;
	int iCmd = 0, iRet = 0;
	unsigned int uiSize = 0;
	int iVersionCur = 0;
	struct timeval stTimePre, stTimeNow;
	struct can_frame stData;
	bzero(&stTimePre, sizeof(struct timeval));
	bzero(&stTimeNow, sizeof(struct timeval));
	bzero(&stData, sizeof(struct can_frame));
	while (bTimeOut == false)
	{
		gettimeofday(&stTimePre, NULL);
		FD_ZERO(&stReadFds);
		FD_SET(g_stAgvParm.iCanSocketFd0, &stReadFds);
		if (pTimeOut->tv_sec <= 0)
		{
			FD_CLR(g_stAgvParm.iCanSocketFd0, &stReadFds);
			return -1;
		}
		if ((iRet = select(g_stAgvParm.iCanSocketFd0 + 1, &stReadFds, NULL, NULL, pTimeOut))> 0)
		{
			bzero(&stData, sizeof(stData));
			uiSize = read(g_stAgvParm.iCanSocketFd0, &stData, sizeof(struct can_frame));
			if (uiSize == sizeof(struct can_frame))
			{
				if (iCanID == stData.can_id)
				{
					switch (stData.can_id)
					{
					case FTP_TC_ACK_CANID:
					case FTP_MC_ACK_CANID:
						bIsMc = (FTP_MC_ACK_CANID == stData.can_id) ? 1 : 0;
						if ((*((unsigned char *)&stData.data[6]) == INQUIRE && (FTP_MC_ACK_CANID == stData.can_id)) ||
							(*((unsigned char *)&stData.data[6]) == 2 && (FTP_TC_ACK_CANID == stData.can_id)))
						{
							bTimeOut = true;  //jump out the while loop
							iVersionCur = *((unsigned short *)stData.data);
							s_iDspType[bIsMc] = (*((unsigned short *)&stData.data[2])) - 1; //dsp version from 1 to n;but array from 0 to n ,by tiger.11
							LOG_INF("success receive %s [%dth] generation AGV :version[%d] ACK\n", (bIsMc == 1) ? "MC" : "TC", s_iDspType[bIsMc] + 1, iVersionCur);//modified by tiger.11

						}
						else if (*((unsigned char *)&stData.data[6]) == UPDATE)
						{
							iCmd = *((unsigned char *)&stData.data[4]);
							bTimeOut = true;  //jump out the while loop
							if (*((unsigned short *)&stData.data[0]) == OK)
							{
								LOG_INF("%s success receive the %s ACK\n", (bIsMc == 1) ? "MC" : "TC", pDesc[iCmd]);
								print_can_frame(&stData);
							}
							else
							{
								LOG_INF("%s failed receive the %s ACK\n", (bIsMc == 1) ? "MC" : "TC", pDesc[iCmd]);
								FD_CLR(g_stAgvParm.iCanSocketFd0, &stReadFds);
								return -1;
							}
						}
						else
						{
							LOG_INF("failed receive %s version ACK\n", (bIsMc == 1) ? "MC" : "TC");
							FD_CLR(g_stAgvParm.iCanSocketFd0, &stReadFds);
							return -1;
						}
						break;
					case FTP_MC_FINISH_CANID:
					case FTP_TC_FINISH_CANID:
						bIsMc = (FTP_MC_FINISH_CANID == stData.can_id) ? 1 : 0;
						if (0xa55a == *((unsigned short *)&stData.data[6]))
						{
							bTimeOut = true;  //jump out the while loop
							ftp_operate_finish(bIsMc, *((unsigned short *)&stData.data[0]));
						}
						break;
					default:
						LOG_INF("filter the can id %d\n", stData.can_id);
						gettimeofday(&stTimeNow, NULL);
						pTimeOut->tv_sec = pTimeOut->tv_sec - (stTimeNow.tv_sec - stTimePre.tv_sec);
						break;
					}
				}
				else
				{
					//LOG_INF("the received %s CAN id 0x%x is not wanted and drop out\n", (bIsMc == 1) ? "MC" : "TC", stData.can_id);
					gettimeofday(&stTimeNow, NULL);
					pTimeOut->tv_sec = pTimeOut->tv_sec - (stTimeNow.tv_sec - stTimePre.tv_sec);
				}

			}
			else
			{
				LOG_INF("wrong:%s reply %d data ", (bIsMc == 1) ? "MC" : "TC", uiSize);
				gettimeofday(&stTimeNow, NULL);
				pTimeOut->tv_sec = pTimeOut->tv_sec - (stTimeNow.tv_sec - stTimePre.tv_sec);
			}

		}
		else
		{
			LOG_ERR("can recv failure, errno[%d-%s]\n", errno, strerror(errno));
			FD_CLR(g_stAgvParm.iCanSocketFd0, &stReadFds);
			return -1;
		}
	}
	FD_CLR(g_stAgvParm.iCanSocketFd0, &stReadFds);
	return 0;
}

/*******************************************************************************
*Function Name    :ftp_recv_can_v2
*Description      :deal mc update cmd ACK of D500_20
*Input       	  :int iCanID��the can id need to receive
*Input       	  :int iTimeOut:wait time ;unit:S
*Output 		  :NONE
*Return           :int:0 if OK ,-1 on error
*******************************************************************************/
int ftp_recv_can_v2(int iCanID, int iTimeOut)
{
	fd_set stReadFds;
	bool bTimeOut = false;
	int iCmd = 0, iRet = 0;
	unsigned int uiSize = 0;
	struct timeval stTimePre = { 0 };
	struct timeval stTimeNow = { 0 };
	struct timeval stTimeout = { 0 };
	struct can_frame stData;
	mc_can_action_ack_st *pActionAck = NULL;

	bzero(&stTimePre, sizeof(struct timeval));
	bzero(&stTimeNow, sizeof(struct timeval));
	bzero(&stData, sizeof(struct can_frame));

	stTimeout.tv_sec = iTimeOut;
	while (false == bTimeOut)
	{
		gettimeofday(&stTimePre, NULL);
		FD_ZERO(&stReadFds);
		FD_SET(g_stAgvParm.iCanSocketFd0, &stReadFds);
		if (stTimeout.tv_sec <= 0)
		{
			LOG_ERR("the stTimeout.tv_sec =%d,iTimeout = %d\n", stTimeout.tv_sec,iTimeOut);
			FD_CLR(g_stAgvParm.iCanSocketFd0, &stReadFds);
			return -1;
		}

		if ((iRet = select(g_stAgvParm.iCanSocketFd0 + 1, &stReadFds, NULL, NULL, &stTimeout)) > 0)
		{
			bzero(&stData, sizeof(stData));
			uiSize = read(g_stAgvParm.iCanSocketFd0, &stData, sizeof(struct can_frame));
			if (uiSize == sizeof(struct can_frame))
			{
				if (iCanID == stData.can_id)
				{
					switch (stData.can_id)
					{
					case MC2ARM_UPDATE_CANID:
						iRet = deal_mc_v2_update_cmd_ack(&stData);
						if (iRet == 0)
							bTimeOut = true;
						break;
					case MC2ARM_UPDATE_DATA_CANID:
						iRet = deal_mc_v2_update_check_ack(&stData);
						if (iRet == 0)
							bTimeOut = true;
						break;
					case MC_CAN_ACK_V2_CANID:
						pActionAck = (mc_can_action_ack_st*)&stData;
						if ((MC_ACTION_ACK_OK_V2 == pActionAck->iRetInfo) && (MC_CAN_CMD_RESTART_V2 == pActionAck->iAction))
						{
							bTimeOut = true;
							LOG_INF("[MCU ACK]:success receive MC_CAN_CMD_RESTART_V2 ACK\n");
						}
						break;
					default:
						LOG_INF("filter the can id %d\n", stData.can_id);
						gettimeofday(&stTimeNow, NULL);
						stTimeout.tv_sec = stTimeout.tv_sec - (stTimeNow.tv_sec - stTimePre.tv_sec);
						break;
					}
				}
				else
				{
					//LOG_INF("the received MC CAN id 0x%x is not wanted and drop out\n", stData.can_id);
					gettimeofday(&stTimeNow, NULL);
					stTimeout.tv_sec = stTimeout.tv_sec - (stTimeNow.tv_sec - stTimePre.tv_sec);
				}

			}
			else
			{
				LOG_INF("wrong:Mc reply %d data ", uiSize);
				gettimeofday(&stTimeNow, NULL);
				stTimeout.tv_sec = stTimeout.tv_sec - (stTimeNow.tv_sec - stTimePre.tv_sec);
			}
		}
		else
		{
			LOG_ERR("can recv failure:[%d-%s]\n", errno, strerror(errno));
			FD_CLR(g_stAgvParm.iCanSocketFd0, &stReadFds);
			return -1;
		}
	}
	FD_CLR(g_stAgvParm.iCanSocketFd0, &stReadFds);
	return 0;
}

/*******************************************************************************
*Function Name    :config_D500_20
*Description      :configure D500_20  
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error  
*******************************************************************************/
int config_d500_20()
{
	int iRet = 0;
	iRet = sync_ftp_server_ip_to_mc(); //add by tiger.64
	if (iRet < 0)
		LOG_WRN("sync ftp server ip to mc failed:[%d-%s]\n", errno, strerror(errno));
	else
		LOG_INF("sync ftp server ip to mc success\n");

	iRet = sync_warehouse_brain_ip_to_mc();//add by tiger.65
	if (iRet < 0)
			LOG_WRN("sync warehouse server ip to mc failed:[%d-%s]\n", errno, strerror(errno));
	else
		LOG_INF("sync warehouse server ip to mc success\n");

	iRet = sync_sn_no_to_mc();//add by tiger.53
	if (iRet < 0)
		LOG_WRN("sync SN and agv name to mc failure\n");
	else
		LOG_INF("sync SN and agv name to mc success\n");

	return iRet;
}

/*******************************************************************************
*Function Name    :sync_agent_time
*Description      :sync agent time to ARM and Mc ,by tiger.72
*Input       	  :time_t iCalendarTime:Calendar Time, the number of seconds that
have passed since the Epoch: 00:00:00 January 1, 1970
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error
*******************************************************************************/
int sync_agent_time(time_t iCalendarTime)
{
	int iRet = 0;
	if (write_rtc(iCalendarTime) == 0)
		LOG_INF("success sync console time\n");
	else
		LOG_WRN("!!!failed sync console time\n");

	if (AGV2_0 == g_stAgvAttr.iAGVType)
	{
		iRet = sync_time_to_mc();
		if (iRet < 0)
			LOG_WRN("sync time to mc failure\n");
		else
			LOG_INF("sync time to mc success\n");
	}
	return iRet;
}

/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/
