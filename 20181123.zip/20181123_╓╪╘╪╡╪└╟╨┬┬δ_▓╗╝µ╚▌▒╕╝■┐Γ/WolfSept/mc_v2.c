/********************************************************************************
* Copyright (c) 2018, JD.COM, Inc .
* All rights reserved.
* FileName: mc_v2.c
* Author: Xu Jing   Version: V2.0   Data:2018-01-09
* Description:
********************************************************************************/
#include "mc_v2.h"
#include "atomic.h"
#include "global_var.h"  //by tiger.41

/*******************************************************************************
* Function Name		 : mc_v1_deal_fin
* Description	     : deal with MC finish and send msg to console
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void mc_v2_deal_fin(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	mc_can_status_finish_st * pMcCanCmdFin = NULL;

	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return;

	pMcCanCmdFin = (mc_can_status_finish_st *)pCanFrame;

	pAgvAttr->iMcAction = pMcCanCmdFin->iAction;		//Byte[5]
	//pAgvAttr->iMcStyle = pMcCanCmdFin->iStyle;		//Byte[6]
	pAgvAttr->iFinishPointId = pMcCanCmdFin->iPointId; //by tiger.89
	
	LOG_INF("recv action[%d-%s] finish can frame\n",
		pAgvAttr->iMcAction, get_mc_cmd_name(pAgvAttr->iMcAction));
	print_can_frame(pCanFrame);
}

/*******************************************************************************
* Function Name		 : mc_v2_deal_heartbeat
* Description	     : deal with the MC heartbeat frame
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : int:the check sum of data[0~6]
*******************************************************************************/
int mc_v2_deal_heartbeat(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	int iCheckSum = 0;
	mc_can_status_heartbeat_st * pMcHeartBeat = (mc_can_status_heartbeat_st *)pCanFrame;
	int iSpeed = abs(pMcHeartBeat->iData2);	//data[0]
	int iResDistance = pMcHeartBeat->iData1;	//data[1]
	int iPath = pMcHeartBeat->iPath;		//data[2].bit[7:1]
	int iNewTag = pMcHeartBeat->iNewTag;	//data[2].bit[0]
	int iEvent = pMcHeartBeat->iEvent;		//data[3].bit[7:2] //add by tiger.58
	//int iMode = pMcHeartBeat->iMode;		//data[3].bit[1:0]
	//int iHeadDirect = pMcHeartBeat->iHeaddirect;	//data[4].bit[7:4]
	//int iStyle = pMcHeartBeat->iStyle;				//data[4].bit[3:0]
	//int iSeq = pMcHeartBeat->iSeq;					//data[5]
	int iMoveStatus = pMcHeartBeat->iMoveState;
	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return -1;

	iCheckSum = (pCanFrame->data[0] + pCanFrame->data[1] + pCanFrame->data[2] + pCanFrame->data[3] + \
		pCanFrame->data[4] + pCanFrame->data[5] + pCanFrame->data[6]) & 0xffffffff;
	pAgvAttr->iMCStatus = 0;
	pAgvAttr->iStatus = 0;
	pAgvAttr->iSpeed = iSpeed / 10;
	pAgvAttr->iEvent = iEvent; //add by tiger.58
	pAgvAttr->iSreamin = iResDistance;//add by jxu 20180312
	pAgvAttr->iMcHeartBeatStatus = iMoveStatus;//add by tiger.61

	// add by kedong, 20180207
	if (g_stAgvConf.cDebugEnable == TRUE)
	{
		pAgvAttr->iPath = iPath;
		pAgvAttr->iNewTag = iNewTag;
	}
	//pAgvAttr->iVehHeadDirect = iHeadDirect;

	return iCheckSum;
}

/*******************************************************************************
* Function Name		 : mc_v2_get_flag
* Description	     : get flag of MC
* input			     : u8FlagVar : series number of flag var
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v2_get_flag(u8 u8FlagVar)
{
	int iCount = 0;
	mc_can_rw_flag_param_req_st stReq = {
		.iCanId = MC_CAN_FLAG_PARAM_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID),
		.iCmd = MC_TYPE_READ_V2_FLAG,
		.iParamId = u8FlagVar,
		.iParamVal = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:get flag\n");
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

///start ,by tiger.41
typedef struct _set_flag
{
	canid_t can_id;  /* 32 bit CAN_ID + EFF/RTR/ERR flags */
	__u8    can_dlc; /* data length code: 0 .. 8 */
	u32 u32DataValue;
	u16  u16FlagVar;
	u8   u8Cmd;
	u8   u8Seq;
}set_flag_can_frame;


/*******************************************************************************
*Function Name    :mc_v2_set_flag
*Description      :  
*Input       	  :u8 u8FlagVar  
*Input       	  :u32 u32Value  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_set_flag(u8 u8FlagVar, u32 u32Value)
{
	int iCount = 0;
	set_flag_can_frame stCanFrame = {
		.can_id = MC_CAN_FLAG_PARAM_REQ_V2_CANID,
		.can_dlc = MC_DATA_DLC_V2,
		.u32DataValue = u32Value,
		.u16FlagVar = u8FlagVar,
		.u8Cmd = MC_TYPE_SET_V2_FLAG,
		.u8Seq = (u8)get_seq(MC_SEQ_ID)
	};

	LOG_INF("send to can:set flag\n");
	print_can_frame((struct can_frame *)&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}


///end by tiger.41

/*******************************************************************************
* Function Name		 : mc_v2_go_forward
* Description	     : set go forward command to mc
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Distance : distance(unit:0.1 degree)
* input			     : u16Speed : speed(unit:millimeter/second)
* Output		     : NONE
* Return		     : 0:if OK ; -1 on error
*******************************************************************************/
int mc_v2_go_forward(u8 u8Weight, u16 u16Distance, u16 u16Speed)
{
	int iCount = 0;
	mc_can_action_req_st req = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CAN_CMD_GOFORWARD_V2,
		.iRsvd = MC_CAN_RESERVE_V2,
		.iWeitLev = u8Weight,
		.iDist = u16Distance,
		.iVel = u16Speed,
	};

	LOG_INF("send to can:go forward:distance=%dmm, speed=%dmm/s, weight=%d\n", 
		u16Distance, u16Speed / 10, u8Weight);
	print_can_frame((struct can_frame *)&req);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&req);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}


/*******************************************************************************
* Function Name		 : mc_v2_go_backward
* Description	     : set go backward command to mc
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Distance : distance(unit:0.1 degree)
* input			     : u16Speed : speed(unit:millimeter/second)
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int mc_v2_go_backward(u8 u8Weight, u16 u16Distance, u16 u16Speed)
{
	int iCount = 0;
	mc_can_action_req_st req = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CAN_CMD_GOBACKWARD_V2,
		.iRsvd = MC_CAN_RESERVE_V2,
		.iWeitLev = u8Weight,
		.iDist = u16Distance,
		.iVel = u16Speed,
	};

	LOG_INF("send to can:go forward:distance=%dmm, speed=%dmm/s, weight=%d\n", 
		u16Distance, u16Speed / 10, u8Weight);
	print_can_frame((struct can_frame *)&req);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&req);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v2_turn_left
* Description	     : set turn left command to mc
* input			     : u8Sync : 1 if u8Sync,0 on async
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Distance : distance(unit:0.1 degree)
* input			     : u16Speed : speed(unit:millimeter/second)
* Output		     : NONE
* Return		     : 0 if OK ,-1 on error
*******************************************************************************/
int mc_v2_turn_left(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	int iCount = 0;
	mc_can_action_req_st req = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CAN_CMD_TURNLEFT_V2,
		.iRsvd = u8Sync,
		.iWeitLev = u8Weight,
		.iDist = u16Angle,
		.iVel = u16Speed,
	};

	LOG_INF("send to can:turn left:%s, angle=%d, weight=%d\n",
		(u8Sync == 1 ? "sync" : "async"), u16Angle, u8Weight);
	print_can_frame((struct can_frame *)&req);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&req);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v2_turn_right
* Description	     : set turn right command to mc
* input			     : u8Sync : 1 if u8Sync,0 on async
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Distance : distance(unit:0.1 degree)
* input			     : u16Speed : speed(unit:millimeter/second)
* Output		     : NONE
* Return		     : 0 if OK ,-1 on error
*******************************************************************************/
int mc_v2_turn_right(u8 u8Sync, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{

	int iCount = 0;
	mc_can_action_req_st req = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CAN_CMD_TURNRIGHT_V2,
		.iRsvd = u8Sync,
		.iWeitLev = u8Weight,
		.iDist = u16Angle,
		.iVel = u16Speed,
	};

	LOG_INF("send to can:turn right:%s, angle=%d, weight=%d\n",
		(u8Sync == 1 ? "sync" : "async"), u16Angle, u8Weight);
	print_can_frame((struct can_frame *)&req);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&req);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
/*******************************************************************************
*Function Name    :mc_v2_leftarc
*Description      :  
*Input       	  :u16 u16Weight  
*Output 		  :
*Return           :int: 0 if OK, -1 on error    
*******************************************************************************/
int mc_v2_leftarc(u16 u16Weight)
{
	int iCount = 0;
	int iSync = (g_stAgvAttr.iPalletStatus == PALLET_STATUS_BOT) ? 0 : 1;  //1:sync turn  0:async turn
	mc_can_action_req_st stReq = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CMD_LEFT_ARC_V2,
		.iRsvd = iSync,
		.iWeitLev = u16Weight,
		.iDist = MC_CAN_RESERVE_V2,
		.iVel = MC_CAN_RESERVE_V2,
	};

	LOG_INF("sent to can:mc %s turn left  arc, weight=%d\n", 
		(iSync == 1) ? "sync" : "async", u16Weight);
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :mc_v2_rightarc
*Description      :  
*Input       	  :unsigned short u16Weight  
*Output 		  :
*Return           :int: 0 if OK, -1 on error    
*******************************************************************************/
int mc_v2_rightarc(unsigned short u16Weight)
{
	int iCount = 0;
	int iSync = (g_stAgvAttr.iPalletStatus == PALLET_STATUS_BOT) ? 0 : 1;  //1:sync turn  0:async turn
	mc_can_action_req_st stReq = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CMD_RIGHT_ARC_V2,
		.iRsvd = iSync,
		.iWeitLev = u16Weight,
		.iDist = MC_CAN_RESERVE_V2,
		.iVel = MC_CAN_RESERVE_V2,
	};

	LOG_INF("sent to can:mc %s turn left  arc, weight=%d\n", (iSync == 1) ? 
		"sync" : "async", u16Weight);
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :mc_v1_slow_go_back
*Description      :  
*Input       	  :u16 u16SRemain  
*Input       	  :u16 u16QRDistance  
*Output 		  :
*Return           :int: 0 if OK, -1 on error  
*******************************************************************************/
int mc_v2_slow_go_back(u16 u16SRemain, u16 u16QRDistance)
{
	int iCount = 0;
	mc_can_action_req_st stReq = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CMD_BACK_TO_CHARGE_V2,
		.iRsvd = MC_CAN_RESERVE_V2,
		.iWeitLev = MC_CAN_RESERVE_V2,
		.iDist = u16SRemain,
		.iVel = u16QRDistance,
	};

	LOG_INF("send to can:slow go back:distance=%d mm, qr'distance=%d mm\n", 
		u16SRemain, u16QRDistance);
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :mc_v1_slow_go_straight
*Description      :  
*Input       	  :u16 u16SRemain  
*Input       	  :u16 u16QRDistance  
*Output 		  :
*Return           :int : 0 if OK, -1 on error   
*******************************************************************************/
int mc_v2_slow_go_straight(u16 u16SRemain, u16 u16QRDistance)
{
	int iCount = 0;
	mc_can_action_req_st stReq = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CMD_FORWARD_LEAVE_CHARGE_V2,
		.iRsvd = MC_CAN_RESERVE_V2,
		.iWeitLev = MC_CAN_RESERVE_V2,
		.iDist = u16SRemain,
		.iVel = u16QRDistance,
	};

	LOG_INF("send to can:slow go back:distance=%d mm, qr'distance=%d mm\n", 
		u16SRemain, u16QRDistance);
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v2_cntl_lift_motor
* Description	     : cntl lift motor
* input			     : u8Operate : 0 if lock,  1 on up ,2 when down,
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : pContainNum : the string of container number if lift up; NULL on other.
* Output		     : NONE
* Return		     :0 if OK ,-1 on error
*******************************************************************************/
int mc_v2_cntl_lift_motor(u8 u8Operate, u8 u8Weight)
{
	int iCount = 0;
	mc_can_action_req_st stReq = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = u8Operate,
		.iRsvd = MC_CAN_RESERVE_V2,
		.iWeitLev = MC_CAN_RESERVE_V2,
		.iDist = MC_CAN_RESERVE_V2,
		.iVel = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:cntl lift motor:operate=[%d-%s], weight=%d\n",
		u8Operate, get_tc_cmd_name(u8Operate), u8Weight);
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(mc_can_action_req_st))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v2_cntl_cycle_motor
* Description	     : make cycle motor lock ,turn left or turn right
* input			     : u8Operate : 0 if lock,  1 on up ,2 when down,
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Angle : In unit of 0.1 degree
* input			     : u16Speed : In unit of millimeter per second
* Output		     : NONE
* Return		     : 0 if OK ,-1 on error
*******************************************************************************/
int mc_v2_cntl_cycle_motor(u8 u8Operate, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	int iCount = 0;
	mc_can_action_req_st stReq = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = u8Operate,
		.iRsvd = MC_CAN_RESERVE_V2,
		.iWeitLev = u8Weight,
		.iDist = u16Angle,
		.iVel = u16Speed,
	};

	LOG_INF("send to can:cntl cycle motor:operate=[%d-%s], weight=%d, angle=%d, speed=%d\n",
		u8Operate, get_tc_cmd_name(u8Operate), u8Weight, u16Angle, u16Speed);
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(mc_can_action_req_st))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v2_stop
* Description	     : stop MC
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v2_stop()
{
	int iCount = 0;
	mc_can_action_req_st stReq = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CAN_CMD_STOP_V2,
		.iRsvd = MC_CAN_RESERVE_V2,
		.iWeitLev = MC_CAN_RESERVE_V2,
		.iDist = MC_CAN_RESERVE_V2,
		.iVel = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:stop agv mc\n");
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(mc_can_action_req_st))
	{
		return -1;
	}
	return 0;
}
/*******************************************************************************
* Function Name		 : mc_panasonic_charge
* Description	     : stop charge power
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_panasonic_charge()
{
	int iCount = 0;
	struct can_frame stFrameCharge =
	{
		.can_id = BATT_REQ_V2_CANID,
		.can_dlc = MC_DATA_DLC_V2,
		.data[0] = BATT_CHARGE_FLAG,
		.data[1] = MC_CAN_RESERVE_V2,
		.data[2] = MC_CAN_RESERVE_V2,
		.data[3] = MC_CAN_RESERVE_V2,
		.data[4] = MC_CAN_RESERVE_V2,
		.data[5] = MC_CAN_RESERVE_V2,
		.data[6] = MC_CAN_RESERVE_V2,
		.data[7] = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:panasonic start charge request\n");
	print_can_frame(&stFrameCharge);

	iCount = send_can(BATT_CAN_DEV, &stFrameCharge);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
/*******************************************************************************
* Function Name		 : mc_panasonic_stopcharge
* Description	     : stop charge power
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_panasonic_stopcharge()
{
	int iCount = 0;
	struct can_frame sFrameStopCharge =
	{
		.can_id = BATT_REQ_V2_CANID,
		.can_dlc = MC_DATA_DLC_V2,
		.data[0] = BATT_STOP_CHARGE_FLAG,
		.data[1] = MC_CAN_RESERVE_V2,
		.data[2] = MC_CAN_RESERVE_V2,
		.data[3] = MC_CAN_RESERVE_V2,
		.data[4] = MC_CAN_RESERVE_V2,
		.data[5] = MC_CAN_RESERVE_V2,
		.data[6] = MC_CAN_RESERVE_V2,
		.data[7] = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:panasonic stop charge request\n");
	print_can_frame(&sFrameStopCharge);

	iCount = send_can(BATT_CAN_DEV, &sFrameStopCharge);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
/*******************************************************************************
* Function Name		 : mc_v2_start_charge
* Description	     : start charge power
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v2_start_charge()
{
	int iCount = 0;
	mc_panasonic_charge();
	mc_can_action_req_st stReq = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CAN_CMD_PARK_V2,
		.iRsvd = MC_CAN_RESERVE_V2,
		.iWeitLev = MC_CAN_RESERVE_V2,
		.iDist = MC_CAN_RESERVE_V2,
		.iVel = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:start charge\n");
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(mc_can_action_req_st))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v2_stop_charge
* Description	     : stop charge power
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v2_stop_charge()
{
	int iCount = 0;
	mc_panasonic_stopcharge();
	mc_can_action_req_st stReq = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CAN_CMD_STOPPARK_V2,
		.iRsvd = MC_CAN_RESERVE_V2,
		.iWeitLev = MC_CAN_RESERVE_V2,
		.iDist = MC_CAN_RESERVE_V2,
		.iVel = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:stop charge\n");
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(mc_can_action_req_st))
	{
		return -1;
	}	
	return 0;
}

/*******************************************************************************
* Function Name		 : mc_v2_restart
* Description	     : restart the mc
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int mc_v2_restart()
{
	int iCount = 0;
	mc_can_action_req_st stReq = {
		.iCanId = MC_CAN_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAction = MC_CAN_CMD_RESTART_V2,
		.iRsvd = MC_CAN_RESERVE_V2,
		.iWeitLev = MC_CAN_RESERVE_V2,
		.iDist = MC_CAN_RESERVE_V2,
		.iVel = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:restart\n");
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(mc_can_action_req_st))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :get_system_event_err
*Description      :change the exceptions of MC system to agent event
*Input       	  :int iErrId: error code of MC
*Output 		  :NONE
*Return           :int:0 if not find ,else agent event code
*******************************************************************************/
int get_system_event_err(int iErrId)
{
	int iEventNum = 0;
	if ((iErrId >= MC_ERR_LIFT_SERVO_INVALID) && (iErrId <= MC_ERR_LIFT_SERVO_DISCONNECT))
	{
		iEventNum = iErrId + MC_ERR_BASE1;
	}
	else if ((iErrId >= MC_ERR_EMO_LWHEEL_SERVO_ERROR) && (iErrId <= MC_ERR_HSLS_LIFT_SERVO_ERROR))
	{
		iEventNum = iErrId + MC_ERR_BASE2;
	}	
	else if ((iErrId >= MC_ERR_LOSENAVIGATE) && (iErrId <= MC_ERR_PLATE_CYCLE_MOTOR_NO_ACTION))
	{
		switch (iErrId)
		{
		case MC_ERR_LOSENAVIGATE:
			iEventNum = EVENT_ERR_LOSENAVIGATE;
			break;
		case MC_ERR_DIFFOVAFTERTHREE:
			iEventNum = EVENT_ERR_DIFFOV_AFTERTHREE;
			break;
		case MC_ERR_WHEEL_ANGLEDIFFOV:
			iEventNum = EVENT_ERR_WHEEL_PLATE_ANGLEDIFFOV;
			break;
		case MC_ERR_PLATE_ANGLEDIFFOV:
			iEventNum = EVENT_ERR_TC_WHEEL_PLATE_ANGLE_OV;
			break;
		case MC_ERR_EMERSTOP:
			iEventNum = EVENT_ERR_EMERSTOP;
			break;
		case MC_ERR_TURNING: //add by tiger.69
			iEventNum = EVENT_ERR_TURNING;
			break;
		case MC_ERR_EMERSTOPPRESS:
			iEventNum = EVENT_ERR_EMERSTOPPRESS;
			break;
		case MC_ERR_TC_LIFT_TACK_1MIN:
			iEventNum = EVENT_ERR_TC_LIFT_TACK_1MIN;
			break;
		case MC_ERR_DERAIL:
			iEventNum = EVENT_ERR_DERAIL;
			break;
		case MC_ERR_CHARGE_FEEDBACK_OVERTIME:
			iEventNum = EVENT_ERR_CHARGE_FEEDBACK_OVERTIME;
			break;
		case MC_ERR_OB_DETECT_FAULT_EVENT:
			iEventNum = EVENT_ERR_OB_DETECT_FAULT_EVENT;
			break;
		case MC_ERR_RESET://by tiger.70
			iEventNum = EVENT_ERR_MC_RESET;
			break;
		case MC_ERR_LEFTSERVOINVALID:
			iEventNum = EVENT_ERR_LEFTSERVOINVALID;
			break;
		case MC_ERR_RIGHTSERVOINVALID:
			iEventNum = EVENT_ERR_RIGHTSERVOINVALID;
			break;
		case MC_ERR_ENCODERL:
			iEventNum = EVENT_ERR_ENCODERL;
			break;
		case MC_ERR_ENCODERR:
			iEventNum = EVENT_ERR_ENCODERR;
			break;
		case MC_ERR_MOTORL_NO_ACTION_EVENT:
			iEventNum = EVENT_ERR_MOTORL_NO_ACTION_EVENT;
			break;
		case MC_ERR_MOTORR_NO_ACTION_EVENT:
			iEventNum = EVENT_ERR_MOTORR_NO_ACTION_EVENT;
			break;
		case MC_ERR_PLATE_CYCLE_SERVO_ERR:
			iEventNum = EVENT_ERR_PLATE_CYCLE_SERVO_INVALID;
			break;
		case MC_ERR_PLATE_CYCLE_ENCODER_ERR:
			iEventNum = EVENT_ERR_TC_CYCLE_ENCODEER_ERR;
			break;
		case MC_ERR_PLATE_CYCLE_MOTOR_NO_ACTION:
			iEventNum = EVENT_ERR_TC_CYCLE_MOTOR_NO_ACTION;
			break;
		default:
			break;
		}
	}
	else
	{
		iEventNum = iErrId + MC_ERR_BASE2;
	}
	return iEventNum;
}

/*******************************************************************************
*Function Name    :get_server_sub_errcode
*Description      :change the exceptions of MC system to agent event
*Input       	  :int iErrId: error code of MC
*Output 		  :NONE
*Return           :int:0 if not find ,else agent event code
*******************************************************************************/
int get_servo_sub_errcode(int iErrId,int iSubErr)
{
	if ((iErrId >= EVENT_ERR_EMO_LWHEEL_SERVO_ERROR) && (iErrId <= EVENT_ERR_EMO_LIFT_SERVO_ERROR))
	{
		char sSubErrCode[64] = { 0 };
		sprintf(sSubErrCode, "%02d%06d", EMO_SID, iSubErr);
		sscanf(sSubErrCode, "%d", &g_stAgvAttr.iServoSubErr);
	}
	else if ((iErrId >= EVENT_ERR_MOTEC_LWHEEL_SERVO_ERROR) && (iErrId <= EVENT_ERR_MOTEC_LIFT_SERVO_ERROR))
	{
		char sSubErrCode[64] = { 0 };
		sprintf(sSubErrCode, "%02d%06d", MOTEC_SID, iSubErr);
		sscanf(sSubErrCode, "%d", &g_stAgvAttr.iServoSubErr);
	}
	else if ((iErrId >= EVENT_ERR_HSLS_LWHEEL_SERVO_ERROR) && (iErrId <= EVENT_ERR_HSLS_LIFT_SERVO_ERROR))
	{
		char sSubErrCode[64] = { 0 };
		sprintf(sSubErrCode, "%02d%06d", HSLS_SID, iSubErr);
		sscanf(sSubErrCode, "%d", &g_stAgvAttr.iServoSubErr);
	}
	else
	{
		g_stAgvAttr.iServoSubErr = FALSE;
	}
	LOG_INF("g_stAgvAttr.iServoSubErr=%d\n", g_stAgvAttr.iServoSubErr);
	return 0;
}
/*******************************************************************************
*Function Name    :mc_v2_deal_exception
*Description      : deal with the exceptions of AGV_2_0 
*Input       	  :struct can_frame * pCanFrame  
*Input       	  :agv_attr_t * pAgvAttr  
*Output 		  :
*Return           :void  
*******************************************************************************/
int mc_v2_deal_exception(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	mc_can_exception_notify_st  *pMcException = (mc_can_exception_notify_st *)pCanFrame;
	unsigned short iErrId = pMcException->iErrId;
	unsigned int   iStyle = pMcException->iStyle;
	unsigned int   iSubErrCode = pMcException->iData;//add by jxu 20180510
	int iErrMsgid = 0;

	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return 0;

	LOG_INF("deal AGV2.0 exception can frame\n");
	print_can_frame(pCanFrame);

	switch (iStyle)
	{
	case MC_STYLE_ERR_SYSTEMSTATUS:
		//TODO:other err code
		if (iErrId == MC_ERR_AGVSAFE)
			iErrMsgid = EVENT_ERR_AGVSAFE;
		else if (iErrId == MC_ERR_NOCONTACTIMPACT)
			iErrMsgid = EVENT_ERR_NOCONTACTIMPACT;
		break;
	case MC_STYLE_ERR_SYSTEMERR:
		iErrMsgid = get_system_event_err(iErrId);
		break;
	default:
		break;
	}
	
	get_servo_sub_errcode(iErrMsgid, iSubErrCode);//add by jxu 20180510

	// if error event continuously happen
	// is necessary to send error msg continuously? NO
	if (g_stAgvAttr.iMcError != iErrMsgid )//by tiger.67
	{
		g_stAgvAttr.iMcError = iErrMsgid;
		return -iErrMsgid;
	}

	return 0;
}

/*******************************************************************************
*Function Name    :mc_v2_get_param
*Description      :  
*Input       	  :u8 u8ParamVar  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_get_param(u8 u8ParamVar)
{
	int iCount = 0;
	mc_can_rw_flag_param_req_st stReq = {
		.iCanId = MC_CAN_FLAG_PARAM_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID),
		.iCmd = MC_TYPE_READ_V2_PARAM,
		.iParamId = u8ParamVar,
		.iParamVal = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:get param\n");
	print_can_frame((struct can_frame *)&stReq);	

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :mc_v2_set_param
*Description      :  
*Input       	  :u8 u8ParamVar  
*Input       	  :u32 u32Value  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_set_param(u8 u8ParamVar, float fValue) //by tiger.42
{
	int iCount = 0;
	mc_can_rw_param_req_st stCanFrame = {
		.iCanId = MC_CAN_FLAG_PARAM_REQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID),
		.iCmd = MC_TYPE_SET_V2_PARAM,
		.iParamId = u8ParamVar,
		.iParamVal = fValue,
	};

	LOG_INF("send to can:set param\n");
	print_can_frame((struct can_frame *)&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
#define VAR_AGV2_0_OUT_TRACK	0x03
#define CLEAN_FLAG      0

/*******************************************************************************
*Function Name    :mc_v2_clear_derail
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_clear_derail(void)
{
	int iRet = 0;
	iRet = set_flag(DEV_MC, VAR_AGV2_0_OUT_TRACK, CLEAN_FLAG);
	return iRet;
}
#define VAR_AGV2_0_OUT_NAVIGATE	0x04 

/*******************************************************************************
*Function Name    :mc_v2_clear_navigation
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_clear_navigation(void)
{
	int iRet = 0;
	iRet = set_flag(DEV_MC, VAR_AGV2_0_OUT_NAVIGATE, CLEAN_FLAG);
	return iRet;
}
#define  VAR_AGV2_0_LCODE_ERROR 0x0B

/*******************************************************************************
*Function Name    :mc_v2_clear_lcoder_error
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_clear_lcoder_error(void)
{
	int iRet = 0;
	iRet = set_flag(DEV_MC, VAR_AGV2_0_LCODE_ERROR, CLEAN_FLAG);
	return iRet;
}
#define  VAR_AGV2_0_RCODE_ERROR 0x0C

/*******************************************************************************
*Function Name    :mc_v2_clear_rcoder_error
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_clear_rcoder_error(void)
{
	int iRet = 0;
	iRet = set_flag(DEV_MC, VAR_AGV2_0_RCODE_ERROR, CLEAN_FLAG);
	return iRet;
}
#define VAR_AGV2_0_DEBUG_MODE 0x10
#define ENTER_DEBUG_MODE    1
#define QUIT_DEBUG_MODE		0

/*******************************************************************************
*Function Name    :mc_v2_enter_debug_mode
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_enter_debug_mode(void)
{
	return set_flag(DEV_MC, VAR_AGV2_0_DEBUG_MODE, ENTER_DEBUG_MODE);	
}

/*******************************************************************************
*Function Name    :mc_v2_quit_debug_mode
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_quit_debug_mode(void)
{
	return set_flag(DEV_MC, VAR_AGV2_0_DEBUG_MODE, QUIT_DEBUG_MODE);
}
#define VAR_AGV2_0_WHEEL_CLASP		0x08
#define VAR_AGV2_0_PALLET_CLASP	    0x09

/*******************************************************************************
*Function Name    :mc_v2_clasp_pallet
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_clasp_pallet(void)
{
	return set_flag(DEV_MC, VAR_AGV2_0_PALLET_CLASP, 1);
}

/*******************************************************************************
*Function Name    :mc_v2_unclasp_pallet
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_unclasp_pallet(void)
{
	return set_flag(DEV_MC, VAR_AGV2_0_PALLET_CLASP, 0);
}

/*******************************************************************************
*Function Name    :mc_v2_clasp_wheel
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_clasp_wheel(void)
{
	return set_flag(DEV_MC, VAR_AGV2_0_WHEEL_CLASP, 1);
}

/*******************************************************************************
*Function Name    :mc_v2_unclasp_wheel
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :int  
*******************************************************************************/
int mc_v2_unclasp_wheel(void)
{
	return set_flag(DEV_MC, VAR_AGV2_0_WHEEL_CLASP, 0);
}

/*******************************************************************************
* Function Name		 : mc_v2_send_angle_offset
* Description	     : send plate angle error
* input			     : u16Angle : In unit of 0.01 degree
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int mc_v2_send_angle_offset(u16 u16Angle)
{
	int iCount = 0;
	//add by jxu 20180920-begin
	int iSupportDiff = CAMERA_VERSION_NOSUPDIFF;
	if (g_stTopCameraDev.iVersion == CAMERA_VERSION_UART)
	{
		iSupportDiff = g_stTopCameraDev.iUartVersion;
	}
	else if (g_stTopCameraDev.iVersion == CAMERA_VERSION_V4L2)
	{
		iSupportDiff = CAMERA_VERSION_SUPDIFF;
	}
	else
	{
		LOG_ERR("g_stTopCameraDev.iVersion[%d] in invalid\n", g_stTopCameraDev.iVersion);
	}
	//add by jxu 20180920-end
	plate_can_angle_req_st stReq = {
		.iCanId = TP_CAN_ANGLEREQ_V2_CANID,
		.iCanDlc = MC_DATA_DLC_V2,
		.iSeq = get_seq(MC_SEQ_ID) % 0xFF,
		.iAngle = u16Angle,
		.iDiffY = g_stQrInfo.iYOffset,
		.iDiffX = g_stQrInfo.iXOffset,
		.iCameraVer = g_stTopCameraDev.iVersion, //add by jxu 20180920
		.iSuppDiff = iSupportDiff,//add by jxu 20180920
		.iRsvd = MC_CAN_RESERVE_V2,
	};

	LOG_INF("send to can:send angle offset\n");
	print_can_frame((struct can_frame *)&stReq);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stReq);
	if (iCount != sizeof(plate_can_angle_req_st))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :mc_v2_start_update_crc_cmd
*Description      :send update crc cmd to mc
*Input       	  :u32 u32Crc32
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error
*******************************************************************************/
int mc_v2_update_crc_cmd(u32 u32Crc32)
{
	int iCount = 0;
	mc_update_req stCanFrame = {
		.can_id = ARM2MC_UPDATE_CANID,
		.can_dlc = MC_DATA_DLC,
		.u32Data = htonl(u32Crc32),
		.u8data4 = REVERSE_VALUE,
		.u8data5 = REVERSE_VALUE,
		.u8Style = MC_UPDATE_CRC_CMD,
		.u8Sequence = get_seq(MC_SEQ_ID) % 0xFF,
	};
	LOG_INF("send to can:mc update crc cmd\n");
	print_can_frame((struct can_frame *)&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :mc_v2_start_update_length_cmd
*Description      :send update length cmd to mc
*Input       	  :u32 u32Length
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error
*******************************************************************************/
int mc_v2_update_length_cmd(u32 u32Length)
{
	int iCount = 0;
	if (u32Length < 0)
	{
		LOG_ERR("invalid input argue value\n");
		return -1;
	}

	mc_update_req stCanFrame = {
		.can_id = ARM2MC_UPDATE_CANID,
		.can_dlc = MC_DATA_DLC,
		.u32Data = htonl(u32Length),
		.u8data4 = REVERSE_VALUE,
		.u8data5 = REVERSE_VALUE,
		.u8Style = MC_UPDATE_LENGTH_CMD,
		.u8Sequence = get_seq(MC_SEQ_ID) % 0xFF,
	};
	LOG_INF("send to can:mc update length cmd\n");
	print_can_frame((struct can_frame *)&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *)&stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
*Function Name    :mc_v2_start_update_abort_cmd
*Description      :send update abort cmd to mc
*Output 		  :NONE
*Return           :int:0 if OK,-1 on error
*******************************************************************************/
int mc_v2_update_abort_cmd()
{
	int iCount = 0;
	mc_update_req stCanFrame = {
		.can_id = ARM2MC_UPDATE_CANID,
		.can_dlc = MC_DATA_DLC,
		.u32Data = REVERSE_VALUE,
		.u8data4 = REVERSE_VALUE,
		.u8data5 = REVERSE_VALUE,
		.u8Style = MC_UPDATE_ABORT_CMD,
		.u8Sequence = get_seq(MC_SEQ_ID) % 0xFF,
	};
	LOG_INF("send to can:mc update abort cmd\n");
	print_can_frame((struct can_frame *)&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, (struct can_frame *) &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}
/******************* (C) COPYRIGHT 2018  Jd.Com, Inc . *****END OF FILE****/
