/********************************************************************************
* Copyright (c) 2017, JD.COM, Inc .
* All rights reserved.
* FileName: tc_v1.c
* Author: tongkedong   Version: V1.0   Data:2017-12-18
* Description:
* top control low-level support api code
********************************************************************************/
#include "tc_v1.h"

/*******************************************************************************
* Function Name      : tc_v1_check_version
* Description	     : check tc software'version
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int tc_v1_check_version()
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;
	stCanFrame.can_id = TC_CANID_REQ;
	stCanFrame.can_dlc = TC_DATA_DLC;
	stCanFrame.data[4] = TC_VERSION_F;
	stCanFrame.data[6] = TC_TYPE_READ_F;
	stCanFrame.data[7] = get_seq(TC_SEQ_ID);

	LOG_INF("send to can:check version\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}


/*******************************************************************************
* Function Name		 : tc_v1_get_flag
* Description	     : get flag of TC
* input			     : u8FlagVar : series number of flag var
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int tc_v1_get_flag(u8 u8FlagVar)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2TC_CMD_CANID;
	stCanFrame.can_dlc = TC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(TC_SEQ_ID));
	stCanFrame.data[6] = TC_GET_FLAG;  //cmd
	stCanFrame.data[4] = u8FlagVar;  //var

	LOG_INF("send to can:get flag\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : tc_v1_set_flag
* Description	     : set flag of TC
* input			     : u8FlagVar : series number of flag var
* input			     : fValue : value will be set
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int tc_v1_set_flag(u8 u8FlagVar, u32 u32Value)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2TC_CMD_CANID;
	stCanFrame.can_dlc = TC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(TC_SEQ_ID));
	stCanFrame.data[6] = TC_SET_FLAG;  //cmd
	stCanFrame.data[4] = u8FlagVar;	 //flag var
	*((int *)(&stCanFrame.data[0])) = u32Value;

	LOG_INF("send to can:set flag\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : tc_v1_get_param
* Description	     : get param from TC
* input			     : u8FlagVar : series number of flag var
* input			     : fValue : the value of param var
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int tc_v1_get_param(u8 u8ParamVar)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2TC_CMD_CANID;
	stCanFrame.can_dlc = TC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(TC_SEQ_ID));
	stCanFrame.data[6] = TC_GET_PARAM;  //cmd
	stCanFrame.data[4] = u8ParamVar;  //param

	LOG_INF("send to can:get param\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : tc_v1_set_param
* Description	     : set param for TC
* input			     : u8FlagVar : series number of flag var
* input			     : fValue : the value of param var
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int tc_v1_set_param(u8 u8ParamVar, float fValue)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2TC_CMD_CANID;
	stCanFrame.can_dlc = TC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(TC_SEQ_ID));
	stCanFrame.data[6] = TC_SET_PARAM;  //cmd
	stCanFrame.data[4] = u8ParamVar;  //flag var
	*((float *)(&stCanFrame.data[0])) = fValue;
	
	LOG_INF("send to can:set param\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : tc_v1_enable_wdg
* Description	     : enable watchdog for TC
* Input              : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int tc_v1_enable_wdg()
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2TC_CMD_CANID;
	stCanFrame.can_dlc = TC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(TC_SEQ_ID));
	stCanFrame.data[6] = TC_OPERATE;  //cmd
	stCanFrame.data[5] = TC_ENABLE_WDG;  //wdg

	LOG_INF("send to can:enable tc watchdog\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : tc_v1_start
* Description	     : start tc
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int tc_v1_start()
{
	struct can_frame stCanFrame = { 0 };
	int iRet = 0;

	// nothing to do

	return iRet;
}

/*******************************************************************************
* Function Name		 : tc_v1_reset
* Description	     : reset tc
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int tc_v1_reset()
{
	struct can_frame stCanFrame = { 0 };
	int iRet = 0;

	// nothing to do

	return iRet;
}


/*******************************************************************************
* Function Name		 : tc_v1_stop
* Description	     : stop TC
* input			     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int tc_v1_stop()
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2TC_CMD_CANID;
	stCanFrame.can_dlc = TC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(TC_SEQ_ID));
	stCanFrame.data[6] = TC_OPERATE; //cmd
	stCanFrame.data[5] = TC_STOP; //stop agv

	LOG_INF("send to can:stop agv tc\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : tc_v1_deal_ack
* Description	     : deal with TC ACK msg, and send finish msg to console
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
///start by tiger.17
void tc_v1_deal_ack(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	tc_can_cmd_ack_t * pTcCanCmdAck = NULL;

	u16 u16Status = 0;
	u32 u32Data = 0;

	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return;

	pTcCanCmdAck = (tc_can_cmd_ack_t *)pCanFrame;

	LOG_DBG("tc can ack[seq=%d style=%d cmd=%d rsv=%d data1=0x%04x data2=0x%04x]\n",
		pTcCanCmdAck->iSeq, pTcCanCmdAck->iStyle, pTcCanCmdAck->iCmd,
		pTcCanCmdAck->iReserve, pTcCanCmdAck->iData1, pTcCanCmdAck->iData2);
	print_can_frame(pCanFrame);

	u16Status = *((u16*)&pTcCanCmdAck->iData1);
	u32Data = *((u32*)&pTcCanCmdAck->iData1);
	pAgvAttr->iTcAction = pTcCanCmdAck->iCmd;
	pAgvAttr->iTcStyle = pTcCanCmdAck->iStyle;
	switch (pAgvAttr->iTcStyle)
	{
	case TC_SET_FLAG:
		pAgvAttr->stTcProperty.key = pTcCanCmdAck->iReserve;
		pAgvAttr->stTcProperty.value = u32Data;
		break;
	case TC_GET_FLAG:
		pAgvAttr->stTcProperty.key = pTcCanCmdAck->iReserve;
		pAgvAttr->stTcProperty.value = u32Data;
		break;
	case TC_SET_PARAM:
		pAgvAttr->stTcProperty.key = pTcCanCmdAck->iReserve;
		pAgvAttr->stTcProperty.value = u32Data;
		break;
	case TC_GET_PARAM:
		pAgvAttr->stTcProperty.key = pTcCanCmdAck->iReserve;
		pAgvAttr->stTcProperty.value = u32Data;
		break;
	case TC_OPERATE:
		pAgvAttr->iTcState = u16Status;  
		break;
	default:
		LOG_INF("received TC'ACK :noting to do\n");
		break;
	}
}
///end by tiger.17
/*******************************************************************************
* Function Name		 : tc_v1_deal_fin
* Description	     : deal with TC finish and send msg to console
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void tc_v1_deal_fin(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	tc_can_cmd_fin_t * pTcCanCmdFin = NULL;
	int iRet = 0;

	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return;

	pTcCanCmdFin = (tc_can_cmd_fin_t *)pCanFrame;

	// when canid=0x284, filter CAN_MDH(Byte[4~7])=0xA55A0101\0xA55A0102\0xA55A0103
	if ((pCanFrame->data[7] == 0xA5) && (pCanFrame->data[6] == 0x5A))
	{
		pAgvAttr->iTcAction = -1;		//Byte[5]
		pAgvAttr->iTcStyle = -1;		//Byte[6]
	}
	else
	{
		pAgvAttr->iTcAction = pTcCanCmdFin->iCmd;		//Byte[5]
		pAgvAttr->iTcStyle = pTcCanCmdFin->iStyle;		//Byte[6]
	}

	LOG_INF("recv action[%d-%s] finish can frame\n",
		pAgvAttr->iTcAction, get_mc_cmd_name(pAgvAttr->iTcAction));
	print_can_frame(pCanFrame);

	return;
}

/*******************************************************************************
* Function Name		 : deal_angle_ack
* Description	     : deal with angle ack of TC
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
void tc_v1_deal_angle_ack(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return;

	LOG_INF("deal tc angle ack can frame\n");
	print_can_frame(pCanFrame);

	//nothing to do
}

/*******************************************************************************
* Function Name		 : tc_v1_deal_heartbeat
* Description	     : deal with the TC heartbeat frame
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int tc_v1_deal_heartbeat(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return 0;

	//LOG_INF("deal tc heartbeat can frame\n");
	//print_can_frame(pCanFrame);

	//nothing to do
	return 0;
}

/*******************************************************************************
* Function Name		 : tc_v1_deal_exception
* Description	     : deal with the exceptions of TC
* input			     : pCanFrame : the pointer of can frame
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int tc_v1_deal_exception(struct can_frame * pCanFrame, agv_attr_t * pAgvAttr)
{
	tc_can_notify_t * pTcCanNotify = NULL;

	if ((pCanFrame == NULL) || (pAgvAttr == NULL))
		return 0;

	LOG_INF("deal tc exception can frame\n");
	print_can_frame(pCanFrame);

	pTcCanNotify = (tc_can_notify_t *)pCanFrame;

	pAgvAttr->iTcError = TC_ERROR_BASE + (pTcCanNotify->iData1 & 0xFF);

	return -pAgvAttr->iTcError;//by tiger.50
}

/*******************************************************************************
* Function Name		 : tc_v1_send_angle_offset
* Description	     : send plate angle error
* input			     : u16Angle : In unit of 0.01 degree
* Output		     : NONE
* Return		     : NONE
*******************************************************************************/
int tc_v1_send_angle_offset(u16 u16Angle)
{
	struct can_frame stCanFrame = {0};
	int iCount = 0;

	stCanFrame.can_id = ARM2TC_ANGLE_CANID;
	stCanFrame.can_dlc = 3;
	stCanFrame.data[2] = (u8)(get_seq(TC_SEQ_ID));
	*((u16 *)(&stCanFrame.data[0])) = u16Angle;

	LOG_INF("send to can:send angle offset\n");
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : tc_v1_cntl_lift_motor
* Description	     : cntl lift motor
* input			     : u8Operate : 0 if lock,  1 on up ,2 when down,
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : pContainNum : the string of container number if lift up; NULL on other.
* Output		     : NONE
* Return		     :0 if OK ,-1 on error
*******************************************************************************/
int tc_v1_cntl_lift_motor(u8 u8Operate, u8 u8Weight)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id = ARM2TC_CMD_CANID;
	stCanFrame.can_dlc = TC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(TC_SEQ_ID));
	stCanFrame.data[6] = TC_OPERATE;  //cmd
	stCanFrame.data[5] = u8Operate;  //Operate
	stCanFrame.data[4] = u8Weight;  //stop charging agv

	LOG_INF("send to can:cntl lift motor:operate=[%d-%s], weight=%d\n",
		u8Operate, get_tc_cmd_name(u8Operate), u8Weight);
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}

/*******************************************************************************
* Function Name		 : tc_v1_cntl_cycle_motor
* Description	     : make cycle motor lock ,turn left or turn right
* input			     : u8Operate : 0 if lock,  1 on up ,2 when down,
* input			     : u8Weight : weight, 0~15 corresponding to 0~300KG
* input			     : u16Angle : In unit of 0.1 degree
* input			     : u16Speed : In unit of millimeter per second
* Output		     : NONE
* Return		     : 0 if OK ,-1 on error
*******************************************************************************/
int tc_v1_cntl_cycle_motor(u8 u8Operate, u8 u8Weight, u16 u16Angle, u16 u16Speed)
{
	struct can_frame stCanFrame = { 0 };
	int iCount = 0;

	stCanFrame.can_id  = ARM2TC_CMD_CANID;
	stCanFrame.can_dlc = TC_DATA_DLC;
	stCanFrame.data[7] = (u8)(get_seq(TC_SEQ_ID));
	stCanFrame.data[6] = TC_OPERATE;  //cmd
	stCanFrame.data[5] = u8Operate;  //Operate
	stCanFrame.data[4] = u8Weight;  //stop charging agv
	*((u16 *)(&stCanFrame.data[2])) = u16Angle;
	*((u16 *)(&stCanFrame.data[0])) = u16Speed;

	LOG_INF("send to can:cntl cycle motor:operate=[%d-%s], weight=%d, angle=%d, speed=%d\n",
		u8Operate, get_tc_cmd_name(u8Operate), u8Weight, u16Angle, u16Speed);
	print_can_frame(&stCanFrame);

	iCount = send_can(CTRL_CAN_DEV, &stCanFrame);
	if (iCount != sizeof(struct can_frame))
	{
		return -1;
	}
	return 0;
}