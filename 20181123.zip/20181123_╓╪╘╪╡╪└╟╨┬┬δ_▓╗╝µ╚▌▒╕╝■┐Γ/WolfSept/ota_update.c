/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* FileName: OTA_UPDATE.C
* Author: Menghu Wang   Version: V1.0   Data:2018-01-26
* Description:REALIZE THE INTERFACE OF OTA UPDATE APP
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include <sys/socket.h>
#include <errno.h>
#include "ota_update.h"
#include "ini_rw.h"
#include "ftp.h"
/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/
#define HAVE_NOT_UPDATED  1;
#define HAVE_UPDATED      0;
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
update_master g_stUpdateMaster = {0};
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : copy_file
* Description    : copy source file to the des file
* Input          : source : file name of the source file
* Output         : des;file name of the destination file
* Return         : 0: copy success -1:failed
*******************************************************************************/
static int copy_file(const char *pSource, const char*pDes)
{
	char pTmp = 0;
	FILE *pSourceFp = NULL, *pDesFp = NULL;
	int iFd = 0;
	if ((pSourceFp = fopen(pSource, "rb")) == NULL)		return -1;

	if ((pDesFp = fopen(pDes, "wb")) == NULL) return -1;

	while (!feof(pSourceFp))
	{
		pTmp = fgetc(pSourceFp);
		fputc(pTmp, pDesFp);
	}
	iFd = fileno(pDesFp);
	fsync(iFd);
	fclose(pSourceFp);
	fclose(pDesFp);

	return 0;
}
/*******************************************************************************
*Function Name    :update_success
*Description      :  
*Input       	  :const char * pFilePath:the absolute path of update success file path    
*Output 		  :
*Return           :int:0:update success ;1: have not been updated;-1 on error ;
*******************************************************************************/
int update_success(const char *pFilePath)
{
	int iRet = 0;
	int iFd = 0;
	struct stat stFileInfo = { 0 };
	u8 pSourceFilName[100] = { 0 };
	u8 pDesFilName[100] = { 0 };
	int iCount = 0;
	if (NULL == pFilePath)
	{
		LOG_ERR("the path is null\n");
		return -1;
	}

	iRet = stat(pFilePath, &stFileInfo);
	if (iRet < 0)
	{
		LOG_ERR("get %s info failure:[%d-%s]\n", pFilePath, errno, strerror(errno));
		iRet = HAVE_NOT_UPDATED;
		return iRet;
	}
	
	sprintf(pSourceFilName, "%s/%s", g_stUpdateMaster.pCurrentDir, g_stUpdateMaster.pMasterAppName);
	sprintf(pDesFilName, "%s/%s", g_stUpdateMaster.pExcuteDir, g_stUpdateMaster.pMasterAppName);
	iCount = 5;
	while ((iCount-- > 0) && (copy_file(pSourceFilName, pDesFilName) != 0))     //copy the app to the excute dir
	{
		LOG_WRN("copy %s error\n",g_stUpdateMaster.pMasterAppName);
		sleep(1);
	}
	if (iCount > 0)
	{
		LOG_INF("copy %s success\n",g_stUpdateMaster.pMasterAppName);
	}

	sprintf(pDesFilName, "%s/%s", g_stUpdateMaster.pExcuteDir, g_stUpdateMaster.pMasterAppName); //change mode to 0777
	iRet = chmod(pDesFilName, S_IRWXU | S_IRWXG | S_IRWXO);
	if (iRet < 0)
		LOG_WRN("error:chmod %s to 0777 error!!!\n", pDesFilName);
	iFd = open(pDesFilName, O_RDWR);
	fsync(iFd);
	close(iFd);
	
	if (remove(pFilePath) < 0)
	{
		LOG_WRN("remove update_success failed\n");
		return -1;
	}
	
	iRet = HAVE_UPDATED;
	return iRet;
}

/*******************************************************************************
*Function Name    :get_new_version
*Description      :  
*Input       	  :char * pNewVersion  
*Output 		  :
*Return           :int  
*******************************************************************************/
int get_new_version(char *pNewVersion)
{
	int iRet = 0;
	iRet = g_stUpdateMaster.get_new_version(g_stUpdateMaster.pNewVersion);
	if (iRet < 0)
	{
		LOG_ERR("Get new version failed\n");
	}
	return iRet;
}

/*******************************************************************************
*Function Name    :need_upgrade
*Description      :  
*Input       	  :const char * pCurVersion  
*Input       	  :const char * pNewVersion  
*Output 		  :
*Return           :int  
*******************************************************************************/
int need_upgrade(const char *pCurVersion, const char *pNewVersion)
{
	int iRet = 0;

	return iRet;
}

/*******************************************************************************
*Function Name    :download_app
*Description      :  
*Input       	  :const char * pMasterAppName  
*Input       	  :const char * pDownloadDir  
*Output 		  :
*Return           :int  
*******************************************************************************/
static int download_file(const char *pMasterAppName, const char *pDownloadDir)
{
	int iRet = 0;

	return iRet;
}

/*******************************************************************************
*Function Name    :execute_app
*Description      :  
*Input       	  :const char * pUpdateScriptPath  
*Output 		  :
*Return           :void  
*******************************************************************************/
static void execute_app(const char *pUpdateScriptPath)
{
	char pUpdateCmd[100] = { 0 };
	sprintf(pUpdateCmd, "sudo /bin/sh %s", pUpdateScriptPath);
	LOG_INF("Start the new master app\n");
	if (system(pUpdateCmd) < 0)
	{
		LOG_WRN("function system error:\n");
	}
	exit(0);
}

/*******************************************************************************
*Function Name    :ota_update_init
*Description      :  
*Input       	  :const char * pConfFilePath  
*Input       	  :update_master * pUpdateMaster  
*Output 		  :
*Return           :int  
*******************************************************************************/
int ota_update_init(const char *pConfFilePath, update_master *pUpdateMaster)
{
	int iRet = 0;
	update_master stUpdateMaster = { 0 };
	iRet = ini_read(CONFIGURE_FILE_PATH, "autoflow_conf","update_method", stUpdateMaster.pUpdateMethod,sizeof(stUpdateMaster.pUpdateMethod));
	if (iRet < 0)
	{
		strcpy(stUpdateMaster.pUpdateMethod, "ftp");
	}

	if (strcasecmp(stUpdateMaster.pUpdateMethod,"ftp") == 0)
	{
		iRet = _ftp_init(pConfFilePath, &stUpdateMaster);
		if (iRet < 0)
		{
			LOG_ERR("init ftp configure failure\n");
			return iRet;
		}
	}

	*pUpdateMaster = stUpdateMaster;
	return 0;
}

/*******************************************************************************
*Function Name    :ota_update_init
*Description      :  
*Input       	  :update_master * pUpdateMaster  
*Output 		  :
*Return           :int  
*******************************************************************************/
int ota_update_deinit(update_master *pUpdateMaster)
{
	int iRet = 0;
	bzero(&g_stUpdateMaster, sizeof(update_master));

	return iRet;
}

/*******************************************************************************
*Function Name    :ota_update_master
*Description      :  
*Input       	  :void  
*Output 		  :
*Return           :int:0 if success ,1:app is latest,-1 on error  
*******************************************************************************/
int ota_update_master(void)
{
	int iRet = 0;
	char pTmp[100] = {0};
	iRet = ota_update_init(CONFIGURE_FILE_PATH, &g_stUpdateMaster);
	if (iRet < 0)
	{
		LOG_ERR("ota update init failed\n");
		return -1;
	}
	iRet = update_success(g_stUpdateMaster.pUpdateSucFilePath);
	if (iRet < 0)
	{
		LOG_ERR("check update success failed\n");
		return -1;
	}
	else if (iRet = 0)
	{
		LOG_INF("update success\n");
		return 0;
	}

	iRet = g_stUpdateMaster.get_new_version(g_stUpdateMaster.pNewVersion);
	if (iRet < 0)
	{
		LOG_ERR("ota update get new version failed\n");
		return -1;
	}
	iRet = g_stUpdateMaster.need_update(g_stUpdateMaster.pCurVersion, g_stUpdateMaster.pNewVersion);
	if (iRet < 0)
	{
		LOG_INF("the curren version is latest,need not update\n");
		return 1;
	}
	iRet = g_stUpdateMaster.download_file(g_stUpdateMaster.pMasterAppName, g_stUpdateMaster.pDownloadDir, &g_stUpdateMaster.stNetAddr, g_stUpdateMaster.pUserName, g_stUpdateMaster.pPassword, g_stUpdateMaster.u8ConnectTimeout);
	if (iRet < 0)
	{
		LOG_ERR("DownLoad %s failed\n",g_stUpdateMaster.pMasterAppName);
		return -1;
	}
	sprintf(pTmp, "%s/%s", g_stUpdateMaster.pDownloadDir, g_stUpdateMaster.pMasterAppName);
	iRet = chmod(pTmp, 0777);
	if (iRet < 0)
	{
		LOG_WRN("chmod %s to 0777 failed:[%d-%s]\n", pTmp, errno, strerror(errno));
	}
	execute_app(g_stUpdateMaster.pUpdateScriptPath);
}
/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/