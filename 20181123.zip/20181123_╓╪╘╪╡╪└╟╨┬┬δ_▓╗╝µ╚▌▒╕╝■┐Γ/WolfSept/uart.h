/********************************************************************************
* Copyright (c) 2017, Jd.Com, Inc .
* All rights reserved.
* FileName:UART.H
* Author: Menghu Wang   Version: V1.0   Data:2017-06-26
* Description:REALIZE THE UART FUNCTION LIB
*Version: V1.0
*History:
	<author>    <time>    <version>     <desc>
********************************************************************************/
#ifndef __UART_H_
#define __UART_H_
/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <stdlib.h>
#include "debug.h"
/* Exported types ------------------------------------------------------------*/
typedef struct
{
	char cDateBit;
	char cParity;
	char cStopBit;
	int iBaud;
	char *pUartName;
}uart_attr_t;
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
 
#define UART_NAME   "/dev/ttymxc1"
///BAUDRATE  
#define     BAUD_1200       1200  
#define     BAUD_2400       2400  
#define     BAUD_4800       4800  
#define     BAUD_9600       9600  
#define     BAUD_19200      19200 
#define     BAUD_38400      38400
#define     BAUD_57600      57600 
#define     BAUD_115200     115200  
#define     BAUD_460800     460800  
///PARITY 
#define     PARITY_ODD    'O' //ODD
#define     PARITY_EVEN   'E' //EVEN
#define     PARITY_NONE   'N' //NONE
///STOP BIT  
#define     STOP_BIT_1     1  
#define     STOP_BIT_2     2  
///DATA BIT  
#define     DATA_BIT_7     7
#define     DATA_BIT_8     8
/* Exported functions ------------------------------------------------------- */
extern int init_uart(uart_attr_t *pUartAttar);
extern size_t recv_uart(int iFd, char *pRcvBuf, ssize_t iLen);
extern ssize_t send_uart(int iFd, char *pBuf, ssize_t iLen);
extern int close_uart(int iFd);
extern int test_uart(void);
#endif/*__UART_H*/

/******************* (C) COPYRIGHT 2017  Jd.Com, Inc . *****END OF FILE****/