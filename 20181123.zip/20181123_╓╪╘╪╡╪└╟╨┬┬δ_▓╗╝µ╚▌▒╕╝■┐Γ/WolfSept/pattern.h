#ifndef __FINDER_PATTERN_H__
#define __FINDER_PATTERN_H__
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float posX; // 特征模式的X坐标
    float posY; // 特征模式的X坐标
    float estimatedModuleSize; // 比例满足1:1:4:1:1的单位色块像素数目
    int count;  // 计算特征模式中心所用的质点的数目，特征模式的中心是距离相近的点的质心
}snake_code_pattern;

// 开辟特征模式结构体
snake_code_pattern * FuncPatternAlloc();

// 比较两个特征模式是否相等
bool FuncIsPatternEquals(snake_code_pattern *pattern, float moduleSize, float i, float j);

// 合并相近的特征模式
bool FuncPatternCombineEstimate(snake_code_pattern *pattern, float i, float j, float newModuleSize);

#ifdef __cplusplus
}
#endif

#endif // end of __FINDER_PATTERN_H__
