/********************************************************************************
* Copyright (c) 2018, Jd.Com, Inc .
* FileName:xxx.H
* Author: Menghu Wang   Version: V1.0   Data:2018-09-29
* Description:THE INTERFACE OF AGV WGET UPDATE
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
#ifndef _WGET_UPDATE_H__
#define _WGET_UPDATE_H__
/* Define to prevent recursive inclusion -------------------------------------*/
/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
#define MM_APP_URL "storage.jd.com/xbrain.org/03001/000010000standard.tgz"
#define MC_APP_URL "torage.jd.com/xbrain.org/05001/020010000standard.tgz"
#define TC_APP_URL "storage.jd.com/xbrain.org/04001/010010000standard.tgz"
#define MC_APP_URL_V2 "storage.jd.com/xbrain.org/05002/020020000standard.tgz"
#define BMS_APP_URL "storage.jd.com/xbrain.org/05002/xxxxstandard.tgz"
/* Exported functions --------------------------------------------------------*/
extern int wget_download_file(char *pUrl, char *pSaveName, int iTryTime);
#endif /* _WGET_UPDATE_H__ */
/******************* (C) COPYRIGHT 2018  Jd.Com, Inc . *****END OF FILE****/