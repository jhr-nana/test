/********************************************************************************
* Copyright (c) 2018, Jd.Com, Inc .
* FileName:xxx.H
* Author: Menghu Wang   Version: V1.0   Data:2018-02-11
* Description:THE INTERFACE OF AGV OTA MOVE CONTROL
*others: null
*History:
1. Date:
Author:
Modification:
VERSION:
********************************************************************************/
#ifndef _OTA_MC_H__
#define _OTA_MC_H__
/* Define to prevent recursive inclusion -------------------------------------*/
/* Includes ------------------------------------------------------------------*/
#include "global_var.h"
#include <stdbool.h>
/* Exported types ------------------------------------------------------------*/
typedef enum _ota_state
{
	OTA_START = 0,
	OTA_CHECK_CRC_FAILD = 1,
	OTA_CHECK_CRC_SUCCESS = 2,
	OTA_SUCCESS =3,
}ota_state;
typedef struct _update_method
{
	u8    pNewVersion[64];
	u8    pCurVersion[64];
	u8    pUserName[64];
	u8    pPassword[64];
	u8    pUpdateMethod[64];
	u8    pUpdateSucFilePath[64];
	u8    pMasterAppName[64];
	u8    pVersionFileName[64];
	u8    pDownloadDir[128];//download dir
	u8	  pCurrentDir[128];//current version app dir
	u8	  pExcuteDir[128];//the execute app dir
	u8    pUpdateScriptPath[128];//the absolute path of update script
	int   iSocketId;
	u32   u32AppFileCrc32;
	u32	  u32AppFileSize;
	struct sockaddr_in stNetAddr;
	u8	  u8ConnectTimeout;
	int(*get_new_version)(char *pNewVersion);
	int(*need_update)(const char *pCurVersion, const char *pNewVersion);
	int(*download_file)(const char *pFileName, const char *pSavePath, const struct sockaddr_in *pHost, const char *pUserName, const char *pPassword, int iTimeOut);
	int(*upload_file)(const char *pMasterAppName, const char *pDownloadDir);
}update_method;
typedef struct _ota_mc{
	ota_state  enOtaState;
	u32 u32NewVersion;
	update_method stUpdateMethod;
	int(*init)(char *pConfFilePath);
	int (*get_current_version)(void);
	int (*get_new_version)(bool bWgetResult);
	int(*get_app)(bool bWgetResult);
	int (*start_update)(void);
	int (*end_update)(void);
	int (*tx_app)(void);
	int (*excute_app)(void);
	int (*deinit)(void);
}ota_mc;


/* Exported constants --------------------------------------------------------*/
extern ota_mc stOtaMc;
/* Exported macro ------------------------------------------------------------*/
#define MC_APP_NAME "stm32_platform_agv2.bin"
#define MC_VERSION_FILE_NAME "mc_version.txt"

#define MC_UPDATE_DCU  "/root/jdagvclientserver/jdagvserver/mc_update"
/* Exported functions --------------------------------------------------------*/
extern int ota_update_d500_20();
extern int ota_mc_get_new_version(bool bWgetResult);//add by jxu 20180910
extern int ota_mc_get_app(bool bWgetResult);//add by jxu 20180910
#endif /* _OTA_MC_H__ */
/******************* (C) COPYRIGHT 2018  Jd.Com, Inc . *****END OF FILE****/