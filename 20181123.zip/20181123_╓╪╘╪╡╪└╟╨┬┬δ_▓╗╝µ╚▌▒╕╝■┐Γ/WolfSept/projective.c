#include "projective.h"

//#define NATIVE (1)
#ifdef NATIVE

#if 0 /// for usb camera
const uint32_t DivideThres = 600;
const uint32_t FrontThres = 80;
const uint32_t HalfCodeThres = 150;
#else /// for dsp camera
const uint32_t DivideThres = 600;
const uint32_t FrontThres = 60;
const uint32_t HalfCodeThres = 100;
#endif

#else

#if 0 /// for usb camera
const int FrontThres = 55;
const int FrontWidth = 10;
const int TotalWidth = 400;
#else /// for dsp camera
const int FrontThres = 60;
const int FrontWidth = 5;
const int TotalWidth = 200;
#endif

typedef struct tagThresRange{
    int idx_s;
    int idx_e;
    int width;
}FrontRange;

static int FindRowStartPattern(const uint8_t *binImage, int rowStart, int width, int height);
static int FindColStartPattern(const uint8_t *binImage, int colStart, int width, int height);
static int FindRowEndPattern(const uint8_t *binImage, int rowStart, int width, int height);
static int FindColEndPattern(const uint8_t *binImage, int colStart, int width, int height);

#endif

snake_rect FuncBinImageProjection(const uint8_t *binImage, int width, int height)
{
#ifndef NATIVE
    int row = 0, col = 0;
    snake_rect rect = {{0,0},{width-1,height-1}};

    while(1)
    {
        rect.topLeft.Lin = FindRowStartPattern(binImage, row, width, height);
        rect.bottomRight.Lin = FindRowEndPattern(binImage, rect.topLeft.Lin+1, width, height);

        if (rect.bottomRight.Lin-rect.topLeft.Lin > TotalWidth
           || rect.bottomRight.Lin == height-1)
        {
            break;
        }

        row = rect.topLeft.Lin+1;
    }

    while(1)
    {
        rect.topLeft.Pix = FindColStartPattern(binImage, col, width, height);
        rect.bottomRight.Pix = FindColEndPattern(binImage, rect.topLeft.Pix+1, width, height);

        if (rect.bottomRight.Pix-rect.topLeft.Pix > TotalWidth
                || rect.bottomRight.Pix == width-1)
        {
            break;
        }

        col = rect.topLeft.Pix+1;
    }

    if (rect.bottomRight.Lin-rect.topLeft.Lin < TotalWidth/2)
    {
        rect.bottomRight.Lin = height-1;
        rect.topLeft.Lin = 0;
    }

    if (rect.bottomRight.Pix-rect.topLeft.Pix < TotalWidth/2)
    {
        rect.bottomRight.Pix = width-1;
        rect.topLeft.Pix = 0;
    }
    return rect;

#else
    bool bRow = false;
    bool bCol = false;
    int i = 0, j = 0, idx = 0;
    uint32_t rowWhitePixels = 0;
    uint32_t colWhitePixels = 0;
    snake_rect rect = {{0,0},{width-1,height-1}};

    /// 行投影，查找矩形区域的起始行
    idx = 0;
    bRow = false;
    for (i=0; i<height; i++)
    {
        rowWhitePixels = 0;
        for (j=0; j<width; j++)
        {
            if (binImage[idx++]==0xFF)
            {
                /// 统计每行中白色像素的个数
                rowWhitePixels++;
            }
        }

        if (rowWhitePixels>width/2)
        {
            /// 如果二值化后背景色几乎是白色
            /// 则将此操作等价于对黑色像素投影
            rowWhitePixels = width-rowWhitePixels;
        }

        /// 当某一行中白色像素数目小于阈值时，
        /// 认为前景即将出现，此点是前景与背景的分割行
        if (rowWhitePixels<DivideThres)
        {
            bRow = true;
        }

        /// 该行之前已经出现过分割行，
        /// 并且该行的白色像素数目大于阈值时，认为出现前景
        if (bRow && rowWhitePixels>FrontThres)
        {
            rect.topLeft.Lin = i;
            break;
        }
    }

    /// 行投影，查找矩形区域的终止行
    idx = width*height-1;
    bRow = false;
    for (i=height-1; i>=0; i--)
    {
        rowWhitePixels = 0;
        for (j=0; j<width; j++)
        {
            if (binImage[idx--]==0xFF)
            {
                rowWhitePixels++;
            }
        }

        if (rowWhitePixels>width/2)
        {
            rowWhitePixels = width-rowWhitePixels;
        }
        if (rowWhitePixels<DivideThres)
        {
            bRow = true;
        }

        if (bRow && rowWhitePixels>FrontThres)
        {
            rect.bottomRight.Lin = i;
            break;
        }
    }

//    if (rect.topLeft.Lin >= rect.bottomRight.Lin
//        || (rect.bottomRight.Lin-rect.topLeft.Lin)<HalfCodeThres)
//    {
//        rect.topLeft.Lin = 0;
//        rect.bottomRight.Lin = height-1;
//    }

    /// 列投影，查找矩形区域的起始列
    bCol = false;
    for (j=0; j<width; j++)
    {
        colWhitePixels = 0;
        idx = j;
        for (i=0; i<=height; i++)
        {
            if (binImage[idx]==0xFF)
            {
                colWhitePixels++;
            }
            idx += width;
        }

        if (colWhitePixels>height/2)
        {
            colWhitePixels = height-colWhitePixels;
        }

        if (colWhitePixels<DivideThres)
        {
            bCol = true;
        }

        if (bCol && colWhitePixels>FrontThres)
        {
            rect.topLeft.Pix = j;
            break;
        }
    }

    /// 列投影，查找矩形区域的终止列
    bCol = false;
    for (j=width-1; j>=0; j--)
    {
        colWhitePixels = 0;
        idx = j;
        for (i=0; i<=height; i++)
        {
            if (binImage[idx]==0xFF)
            {
                colWhitePixels++;
            }
            idx += width;
        }

        if (colWhitePixels>(height)/2)
        {
            colWhitePixels = height-colWhitePixels;
        }

        if (colWhitePixels<DivideThres)
        {
            bCol = true;
        }

        if (bCol && colWhitePixels>FrontThres)
        {
            rect.bottomRight.Pix = j;
            break;
        }
    }

//    if (rect.topLeft.Pix >= rect.bottomRight.Pix
//        || (rect.bottomRight.Pix-rect.topLeft.Pix)<HalfCodeThres)
//    {
//        rect.topLeft.Pix = 0;
//        rect.bottomRight.Pix = width-1;
//    }

    return rect;
#endif
}

#ifndef NATIVE
int FindRowStartPattern(const uint8_t *binImage, int rowStart, int width, int height)
{
    int i = 0, j = 0, idx = 0;
    uint32_t rowFrontPixels = 0;
    int res = height-1;
    FrontRange range;

    idx = rowStart*width;
    range.idx_s = range.idx_e = -1;
    range.width = 0;
    for (i=rowStart; i<height; i++)
    {
        rowFrontPixels = 0;
        for (j=0; j<width; j++)
        {
            if (binImage[idx++]==0xFF)
            {
                /// 统计每行中前景像素的个数
                /// 默认白色为前景
                rowFrontPixels++;
            }
        }

        if (rowFrontPixels>width/2)
        {
            /// 如果二值化后背景色几乎是白色
            /// 则将此操作将黑色认为是前景
            rowFrontPixels = width-rowFrontPixels;
        }

        if (rowFrontPixels>=FrontThres)
        {
            /// 若行像素超过阈值，则认为当前行是二维码的起始边界
            if (0 == range.width)
            {
                range.idx_s = i;
            }
            range.width++;
        }

        /// 当前行像素数目小于阈值，认为找到二维码的终止边界
        if (range.width>0 && rowFrontPixels<FrontThres)
        {
            range.idx_e = i;
        }

        /// 如果找到了二维码的终止边界，但二维码宽度小于阈值，则重置参数
        if ( -1!=range.idx_e && range.width <= FrontWidth)
        {
            range.idx_s = range.idx_e = -1;
            range.width = 0;
        }

        /// 无论是否找到终止边界，只要宽度大于阈值，则认为找到二维码的边界
        if (range.width > FrontWidth)
        {
            res = range.idx_s;
            break;
        }
    }
    return res;
}

int FindColStartPattern(const uint8_t *binImage, int colStart, int width, int height)
{
    int i = 0, j = 0, idx = 0;
    uint32_t colWhitePixels = 0;
    int res = width-1;
    FrontRange range;

    range.idx_s = range.idx_e = -1;
    range.width = 0;
    for (j=colStart; j<width; j++)
    {
        colWhitePixels = 0;
        idx = j;
        for (i=0; i<=height; i++)
        {
            if (binImage[idx]==0xFF)
            {
                colWhitePixels++;
            }
            idx += width;
        }

        if (colWhitePixels>height/2)
        {
            colWhitePixels = height-colWhitePixels;
        }

        if (colWhitePixels>=FrontThres)
        {
            /// 若行像素超过阈值，则认为当前行是二维码的起始边界
            if (0 == range.width)
            {
                range.idx_s = j;
            }
            range.width++;
        }

        /// 当前行像素数目小于阈值，认为找到二维码的终止边界
        if (range.width>0 && colWhitePixels<FrontThres)
        {
            range.idx_e = j;
        }

        /// 如果找到了二维码的终止边界，但二维码宽度小于阈值，则重置参数
        if ( -1!=range.idx_e && range.width <= FrontWidth)
        {
            range.idx_s = range.idx_e = -1;
            range.width = 0;
        }

        /// 无论是否找到终止边界，只要宽度大于阈值，则认为找到二维码的边界
        if (range.width > FrontWidth)
        {
            res = range.idx_s;
            break;
        }
    }

    return res;
}

int FindRowEndPattern(const uint8_t *binImage, int rowStart, int width, int height)
{
    int i = 0, j = 0, idx = 0;
    uint32_t rowFrontPixels = 0;
    int res = height-1;
    FrontRange range;

    idx = rowStart*width;
    range.idx_s = range.idx_e = -1;
    range.width = 0;
    for (i=rowStart; i<height; i++)
    {
        rowFrontPixels = 0;
        for (j=0; j<width; j++)
        {
            if (binImage[idx++]==0xFF)
            {
                /// 统计每行中前景像素的个数
                /// 默认白色为前景
                rowFrontPixels++;
            }
        }

        if (rowFrontPixels>width/2)
        {
            /// 如果二值化后背景色几乎是白色
            /// 则将此操作将黑色认为是前景
            rowFrontPixels = width-rowFrontPixels;
        }

        if (rowFrontPixels<FrontThres)
        {
            /// 若行像素超过阈值，则认为当前行是二维码的起始边界
            if (0 == range.width)
            {
                range.idx_s = i;
            }
            range.width++;
        }

        /// 当前行像素数目小于阈值，认为找到二维码的终止边界
        if (range.width>0 && rowFrontPixels>=FrontThres)
        {
            range.idx_e = i;
        }

        /// 如果找到了二维码的终止边界，但二维码宽度小于阈值，则重置参数
        if ( -1!=range.idx_e && range.width <= FrontWidth)
        {
            range.idx_s = range.idx_e = -1;
            range.width = 0;
        }

        /// 无论是否找到终止边界，只要宽度大于阈值，则认为找到二维码的边界
        if (range.width > FrontWidth)
        {
            res = range.idx_s;
            break;
        }
    }
    return res;
}

int FindColEndPattern(const uint8_t *binImage, int colStart, int width, int height)
{
    int i = 0, j = 0, idx = 0;
    uint32_t colWhitePixels = 0;
    int res = width-1;
    FrontRange range;

    range.idx_s = range.idx_e = -1;
    range.width = 0;
    for (j=colStart; j<width; j++)
    {
        colWhitePixels = 0;
        idx = j;
        for (i=0; i<=height; i++)
        {
            if (binImage[idx]==0xFF)
            {
                colWhitePixels++;
            }
            idx += width;
        }

        if (colWhitePixels>height/2)
        {
            colWhitePixels = height-colWhitePixels;
        }

        if (colWhitePixels<FrontThres)
        {
            /// 若行像素超过阈值，则认为当前行是二维码的起始边界
            if (0 == range.width)
            {
                range.idx_s = j;
            }
            range.width++;
        }

        /// 当前行像素数目小于阈值，认为找到二维码的终止边界
        if (range.width>0 && colWhitePixels>=FrontThres)
        {
            range.idx_e = j;
        }

        /// 如果找到了二维码的终止边界，但二维码宽度小于阈值，则重置参数
        if ( -1!=range.idx_e && range.width <= FrontWidth)
        {
            range.idx_s = range.idx_e = -1;
            range.width = 0;
        }

        /// 无论是否找到终止边界，只要宽度大于阈值，则认为找到二维码的边界
        if (range.width > FrontWidth)
        {
            res = range.idx_s;
            break;
        }
    }

    return res;
}
#endif
