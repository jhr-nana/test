#include "decoder.h"

#define MASK_XY2(x,y) (((x)+(y))%2)
#define IDX_NUM (4)         /// 单码索引数目
#define IDX_BIT_WIDTH (6)   /// 表示索引的bit位数
#define X_HIGH_BITS (15)    /// X高位的bit数目
#define Y_HIGH_BITS (15)    /// Y高位的bit数目
#define X_LOW_BITS  (24)    /// X低位的bit数目
#define Y_LOW_BITS  (24)    /// Y低位的bit数目
#define HIGH_BITS   (X_HIGH_BITS+Y_HIGH_BITS)
#define LOW_BITS    (X_LOW_BITS+Y_LOW_BITS)
#define TAG_BIT_WIDTH (HIGH_BITS+LOW_BITS)
#define ENCODE_5_BITS (5)
#define ENCODE_8_BITS (8)
#define DECIMAL_NUM   (10)
#define TAG_LENGTH    (12)
#define CANDIATE_NUM  (4)

const snake_position TagData8BitsPos[] = {
    {4,0},{2,3},{4,2},{1,6},{7,0},{2,6},{5,4},{6,4}, /// E0~E7 --> x2
    {0,3},{0,5},{6,0},{0,6},{5,2},{4,4},{3,6},{8,2}, /// C0~C7 --> x1
    {2,0},{1,3},{4,1},{2,4},{3,4},{6,2},{1,8},{7,2}, /// A0~A7 --> x0
    {3,1},{3,2},{3,3},{2,5},{7,1},{1,7},{6,3},{5,5}, /// F0~F7 --> y2
    {3,0},{1,4},{5,1},{0,7},{6,1},{3,5},{4,5},{7,3}, /// D0~D7 --> y1
    {0,2},{0,4},{5,0},{1,5},{4,3},{5,3},{2,7},{8,1}  /// B0~B7 --> y0
};

const snake_position TagData5BitsPos[] = {
    {2,9},{8,3},{3,9},{8,6},{8,7}, /// K0~K4 --> x5
    {2,8},{6,5},{5,7},{7,6},{6,9}, /// I0~I4 --> x4
    {4,6},{4,7},{7,5},{5,8},{6,8}, /// G0~G4 --> x3
    {3,8},{8,4},{4,9},{7,7},{7,9}, /// L0~L4 --> y5
    {1,9},{7,4},{4,8},{8,5},{7,8}, /// J0~J4 --> y4
    {3,7},{5,6},{6,6},{6,7},{5,9}  /// H0~H4 --> y3
};

const char * TagData5BitsStr[DECIMAL_NUM] = {
    "11010","10101","01110","10011","01101",
    "10110","11001","00111","11100","01011"
};

const char * TagData8BitsStr[DECIMAL_NUM] = {
    "10111000","11100100","01110010","10010110","01001110",
    "01011001","00110101","10001101","11000011","00101011"
};

uint8_t chMapIdx[6] = {0};
uint8_t chMapValue[TAG_BIT_WIDTH] = {0};

uint8_t CandiateDecMat[TAG_LENGTH][DECIMAL_NUM] = {0};

const snake_position TagIdxPos[] = {
    {1,0},{2,1},{2,2},{1,1},{0,1},{1,2}
};

const char* TagIdxStr[] = {"000101","011000","101011","110110"};

static void extractTagIdx(snake_infoMatrix infoMatrix[INFO_MATRIX_ROW][INFO_MATRIX_COLUMN]);
static void extractTagData(snake_infoMatrix infoMatrix[INFO_MATRIX_ROW][INFO_MATRIX_COLUMN]);

/// convert 6bits bin string to index
static snake_WarnType matchTagIdx(const uint8_t *binChain, int8_t *matchIdx, uint8_t *matchNum);

static void matchTagData(uint8_t decMatRow, uint8_t chainIdx, uint8_t nChain);

void extractTagIdx(snake_infoMatrix infoMatrix[INFO_MATRIX_ROW][INFO_MATRIX_COLUMN])
{
    uint8_t i = 0;
    for (i=0; i<IDX_BIT_WIDTH; i++)
    {
        if (BLACK == infoMatrix[TagIdxPos[i].row][TagIdxPos[i].col].color)
        {
            chMapIdx[i] = (1 ^ MASK_XY2(TagIdxPos[i].row, TagIdxPos[i].col)) + '0';
        }
        else
        {
            chMapIdx[i] = (0 ^ MASK_XY2(TagIdxPos[i].row, TagIdxPos[i].col)) + '0';
        }
    }
}

void extractTagData(snake_infoMatrix infoMatrix[INFO_MATRIX_ROW][INFO_MATRIX_COLUMN])
{
    uint8_t i = 0, idx = 0;

    for (i=0; i<X_HIGH_BITS; i++)
    {
        if (BLACK == infoMatrix[TagData5BitsPos[i].row][TagData5BitsPos[i].col].color)
        {
            chMapValue[idx++] = (1 ^ MASK_XY2(TagData5BitsPos[i].row, TagData5BitsPos[i].col)) + '0';
        }
        else
        {
            chMapValue[idx++] = (0 ^ MASK_XY2(TagData5BitsPos[i].row, TagData5BitsPos[i].col)) + '0';
        }
    }

    idx = X_HIGH_BITS + X_LOW_BITS;
    for (; i<HIGH_BITS; i++)
    {
        if (BLACK == infoMatrix[TagData5BitsPos[i].row][TagData5BitsPos[i].col].color)
        {
            chMapValue[idx++] = (1 ^ MASK_XY2(TagData5BitsPos[i].row, TagData5BitsPos[i].col)) + '0';
        }
        else
        {
            chMapValue[idx++] = (0 ^ MASK_XY2(TagData5BitsPos[i].row, TagData5BitsPos[i].col)) + '0';
        }
    }

    idx = X_HIGH_BITS;
    for (i=0; i<X_LOW_BITS; i++)
    {
        if (BLACK == infoMatrix[TagData8BitsPos[i].row][TagData8BitsPos[i].col].color)
        {
            chMapValue[idx++] = (1 ^ MASK_XY2(TagData8BitsPos[i].row, TagData8BitsPos[i].col)) + '0';
        }
        else
        {
            chMapValue[idx++] = (0 ^ MASK_XY2(TagData8BitsPos[i].row, TagData8BitsPos[i].col)) + '0';
        }
    }

    idx = HIGH_BITS + X_LOW_BITS;
    for (; i<LOW_BITS; i++)
    {
        if (BLACK == infoMatrix[TagData8BitsPos[i].row][TagData8BitsPos[i].col].color)
        {
            chMapValue[idx++] = (1 ^ MASK_XY2(TagData8BitsPos[i].row, TagData8BitsPos[i].col)) + '0';
        }
        else
        {
            chMapValue[idx++] = (0 ^ MASK_XY2(TagData8BitsPos[i].row, TagData8BitsPos[i].col)) + '0';
        }
    }
}

snake_WarnType matchTagIdx(const uint8_t *binChain, int8_t *matchIdx, uint8_t *matchNum)
{
    uint8_t i = 0, j = 0, maxMatchDist = 0;
    uint8_t matchDist[4] = {0,0,0,0};
    snake_WarnType warn = WARN_NONE;
    *matchNum = 0;

    /// calculate the map index coding distance
    for (i=0; i<IDX_NUM; i++)
    {
        for (j=0; j<IDX_BIT_WIDTH; j++)
        {
            if (binChain[j] == TagIdxStr[i][j])
            {
                matchDist[i]++;
            }
        }

        if (maxMatchDist < matchDist[i])
        {
            maxMatchDist = matchDist[i];
            *matchIdx = i;
        }

        if (maxMatchDist == IDX_BIT_WIDTH)
        {
            (*matchNum)++;
            break;
        }
    }

    /// the number of error bits is less than 5, return -1
    if (maxMatchDist >= IDX_BIT_WIDTH-1)
    {
        warn = WARN_NONE;
    }
    else
    {
        if (maxMatchDist == IDX_BIT_WIDTH-2)
        {
            warn = WARN_LIGHT;
        }
        else
        {
            warn = WARN_SERIOUS;
        }

        for (i=0; i<IDX_NUM; i++)
        {
            if (maxMatchDist == matchDist[i])
            {
                matchIdx[*matchNum] = i;
                (*matchNum)++;
            }
        }
    }

    return warn;
}

void matchTagData(uint8_t decMatRow, uint8_t chainIdx, uint8_t nChain)
{
    uint8_t i = 0, j = 0;
    uint8_t binChain[ENCODE_8_BITS];
    uint8_t matchDist[DECIMAL_NUM] = {0}, maxMatchDist = 0;

    memcpy(binChain, &chMapValue[chainIdx], sizeof(uint8_t)*nChain);

    if (nChain == ENCODE_5_BITS)
    {
        for (i=0; i<DECIMAL_NUM; i++)
        {
            matchDist[i] = 0;
            for (j=0; j<ENCODE_5_BITS; j++)
            {
                if (TagData5BitsStr[i][j]==binChain[j])
                    matchDist[i]++;
            }

            if (matchDist[i] == ENCODE_5_BITS)
            {
                CandiateDecMat[decMatRow][i] += 3;
                return;
            }

            if (maxMatchDist < matchDist[i])
            {
                maxMatchDist = matchDist[i];
            }
        }

        for (i=0; i<DECIMAL_NUM; i++)
        {
            if (maxMatchDist == matchDist[i])
            {
                if (maxMatchDist == ENCODE_5_BITS-1)
                    CandiateDecMat[decMatRow][i] += 2;
                else
                    CandiateDecMat[decMatRow][i]++;
            }
        }
    }
    else
    {
        for (i=0; i<DECIMAL_NUM; i++)
        {
            matchDist[i] = 0;
            for (j=0; j<ENCODE_8_BITS; j++)
            {
                if (TagData8BitsStr[i][j]==binChain[j])
                    matchDist[i]++;
            }

            if (matchDist[i] == ENCODE_8_BITS)
            {
                CandiateDecMat[decMatRow][i] += 3;
                return;
            }

            if (maxMatchDist < matchDist[i])
            {
                maxMatchDist = matchDist[i];
            }

        }

        for (i=0; i<DECIMAL_NUM; i++)
        {
            if (maxMatchDist == matchDist[i])
            {
                if (maxMatchDist == ENCODE_8_BITS-1)
                    CandiateDecMat[decMatRow][i] += 3;
                else if (maxMatchDist == ENCODE_8_BITS-2)
                    CandiateDecMat[decMatRow][i] += 2;
                else
                    CandiateDecMat[decMatRow][i]++;
            }
        }
    }
}

//********************************************
//函数功能:FuncDecodeProcessing函数实现
//函数输出:
//*********************************************/
snake_WarnType FuncSingleDecoder(int8_t *singleCodeIdx, uint8_t *matchNum)
{
    uint8_t i = 0, chainIdx = 0, decMatRow = 0;
    snake_WarnType warn = WARN_NONE;
    *singleCodeIdx = -1;

    extractTagIdx(infoMatrix);
    extractTagData(infoMatrix);

    warn = matchTagIdx(chMapIdx, singleCodeIdx, matchNum);

    for (chainIdx=0; chainIdx<X_HIGH_BITS;)
    {
        matchTagData(decMatRow++, chainIdx, ENCODE_5_BITS);
        chainIdx += ENCODE_5_BITS;
    }

    for (; chainIdx<X_HIGH_BITS+X_LOW_BITS;)
    {
        matchTagData(decMatRow++, chainIdx, ENCODE_8_BITS);
        chainIdx += ENCODE_8_BITS;
    }

    for (; chainIdx<TAG_BIT_WIDTH-Y_LOW_BITS;)
    {
        matchTagData(decMatRow++, chainIdx, ENCODE_5_BITS);
        chainIdx += ENCODE_5_BITS;
    }

    for (; chainIdx<TAG_BIT_WIDTH;)
    {
        matchTagData(decMatRow++, chainIdx, ENCODE_8_BITS);
        chainIdx += ENCODE_8_BITS;
    }

    return warn;
}

void FuncFusionDecoder(uint64_t *message)
{
    uint8_t votes = 0, i = 0, j = 0;
    uint8_t tag = 0;

    for (i=0; i<TAG_LENGTH; i++)
    {
        votes = 0;
        for (j=0; j<DECIMAL_NUM; j++)
        {
            if (votes < CandiateDecMat[i][j])
            {
                votes = CandiateDecMat[i][j];
                tag = j;
            }
        }

        *message *= 10;
        *message += tag;
    }

    /// reset to zeros for next code recogination
    memset(CandiateDecMat, 0, sizeof(CandiateDecMat));
}

/////////////////////// end //////////////////////////
