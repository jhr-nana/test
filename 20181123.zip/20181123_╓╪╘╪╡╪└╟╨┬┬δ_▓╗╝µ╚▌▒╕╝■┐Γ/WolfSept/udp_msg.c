#include "udp_msg_v1.h"
#include "udp_msg_v2.h"
#include "ftp.h"
#include "device.h"
#include "statistical_info.h"

struct seq_buff_item g_iSeqBuff[UDP_SEQ_BUF_SIZE + 1];

/*******************************************************************************
* Function Name		 : sequence_buff_init
* Description	     : init sequence buffer
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; -1:failure
*******************************************************************************/
int sequence_buff_init()
{
	int iIndex = 0;

	for (iIndex = 0; iIndex <= UDP_SEQ_BUF_SIZE; iIndex++)
	{
		g_iSeqBuff[iIndex].iSeq = INVALID_SEQUENCE;
		g_iSeqBuff[iIndex].iMsgType = INVALID_MSG_TYPE;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msgv2_seq_is_valid
* Description	     : judge udp recv msg sequence is valid.
* Input 		     : iSequence: the sequence of msg from console
* Input 		     : iMsgType: the type of msg from console
* Output		     : NONE
* Return		     : 0:valid; -1:invalid
*******************************************************************************/
int sequence_is_valid(int iSequence, int iMsgType)
{
	int iRet = 0;
	int iIndex = 0;

	for (iIndex = 0; iIndex < UDP_SEQ_BUF_SIZE; iIndex++)
	{
		// Case1:iSequence and iMsgType is exist, return invalid(-1)
		if ((g_iSeqBuff[iIndex].iSeq == iSequence) && (g_iSeqBuff[iIndex].iMsgType == iMsgType)){
			iRet = -1;
			break;
		}
		else {
			// Case2:iSequence is not exist and g_iSeqBuff[iIndex] is not set
			// save iSequence into g_iSeqBuff[iIndex], then return valid(0)
			if ((g_iSeqBuff[iIndex].iSeq == INVALID_SEQUENCE) && (g_iSeqBuff[iIndex].iMsgType == INVALID_MSG_TYPE)) {
				g_iSeqBuff[iIndex].iSeq = iSequence;
				g_iSeqBuff[iIndex].iMsgType = iMsgType;
				iRet = 0;
				break;
			}

			// Case3:iSequence is not exist and the last g_iSeqBuff[iIndex]
			// move the value of g_iSeqBuff[], and 
			// save iSequence and iMsgType into g_iSeqBuff[0], then return valid(0)
			if (iIndex == (UDP_SEQ_BUF_SIZE - 1)) {
				int i = 0;
				for (i = UDP_SEQ_BUF_SIZE; i >= 1; i--)
				{
					g_iSeqBuff[i] = g_iSeqBuff[i - 1];
				}
				g_iSeqBuff[0].iSeq = iSequence;
				g_iSeqBuff[0].iMsgType = iMsgType;
				iRet = 0;
				break;
			}

			// Case4:iSequence is not exist and g_iSeqBuff[iIndex] is set
			// and is not the last, so continue, compare the next one.
		}
	}

	return iRet;
}

/*******************************************************************************
* Function Name		 : agv_register
* Description	     : agv register, should execute before create work_thread_create()
: and execute after init_xxxx_dev()
* Input 		     : NONE
* Output		     : NONE
* Return		     : 0:success; <0:failure
*******************************************************************************/
int agv_register()
{
	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		return msgv1_agv_register();
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return msgv2_agv_register();
	}
	else {
		return -1;
	}
}

/*******************************************************************************
* Function Name		 : msg_recv
* Description	     : msg v1/v2 recv process msg.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msg_recv(const char * pMsgBuff, int iMsgSize)
{
	if ((pMsgBuff == NULL) || (iMsgSize <= 0)) {
		return -1;
	}

	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		return msgv1_recv(pMsgBuff, iMsgSize);
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return msgv2_recv(pMsgBuff, iMsgSize);
	}
	else {
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msg_deal
* Description	     : msg v1/v2 deal process msg.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msg_deal(const char * pMsgBuff, int iMsgSize)
{
	if ((pMsgBuff == NULL) || (iMsgSize <= 0)) {
		return -1;
	}

	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		return msgv1_deal(pMsgBuff, iMsgSize);
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return msgv2_deal(pMsgBuff, iMsgSize);
	}
	else {
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : msg_dump
* Description	     : msg v1/v2 dump process msg.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msg_dump(const char * pMsgBuff, int iMsgSize)
{

	if ((pMsgBuff == NULL) || (iMsgSize <= 0)) {
		return -1;
	}

	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		return msgv1_head_dump(pMsgBuff);
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return msgv2_head_dump(pMsgBuff);
	}
	else {
		return -1;
	}

	return 0;
}

/*******************************************************************************
* Function Name		 : send_heartbeat_msg
* Description	     : msg v1/v2 send heartbeat msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int send_heartbeat_msg()
{
	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		return msgv1_send_heartbeat();
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return msgv2_send_heartbeat();
	}
	else {
		return -1;
	}
}

/*******************************************************************************
* Function Name		 : send_error_msg
* Description	     : msg v1/v2 send error msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int send_error_msg(int iEventType, int iErrorCode)
{
	int iRet = 0;
	iErrorCode = abs(iErrorCode);

	// modified by kedong, 20181025
	// iErrorCodeӦ����1XXX��2XXX��3XXX��4XXX��XXXX�ȣ�������С��100
	// ��ô���С��100��iErrorCode,��Ӧ��send�쳣��Ϣ������̨
	if (iErrorCode < 100)
	{
		LOG_WRN("ErrorCode[%d] no need to send console\n", iErrorCode);
		return 0;
	}

	//add by kedong, 20180126
	EVENT_LOG("%d\t%s\n", iErrorCode, get_err_str(iErrorCode));
	
	// first of all, print the error information
	LOG_INF("append error/event[%d-%s] to error rx queue\n", iErrorCode, get_err_str(iErrorCode));
	get_ip_sn(g_stAgvParm.iMsgSocketFd);//add by tiger.51,refresh the agv ip

	if ((iErrorCode != EVENT_ERR_AGVSAFE) &&(iErrorCode != EVENT_ERR_NOCONTACTIMPACT))//by tiger.85
		dump_exception_context();
	
	//start,add by tiger.51
	//iRet = sta_send_event_info(SATISTICAL_SEND_PERIOD_30S);
	iRet = sta_send_event_info(SATISTICAL_SEND_NOW);
	if (iRet < 0)
	{
		LOG_WRN("send statistical event info failed:[%d-%s]", errno, strerror(errno));
	}
	//end ,add by tiger.51
	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		return msgv1_send_event(iEventType, iErrorCode);
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return msgv2_send_event(iEventType, iErrorCode);
	}
	else {
		return -1;
	}
}

/*******************************************************************************
* Function Name		 : send_error_msg_suberror
* Description	     : msg v1/v2 send error msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int send_error_msg_suberror(int iEventType, int iErrorCode, int iSubErrorcode)
{
	int iRet = 0;
	iErrorCode = abs(iErrorCode);

	//add by kedong, 20180126
	EVENT_LOG("%d\t%s\n", iErrorCode, get_err_str(iErrorCode));

	// first of all, print the error information
	LOG_INF("append error/event[%d-%s] to error rx queue\n", iErrorCode, get_err_str(iErrorCode));
	get_ip_sn(g_stAgvParm.iMsgSocketFd);//add by tiger.51,refresh the agv ip
	dump_exception_context();
	//start,add by tiger.51
	//iRet = sta_send_event_info(SATISTICAL_SEND_PERIOD_30S);
	iRet = sta_send_event_info(SATISTICAL_SEND_NOW);
	if (iRet < 0)
	{
		LOG_WRN("send statistical event info failed:[%d-%s]", errno, strerror(errno));
	}
	//end ,add by tiger.51
	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		return msgv1_send_event_suberror(iEventType, iErrorCode, iSubErrorcode);
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return msgv2_send_event(iEventType, iErrorCode);
	}
	else {
		return -1;
	}
}

/*******************************************************************************
* Function Name		 : send_point_msg
* Description	     : msg v1/v2 send point msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int send_point_msg(int iLocation, int iDriverMode)
{
	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		return msgv1_send_point(iLocation, iDriverMode);
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return msgv2_send_point(iLocation, iDriverMode);
	}
	else {
		return -1;
	}
}

/*******************************************************************************
* Function Name		 : send_error_point_msg
* Description	     : msg v1/v2 send point msg.
* input			     : iErrorCode: the code of error
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int send_error_point_msg(int iErrorCode)
{
	int iRet = 0;

	update_mcu_log();
	//start,add by tiger.51
	//iRet = sta_send_event_info(SATISTICAL_SEND_PERIOD_30S);
	iRet = sta_send_event_info(SATISTICAL_SEND_NOW);
	if (iRet < 0)
	{
		LOG_WRN("send statistical event info failed:[%d-%s]\n", errno, strerror(errno));
	}
	//end ,add by tiger.51
	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		return msgv1_send_error_point(iErrorCode);
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return msgv2_send_error_point(iErrorCode);
	}
	else {
		return -1;
	}
}

/*******************************************************************************
* Function Name		 : send_offset_statistic_msg
* Description	     : msg v1/v2 send offset info msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int send_offset_statistic_msg(int iAction)
{
	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {

		return msgv1_send_offset_statistic(iAction);
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return 0;	//TODO: add msgv2_send_info();
	}
	else {
		return -1;
	}
}

/*******************************************************************************
* Function Name		 : send_finish_msg
* Description	     : msg v1/v2 send finish msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int send_finish_msg(int iAction)
{
	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		return msgv1_send_finish(iAction);
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return msgv2_send_finish(iAction);
	}
	else {
		return -1;
	}
}

/*******************************************************************************
* Function Name		 : send_battery_info
* Description	     : msg v1/v2 send finish msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int send_battery_info()
{
	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		return msgv1_send_batt_info();
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		return msgv2_send_batt_info();
	}
	else {
		return -1;
	}
}

/*******************************************************************************
* Function Name		 : msg_send
* Description	     : msg v1/v2 send process msg.
* input			     : pMsgBuff: the point of msg.
* input			     : iMsgSize: the size of msg.
* Output		     : NONE
* Return		     : 0 if OK,-1 on error
*******************************************************************************/
int msg_send(const char * pMsgBuff, int iMsgSize)
{
	int iRet = 0;
	int iMsgtype = 0;
	int iSequence = 0;
	int iTryTime = 1;//modify by jxu 20180504
	int iTimeOut = 0;
	agv_sem_t *pAgvSem = NULL;

	if (g_stAgvAttr.iProtoVer == MSG_TYPE_V1P0) {
		iMsgtype = msgv1_get_msgtype(pMsgBuff, iMsgSize);
		iSequence = msgv1_get_sequence(pMsgBuff, iMsgSize);
	}
	else if (g_stAgvAttr.iProtoVer == MSG_TYPE_V2P0) {
		iMsgtype = msgv2_get_msgtype(pMsgBuff, iMsgSize);
		iSequence = msgv2_get_sequence(pMsgBuff, iMsgSize);
	}
	else {
		return -1;
	}
	while (iTryTime++)
	{
		if (iTryTime < 10)
			iTimeOut = TIME_OUT_4S / 10;//by tiger.75
		else if ((iTryTime >= 10) && (iTryTime < 20))
			iTimeOut = TIME_OUT_8S / 10;//by tiger.75
		else if ((iTryTime >= 20) && (iTryTime < 50))
			iTimeOut = TIME_OUT_10S / 10;//by tiger.75
		else
			iTimeOut = TIME_OUT_20S / 10;//by tiger.75

		//add sem before send udp msg to console
		pAgvSem = agv_sem_add(SEM_MSG_TYPE, iMsgtype, iSequence);
		if (NULL == pAgvSem)
		{
			LOG_ERR("add sem failed\n");
		}

		iRet = send_msg2console(pMsgBuff, iMsgSize);
		if (iRet < 0)
		{

			LOG_WRN("send msg to console error:[%d-%s]\n", errno, strerror(errno));
			usleep(iTimeOut * 1000); //iTimeOut
			continue;
		}

		/// judge whether get the ack
		if (0 == agv_sem_wait(SEM_MSG_TYPE, iMsgtype, iSequence, iTimeOut))
		{
			agv_sem_clean(SEM_MSG_TYPE, iMsgtype, iSequence);

			if ((MSG_TYPE_FINISH == iMsgtype) || (MSG_TYPE_EVENT == iMsgtype))
			{
				// print current vehicle status
				LOG_INF("task process complete with status:\n");
				LOG_INF("location      = %d\n", g_stAgvAttr.iLocation);
				LOG_INF("head direct   = %d-%s\n", g_stAgvAttr.iVehHeadDirect, get_direct_desc(g_stAgvAttr.iVehHeadDirect));
				LOG_INF("pallet direct = %d-%s\n", g_stAgvAttr.iPalletDirect, get_direct_desc(g_stAgvAttr.iPalletDirect));
				LOG_INF(">>>>>>>>>>>>>>>>>>>>>>>>>>>task process complete\n");
				LOG_INF("\n");
			}

			return 0;
		}
	}
	return -1;
}