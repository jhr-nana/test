/********************************************************************************
* Copyright (c) 2020, JD.COM, Inc .
* All rights reserved.
* FileName: netstat.c
* Author: tongkedong   Version: V1.0   Data:2018-03-07
* Description:
* monitor wireless interface performance and status
********************************************************************************/
#include "netstat.h"
#include "gateway.h"

#define WIRELESS_DEVICE	"wlan0"
net_info_t g_stNetInfo;


/*******************************************************************************
* Function Name      : get_ip_addr
* Description	     : get ip address for netdev from linux system
* Input 		     : pNetDevName
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
char * get_ip_addr(char *pNetDevName)
{
	int iSock = 0;
	struct ifreq stReq = {0};
	char *pIP = NULL;

	if (pNetDevName == NULL)
		return NULL;

	iSock = socket(AF_INET, SOCK_DGRAM, 0);
	strncpy(stReq.ifr_name, pNetDevName, IFNAMSIZ);
	if (ioctl(iSock, SIOCGIFADDR, &stReq) < 0) {
		LOG_ERR("ioctl error: %d, %s\n", errno, strerror(errno));
		return NULL;
	}

	pIP = (char *)inet_ntoa(*(struct in_addr *) &((struct sockaddr_in *) &stReq.ifr_addr)->sin_addr);
	if (pIP == NULL)
		pIP = "NONE";

	shutdown(iSock, 2);
	close(iSock);

	return pIP;
}

/*******************************************************************************
* Function Name      : get_wireless_info
* Description	     : get wireless pWireLessInfo from linux system
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
static int get_wireless_info(wireless_info * pWireLessInfo, char *pNetDevName)
{
	wireless_config * pWireLessConfig = NULL;
	int iSocketFd = 0;	// generic raw socket desc.
	struct iwreq stWRQ = {0};
		
	if(pWireLessInfo == NULL)
		return 0;
	
	memset((char *)pWireLessInfo, 0, sizeof(struct wireless_info));
	pWireLessConfig = (wireless_config *)&pWireLessInfo->b;
	
	// Create a channel to the NET kernel. 
	// Try all families we support :
	// AF_INET, AF_IPX, AF_AX25, AF_APPLETALK
	iSocketFd = socket(AF_INET, SOCK_DGRAM, 0);
	if (iSocketFd < 0)
	{
		LOG_WRN("open socket for wireless interface failure\n");
		return -1;
	}
	
	/* Get wireless name */
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWNAME, &stWRQ) < 0)
	{
		/* If no wireless name : no wireless extensions */
		return -1;
	}
	else
	{
		strncpy(pWireLessConfig->name, stWRQ.u.name, IFNAMSIZ);
		pWireLessConfig->name[IFNAMSIZ] = '\0';
	}

	/* Get network ID */
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWNWID, &stWRQ) >= 0)
	{
		pWireLessConfig->has_nwid = 1;
		memcpy(&(pWireLessConfig->nwid), &(stWRQ.u.nwid), sizeof(iwparam));
	}


	/* Get frequency / channel */
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWFREQ, &stWRQ) >= 0)
	{
		pWireLessConfig->has_freq = 1;
		pWireLessConfig->freq = iw_freq2float(&(stWRQ.u.freq));
		pWireLessConfig->freq_flags = stWRQ.u.freq.flags;
	}

	/* Get encryption information */
	stWRQ.u.data.pointer = (caddr_t)pWireLessConfig->key;
	stWRQ.u.data.length = IW_ENCODING_TOKEN_MAX;
	stWRQ.u.data.flags = 0;
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWENCODE, &stWRQ) >= 0)
	{
		pWireLessConfig->has_key = 1;
		pWireLessConfig->key_size = stWRQ.u.data.length;
		pWireLessConfig->key_flags = stWRQ.u.data.flags;
	}

	/* Get ESSID */
	stWRQ.u.essid.pointer = (caddr_t)pWireLessConfig->essid;
	stWRQ.u.essid.length = IW_ESSID_MAX_SIZE + 1;
	stWRQ.u.essid.flags = 0;
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWESSID, &stWRQ) >= 0)
	{
		pWireLessConfig->has_essid = 1;
		pWireLessConfig->essid_on = stWRQ.u.data.flags;
	}

	/* Get operation mode */
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWMODE, &stWRQ) >= 0)
	{
		pWireLessConfig->has_mode = 1;
		/* Note : event->u.mode is unsigned, no need to check <= 0 */
		if (stWRQ.u.mode < IW_NUM_OPER_MODE)
			pWireLessConfig->mode = stWRQ.u.mode;
		else
			pWireLessConfig->mode = IW_NUM_OPER_MODE;	/* Unknown/bug */
	}



	/* Get ranges */
	if (iw_get_range_info(iSocketFd, pNetDevName, &(pWireLessInfo->range)) >= 0)
		pWireLessInfo->has_range = 1;

	/* Get AP address */
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWAP, &stWRQ) >= 0)
	{
		pWireLessInfo->has_ap_addr = 1;
		memcpy(&(pWireLessInfo->ap_addr), &(stWRQ.u.ap_addr), sizeof (sockaddr));
	}

	/* Get bit rate */
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWRATE, &stWRQ) >= 0)
	{
		pWireLessInfo->has_bitrate = 1;
		memcpy(&(pWireLessInfo->bitrate), &(stWRQ.u.bitrate), sizeof(iwparam));
	}

	/* Get Power Management settings */
	stWRQ.u.power.flags = 0;
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWPOWER, &stWRQ) >= 0)
	{
		pWireLessInfo->has_power = 1;
		memcpy(&(pWireLessInfo->power), &(stWRQ.u.power), sizeof(iwparam));
	}

	/* Get stats */
	if (iw_get_stats(iSocketFd, pNetDevName, &(pWireLessInfo->stats),
		&pWireLessInfo->range, pWireLessInfo->has_range) >= 0)
	{
		pWireLessInfo->has_stats = 1;
	}

#ifndef WE_ESSENTIAL
	/* Get NickName */
	stWRQ.u.essid.pointer = (caddr_t)pWireLessInfo->nickname;
	stWRQ.u.essid.length = IW_ESSID_MAX_SIZE + 1;
	stWRQ.u.essid.flags = 0;
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWNICKN, &stWRQ) >= 0)
	if (stWRQ.u.data.length > 1)
		pWireLessInfo->has_nickname = 1;

	if ((pWireLessInfo->has_range) && (pWireLessInfo->range.we_version_compiled > 9))
	{
		/* Get Transmit Power */
		if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWTXPOW, &stWRQ) >= 0)
		{
			pWireLessInfo->has_txpower = 1;
			memcpy(&(pWireLessInfo->txpower), &(stWRQ.u.txpower), sizeof(iwparam));
		}
	}

	/* Get sensitivity */
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWSENS, &stWRQ) >= 0)
	{
		pWireLessInfo->has_sens = 1;
		memcpy(&(pWireLessInfo->sens), &(stWRQ.u.sens), sizeof(iwparam));
	}

	if ((pWireLessInfo->has_range) && (pWireLessInfo->range.we_version_compiled > 10))
	{
		/* Get retry limit/lifetime */
		if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWRETRY, &stWRQ) >= 0)
		{
			pWireLessInfo->has_retry = 1;
			memcpy(&(pWireLessInfo->retry), &(stWRQ.u.retry), sizeof(iwparam));
		}
	}

	/* Get RTS threshold */
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWRTS, &stWRQ) >= 0)
	{
		pWireLessInfo->has_rts = 1;
		memcpy(&(pWireLessInfo->rts), &(stWRQ.u.rts), sizeof(iwparam));
	}

	/* Get fragmentation threshold */
	if (iw_get_ext(iSocketFd, pNetDevName, SIOCGIWFRAG, &stWRQ) >= 0)
	{
		pWireLessInfo->has_frag = 1;
		memcpy(&(pWireLessInfo->frag), &(stWRQ.u.frag), sizeof(iwparam));
	}
#endif	/* WE_ESSENTIAL */
	
	/* Close the socket. */
	close(iSocketFd);

	return 0;
}

/*******************************************************************************
* Function Name      : check_net_stat
* Description	     : check network status
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int check_net_stat()
{
	char pCmd[512] = {0};
	int iRet = -1, i = 0, iCount = 0;
	char pGateWayIp[IP_LEN] = { 0 };
	char pNetDevName[NETIF_NAME_SIZE] = { 0 };

	// Using dynamic get gateways
	snprintf(g_stNetInfo.pGateWayIpAddr, IP_LEN, "%s", "NONE");

	iRet = get_gateway(pGateWayIp, pNetDevName);
	// when iRet != 0 or netdev != wlan0, skip ping test
	if ((iRet < 0) || (strncmp(pNetDevName, "wlan0", 4) != 0))
	{
		LOG_WRN("get wlan0 gateway ip failure, iRet=%d or netdev=%s\n", iRet, pNetDevName);
		return -1;
	}
	snprintf(g_stNetInfo.pGateWayIpAddr, IP_LEN, "%s", pGateWayIp);

	memset(pCmd, 0, sizeof(pCmd));
	snprintf(pCmd, 512, "ping -c 1 -s 1400 -w 4 %s > /dev/null", g_stNetInfo.pGateWayIpAddr);
	// sprintf(pCmd, "ping -c 1 -W 4 %s", g_stAgvParm.cServerIp);	
	iRet = system(pCmd);
	if (iRet != 0)
	{
		LOG_WRN("%s return:%s %d, iCount:%d\n", pCmd, iRet == 0 ? "OK" : "ERROR", iRet, iCount);
		g_stNetInfo.iConnectConsoleOK = FALSE;
	}
	else
	{
		g_stNetInfo.iConnectConsoleOK = TRUE;
	}
	
	return iRet;
}

/*******************************************************************************
* Function Name      : restart_net_wifi
* Description	     : restart wifi network
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
#define SERVICE_SH		"/etc/norco/service.sh"
int restart_net_wifi(void)
{
	char pCmd[512] = { 0 };
	int iRet = -1;
	FILE *file = NULL;

	memset(pCmd, 0, sizeof(pCmd));
	sprintf(pCmd, "%s %s", SERVICE_SH, "restart");
	iRet = system(pCmd);
	if (iRet == 0)
	{
		LOG_INF("execute CMD=%s success\n", pCmd);
	}
	else
	{
		LOG_WRN("execute CMD=%s failure\n", pCmd);
	}

	return iRet;
}

/*******************************************************************************
* Function Name      : update_net_stat
* Description	     : update network status
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int update_net_stat()
{
	wireless_info stWireLessInfo = { 0 };
	wireless_info *pWireLessInfo = &stWireLessInfo;
	char * pNetDevName = WIRELESS_DEVICE;
	char *pProtocolName = "802.11bgn";
	char *pEssid = "off/any";
	double iFreq = 0;
	int iChannel = -1;
	int iBitRate = 0;
	int iSensitivity = 0;
	int iLinkQuality = 0;
	int iSignalLevel = 0;
	int iNoiseLevel = 0;
	struct iwreq stWRQ = {0};

	memset(g_stNetInfo.pLocalIpAddr, '\0', IP_LEN);
	char *pIP = get_ip_addr(WIRELESS_DEVICE);
	if (pIP == NULL)
		pIP = "NONE";
	snprintf(g_stNetInfo.pLocalIpAddr, IP_LEN, "%s", pIP);

	int iRet = get_wireless_info(pWireLessInfo, pNetDevName);
	if (iRet < 0)
	{
		LOG_WRN("get wireless infomation failure\n");
		return -1;
	}

	pProtocolName = pWireLessInfo->b.name;

	/* Display ESSID (extended network), if any */
	if (pWireLessInfo->b.has_essid)
	{
		if (pWireLessInfo->b.essid_on)
			pEssid = pWireLessInfo->b.essid;
		else
			pEssid = "off/any";
	}

	/* Display frequency / channel */
	if (pWireLessInfo->b.has_freq)
	{
		/* Frequency/channel */
		iFreq = pWireLessInfo->b.freq;

		/* Some drivers insist of returning channel instead of frequency.
		* This fixes them up. Note that, driver should still return
		* frequency, because other tools depend on it. */
		if (pWireLessInfo->has_range && (iFreq < KILO))
			iChannel = iw_channel_to_freq((int)iFreq, &iFreq, &pWireLessInfo->range);
	}

	/* Display the currently used/set bit-rate */
	if (pWireLessInfo->has_bitrate)
	{
		iBitRate = pWireLessInfo->bitrate.value;
	}

	/* Display sensitivity */
	if (pWireLessInfo->has_sens)
	{
		iSensitivity = pWireLessInfo->sens.value;
	}

	/* Display statistics */
	if (pWireLessInfo->has_stats)
	{
		const iwqual *	qual = &pWireLessInfo->stats.qual;
		iLinkQuality = qual->qual;
		iSignalLevel = qual->level;
		iNoiseLevel = qual->noise;
	}

	// modified by kedong 20180327
	// get essid may be failure, and pEssid == NULL
	if (pProtocolName != NULL)
		memcpy(g_stNetInfo.pNetDevName, pNetDevName, NETIF_NAME_SIZE);
	if (pProtocolName != NULL)
		memcpy(g_stNetInfo.pProtocolName, pProtocolName, NETIF_NAME_SIZE);
	if ((pWireLessInfo->b.has_essid) && (pEssid != NULL))
		memcpy(g_stNetInfo.pEssid, pEssid, ESSID_MAX_LEN);
	else
		sprintf(g_stNetInfo.pEssid, "%s", "NONE");

	if (pWireLessInfo->has_ap_addr) //by tiger
    {
   		sprintf(g_stNetInfo.pApAddr,"%.2x%.2x%.2x%.2x%.2x%.2x",
		(unsigned char)pWireLessInfo->ap_addr.sa_data[0],
		(unsigned char)pWireLessInfo->ap_addr.sa_data[1],
		(unsigned char)pWireLessInfo->ap_addr.sa_data[2],
		(unsigned char)pWireLessInfo->ap_addr.sa_data[3],
		(unsigned char)pWireLessInfo->ap_addr.sa_data[4],
		(unsigned char)pWireLessInfo->ap_addr.sa_data[5]);
    }
	else
	{
		sprintf(g_stNetInfo.pApAddr, "%s", "NONE");
	}
	g_stNetInfo.iFreq = iFreq;
	g_stNetInfo.iChannel = iChannel;
	g_stNetInfo.iBitRate = iBitRate;
	g_stNetInfo.iSensitivity = iSensitivity;
	g_stNetInfo.iLinkQuality = iLinkQuality;
	g_stNetInfo.iSignalLevel = iSignalLevel;
	g_stNetInfo.iNoiseLevel = iNoiseLevel;
	
	return 0;
}

/*******************************************************************************
* Function Name      : print_net_stat
* Description	     : print network status
* Input 		     : NONE
* Output		     : NONE
* Return		     : error code on error, 0 on success.
*******************************************************************************/
int print_net_stat()
{
	char * pNetDevName = NULL;
	char *pProtocolName = NULL;
	char *pEssid = NULL;
	double iFreq = 0;
	int iChannel = -1;
	int iBitRate = 0;
	int iSensitivity = 0;
	int iLinkQuality = 0;
	int iSignalLevel = 0;
	int iNoiseLevel = 0;

	update_net_stat();

	pNetDevName = g_stNetInfo.pNetDevName;
	pProtocolName = g_stNetInfo.pProtocolName;
	pEssid = g_stNetInfo.pEssid;

	iFreq = g_stNetInfo.iFreq;
	iChannel = g_stNetInfo.iChannel;
	iBitRate = g_stNetInfo.iBitRate;
	iSensitivity = g_stNetInfo.iSensitivity;
	iLinkQuality = g_stNetInfo.iLinkQuality;
	iSignalLevel = g_stNetInfo.iSignalLevel;
	iNoiseLevel = g_stNetInfo.iNoiseLevel;

	LOG_INF("--------------------------\n");
	LOG_INF("%s : ESSID=%s, Protocol=%s\n", pNetDevName, pEssid, pProtocolName);
	LOG_INF("%s : Frequency=%.4f GHz, BitRate=%.4f Mbps, Channel=%d\n", pNetDevName, iFreq / 1000000000, (float)(iBitRate/1000000), iChannel);
	LOG_INF("%s : Sensitivity=%d, LinkQuality=%d, SignalLevel=%d, NoiseLevel=%d\n",pNetDevName, iSensitivity, iLinkQuality, iSignalLevel, iNoiseLevel);
	LOG_INF("%s : AP MAC = %s", pNetDevName, g_stNetInfo.pApAddr);//by tiger.76
	LOG_INF("--------------------------\n");
	
	return 0;
}
