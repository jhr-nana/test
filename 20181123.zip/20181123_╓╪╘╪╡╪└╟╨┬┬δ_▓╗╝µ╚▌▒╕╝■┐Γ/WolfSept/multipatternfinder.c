#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "pattern.h"
#include "multipatternfinder.h"
#include "globaldefine.h"
#include "databank.h"

#define MAX_PATTERN (100)

static int const CENTER_QUORUM = 2;
static int const MIN_SKIP = 3;
static int const MAX_MODULES = 300;
static int const NUM_BLOCKS_PER_PATTERN = 8; // 1:1:4:1:1

typedef struct {
	snake_code_pattern *possibleCenters[MAX_PATTERN];
	int nCenter;
	bool hasSkipped;
}snake_pattern_finder;

typedef struct {
    float startI;
    float endI;
    float startJ;
    float endJ;
}snake_pattern_region;

// global static variable prefix gs_
static snake_pattern_finder gs_patternFinder;
static snake_pattern_region gs_patternRegion[MAX_RING_NUM];
static int g_uPatternRegionSize = 0;
static uint8_t *gs_imageData = NULL;
static int g_npatternIdxArrayNum = 0;

// 打印候选的特征圆中心
//static void FuncDebugPrintPatternCenters(int* stateCount, int centerI, int centerJ);

// 判断当前位置像素的颜色
static int FuncPixelColorX(int posIdx);
static int FuncPixelColorY(int posIdx);

/********************************************
函数功能: 两个特征圆的中心比较大小
函数输入: averageModuleSize_ 表示所有候选特征圆的扫描线的单位宽度的像素数目
函数输出: 若特征圆'a'的横向和纵向扫描线，符合1:1:4:1:1的比例的数目多，则返回true
         当扫描线数目相等时，若特征圆'a'的平均单位黑色像素数接近averageModuleSize_，则返回true
*********************************************/
static bool FuncPatternCenterComparator(snake_code_pattern* a, snake_code_pattern* b, float averageModuleSize_);

/********************************************
函数功能: 根据检测线色块的数目，计算特征模式的中心坐标
函数输入: stateCount是长度为5的整型数组，存放的是连续黑色或者白色像素的数目
函数输出: 返回扫描线中心的X/Y坐标
*********************************************/
static float FuncCenterFromEnd(int* stateCount, int end);

/********************************************
函数功能: 检验stateCount中的数目是否满足特征圆比例关系，容差为60%
函数输入: stateCount是长度为5的整型数组
函数输出: 满足比例关系返回true
*********************************************/
static bool FuncFoundPatternCross(int* stateCount);

/********************************************
函数功能: 检查垂直方向扫描线是否满足特征圆比例关系
函数输入:
函数输出: 若满足比例，则返回Y方向特征圆的坐标;否则，返回一个负值
*********************************************/
static float FuncCrossCheckVertical(int startI, int centerJ, int maxCount, int originalStateCountTotal);

/********************************************
函数功能: 检查水平方向扫描线是否满足特征圆比例关系
函数输入:
函数输出: 若满足比例，则返回X方向特征圆的坐标;否则，返回一个负值
*********************************************/
static float FuncCrossCheckHorizontal(int startJ, int centerI, int maxCount, int originalStateCountTotal);

/********************************************
函数功能: 根据stateCount以及此时的像素位置，判断特征圆的中心是否存在
函数输入: stateCount指针和当前像素的位置
函数输出: 若特征圆中心存在，则中心存在放'gs_patternFinder'的数组中并返回true；否则返回false
*********************************************/
static bool FuncHandlePossibleCenter(int* stateCount, int i, int j);

/********************************************
函数功能: 删掉一些假的特征圆并选择某种准则下最好的特征圆
函数输入:
函数输出:
*********************************************/
static bool FuncSelectBestPatterns();

/********************************************
函数功能: 对区域进行先膨胀后腐蚀操作，以消除部分噪点，增加识别的稳定性
函数输入: 图像指针data，图像的宽、高，区域的横向与纵向的起始和终止位置
函数输出:
*********************************************/
static void regionDilationErosionOr(uint8_t* data, int width, int height,
                             int startI, int endI, int startJ, int endJ);

// 判断gs_patternRegion是否存在某个区域包含(centerI,centerJ)这个点
static bool isInside(float centerI, float centerJ);

// 计算校正特征模式的坐标
static bool FuncCalcuRevisePattern(snake_code_pattern *patternA,
                                           snake_code_pattern *patternB,
                                           snake_code_pattern *patternC, snake_pointf *ret);

// 打印候选的特征圆中心
//static void FuncDebugPrintPatternCenters(int* stateCount, int centerI, int centerJ)
//{
//    if (NULL == stateCount)
//        return;
//    printf("The Pattern Center is (%d,%d) and the state is %d:%d:%d:%d:%d\n",
//           centerJ, centerI, stateCount[0],stateCount[1],stateCount[2],stateCount[3],stateCount[4]);
//}

/********************************************
函数功能: 横向扫描线上，查看连续三个像素的颜色，计算gs_imageData[posIdx]处像素的颜色
函数输入: 当前像素的位置索引
函数输出: 当前位置的颜色
*********************************************/
static int FuncPixelColorX(int posIdx)
{
    int pos = posIdx%IMG_WIDTH;
    if ((pos+1 < IMG_WIDTH) && (pos > 0 ))
    {
        // 当前像素与下一个像素或下下个像素同色，则返回当前像素的颜色，否则返回下一个像素的颜色
        if (gs_imageData[posIdx]==gs_imageData[posIdx+1]
                || gs_imageData[posIdx]==gs_imageData[posIdx-1])
            return gs_imageData[posIdx];
        else
            return ~gs_imageData[posIdx];
    }

    // 当前像素位于边界或者与边界相邻时，返回当前像素的颜色
    return gs_imageData[posIdx];
}

/********************************************
函数功能: 横向扫描线上，查看连续三个像素的颜色，计算gs_imageData[posIdx]处像素的颜色
函数输入: 当前像素的位置索引
函数输出: 当前位置的颜色
*********************************************/
static int FuncPixelColorY(int posIdx)
{
    int pos = posIdx/IMG_WIDTH;
    if (pos+1 < IMG_HEIGHT && pos > 0 )
    {
        // 当前像素与下一个像素或下下个像素同色，则返回当前像素的颜色，否则返回下一个像素的颜色
        if (gs_imageData[posIdx]==gs_imageData[posIdx+IMG_WIDTH]
               || gs_imageData[posIdx]==gs_imageData[posIdx-IMG_WIDTH])
            return gs_imageData[posIdx];
        else
            return ~gs_imageData[posIdx];
    }
    // 当前像素位于边界或者与边界相邻时，返回当前像素的颜色
    return gs_imageData[posIdx];
}

/********************************************
函数功能: 两个特征圆的中心比较大小
函数输入: averageModuleSize_ 表示所有候选特征圆的扫描线的单位宽度的像素数目
函数输出: 若特征圆'a'的横向和纵向扫描线，符合1:1:4:1:1的比例的数目多，则返回true
         当扫描线数目相等时，若特征圆'a'的平均单位黑色像素数接近averageModuleSize_，则返回true
*********************************************/
static bool FuncPatternCenterComparator(snake_code_pattern* a, snake_code_pattern* b, float averageModuleSize_)
{
    if (a->count != b->count)
    {
      return a->count > b->count;
    }
    else
    {
      float dA = fabs(a->estimatedModuleSize - averageModuleSize_);
      float dB = fabs(b->estimatedModuleSize - averageModuleSize_);
      return dA < dB;
    }
}

/********************************************
函数功能: 根据检测线色块的数目，计算特征模式的中心坐标
函数输入: stateCount是长度为5的整型数组，存放的是连续黑色或者白色像素的数目
函数输出: 返回扫描线中心的X/Y坐标
*********************************************/
static float FuncCenterFromEnd(int* stateCount, int end)
{
	return (float)(end - stateCount[4] - stateCount[3]) - stateCount[2] / 2.0f;
}

/********************************************
函数功能: 检验stateCount中的数目是否满足特征圆比例关系，容差为60%
函数输入: stateCount是长度为5的整型数组
函数输出: 满足比例关系返回true
*********************************************/
static bool FuncFoundPatternCross(int* stateCount)
{
    int i = 0;
	int totalModuleSize = 0;
    float moduleSize = 0.0f;
    float maxVariance = 0.0f;

    for (i = 0; i < 5; i++)
	{
		if (stateCount[i] == 0) 
		{
			return false;
		}
		totalModuleSize += stateCount[i];
	}
    if (totalModuleSize < NUM_BLOCKS_PER_PATTERN)
	{
		return false;
	}

    // 1:1:4:1:1 每个单位所占的像素数目
    moduleSize = (float)totalModuleSize / NUM_BLOCKS_PER_PATTERN;

    // 单位像素的最大容差
    maxVariance = moduleSize; /// default 0.6*moduleSize

    // Allow less than 60% variance from 1-1-4-1-1 proportions
	return fabs(moduleSize - stateCount[0]) < maxVariance
		&& fabs(moduleSize - stateCount[1]) < maxVariance
        && fabs((NUM_BLOCKS_PER_PATTERN)/2.0 * moduleSize - stateCount[2]) < (NUM_BLOCKS_PER_PATTERN)/2.0 * maxVariance
		&& fabs(moduleSize - stateCount[3]) < maxVariance
		&& fabs(moduleSize - stateCount[4]) < maxVariance;
}

/********************************************
函数功能: 检查垂直方向扫描线是否满足特征圆比例关系
函数输入:
函数输出: 若满足比例，则返回Y方向特征圆的坐标;否则，返回一个负值
*********************************************/
static float FuncCrossCheckVertical(int startI, int centerJ, int maxCount, int originalStateCountTotal)
{
	float NaN = -100.0;
    int i = 0;
    int pixIdx = 0;
	int maxI = IMG_HEIGHT;
    int stateCountTotal = 0;
	int stateCount[5];
    memset(stateCount,0,sizeof(stateCount));

  	// Start counting up from center
    i = startI;
    pixIdx = centerJ + i*IMG_WIDTH;
    while (i >= 0 && BLACK==FuncPixelColorY(pixIdx)) {
		stateCount[2]++;
		pixIdx -= IMG_WIDTH;
		i--;
	}
	if (i < 0) {
		return NaN;
	}
    while (i >= 0 && BLACK!=FuncPixelColorY(pixIdx) && stateCount[1] <= maxCount) {
		stateCount[1]++;
		pixIdx -= IMG_WIDTH;
		i--;
	}
  	// If already too many modules in this state or ran off the edge:
	if (i < 0 || stateCount[1] > maxCount) {
		return NaN;
	}
    while (i >= 0 && BLACK==FuncPixelColorY(pixIdx) && stateCount[0] <= maxCount) {
		stateCount[0]++;
		pixIdx -= IMG_WIDTH;
		i--;
	}
	if (stateCount[0] > maxCount) {
		return NaN;
	}

  	// Now also count down from center
	i = startI + 1;
	pixIdx = centerJ + i*IMG_WIDTH;
    while (i < maxI && BLACK==FuncPixelColorY(pixIdx)) {
		stateCount[2]++;
		pixIdx += IMG_WIDTH;
		i++;
	}
	if (i == maxI) {
		return NaN;
	}
    while (i < maxI && BLACK!=FuncPixelColorY(pixIdx) && stateCount[3] < maxCount) {
		stateCount[3]++;
		pixIdx += IMG_WIDTH;
		i++;
	}
	if (i == maxI || stateCount[3] >= maxCount) {
		return NaN;
	}
    while (i < maxI && BLACK==FuncPixelColorY(pixIdx) && stateCount[4] < maxCount) {
		stateCount[4]++;
		pixIdx += IMG_WIDTH;
		i++;
	}
	if (stateCount[4] >= maxCount) {
		return NaN;
	}

  	// If we found a finder-pattern-like section, but its size is more than 40% different than
  	// the original, assume it's a false positive
    stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2] + stateCount[3] + stateCount[4];
	if (5 * fabs(stateCountTotal - originalStateCountTotal) >= 2 * originalStateCountTotal) {
		return NaN;
	}

    // for test
    //printf("*****For test in line : %d\n",__LINE__);
    //FuncDebugPrintPatternCenters(stateCount, FuncCenterFromEnd(stateCount, i), centerJ);

    return FuncFoundPatternCross(stateCount) ? FuncCenterFromEnd(stateCount, i) : NaN;
}

/********************************************
函数功能: 检查水平方向扫描线是否满足特征圆比例关系
函数输入:
函数输出: 若满足比例，则返回X方向特征圆的坐标;否则，返回一个负值
*********************************************/
static float FuncCrossCheckHorizontal(int startJ, int centerI, int maxCount, int originalStateCountTotal)
{
	float NaN = -100.0;

	int maxJ = IMG_WIDTH;
    int stateCountTotal = 0;
	int stateCount[5];
    int j = 0;
    int pixIdx = 0;
    memset(stateCount,0,sizeof(stateCount));

    j = startJ;
    pixIdx = centerI*IMG_WIDTH + j;
    while (j >= 0 && BLACK==FuncPixelColorX(pixIdx)) {
		stateCount[2]++;
		pixIdx--;
		j--;
	}
	if (j < 0) {
		return NaN;
	}
    while (j >= 0 && BLACK!=FuncPixelColorX(pixIdx) && stateCount[1] <= maxCount) {
		stateCount[1]++;
		pixIdx--;
		j--;
	}
	if (j < 0 || stateCount[1] > maxCount) {
		return NaN;
	}
    while (j >= 0 && BLACK==FuncPixelColorX(pixIdx) && stateCount[0] <= maxCount) {
		stateCount[0]++;
		pixIdx--;
		j--;
	}
	if (stateCount[0] > maxCount) {
		return NaN;
	}

	j = startJ + 1;
    pixIdx = centerI*IMG_WIDTH + j;
    while (j < maxJ && BLACK==FuncPixelColorX(pixIdx)) {
		stateCount[2]++;
		pixIdx++;
		j++;
	}
	if (j == maxJ) {
		return NaN;
	}
    while (j < maxJ && BLACK!=FuncPixelColorX(pixIdx) && stateCount[3] < maxCount) {
		stateCount[3]++;
		pixIdx++;
		j++;
	}
	if (j == maxJ || stateCount[3] >= maxCount) {
		return NaN;
	}
    while (j < maxJ && BLACK==FuncPixelColorX(pixIdx) && stateCount[4] < maxCount) {
		stateCount[4]++;
		pixIdx++;
		j++;
	}
	if (stateCount[4] >= maxCount) {
		return NaN;
	}

  	// If we found a finder-pattern-like section, but its size is significantly different than
  	// the original, assume it's a false positive
    stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2] + stateCount[3] + stateCount[4];
	if (5 * fabs(stateCountTotal - originalStateCountTotal) >= originalStateCountTotal) {
		return NaN;
	}

    // for test
    //printf("*****For test in line : %d\n",__LINE__);
    //FuncDebugPrintPatternCenters(stateCount, centerI, FuncCenterFromEnd(stateCount, j));

    return FuncFoundPatternCross(stateCount) ? FuncCenterFromEnd(stateCount, j) : NaN;
}

/********************************************
函数功能: 根据stateCount以及此时的像素位置，判断特征圆的中心是否存在
函数输入: stateCount指针和当前像素的位置
函数输出: 若特征圆中心存在，则中心存在放'gs_patternFinder'的数组中并返回true；否则返回false
*********************************************/
static bool FuncHandlePossibleCenter(int* stateCount, int i, int j)
{
    int index = 0;
    int max = 0;
    bool found = false;
    snake_code_pattern *center = NULL;
    snake_code_pattern *newPattern = NULL;
    snake_code_pattern **possibleCenters_ = gs_patternFinder.possibleCenters;
	int stateCountTotal = stateCount[0] + stateCount[1] + stateCount[2] + stateCount[3] + stateCount[4];
    float estimatedModuleSize = 0.0f;
    float centerI = 0.0f, centerJ = 0.0f;

    // 计算水平方向的特征圆中心 centerJ
    centerJ = FuncCenterFromEnd(stateCount, j);
/*
    if (!isInside(i,centerJ))
    {
        if (g_uPatternRegionSize<MAX_RING_NUM)
        {
            gs_patternRegion[g_uPatternRegionSize].startI = i-stateCount[2];
            gs_patternRegion[g_uPatternRegionSize].endI = i+stateCount[2];
            gs_patternRegion[g_uPatternRegionSize].startJ = centerJ-stateCount[2];
            gs_patternRegion[g_uPatternRegionSize].endJ= centerJ+stateCount[2];
            g_uPatternRegionSize++;
            regionDilationErosionOr(gs_imageData, IMG_WIDTH, IMG_HEIGHT,
                                        (int)i-stateCount[2], (int)i+stateCount[2],
                                        (int)centerJ-stateCount[2], (int)centerJ+stateCount[2]);
        }
        else
        {
            printf("The number of pattern regions, which is less than %d, is out of range!\n",g_uPatternRegionSize);
        }
    }
*/
    // 计算垂直方向的特征圆中心 centerI
    centerI = FuncCrossCheckVertical(i, (int)centerJ, stateCount[2], stateCountTotal);

	if (centerI>0 && centerI<IMG_HEIGHT)
	{
        // 进行膨胀腐蚀操作
/*        regionDilationErosionOr(gs_imageData, IMG_WIDTH, IMG_HEIGHT,
                                (int)centerI-(stateCount[2]<<1), (int)centerI+(stateCount[2]<<1),
                                (int)centerJ-(stateCount[2]<<1), (int)centerJ+(stateCount[2]<<1));
*/
    	// Re-cross check
        centerJ = FuncCrossCheckHorizontal((int)centerJ, (int)centerI, stateCount[2], stateCountTotal);
        if (centerJ>0 && centerJ<IMG_WIDTH)
		{
            // 特征圆扫描线的单位像素数目
            estimatedModuleSize = (float)stateCountTotal / (float)NUM_BLOCKS_PER_PATTERN;
            found = false;
            max = gs_patternFinder.nCenter;
            for (index = 0; index < max && max < MAX_PATTERN; index++)
			{
                center = possibleCenters_[index];
                // Look for about the same center and module size:
                if (FuncIsPatternEquals(center, estimatedModuleSize, centerI, centerJ))
                {
                    // 将现有的特征圆与新找到的圆心合并
                    FuncPatternCombineEstimate(possibleCenters_[index], centerI, centerJ, estimatedModuleSize);
                    found = true;
                    break;
                }
			}
			if (!found)
            {   // 若新找到的圆心与已有的特征圆相差较大，则认为找到一个新的特征圆
                if (gs_patternFinder.nCenter<MAX_RING_NUM)
                {
                    newPattern = FuncPatternAlloc();
                    newPattern->posX = centerJ;
                    newPattern->posY = centerI;
                    newPattern->estimatedModuleSize = estimatedModuleSize;
                    possibleCenters_[index] = newPattern;
                    gs_patternFinder.nCenter++;
                }
                else
                {
                    // printf("The number of patterns, which shoud be less than %d, is out of range!\n",MAX_RING_NUM);
                    return false;
                }
			}
			return true;
		}
	}
	return false;
}

/********************************************
函数功能: 删掉一些假的特征圆并选择某种准则下最好的特征圆
函数输入:
函数输出:
*********************************************/
static bool FuncSelectBestPatterns()
{
    int i = 0, j = 0, k = 0;
    int idxA = 0, idxB = 0, idxC = 0;
    int startSize = gs_patternFinder.nCenter;
    float line12 = 0.0f;
    float line13 = 0.0f;
    float line23 = 0.0f;
    float fBAlen = 0.0f;  // Length of BA
    float fBClen = 0.0f;  // Length of BC
    float fAClen = 0.0f;  // Length of AC

    snake_pointf revisePoint = {0.0f, 0.0f};
    float fLenPix = 0.0f;
    float fLenLin = 0.0f;

    float totalModuleSize = 0.0f;
    float square = 0.0f;
    float size = 0.0f;
    float average = 0.0f;
    float stdDev = 0.0f;
    float limit = 0.0f;

    float vABBC = 0.0f;
    float dCpy = 0.0f;
    float vPyC = 0.0f;
    float avgLegEdgeLength = 0.0f;
    float len = 0.0f;
    bool isExist = false;

    snake_code_pattern *tmp = NULL;
    int headIdx = 0, tailIdx = 0;

    snake_pointf r1 = {0.0f,0.0f};
    snake_pointf r2 = {0.0f,0.0f};
    snake_pointf r3 = {0.0f,0.0f};

    snake_code_pattern **possibleCenters_ = gs_patternFinder.possibleCenters;
    if (startSize < STANDARD_RING_NUM) {
    	// Couldn't find enough finder patterns
		// printf("Could not find three finder patterns\n");
		return false;
	}

    for (i = startSize-1; i >= 0 && gs_patternFinder.nCenter > STANDARD_RING_NUM; i--)
    {
        if (possibleCenters_[i]->count < 2)
        {
            free(possibleCenters_[i]);
            possibleCenters_[i] = NULL;
            gs_patternFinder.nCenter--;
        }
    }

    headIdx = 0;
    tailIdx = MAX_PATTERN-1;
    while(1)
    {
        if (NULL!=gs_patternFinder.possibleCenters[headIdx])
            headIdx++;
        if (NULL==gs_patternFinder.possibleCenters[tailIdx])
            tailIdx--;
        if (headIdx>=tailIdx)
            break;
        if (gs_patternFinder.possibleCenters[headIdx]==NULL
            && gs_patternFinder.possibleCenters[tailIdx]!=NULL)
        {
            gs_patternFinder.possibleCenters[headIdx] = gs_patternFinder.possibleCenters[tailIdx];
            gs_patternFinder.possibleCenters[tailIdx] = NULL;
        }
    }

    startSize = gs_patternFinder.nCenter;
  	// Filter outlier possibilities whose module size is too different
    if (startSize > STANDARD_RING_NUM) {
    	// But we can only afford to do so if we have at least 4 possibilities to choose from
        totalModuleSize = 0.0f;
        square = 0.0f;
        for (i = 0; i < startSize; i++) {
            size = possibleCenters_[i]->estimatedModuleSize;
			totalModuleSize += size;
			square += size * size;
		}
        average = totalModuleSize / (float) startSize;
        stdDev = (float)sqrtf(square / startSize - average * average);

		for (i = 0; i<startSize-1; i++)
		{
            for (j = i+1; j<startSize; j++)
            {
                if (FuncPatternCenterComparator(possibleCenters_[i], possibleCenters_[j], average))
                    continue;
                tmp = possibleCenters_[i];
                possibleCenters_[i] = possibleCenters_[j];
                possibleCenters_[j] = tmp;
            }
		}

        limit = MAX(0.2f * average, stdDev);

        for (i = startSize-1; i >= 0 && gs_patternFinder.nCenter > STANDARD_RING_NUM; i--)
        {
            if (fabs(possibleCenters_[i]->estimatedModuleSize - average) > limit)
			{
				free(possibleCenters_[i]);
				possibleCenters_[i] = NULL;
                gs_patternFinder.nCenter--;
            }
		}


        headIdx = 0;
        tailIdx = MAX_PATTERN-1;
        while(1)
        {
            if (NULL!=gs_patternFinder.possibleCenters[headIdx])
                headIdx++;
            if (NULL==gs_patternFinder.possibleCenters[tailIdx])
                tailIdx--;
            if (headIdx>=tailIdx)
                break;
            if (gs_patternFinder.possibleCenters[headIdx]==NULL
                && gs_patternFinder.possibleCenters[tailIdx]!=NULL)
            {
                gs_patternFinder.possibleCenters[headIdx] = gs_patternFinder.possibleCenters[tailIdx];
                gs_patternFinder.possibleCenters[tailIdx] = NULL;
            }
        }

	}

    if (gs_patternFinder.nCenter < STANDARD_RING_NUM)
    {
        // Couldn't find enough finder patterns
        // printf("Could not find three finder patterns\n");
        return false;
    }

    // 如果模式特征数目大于3，将特征模式降序排列，最有可能是真的特征模式的越靠前
    if (gs_patternFinder.nCenter > STANDARD_RING_NUM) {
        // Throw away all but those first size candidate points we found.
        totalModuleSize = 0.0f;
        for (i = 0; i < gs_patternFinder.nCenter; i++) {
            size = possibleCenters_[i]->estimatedModuleSize;
            totalModuleSize += size;
        }
        average = totalModuleSize / (float) gs_patternFinder.nCenter;

        for (i = 0; i<gs_patternFinder.nCenter-1; i++)
        {
            for (j = i+1; j<gs_patternFinder.nCenter; j++)
            {
                if (FuncPatternCenterComparator(possibleCenters_[i], possibleCenters_[j], average))
                    continue;
                tmp = possibleCenters_[i];
                possibleCenters_[i] = possibleCenters_[j];
                possibleCenters_[j] = tmp;
            }
        }
    }

    for (i = 0; i<gs_patternFinder.nCenter; i++)
    {
        detectedRings[i].pos.Pix = gs_patternFinder.possibleCenters[i]->posX;
        detectedRings[i].pos.Lin = gs_patternFinder.possibleCenters[i]->posY;
        detectedRings[i].DetectCount = gs_patternFinder.possibleCenters[i]->count;
    }

    // 根据特征圆圆心之间距离的几何关系删除假圆
    g_npatternIdxArrayNum = 0;
    memset(g_iPatternIdxArray,0xffffffff,MAX_RING_NUM*sizeof(int));
    for (i=0; i<gs_patternFinder.nCenter-2; i++)
    {
        r1.Pix = possibleCenters_[i]->posX;
        r1.Lin = possibleCenters_[i]->posY;
        for (j=i+1; j<gs_patternFinder.nCenter-1; j++)
        {
            r2.Pix = possibleCenters_[j]->posX;
            r2.Lin = possibleCenters_[j]->posY;
            for (k=j+1; k<gs_patternFinder.nCenter; k++)
            {
                r3.Pix = possibleCenters_[k]->posX;
                r3.Lin = possibleCenters_[k]->posY;

                line12 = sqrtf((r1.Pix - r2.Pix)*(r1.Pix - r2.Pix)
                          + (r1.Lin - r2.Lin)*(r1.Lin - r2.Lin));

                line13 = sqrtf((r1.Pix - r3.Pix)*(r1.Pix - r3.Pix)
                          + (r1.Lin - r3.Lin)*(r1.Lin - r3.Lin));

                line23 = sqrtf((r2.Pix - r3.Pix)*(r2.Pix - r3.Pix)
                          + (r2.Lin - r3.Lin)*(r2.Lin - r3.Lin));

                // BA 和 BC 这里姑且随意指定
                if (line12<line23 && line13<line23)
                {
                    fAClen = line23;
                    fBAlen = line12;
                    fBClen = line13;
                    idxB = i;
                    idxA = j;
                    idxC = k;
                }
                else if (line12<line13 && line23<line13)
                {
                    fAClen = line13;
                    fBAlen = line12;
                    fBClen = line23;
                    idxB = j;
                    idxA = i;
                    idxC = k;
                }
                else
                {
                    fAClen = line12;
                    fBAlen = line23;
                    fBClen = line13;
                    idxB = k;
                    idxA = i;
                    idxC = j;
                }

                /* 这里仍需确定BA或BC占用单位宽度的区间，即宽度的上下界"MAX_MODULE_COUNT"和"MIN_MODULE_COUNT"
                // 计算BA和BC平均长度是多少个单位宽度
                float estimatedModuleCount = (fBAlen + fBClen) / (orgDetectedRings[i].estimatedModuleSize * 2.0f);
                if (estimatedModuleCount > MAX_MODULE_COUNT
                        || estimatedModuleCount < MIN_MODULE_COUNT)
                {
                    continue;
                }
                */

                // 判断两条直角边长度是否相等
                vABBC = fabs((fBAlen - fBClen) / MIN(fBAlen, fBClen));
                if (vABBC >= 0.1f)
                    continue;

                // 判断三条边是否满足勾股定理
                dCpy = (float) sqrtf(fBAlen * fBAlen + fBClen * fBClen);
                // Compare to the real distance in %
                vPyC = fabs((fAClen - dCpy) / MAX(fAClen, dCpy));
                if (vPyC >= 0.1f)
                    continue;

                if (g_npatternIdxArrayNum >= MAX_RING_NUM-3)
                    continue;

                // 将符合条件的三个圆心对应的索引依次保存到数组中
                g_iPatternIdxArray[g_npatternIdxArrayNum++] = idxA;
                g_iPatternIdxArray[g_npatternIdxArrayNum++] = idxB;
                g_iPatternIdxArray[g_npatternIdxArrayNum++] = idxC;
            }
        }
    }

    /******************下面删除错误的A/B/C三元组**********************/

    // 满足等腰直角三角形条件的三个圆环依次为A/B/C，计算圆环D的圆心
    // 若得到的圆心正好是黑白同心圆环，则A/B/C圆环组成的三元组删除
    for (i=0; i<g_npatternIdxArrayNum-2; i+=3)
    {
        // D的圆心坐标
        isExist = FuncCalcuRevisePattern(possibleCenters_[g_iPatternIdxArray[i]],
                                             possibleCenters_[g_iPatternIdxArray[i+1]],
                                             possibleCenters_[g_iPatternIdxArray[i+2]], &revisePoint);
        if (isExist)
        {
            // 遍历其余特征圆，比较特征圆圆心之间的距离
            for (j=0; j<g_npatternIdxArrayNum; j++)
            {
                if (j>=i && j<i+3)
                    continue;

                // 计算圆心 Pix 和 Lin 方向的距离
                fLenPix = fabs(possibleCenters_[g_iPatternIdxArray[j]]->posX - revisePoint.Pix);
                fLenLin = fabs(possibleCenters_[g_iPatternIdxArray[j]]->posY - revisePoint.Lin);

                // 当圆心距离很接近时，则删除三元组
                if ( fLenPix < 4*possibleCenters_[g_iPatternIdxArray[j]]->estimatedModuleSize
                     && fLenLin < 4*possibleCenters_[g_iPatternIdxArray[j]]->estimatedModuleSize )
                {
                    g_iPatternIdxArray[i] = g_iPatternIdxArray[g_npatternIdxArrayNum-3];
                    g_iPatternIdxArray[i+1] = g_iPatternIdxArray[g_npatternIdxArrayNum-2];
                    g_iPatternIdxArray[i+2] = g_iPatternIdxArray[g_npatternIdxArrayNum-1];
                    g_iPatternIdxArray[g_npatternIdxArrayNum-3] = -1;
                    g_iPatternIdxArray[g_npatternIdxArrayNum-2] = -1;
                    g_iPatternIdxArray[g_npatternIdxArrayNum-1] = -1;
                    g_npatternIdxArrayNum -= 3;
                    i -= 3;
                    break;
                }
            }
        }
        else
        {
            g_iPatternIdxArray[i] = g_iPatternIdxArray[g_npatternIdxArrayNum-3];
            g_iPatternIdxArray[i+1] = g_iPatternIdxArray[g_npatternIdxArrayNum-2];
            g_iPatternIdxArray[i+2] = g_iPatternIdxArray[g_npatternIdxArrayNum-1];
            g_iPatternIdxArray[g_npatternIdxArrayNum-3] = -1;
            g_iPatternIdxArray[g_npatternIdxArrayNum-2] = -1;
            g_iPatternIdxArray[g_npatternIdxArrayNum-1] = -1;
            g_npatternIdxArrayNum -= 3;
            i -= 3;
        }
    }

    // 根据直角边边长的均值与方差删除假的A/B/C三元组
    avgLegEdgeLength = 0.0f; // 计算所有直角边的均值
    square = 0.0f;
    for (i=0; i<g_npatternIdxArrayNum-2; i+=3)
    {
        r1.Pix = possibleCenters_[g_iPatternIdxArray[i]]->posX;
        r1.Lin = possibleCenters_[g_iPatternIdxArray[i]]->posY;
        r2.Pix = possibleCenters_[g_iPatternIdxArray[i+1]]->posX;
        r2.Lin = possibleCenters_[g_iPatternIdxArray[i+1]]->posY;
        len = sqrtf((r1.Pix - r2.Pix)*(r1.Pix - r2.Pix)
                            + (r1.Lin - r2.Lin)*(r1.Lin - r2.Lin));
        avgLegEdgeLength += len;
        square += len*len;
    }

    // 直角边的均值
    avgLegEdgeLength /= g_npatternIdxArrayNum/3;

    // 直角边的标准差
    stdDev = (float)sqrtf(square / (g_npatternIdxArrayNum/3) - avgLegEdgeLength * avgLegEdgeLength);

    // 阈值
    limit = MAX(0.2f * avgLegEdgeLength, stdDev);

    for (i=0; i<g_npatternIdxArrayNum-2; i+=3)
    {
        r1.Pix = possibleCenters_[g_iPatternIdxArray[i]]->posX;
        r1.Lin = possibleCenters_[g_iPatternIdxArray[i]]->posY;
        r2.Pix = possibleCenters_[g_iPatternIdxArray[i+1]]->posX;
        r2.Lin = possibleCenters_[g_iPatternIdxArray[i+1]]->posY;
        len = sqrtf((r1.Pix - r2.Pix)*(r1.Pix - r2.Pix)
                            + (r1.Lin - r2.Lin)*(r1.Lin - r2.Lin));

        // 当标准差大于一定值时，说明存在较大的等腰直角三角形
        // 因为A/B/C组成的直角边边长最小，所以这里只用判断大于均值的直角边
        if (len-avgLegEdgeLength>limit)
        {
            g_iPatternIdxArray[i] = g_iPatternIdxArray[g_npatternIdxArrayNum-3];
            g_iPatternIdxArray[i+1] = g_iPatternIdxArray[g_npatternIdxArrayNum-2];
            g_iPatternIdxArray[i+2] = g_iPatternIdxArray[g_npatternIdxArrayNum-1];
            g_iPatternIdxArray[g_npatternIdxArrayNum-3] = -1;
            g_iPatternIdxArray[g_npatternIdxArrayNum-2] = -1;
            g_iPatternIdxArray[g_npatternIdxArrayNum-1] = -1;
            g_npatternIdxArrayNum -= 3;
            i -= 3;
        }
    }

    // 如果没有找到符合几何关系的三个点，则返回错误
    if (g_npatternIdxArrayNum < STANDARD_RING_NUM)
        return false;

    return true;
}

/********************************************
函数功能: 对区域进行先膨胀后腐蚀操作，以消除部分噪点，增加识别的稳定性
函数输入: 图像指针data，图像的宽、高，区域的横向与纵向的起始和终止位置
函数输出:
*********************************************/
static void regionDilationErosionOr(uint8_t* data, int width, int height,
                                    int startI, int endI, int startJ, int endJ)
{
    int i, j, sum, flag, m, n;

    startI = MAX(0, startI);
    endI = MIN(endI, height-1);
    startJ = MAX(0, startJ);
    endJ = MIN(endJ, width-1);

    sum = height * width * sizeof(uint8_t);
    uint8_t *tmpdata = (uint8_t*)malloc(sum);
    memcpy((char*)tmpdata, (char*)data, sum);

    // 图像膨胀操作
    for(i = startI+1;i < endI;i++)
    {
        for(j = startJ+1;j < endJ;j++)
        {
            flag = 1;
            for(m = i - 1;m < i + 2;m++)
            {
                for(n = j - 1; n < j + 2;n++)
                {
                    //自身及领域中若有一个为255
                    //则将该点设为255
                    if(tmpdata[i * width + j] == 255
                        || tmpdata[m * width + n] == 255)
                    {
                        flag = 0;
                        break;
                    }
                }
                if(flag == 0)
                    break;
            }

            if(flag == 0)
                data[i * width + j] = 255;
            else
                data[i * width + j] = 0;
        }
    }

    memcpy((char*)tmpdata, (char*)data, sum);

    // 图像腐蚀操作
    for(i = startI+1;i < endI;i++)
    {
        for(j = startJ+1;j < endJ;j++)
        {
            flag = 1;
            for(m = i - 1;m < i + 2;m++)
            {
                for(n = j - 1; n < j + 2;n++)
                {
                    //自身及领域中若有一个为255
                    //则将该点设为255
                    if(tmpdata[i * width + j] == 0
                        || tmpdata[m * width + n] == 0)
                    {
                        flag = 0;
                        break;
                    }
                }
                if(flag == 0)
                    break;
            }
            if(flag == 0)
                data[i * width + j] = 0;
            else
                data[i * width + j] = 255;
        }
    }

    free(tmpdata);
}

static bool isInside(float centerI, float centerJ)
{
    int regionIdx = 0;
    if (g_uPatternRegionSize<1)
        return false;

    for (regionIdx = 0; regionIdx < g_uPatternRegionSize; regionIdx++)
    {
        if (centerI > gs_patternRegion[regionIdx].startI
         && centerI < gs_patternRegion[regionIdx].endI
         && centerJ > gs_patternRegion[regionIdx].startJ
         && centerJ < gs_patternRegion[regionIdx].endJ)
        {
            return true;
        }
    }
    return false;
}

bool FuncCalcuRevisePattern(snake_code_pattern *patternA,
                                           snake_code_pattern *patternB,
                                           snake_code_pattern *patternC, snake_pointf *ret)
{
    snake_pointf Center = {0.0f, 0.0f};

    if (NULL==patternA || NULL==patternB || NULL==patternC)
        return false;

    // 计算线段AC的中点 Center
    Center.Pix = (patternA->posX + patternC->posX)/2.0;
    Center.Lin = (patternA->posY + patternC->posY)/2.0;

    // 计算校正特征模式的中心：Center + (Center - B)
    ret->Pix = 2.0*Center.Pix - patternB->posX;
    ret->Lin = 2.0*Center.Lin - patternB->posY;

    if (ret->Pix < 0 || ret->Lin < 0 || ret->Pix >= IMG_WIDTH || ret->Lin >= IMG_HEIGHT)
        return false;

    return true;
}

/********************************************
函数功能: 图像滤波，使用当前像素及其上下左右五个元素均值滤波
函数输入: 图像指针以及图像的宽和高
函数输出:
*********************************************/
void FuncImageFilter(uint8_t *img, int width, int height)
{
    int idx = 0;
    int sum = 0;
    int row, col;
    int color = 0;
    uint8_t *tmpdata = NULL;

    if (NULL == img)
    {
        // printf("Function %s : The image pointer is null!\n",__func__);
        return;
    }

    sum = width*height*sizeof(uint8_t);
    tmpdata = (uint8_t*)malloc(sum);

    memcpy(tmpdata,img,sum);

    for (row = 1; row < height-1; row++)
    {
        idx = row*width;
        for (col = 1; col < width-1; col++)
        {
            idx += 1;
            color = tmpdata[idx] + tmpdata[idx-1] + tmpdata[idx+1]
                    + tmpdata[idx-width] + tmpdata[idx-width-1] + tmpdata[idx-width+1]
                    + tmpdata[idx+width] + tmpdata[idx+width-1] + tmpdata[idx+width+1];
            color /= 9.0f;
            img[idx] = color;
        }
    }
    free(tmpdata);
}

/********************************************
函数功能: 检测特征圆入口函数
函数输入: 存放无符号8bits整型图像的指针
函数输出:
*********************************************/
bool FuncFindPatternCenters(uint8_t *image_)
{
    int i = 0, j = 0;
    int maxI = IMG_HEIGHT;
    int maxJ = IMG_WIDTH;
    int currentState = 0;
    int linePixIdx = 0;
    int patternNum = 0;
    int patternIdxArray[MAX_RING_NUM];

	// We are looking for black/white/black/white/black modules in
    // 1:1:4:1:1 ratio; this tracks the number of such modules seen so far
  	// As this is used often, we use an integer array instead of vector
	int stateCount[5];
    bool bRet = false;
	bool done = false;
    snake_code_pattern *pattern = NULL;


  	// Let's assume that the maximum version QR Code we support takes up 1/4
  	// the height of the image, and then account for the center being 3
  	// modules in size. This gives the smallest number of pixels the center
  	// could be, so skip this often. When trying harder, look for all
  	// QR versions regardless of how dense they are.
    int iSkip = (3 * maxI) / (4 * MAX_MODULES);
	if (iSkip < MIN_SKIP) {
		iSkip = MIN_SKIP;
	}

    if (NULL == image_)
    {
        // printf("the image pointer is null!\n");
        return bRet;
    }
  	// This is slightly faster than using the Ref. Efficiency is important here
    gs_imageData = image_;

    memset(patternIdxArray,0xffffffff,sizeof(patternIdxArray));
    memset(gs_patternFinder.possibleCenters,0,MAX_PATTERN*sizeof(snake_code_pattern*));
    gs_patternFinder.nCenter = 0;
    gs_patternFinder.hasSkipped = false;
    memset(gs_patternRegion,0,MAX_RING_NUM*sizeof(snake_pattern_region));
    g_uPatternRegionSize = 0;

    // 针对单幅图像来说，对二值图像进行滤波，识别效果比先滤波后二值化好，也比膨胀腐蚀好
    // 但如果边采集边识别，此方法不太稳定
    //FuncImageFilter(gs_imageData, IMG_WIDTH, IMG_HEIGHT);

    // 针对单幅图像来说，对整幅图像进行膨胀腐蚀操作，其识别效果没有二值滤波好，而且速度也比二值滤波慢一些
    // 但如果边采集边识别，效果较为稳定
    //regionDilationErosionOr(gs_imageData, IMG_WIDTH, IMG_HEIGHT,0,IMG_HEIGHT-1,0,IMG_WIDTH-1);

    for (i = iSkip - 1; i < maxI && !done; i += iSkip)
	{
    	// Get a row of black/white values

		stateCount[0] = 0;
		stateCount[1] = 0;
		stateCount[2] = 0;
		stateCount[3] = 0;
		stateCount[4] = 0;
        currentState = 0;
        linePixIdx = i*IMG_WIDTH;
        for (j = 0; j < maxJ; j++)
		{
            if (BLACK==FuncPixelColorX(linePixIdx+j))
			{
        		// Black pixel
             /* if ((currentState & 1) == 1)
                { // Counting white pixels
                    currentState++;
                }
              */
                // Counting white pixels
                currentState += currentState & 1;
        		stateCount[currentState]++;
      		} 
	      	else
	      	{ // White pixel
	        	if ((currentState & 1) == 0)
	        	{ // Counting black pixels
	          		if (currentState == 4) 
	          		{ // A winner?
                        if (FuncFoundPatternCross(stateCount) && FuncHandlePossibleCenter(stateCount, i, j))
                        { // Yes
			              	// Clear state to start looking again
			            	currentState = 0;
			            	stateCount[0] = 0;
			            	stateCount[1] = 0;
			            	stateCount[2] = 0;
			            	stateCount[3] = 0;
			            	stateCount[4] = 0;
		            	}
		            	else
		            	{ // No, shift counts back by two
			            	stateCount[0] = stateCount[2];
			            	stateCount[1] = stateCount[3];
			            	stateCount[2] = stateCount[4];
			            	stateCount[3] = 1;
			            	stateCount[4] = 0;
			            	currentState = 3;
		            	}
		        	}
		        	else
		        	{
		        		stateCount[++currentState]++;
		        	}
		        }
	        	else
	        	{ // Counting white pixels
	        		stateCount[currentState]++;
	        	}
	    	}
		}
        if (FuncFoundPatternCross(stateCount))
		{
            FuncHandlePossibleCenter(stateCount, i, maxJ);
		}
	}

    if (FuncSelectBestPatterns())
    {
        detectedRingsNum = g_npatternIdxArrayNum;
        bRet = true;
    }
    else
    {
        detectedRingsNum = gs_patternFinder.nCenter;
    }

    for (i = 0; i<MAX_PATTERN; i++)
        free(gs_patternFinder.possibleCenters[i]);
    memset(gs_patternFinder.possibleCenters, 0, MAX_PATTERN*sizeof(pattern));
    memset(&gs_patternFinder, 0, sizeof(gs_patternFinder));

    return bRet;
}
