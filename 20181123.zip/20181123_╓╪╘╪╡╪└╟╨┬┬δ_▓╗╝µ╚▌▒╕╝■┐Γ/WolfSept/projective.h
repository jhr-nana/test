#ifndef PROJECTIVE_H
#define PROJECTIVE_H
#include "globaldefine.h"

snake_rect FuncBinImageProjection(const uint8_t *binImage, int width, int height);

#endif // PROJECTIVE_H
