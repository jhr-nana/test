#ifndef _BMS_H__
#define _BMS_H__

#include <stdio.h>
#include <stdint.h>
#include <malloc.h>
#include <pthread.h>

#include "can.h"
#include "global_var.h"

#define TRY_COUNT_LIMIT 10000
#define INQUIRE_PERIOD_SECONDS		1 //by tiger.89//change from 2s to 1s add by jxu 20180917
//add by jxu 20180925-begin
#define BMS_VID_ANSHANG            "Anshang"
#define BMS_VID_PANSONIC           "Pansonic" 
//add by jxu 20180925-end

extern int get_bms_info(struct can_frame *pBatCanData);
extern int parse_bms_info(struct can_frame* pBatCanData);
extern int inquiry_bms_info();
extern int anshang_inquiry_bms_errinfo();//add by jxu 20180917
extern int anshang_parse_bms_error_info(struct can_frame *pBatCanData);//add by jxu 20180917
extern int check_bms_monitor(FILE *fp);//add by jxu 20180719
extern int songxia_battery_init_check();//add by jxu 20180820
extern int songxia_battery_vid_pid();//add by jxu 20180910
extern int songxia_battery_lasterfive_poweroff();//add by jxu 20180917
#endif
